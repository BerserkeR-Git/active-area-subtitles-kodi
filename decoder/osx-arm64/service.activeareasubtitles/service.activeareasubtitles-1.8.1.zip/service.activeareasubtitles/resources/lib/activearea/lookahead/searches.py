"""The read-ahead's pending searches (Searches, each a Job): which runs next, which waits, which is dropped, by the
lead they leave (LEAD, as far as the sweep reads; the floors)."""

import collections

LEAD = 60.0           # seconds ahead of playback read
SEARCH_FLOOR = 8.0    # seconds of lead a pending search must leave at its estimated cost, else the sweep reads first
                      # (in the film simulator's dense cuts at a laptop's 4K costs 6 to 20 s kept every move into scope
                      # on time; at 4 a search estimated too cheap ate the lead)
SHOTS_FLOOR = 20.0    # the same for a search for shots the keyframes did not show (the keyframes between two read ones,
                      # a carried dark run's frames): each pair asked for costs a seek back even where nothing lies
                      # between (1.2 to 1.9 s a step on a laptop's network share); run from SEARCH_FLOOR on, after
                      # nearly every keyframe, they kept the film simulator's dense cuts 10 s ahead, and no cut's frames
                      # could be searched in time
LATE = 1.0            # seconds before its span a search must end: what it finds is planned before playback gets there
                      # (EXACT_AHEAD, the screen's lead up to capture.SHOWN_AHEAD_MOST, a look); else it is dropped
COARSE_MOST = 2.1     # seconds of keyframe gap a coarse cut may rise early by before its search goes ahead of nearer
                      # ones: the person accepted the text rising about one keyframe gap of their film early (2 s;
                      # "about 1 to 2 s"), with a few frames for a gap of 2.002 s at 23.976 frames a second; some
                      # encodes have keyframes 5 to 10 s apart


class Job(collections.namedtuple('Job', 'kind before after dark tries')):
    """A pending search: kind 'cut' (the frames between two keyframes of different pictures, across a dark run or
    not), 'walk' (the keyframes inside a dark run whose cut was found up to its first keyframe), 'shots' (the keyframes
    between two read ones of the same picture) or 'inside' (a carried dark run's frames, for shots of a narrower
    picture); before and after, the keyframes it lies between ((film time, picture) each); dark, the DarkRun between
    them or None; tries, the times it was stopped short."""

    __slots__ = ()

    @property
    def coarse(self):
        """Whether a coarse cut waits on it: into a wider picture, no dark run between."""
        return self.kind == 'cut' and self.dark is None and float(self.after[1]) > float(self.before[1])

    @property
    def gap(self):
        """Seconds between its two keyframes."""
        return self.after[0] - self.before[0]

    @property
    def long(self):
        """A coarse cut whose keyframe gap passes COARSE_MOST: the text would rise more than the person accepted."""
        return self.coarse and self.gap > COARSE_MOST

    @property
    def worth(self):
        """What the text gains by it: 3 a long coarse cut; 2 a coarse cut (up to a keyframe gap early) or a cut across a
        dark run (the grabs read a dark scene dimly or not at all); 1 a silent span into a narrower picture with nothing
        dark between (the grabs move the text down a look after the cut, high meanwhile); 0 shots the keyframes did not
        show. A shot of a wider picture there leaves the text in its bar until a lit grab sees it, but where the lead
        is short a search for it is too late whatever its worth (in the film simulator's dense cuts with short scope
        shots, worth 2 or SHOTS_FLOOR down to 8 placed none more and cost other rows), and each costs a seek back."""
        if self.kind in ('shots', 'inside'):
            return 0
        if self.long:
            return 3
        return 1 if self.kind == 'cut' and self.dark is None and not self.coarse else 2

    def needs(self, cost):
        """The lead it needs to run, at its estimated cost: SEARCH_FLOOR left after it; for a silent span with nothing
        dark between, that after it and one more search like it (the next cut into a wider picture may need the lead:
        in dense cuts on a laptop's 4K decoding these took the searches of the coarse cuts, 3 s more of text high per
        pass); SHOTS_FLOOR after it for shots."""
        if self.worth == 0:
            return SHOTS_FLOOR + cost
        return SEARCH_FLOOR + cost * (2 if self.worth == 1 else 1)

    @property
    def deadline(self):
        """The film time by which playback may come before it is too late to run: LATE before the keyframe before for a
        coarse cut (refined after playback passed that keyframe, the text would go back down for a moment before the
        cut), else LATE before the keyframe after (a silent span closed, a stretch filled in, helps until playback
        leaves it)."""
        return (self.before[0] if self.coarse else self.after[0]) - LATE

    @property
    def reopens(self):
        """Whether it reads keyframes and was stopped short before: the open decoder names one its first try decoded as
        none (the end of the run, or of the keyframes between), so a fresh one reads them."""
        return self.kind in ('walk', 'shots') and self.tries > 0

    def again(self):
        return self._replace(tries=self.tries + 1)


class Searches:
    """The read-ahead's pending searches (Job), one at a time, each in time for what it tells (by its deadline; one that
    can not be any more is dropped). One principle orders them: the lead and the time go first to the coarse cuts, where
    the person sees the text rise early, and to those of a long keyframe gap before all (they rise past what the person
    accepted); what the grabs already do well enough waits for lead to spare. So a long coarse cut runs first; once the
    film has shown one, every other search runs only where it leaves the lead another would need when the sweep finds
    it (its cost, its gap and LATE before its keyframe before, and SEARCH_FLOOR left: found with less it is too late at
    birth); the search playback reaches first goes next, unless that leaves one worth more (Job.worth) too little time;
    a silent span waits for the lead of one more search after it, and shots the keyframes did not show for SHOTS_FLOOR
    (Job.needs). On a laptop's 4K decoding about one cut in three can be searched in dense cuts. It reads nothing: the
    read-ahead runs what next() gives."""

    def __init__(self, dropped=lambda job: None):
        """dropped(job): told of each search dropped (playback came too near)."""
        self._jobs = []
        self._dropped = dropped
        self._longest = None            # the long coarse cut of the widest keyframe gap the film has shown

    def __len__(self):
        return len(self._jobs)

    def add(self, job):
        """A search to run, unless the same one is pending already."""
        if any(other.kind == job.kind and other.before[0] == job.before[0] and other.after[0] == job.after[0]
               for other in self._jobs):
            return
        self._jobs.append(job)
        if job.long and (self._longest is None or job.gap > self._longest.gap):
            self._longest = job

    def clear(self):
        """A seek: nothing pending is worth reading any more (the film's keyframes are as far apart after it)."""
        self._jobs = []

    def next(self, now, lead, cost):
        """The search to run now, taken off the list, or None: now, playback's film time; lead, seconds from it to the
        next keyframe the sweep reads; cost(job), the seconds of playback a search is estimated to take."""
        costs = {id(job): cost(job) for job in self._jobs}
        for job in [job for job in self._jobs if now + costs[id(job)] > job.deadline]:
            self._jobs.remove(job)
            self._dropped(job)
        kept = self._kept(cost)
        for job in sorted(self._jobs, key=lambda job: (not job.long, job.deadline)):
            seconds = costs[id(job)]
            if lead < job.needs(seconds) or (not job.long and lead < kept + seconds):
                continue
            if any(other.worth > job.worth and other.needs(costs[id(other)]) <= LEAD
                   and now + seconds + costs[id(other)] > other.deadline for other in self._jobs):
                continue
            self._jobs.remove(job)
            return job
        return None

    def _kept(self, cost):
        """The lead kept for the next long coarse cut, once the film has shown one: what it needs when the sweep finds
        it at the keyframe after, to end LATE before the one before with SEARCH_FLOOR left; nothing where no lead could
        hold that."""
        if self._longest is None:
            return 0.0
        kept = SEARCH_FLOOR + cost(self._longest) + self._longest.gap + LATE
        return kept if kept <= LEAD else 0.0
