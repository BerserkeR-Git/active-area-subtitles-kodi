"""The two ways of finding the picture's shape, and when to trust what they see.

Each way is a generator of (ratio, how, final): a ratio may be offered early and confirmed
or corrected later, and the caller applies every one it gets. Unavailable means the way
does not work for this playback, so the next one may be tried.

- screen: tiny frame grabs of what Kodi renders (PCs and most Kodi systems).
- film: single keyframes decoded from the playing file with the system's FFmpeg
  (CoreELEC, where the video plane is out of Kodi's reach). Frames come from across the
  whole film, so an opening in another shape can not mislead it.
"""
import time

from . import detect, ffmpeg

SIXTEEN_NINE = 16.0 / 9.0

SCREEN_WIDTH = 256
SCREEN_SETTLE = 0.15          # time Kodi gets to render into a capture before it is read
SCREEN_INTERVAL = 0.3         # between grabs during the first minute
SCREEN_SLOW_INTERVAL = 2.0    # after that (long logos or a dark opening)
SCREEN_FAST_PERIOD = 60.0
SCREEN_GIVE_UP = 600.0
SCREEN_EMPTY_LIMIT = 3        # grabs in a row without an image: the grab does not work here
SCREEN_BLACK_LIMIT = 40       # first grabs all black: nothing useful comes back

# Where in the film keyframes are taken, as shares of its length, in this order.
FILM_POSITIONS = (0.5, 0.25, 0.75, 0.35, 0.65, 0.15, 0.85)
FILM_MIN_LENGTH = 120.0       # seconds; shorter videos are measured from the screen only


class Unavailable(Exception):
    """This way of measuring does not work for the current playback."""


class LeftToCoreELEC(Exception):
    """The film's Dolby Vision Level 5 has values, so CoreELEC places the subtitles itself."""


def decide(ratios, last=False):
    """The shape to use from the clear samples so far, and whether it is settled.

    The widest shape seen (largest bars) is what keeps subtitles inside the picture in every
    scene, IMAX ones included, so it is offered first and settled once seen twice. If the
    samples run out first, the widest shape seen at least twice is used, so one misread frame
    can not decide on its own.
    """
    if not ratios:
        return None, False
    counts = {}
    for ratio in ratios:
        counts[ratio] = counts.get(ratio, 0) + 1
    widest = max(counts)
    if counts[widest] >= 2:
        return widest, True
    if last:
        repeated = [ratio for ratio, count in counts.items() if count >= 2]
        return (max(repeated) if repeated else widest), True
    return widest, False


def screen(video_ratio, current, wait, record):
    """Frame grabs until enough clear ones in a row agree."""
    import xbmc   # only here: the rest of this module works without Kodi
    width, height = SCREEN_WIDTH, max(16, int(round(SCREEN_WIDTH / video_ratio)))
    agreement = detect.Agreement()
    started = time.time()
    grabs = clear = empty_run = 0
    all_black = True
    while current():
        elapsed = time.time() - started
        if elapsed > SCREEN_GIVE_UP:
            return
        capture = xbmc.RenderCapture()
        capture.capture(width, height)
        wait(SCREEN_SETTLE)
        frame = capture.getImage(0)
        del capture                       # releasing it stops Kodi copying frames
        grabs += 1
        sample = detect.analyse(frame, width, height)
        record(grabs, frame, width, height, 4, sample)
        nothing = sample.reason.startswith('no image')
        empty_run = empty_run + 1 if nothing else 0
        all_black = all_black and (nothing or sample.reason == 'black frame')
        if empty_run >= SCREEN_EMPTY_LIMIT:
            raise Unavailable('the frame grab returns no image here')
        if all_black and grabs >= SCREEN_BLACK_LIMIT:
            raise Unavailable('the frame grab returns only black here')
        if sample.clear:
            clear += 1
            if agreement.add(detect.snap(sample.picture_ratio(video_ratio))):
                yield agreement.ratio, 'screen, %d grabs, %d clear, %.1f s' % (grabs, clear, elapsed), True
                return
        if wait(SCREEN_INTERVAL if elapsed < SCREEN_FAST_PERIOD else SCREEN_SLOW_INTERVAL):
            return


def film(target, length, video_ratio, memory_path, current, record, guard, full=False, level5_hands_over=False):
    """Keyframes from across the film; the widest clear shape is offered at once, then confirmed.

    target is a locate.Target. guard() wraps every decode (see guard.DecodeGuard.decoding).
    level5_hands_over: CoreELEC restricts subtitles once Level 5 has values, and it was zero at
    the start. Each keyframe's Level 5 is read along with it (no extra decoding); values in any
    of them raise LeftToCoreELEC, before that keyframe's shape is offered.
    """
    if length < FILM_MIN_LENGTH:
        raise Unavailable('no film length to sample from')
    try:
        decoder = ffmpeg.Decoder(target, memory_path, full=full)
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    ratios, offered = [], None
    try:
        with guard():
            decoder.__enter__()
        try:
            for number, share in enumerate(FILM_POSITIONS, 1):
                if not current():
                    return
                with guard():
                    frame, detail = decoder.sample(length * share)
                if frame is None:
                    continue
                level5 = getattr(decoder, 'level5', None)
                if level5_hands_over and level5 and any(level5):
                    raise LeftToCoreELEC('Level 5 at %d s: top %d, bottom %d' % (length * share, level5[0], level5[1]))
                sample = detect.analyse(frame, decoder.out_w, decoder.out_h, 3)
                record(number, frame, decoder.out_w, decoder.out_h, 3, sample, detail)
                if sample.clear:
                    ratios.append(detect.snap(sample.picture_ratio(video_ratio)))
                ratio, settled = decide(ratios)
                how = 'file, %d keyframes, %d clear, %s, %s' % (number, len(ratios), target.description,
                                                              decoder.description)
                if settled:
                    yield ratio, how, True
                    return
                if ratio is not None and ratio != offered:
                    offered = ratio
                    yield ratio, how, False
        finally:
            decoder.close()
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    ratio, _settled = decide(ratios, last=True)
    if ratio is not None:
        yield ratio, 'file, %d clear of %d keyframes, %s' % (len(ratios), len(FILM_POSITIONS), target.description), True
