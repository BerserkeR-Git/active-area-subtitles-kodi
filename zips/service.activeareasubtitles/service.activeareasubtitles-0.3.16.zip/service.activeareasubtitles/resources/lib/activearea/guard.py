"""Protection against the one part that could take Kodi down: decoding through FFmpeg.

A marker file is present while any decode runs. Finding it when the service starts means
Kodi stopped in the middle of a decode without closing normally, so decoding stays off until
the add-on's version changes (an update with a fix arrives). A normal close removes it, even
when a decode is still running then (a slow network read), so that is never taken for a crash.
"""
import contextlib
import os
import threading
import time


class DecodeGuard:

    def __init__(self, folder, version):
        self.marker = os.path.join(folder, 'decoding.marker')
        self.block = os.path.join(folder, 'decoding.disabled')
        self.folder, self.version = folder, version
        self.lock = threading.Lock()
        self.running = 0    # decodes in progress: an older playback's may still be finishing

    def check_last_run(self):
        """True when the previous run stopped during a decode (decoding is then switched off)."""
        if not os.path.exists(self.marker):
            return False
        _remove(self.marker)
        try:
            self._ensure_folder()
            with open(self.block, 'w', encoding='utf-8') as handle:
                handle.write(self.version)
        except OSError:
            pass
        return True

    def allowed(self):
        try:
            with open(self.block, encoding='utf-8') as handle:
                blocked = handle.read().strip()
        except OSError:
            return True
        if blocked != self.version:
            _remove(self.block)
            return True
        return False

    @contextlib.contextmanager
    def decoding(self):
        with self.lock:
            if not self.running:
                self._ensure_folder()
                with open(self.marker, 'w', encoding='utf-8') as handle:
                    handle.write(str(time.time()))
            self.running += 1
        try:
            yield
        finally:
            with self.lock:
                self.running -= 1
                if not self.running:
                    _remove(self.marker)

    def wait_until_idle(self, seconds=4.0):
        """At a normal close: let a running decode finish (about two seconds at most), then
        remove the marker in any case, since Kodi did not stop in the middle of one."""
        deadline = time.time() + seconds
        while self.running and time.time() < deadline:
            time.sleep(0.1)
        _remove(self.marker)

    def _ensure_folder(self):
        if self.folder and not os.path.isdir(self.folder):
            os.makedirs(self.folder)


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass
