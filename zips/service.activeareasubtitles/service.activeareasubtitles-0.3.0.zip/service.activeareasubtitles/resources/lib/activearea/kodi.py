"""Small helpers around Kodi's Python and JSON-RPC interfaces."""
import json

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = 'service.activeareasubtitles'
PREFIX = '[Active Area Subtitles] '


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def setting_bool(name, default=True):
    try:
        return addon().getSettingBool(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def is_coreelec(path='/etc/os-release'):
    """True on CoreELEC, from the system's own release file."""
    try:
        with open(path, encoding='utf-8') as handle:
            text = handle.read().lower()
    except OSError:
        return False
    return 'coreelec' in text


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    return folder + name


def picture_folder():
    """Where diagnostic pictures go: somewhere easy to reach from another computer.

    CoreELEC's Screenshots share (/storage/screenshots), else Kodi's own screenshot
    folder when one is set, else the add-on's data folder.
    """
    import os
    if is_coreelec() and os.path.isdir('/storage/screenshots'):
        return '/storage/screenshots/'
    chosen = get_setting('debug.screenshotpath')
    if chosen:
        folder = xbmcvfs.translatePath(chosen)
        if os.path.isdir(folder):
            return os.path.join(folder, '')
    return data_path('')


def log(message, always=False):
    if always or setting_bool('diagnostics'):
        xbmc.log(PREFIX + message, xbmc.LOGINFO)


def rpc(method, params=None):
    """Call Kodi's JSON-RPC. Returns the result, or None on an error."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except ValueError:
        return None
    if 'error' in reply:
        log('%s refused: %s' % (method, reply['error'].get('message')))
        return None
    return reply.get('result')


def get_setting(setting_id):
    result = rpc('Settings.GetSettingValue', {'setting': setting_id})
    return None if result is None else result.get('value')


def set_setting(setting_id, value):
    return rpc('Settings.SetSettingValue', {'setting': setting_id, 'value': value}) is True


def video_player_id():
    for player in rpc('Player.GetActivePlayers') or []:
        if player.get('type') == 'video':
            return player.get('playerid')
    return None
