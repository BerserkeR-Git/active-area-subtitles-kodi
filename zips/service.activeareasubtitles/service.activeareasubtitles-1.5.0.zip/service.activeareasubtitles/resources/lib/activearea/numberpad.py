"""The add-on's own number pad, in the style of its menu, for the custom distance: the value large
at the top, the keys below, and the remote's number keys work too. Kodi's own number pad takes
whole numbers only.

The first key replaces the value shown; what can be typed stays a number from 0.00 to its maximum
(10.00 for text, 6.65 for image subtitles) with at most two decimals, and OK rounds it to Kodi's steps of 0.05."""
import re

import xbmcgui

from . import geometry, kodi

WINDOW = 'activearea-number.xml'
TITLE, VALUE, HINT = 10, 20, 21
DIGITS = {100 + digit: str(digit) for digit in range(10)}     # buttons 100 to 109
POINT, DELETE, CANCEL, OK = 110, 111, 120, 121
LABELS = {POINT: '.', DELETE: 32122, CANCEL: 32130, OK: 32109}
REMOTE_DIGITS = {58 + digit: str(digit) for digit in range(10)}   # REMOTE_0 to REMOTE_9
BACKSPACE = 110                                                  # ACTION_BACKSPACE
CLOSE_ACTIONS = (10, 92)                                         # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
TYPED = re.compile(r'\d{1,2}(\.\d{0,2})?$')
EMPTY = 'FF7D828A'


def typed(text, key, fresh, maximum=geometry.CUSTOM_RANGE[1]):
    """The text after pressing key (a digit, '.' or 'delete'); keys that would make it no number
    from 0.00 to maximum with at most two decimals change nothing."""
    if key == 'delete':
        return '' if fresh else text[:-1]
    candidate = ('' if fresh else text) + ('0.' if key == '.' and (fresh or not text) else key)
    if len(candidate) > 1 and candidate[0] == '0' and candidate[1] != '.':
        candidate = candidate[1:]                  # "05" is 5
    if not TYPED.match(candidate) or float(candidate) > maximum:
        return text
    return candidate


class NumberPad(xbmcgui.WindowXML):   # a full window: dialog closes toggle P3i's OSD and eat a press

    def onInit(self):
        self.result, self.fresh = None, True
        self.getControl(TITLE).setLabel(kodi.text(32119))
        self.getControl(HINT).setLabel(kodi.text(self.hint))
        for control_id, label in LABELS.items():
            self.getControl(control_id).setLabel(label if isinstance(label, str) else kodi.text(label))
        for control_id, digit in DIGITS.items():
            self.getControl(control_id).setLabel(digit)
        self.text = '%.2f' % self.start
        self.show_value()
        self.setFocusId(OK)

    def show_value(self):
        self.getControl(VALUE).setLabel(self.text if self.text else '[COLOR %s]0.00[/COLOR]' % EMPTY)

    def press(self, key):
        self.text, self.fresh = typed(self.text, key, self.fresh, self.maximum), False
        self.show_value()

    def onClick(self, control_id):
        if control_id in DIGITS:
            self.press(DIGITS[control_id])
        elif control_id == POINT:
            self.press('.')
        elif control_id == DELETE:
            self.press('delete')
        elif control_id == OK:
            self.result = geometry.custom_distance(self.text or '0', self.maximum)      # empty shows 0.00
            self.close()
        elif control_id == CANCEL:
            self.close()

    def onAction(self, action):
        if action.getId() in REMOTE_DIGITS:
            self.press(REMOTE_DIGITS[action.getId()])
        elif action.getId() == BACKSPACE:
            self.press('delete')
        elif action.getId() in CLOSE_ACTIONS:
            self.close()


def ask(start, maximum=geometry.CUSTOM_RANGE[1], hint=32121):
    """Opens the number pad with start shown; the distance typed (0 to maximum), or None when cancelled.
    hint: the string under the value that says the range."""
    pad = NumberPad(WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')
    pad.start, pad.maximum, pad.hint = start, maximum, hint
    pad.doModal()
    result = getattr(pad, 'result', None)
    del pad
    return result
