"""The add-on's own menu: a wide window with the status at the top, the switches and buttons in a
list, and the focused row's explanation at the bottom. The values live in Kodi's add-on settings,
so the service and Kodi's own settings window see the same thing.

The list is filled once. A press changes only that row's value, so the highlight and the
explanation never jump; rows that need "Keep subtitles inside the picture" are dimmed while it
is off instead of disappearing. The distance rows show their choice with the margin it gives
in grey before it: left and right choose, and OK opens the number pad when the row is on Custom (OK never steps
on: it would move a distance by accident)."""
import xbmc
import xbmcgui

from . import choices, geometry, hdr, kodi, numberpad, shapes, status

WINDOW = 'activearea-menu.xml'
TITLE, SYSTEM_LABEL, SYSTEM_VALUE, METHOD_LABEL, METHOD_VALUE, LIST = 10, 21, 22, 23, 24, 100
CLOSE_ACTIONS = (10, 92)        # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
LEFT, RIGHT = 1, 2              # ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT
COREELEC_CONDITION = 'System.HasAddon(service.coreelec.settings)'
ON, OFF, VERSION = 32104, 32105, 32106
FILE, FILES = 32158, 32159          # the number of cached files, on the Clear cache row
DEFAULTS = dict({'enabled': True, 'remember_shapes': True, 'follow_scenes': True},           # as in settings.xml; other switches off
                **{key: row.default for key, row in choices.ROWS.items()})
# The rows with a Custom choice: (its index, the setting holding the number, its maximum, the number pad's hint,
# the number before anything was typed), from the distance rows (choices.ROWS).
CUSTOMS = {key: (row.custom_index, row.custom_key, row.custom_max, row.custom_hint, row.custom_default)
           for key, row in choices.ROWS.items()}
GREY, GREY_DIMMED = 'FF7D828A', '4D7D828A'
# Set on Kodi's home window while the menu is open. On a box the add-on takes a moment to start, and a second
# press of OK meanwhile would open a second menu on top of the first, so Back would have to be pressed twice.
OPEN = 'activearea.menu.open'
HOME = 10000


class Row:

    def __init__(self, key, label, help_text, switch=False, needs_enabled=False, choices=(), needs=None):
        self.key, self.label, self.help, self.switch = key, label, help_text, switch
        self.needs_enabled, self.choices = needs_enabled, choices
        self.needs = needs                   # another switch it needs on as well (dimmed while that is off)


def distance_row(key, label, help_text):
    """A distance row of the menu: its choices and what it needs from choices.ROWS."""
    row = choices.ROWS[key]
    return Row(key, label, help_text, needs_enabled=True, choices=row.labels, needs=row.needs)


def rows(condition, p3i=False):
    """The menu's rows for this device, in order. Switches carry a setting id as key. p3i: a P3i build of
    CoreELEC, which places image subtitles itself (the add-on gives it their distances)."""
    # The image subtitle sentence only where CoreELEC can place them; a PC shows nothing of CoreELEC.
    found = [Row('enabled', 32002, 32164 if condition(COREELEC_CONDITION) else 32003, switch=True),
             distance_row('gap_bars', 32107, 32108), distance_row('gap_full', 32110, 32111)]
    coreelec_box = condition(COREELEC_CONDITION)
    if p3i or not coreelec_box:      # scenes are followed from P3i's labels on the box, from the screen on a PC
        found += [Row('follow_scenes', 32166, 32167, switch=True, needs_enabled=True),
                  distance_row('gap_imax', 32168, 32169)]
    if p3i and coreelec_box:
        found += [distance_row('image_bars', 32140, 32141), distance_row('image_full', 32142, 32143)]
    if condition(COREELEC_CONDITION):
        found.append(Row('fix_level5', 32102, 32103, switch=True, needs_enabled=True))
    # What a person uses (the cache, HDR brightness where Kodi has it) before what is for troubleshooting, then updates.
    found += [Row('remember_shapes', 32151, 32152, switch=True), Row('forget_shapes', 32153, 32154)]
    if any(condition(platform) for platform in hdr.PLATFORMS):
        found += [Row('hdr_apply', 32011, 32012), Row('hdr_restore', 32013, 32014), Row('hdr_steps', 32015, 32016)]
    found += [Row('diagnostics', 32004, 32005, switch=True), Row('check_updates', 32051, 32052)]
    return found


# A full window, not a dialog: P3i switches its OSD mode for every dialog that opens or closes (aml_dv_dump_state
# xbmc_osd/on|off in the box debug log, ours and Kodi's alike) and the TV then still shows the menu for up to a
# second after Kodi closed it, so a second Back goes to Home and throws the focus to the side. A full window does
# not switch it: one Back, every time, on the box. Kodi draws nothing behind a full window.
# The question window and the number pad are full windows for the same reason.
class Menu(xbmcgui.WindowXML):

    def prepare(self):
        """Everything slow, done before the window opens (show calls it ahead of doModal): CoreELEC's settings,
        the rows and every value. While onInit runs Kodi drops the remote's presses, so with this in onInit a Back
        pressed as the menu appears on a slow box would be lost and need pressing twice (reproduced in the test rig
        with a slowed setup: the first Back never reached onAction)."""
        self.after = None       # an action that needs the menu closed first
        self.addon = kodi.addon()
        self.version = self.addon.getAddonInfo('version')
        self.status = [(kodi.text(string_id), self.addon.getSetting(setting_id))
                       for string_id, setting_id in ((32081, 'status_system'), (32082, 'status_method'))]
        try:
            p3i = self.addon.getSettingBool(status.P3I_SHOWN)      # the service's word, as Kodi's settings window takes it
        except Exception:  # before the service's first start
            p3i = False
        self.rows = rows(xbmc.getCondVisibility, p3i)
        # Read once: a fresh read straight after a change can still return the old value.
        self.values = {row.key: self._read(row) for row in self.rows if row.switch or row.choices}
        self.customs = {key: self._custom(key) for key in CUSTOMS}
        self.items = []
        for row in self.rows:
            item = xbmcgui.ListItem(kodi.text(row.label))
            item.setProperty('help', kodi.text(row.help))
            if row.key == 'check_updates':
                item.setLabel2(kodi.text(VERSION).format(self.version))
            elif row.key == 'forget_shapes':
                cached = shapes.Shapes(kodi.data_path(shapes.FILE_NAME), lambda: True, kodi.log).count()
                item.setLabel2(kodi.text(FILE if cached == 1 else FILES).format(cached))
            self.items.append(item)

    def onInit(self):
        """Only puts what prepare read on screen: quick, so the window answers the remote from the start."""
        self.getControl(TITLE).setLabel('%s %s' % (kodi.text(32000), self.version))
        for (label, shown), (text, value) in zip(((SYSTEM_LABEL, SYSTEM_VALUE), (METHOD_LABEL, METHOD_VALUE)),
                                                  self.status):
            self.getControl(label).setLabel(text)
            self.getControl(shown).setLabel(value)
        listing = self.getControl(LIST)
        # Kodi runs onInit again when a full window opened over the menu closes (the OK after an HDR button, the
        # number pad), and the list still has its rows: added again, the whole menu would show twice.
        if listing.size() == 0:
            for item in self.items:
                listing.addItem(item)
        self.show_values()
        self.setFocusId(LIST)

    def _read(self, row):
        default = DEFAULTS.get(row.key, False)
        try:
            if row.choices:
                value = self.addon.getSettingInt(row.key)
                return value if value in range(len(row.choices)) else default
            return self.addon.getSettingBool(row.key)
        except Exception:  # missing or malformed: the default from settings.xml
            return default

    def _custom(self, key):
        _index, setting, maximum, _hint, default = CUSTOMS[key]
        try:
            typed = geometry.custom_distance(self.addon.getSettingNumber(setting), maximum)
        except Exception:  # missing or malformed: the default from settings.xml
            typed = None
        return default if typed is None else typed

    def _distance(self, row):
        """The row's distance, or None for As on the disc; a choice with no number of its own (Same as full screen,
        Same as black bars) gives None too."""
        distance = choices.ROWS[row.key].distance(self.values[row.key], self.customs[row.key])
        return distance if isinstance(distance, (int, float)) else None

    def show_values(self, keys=None):
        """Every row's value, or only the rows in keys: a change redraws its own row (the add-on switch also the rows
        it dims), so the box has as little to draw as possible when Back follows a change."""
        for row, item in zip(self.rows, self.items):
            if keys is not None and row.key not in keys:
                continue
            if row.switch:
                item.setLabel2(kodi.text(ON if self.values[row.key] else OFF))
            elif row.choices:
                distance = self._distance(row)
                item.setLabel2('%s\u2039  %s  \u203a' % (
                    '' if distance is None else '[COLOR %s]%.2f[/COLOR]      ' % (
                        GREY_DIMMED if self._dimmed(row) else GREY, distance),
                    kodi.text(row.choices[self.values[row.key]])))
            item.setProperty('dimmed', 'true' if self._dimmed(row) else '')

    def _dimmed(self, row):
        return (row.needs_enabled and not self.values['enabled']) or bool(row.needs and not self.values[row.needs])

    def _changed(self, row):
        kodi.settings_changed()                 # Detailed logging among them
        keys = {row.key}
        if row.key == 'enabled':
            keys |= {other.key for other in self.rows if other.needs_enabled}
        keys |= {other.key for other in self.rows if other.needs == row.key}
        self.show_values(keys)

    def onClick(self, control_id):
        if control_id != LIST:
            return
        position = self.getControl(LIST).getSelectedPosition()
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        if self._dimmed(row):
            return
        if row.switch:
            wanted = not self.values[row.key]
            self.addon.setSettingBool(row.key, wanted)
            self.values[row.key] = wanted
            self._changed(row)
        elif row.choices:
            if self._custom_chosen(row):
                self._enter_custom(row)
        elif row.key in ('check_updates', 'forget_shapes'):
            self.after = row.key            # it may open Kodi's list of updates, or tell: closed first
            self.close()
        else:
            getattr(hdr, row.key[len('hdr_'):])()

    def _custom_chosen(self, row):
        return row.key in CUSTOMS and self.values[row.key] == CUSTOMS[row.key][0]

    def _choose(self, row, value):
        self.addon.setSettingInt(row.key, value)
        self.values[row.key] = value
        self._changed(row)

    def _enter_custom(self, row):
        _index, setting, maximum, hint, _default = CUSTOMS[row.key]
        typed = numberpad.ask(self.customs[row.key], maximum, hint)
        if typed is not None:
            self.addon.setSettingNumber(setting, typed)
            self.customs[row.key] = typed
            self._changed(row)

    def onAction(self, action):
        # Every action the window receives, with the detailed log on: where a box needs Back twice to close the
        # menu, the log tells whether the first press reaches this window at all.
        kodi.log('menu: action %d' % action.getId())
        if action.getId() in CLOSE_ACTIONS:
            self.close()
        elif action.getId() in (LEFT, RIGHT):
            position = self.getControl(LIST).getSelectedPosition()
            row = self.rows[position] if 0 <= position < len(self.rows) else None
            if row is None or not row.choices or self._dimmed(row):
                return
            step = 1 if action.getId() == RIGHT else -1
            value = min(len(row.choices) - 1, max(0, self.values[row.key] + step))
            if value != self.values[row.key]:
                self._choose(row, value)


def show():
    """Opens the menu; returns the action to run once it is closed, if any. Opened once: a launch while it
    is already open does nothing."""
    home = xbmcgui.Window(HOME)
    if home.getProperty(OPEN):
        return None
    home.setProperty(OPEN, 'true')
    kodi.settings_changed()                     # the settings as they are now
    try:
        menu = Menu(WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')
        menu.prepare()
        menu.doModal()
        after = getattr(menu, 'after', None)
        del menu
    finally:
        home.clearProperty(OPEN)
    return after
