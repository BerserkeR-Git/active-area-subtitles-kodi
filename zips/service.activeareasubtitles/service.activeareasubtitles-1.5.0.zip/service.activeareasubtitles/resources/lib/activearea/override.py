"""CoreELEC's Level 5 override, set for one playback and always cleared again.

The P3i build reads coreelec.amlogic.dolbyvision.level5.override ("top,bottom,left,right" in
the frame's pixels, empty for none) during playback, for the subtitle restriction and the
Level 5 sent to the TV. The add-on only sets it when it is empty, so a value someone else put
there (P3i's helpers, the person) is never replaced, and only clears it when it still holds
the add-on's own value. A small file records what was set, so it is cleared after a crash too.
"""
import os  # noqa: F401  (tests patch override.os)
import posixpath

from . import keeper

SETTING = 'coreelec.amlogic.dolbyvision.level5.override'
INI = 'override.ini'      # P3i's per-folder setting override add-on (service.p3i.override)
# Addresses that add-on never looks next to; asking a Plex server for override.ini is pointless.
REMOTE_SCHEMES = ('http://', 'https://', 'plugin://', 'pvr://', 'plex://', 'upnp://')


def set_by_override_ini(playing, read_text):
    """True when an override.ini next to the playing file, or one folder up (where P3i's
    per-folder override add-on looks), sets the Level 5 override: the person supplies their
    own Level 5 there, so it is trusted and nothing is checked or changed. read_text(path)
    returns the file's text, or None when there is none."""
    address = playing.partition('|')[0]
    if address.lower().startswith(REMOTE_SCHEMES):
        return False
    folder = posixpath.dirname(address)
    for place in (folder, posixpath.dirname(folder.rstrip('/'))):
        if not place:
            continue
        text = read_text(posixpath.join(place, INI)) or ''
        for line in text.splitlines():
            key = line.split('=', 1)[0].strip()
            if '=' in line and key == SETTING:
                return True
    return False


def value_for(top, bottom):
    return '%d,%d,0,0' % (top, bottom)


class Override:
    """The record stays until neither Kodi's memory nor its settings file holds the add-on's
    value (see keeper.Keeper); saved() reads the file (None when unknown)."""

    def __init__(self, read, write, path, saved=None):
        self._read = read      # () -> the setting's text, or None when it can not be read
        self._write = write    # (text) -> True when CoreELEC took it
        self._saved = saved or read
        self._record = keeper.Record(path, _decode)

    def _current(self):
        value = self._read()
        return value if isinstance(value, str) else None

    def _load(self):
        """(applied, put back already, earlier values of ours that may still be on disk) or None."""
        return self._record.load()

    def apply(self, value):
        """Set value for this playback. False when the setting holds someone else's value, or can
        not be read (it might hold someone else's)."""
        if not value:
            return False            # '' is what restore writes: as a value of ours it would leave a record of nothing
        now, record = self._current(), self._load()
        ours = [record[0]] + record[2] if record else []
        if now is None or (now and now not in ours):
            return False
        # Earlier values of ours stay on record while Kodi's settings file may hold one (see
        # keeper.Keeper.apply): a stale correction there would apply to every film after a crash.
        earlier = []
        if record:
            earlier = keeper.still_saved([v for v in ours if v != value], self._saved(), _equal)
        return self._record.change(_data(value, False, earlier), self._write, value,
                                   _data(*record) if record else None)

    def restore(self):
        """Clear the add-on's own value. True when something was cleared."""
        record = self._load()
        if record is None:
            return False
        applied, put_back, earlier = record
        ours = [applied] + earlier
        now = self._current()
        written = False
        if now in ours or (now is None and not put_back):   # ours (or unreadable): cleared
            if not keeper.took(self._write, ''):
                return False                   # still in place: kept on record, cleared next time
            written = True
        elif now is None:
            return False                       # unreadable: looked at again next time
        elif now != '':
            # Someone else's value now: theirs to keep. Ours stays on record, because the other
            # party may put it back later (P3i's override add-on restores what it found when it
            # applied an override.ini, and a playlist skip gives no stop): then it is cleared.
            return False
        elif not put_back:
            self._record.forget()              # cleared by someone else while ours was in place
            return False
        left = keeper.still_saved(ours, self._saved(), _equal)
        if left:                               # Kodi starts with ours next time unless it saves again
            if written or not put_back or left != ours:
                self._record.mark(_data(applied, True, [v for v in left if v != applied]))
        else:
            self._record.forget()              # neither in memory nor on disk any more: done
        return written


def _decode(data):
    applied = data['applied']
    earlier = [v for v in data.get('earlier', []) if isinstance(v, str) and v]
    if isinstance(applied, str) and applied:
        return applied, bool(data.get('put_back', False)), earlier
    return None


def _data(applied, put_back=False, earlier=()):
    return {'applied': applied, 'put_back': put_back, 'earlier': list(earlier)}


def _equal(a, b):
    return a == b
