"""The margin for a picture: which Kodi setting feeds which part of the renderer model (geometry.py), the font file
Kodi draws with (fonts.py), and the distance chosen for the picture's shape. Reads Kodi's subtitle settings and the
fonts folders, writes nothing; the playback writes what comes out of here under its lock.
"""
import collections
import os

import xbmcvfs

from . import fonts, geometry, kodi
from .restores import number as _number

# What _layout decides once per epoch: the area Kodi lays subtitles out in ('screen' or 'video'), the screen, the
# video's shape, and whether the subtitles sit at the top (their outline reaches up to the picture's edge).
Layout = collections.namedtuple('Layout', 'area screen_w screen_h video_ratio top')
# The margin for a text subtitle and what made it: reach and give in canvas pixels, the font's metrics or None when
# its file could not be read.
Margin = collections.namedtuple('Margin', 'value reach give font')

FONT_DEFAULT_FILE = 'arial.ttf'                        # Kodi's name for its default subtitle font (FontUtils.h)
SYSTEM_FONTS, USER_FONTS = 'special://xbmc/media/Fonts/', 'special://home/media/Fonts/'
_fonts = {}                                            # (path, face, modification time) -> fonts.Metrics or None
MOST_FONTS = 8


def text_margin(layout, picture_ratio, distances):
    """Kodi's margin setting that puts a text subtitle the chosen distance inside the picture. distances: the two
    text distances (content with black bars, full-screen content), choices.distances(). The bar on the subtitle's
    side decides: a picture's bars can differ, and the text sits on one of them."""
    bars_gap, full_gap = distances
    reach, give, font = text_reach(layout.top)
    placed_ratio = geometry.placed_ratio(picture_ratio, layout.video_ratio, layout.top)
    value = geometry.margin_value(layout.area, layout.screen_w / layout.screen_h, layout.video_ratio, placed_ratio,
                                  bars_gap, full_gap, reach, give)
    return Margin(value, reach, give, font)


def image_distance(layout, picture_ratio, distances):
    """(whether the content is full-screen, the image distance for it or geometry.DISC). distances: the two image
    distances, choices.image_distances()."""
    full = geometry.full_screen(layout.screen_w / layout.screen_h, layout.video_ratio, picture_ratio)
    return full, distances[1 if full else 0]


def font_metrics(name, bold=False):
    """The metrics of the font Kodi draws text subtitles with (fonts.Metrics), or None when its file can not be found
    or read; one log line per font file. name: subtitles.fontname, DEFAULT or a family from the user fonts folder;
    bold: the face of that weight when the family has one."""
    if name in (None, '', geometry.KODI_FONT):
        found = (os.path.join(xbmcvfs.translatePath(SYSTEM_FONTS), FONT_DEFAULT_FILE), 0)
    else:
        found = fonts.find(xbmcvfs.translatePath(USER_FONTS), name, bold)
        if found is None:
            _remember(('family', name), None, 'font %s: no file of that family in %s, outline added in full' % (
                name, USER_FONTS))
            return None
    path, face = found
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = None
    key = (path, face, stamp)
    if key not in _fonts:
        try:
            metrics = fonts.read(path, face)
            _remember(key, metrics, 'font %s from %s: %d units per em, ascent %d, descent %d, lowest letter %s, '
                      'tallest %s%s' % (metrics.family, path, metrics.units_per_em, metrics.ascent, metrics.descent,
                                        metrics.depth, metrics.height, ', bold' if metrics.bold else ''))
        except fonts.Broken as why:
            _remember(key, None, 'font file %s not read (%s), outline added in full' % (path, why))
    return _fonts[key]


def _remember(key, metrics, line):
    """Keep what a font file gave, and say so once (a family whose file is gone is looked for every time, in case
    it comes back, but reported once)."""
    if key in _fonts:
        return
    if len(_fonts) >= MOST_FONTS:
        _fonts.clear()
    _fonts[key] = metrics
    kodi.log(line, always=True)


def text_reach(top=False):
    """(how far the ink of a text subtitle reaches past its line box towards the edge, how much of it may end up past
    the edge, its font's metrics or None): geometry.text_reach and edge_give from Kodi's subtitle settings and the font
    file; Kodi's defaults for settings an older Kodi does not have."""
    def setting(name, default):
        value = kodi.get_setting('subtitles.' + name, quiet=True)
        return default if value is None else value
    style = _number(setting('style', geometry.KODI_STYLE))
    bold = style in (geometry.STYLE_BOLD, geometry.STYLE_BOLD_ITALIC)
    metrics = font_metrics(setting('fontname', geometry.KODI_FONT), bold)
    border = setting('bordersize', geometry.KODI_BORDER_SIZE)
    background = setting('backgroundtype', geometry.KODI_BACKGROUND)
    shadow = setting('shadowsize', geometry.KODI_SHADOW_SIZE)
    return (geometry.text_reach(metrics, setting('fontsize', geometry.KODI_FONT_SIZE), border, background, shadow, bold,
                                top),
            geometry.edge_give(border, background, shadow), metrics)
