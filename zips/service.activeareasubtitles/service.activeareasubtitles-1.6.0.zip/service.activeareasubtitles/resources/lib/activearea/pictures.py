"""The film's pictures as the scene follower's readers and the cache hold them: when two shapes are one picture, when
one is wider or narrower than another, whether a shape knows its rows, the one version of each picture a holder
keeps, and a frame lit at its edge through every bar the film is known to show.

One picture can come in several versions: the measurement's settled shape, a keyframe's exact edges a row apart, a
grab's shape without rows, a Level 5 picture. Placing two versions of one picture at two margins moves the text a step
for nothing, so each holder keeps one version per picture (Versions), and a version with its rows is never replaced by
one without. Each holder keeps its own belief level: the grab reader's file shapes replace what the grabs read
(put), the read-ahead's first believed version stays (add), a scene map's shapes keep their indexes (add).

Outside the detector's modules (shapes.DETECTOR_MODULES): a change here measures no cached shape again, and nothing
here decides a measured shape.
"""
from . import detect


def same(a, b):
    """Whether two shapes are one picture within the measuring precision (detect.same_picture)."""
    return detect.same_picture((float(a), float(b)))


def wider(a, b):
    """Whether a is another picture than b, and wider."""
    return float(a) > float(b) and not same(a, b)


def narrower(a, b):
    """Whether a is another picture than b, and narrower."""
    return float(a) < float(b) and not same(a, b)


def wider_number(a, b):
    """Whether a is wider than b beyond float noise, one picture or not: the direction of a cut between two shapes a
    scene map keeps apart, where a wider one moves the text up early (inside the picture before it) rather than late
    into a bar."""
    return float(a) > float(b) * 1.0001


def has_rows(picture):
    """Whether a shape knows its own rows (a detect.Picture measured in the frame's rows), not its ratio alone."""
    return bool(getattr(picture, 'height', 0))


def version(picture, *holders):
    """The version of picture to place, from holders (Versions or lists, the most believed first): the first of the
    same picture with its rows, else picture itself where it has rows, else the first of the same picture, else
    picture. One picture is then placed at one margin whichever map or grab names it."""
    found = [known for holder in holders for known in holder if same(picture, known)]
    with_rows = [known for known in found if has_rows(known)]
    return (with_rows or ([picture] if has_rows(picture) else found) or [picture])[0]


def joined(newer, older):
    """newer's shapes, then older's that are none of newer's pictures."""
    return list(newer) + [shape for shape in older if not any(same(shape, known) for known in newer)]


def wider_than(picture, *holders):
    """Whether any shape in holders is another picture than picture, and wider."""
    return any(wider(shape, picture) for holder in holders for shape in holder)


def narrower_than(picture, *holders):
    """Whether any shape in holders is another picture than picture, and narrower."""
    return any(narrower(shape, picture) for holder in holders for shape in holder)


def lit_at_edge(frame, width, height, channels, shapes, video_ratio, black=0):
    """Whether an unclear frame (or grab) is the full picture lit at its top or bottom edge: its rows from that edge
    are picture (detect.lit_edges) through the thinnest bar of every letterboxed picture in shapes
    (detect.thinnest_bar).
    A letterboxed picture's bar at that edge is black, so the frame is none of the film's pictures with bars; with bars
    at both edges in each, it is the full one. black: the video's black (0 on the screen, detect.LIMITED_BLACK in a
    decoded frame)."""
    return bool(detect.lit_edges(frame, width, height, channels, detect.thinnest_bar(shapes, video_ratio, height),
                                 black))


class Versions(list):
    """One version of each picture, a list in the order its holder came to know them."""

    def find(self, picture):
        """The version kept of picture, or None."""
        return next((known for known in self if same(picture, known)), None)

    def index_of(self, picture):
        """The index of the version kept of picture, or None."""
        return next((number for number, known in enumerate(self) if same(picture, known)), None)

    def fill(self, picture):
        """picture's rows for every version of it kept without rows."""
        if not has_rows(picture):
            return
        for number, known in enumerate(self):
            if not has_rows(known) and same(picture, known):
                self[number] = picture

    def add(self, picture, most=None):
        """The index of picture's version, the first one kept (its rows filled in from picture: fill), picture itself
        appended where none is kept; None where there is no room for another (most)."""
        self.fill(picture)
        found = self.index_of(picture)
        if found is not None:
            return found
        if most is not None and len(self) >= most:
            return None
        self.append(picture)
        return len(self) - 1

    def put(self, picture):
        """picture as its picture's version from now on, first: it replaces every version kept of it."""
        self[:] = [picture] + [known for known in self if not same(picture, known)]

    def widest(self):
        return max(self, key=float)
