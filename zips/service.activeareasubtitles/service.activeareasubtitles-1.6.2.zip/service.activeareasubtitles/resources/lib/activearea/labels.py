"""P3i's live labels for the playing video, the one place they are read: its Level 5 (Player.Process(video.dovi.*))
and its scan state. Two adapters fill them: Kodi's info labels on the box (the service's Labels), a dictionary of
scripted labels in the tests. Beside them Kodi's own hold (paused, seeking, loading), which is no label of P3i's but
decides whether a reading counts.

Labels.reader(height, video_ratio) is bound once to a followed picture's height and the video's shape: read() gives
one look as the measurement's kind of picture with P3i's own numbers for the log, shows(bars) whether that picture is
still on screen.
"""
from . import detect, follow

HAS_L5 = 'Player.Process(video.dovi.has.l5)'
L5_TOP = 'Player.Process(video.dovi.l5.top.offset)'
L5_BOTTOM = 'Player.Process(video.dovi.l5.bottom.offset)'
SCAN_STATE = 'Player.Process(video.dovi.l5.detect.state)'
CACHE_LEVEL = 'Player.CacheLevel'      # Kodi's buffer, per cent full (not P3i's, but read here with the others)
VIDEO_HEIGHT = 'Player.Process(videoheight)'    # the video's rows as Kodi's player reports them (Kodi's too)


class Labels:

    def __init__(self, info_label, condition, rpc=None, player=None):
        self._info = info_label              # name -> text ('' when not reported)
        self._condition = condition          # a Kodi condition -> True or False
        # kodi.rpc and kodi.video_player, for the stream info where the player label is empty
        self._rpc, self._player = rpc, player

    def report(self):
        """(has.l5, top, bottom, scan state) as P3i reports them now."""
        return self._info(HAS_L5), self._info(L5_TOP), self._info(L5_BOTTOM), self._info(SCAN_STATE)

    def has_level5(self):
        return self._info(HAS_L5) == '1'

    def scan_state(self):
        return self._info(SCAN_STATE)

    def seeking(self, last_seek, now):
        """Paused, seeking or loading, or within SEEK_QUIET of Kodi's seek event (last_seek and now on one clock): P3i
        reports "no Level 5" for a moment around a seek (seen on the box), and none of that may move
        the text."""
        return now - last_seek < follow.SEEK_QUIET or self._condition(follow.HOLD)

    def cache_level(self):
        """How full Kodi's buffer is, per cent, or None when Kodi does not say."""
        try:
            return int(float(self._info(CACHE_LEVEL)))
        except (TypeError, ValueError):
            return None

    def video_height(self):
        """The playing video's rows: as Kodi's player reports them, else from Kodi's stream info (JSON-RPC, the
        file's own size: the box's Kodi leaves Player.Process(videoheight) empty, its hardware decoder never reports
        it), or None when neither says."""
        try:
            height = int(self._info(VIDEO_HEIGHT))
        except (TypeError, ValueError):
            height = 0
        if height > 0:
            return height
        if self._rpc is None or self._player is None:
            return None
        player = self._player()
        if player is None:
            return None
        found = self._rpc('Player.GetProperties', {'playerid': player, 'properties': ['currentvideostream']},
                          quiet=True)
        try:
            height = int(found['currentvideostream']['height'])
        except (TypeError, KeyError, ValueError):
            return None
        return height if height > 0 else None

    def reader(self, height, video_ratio, film_time=None):
        return Reader(self._info, height, video_ratio, film_time)


class Reader:
    """The scene follower's readings on the box, as the follow loop reads them: read(), note(shown), pace(),
    film_time(), verifiable; and shows(bars), which only the scene checks ask."""

    verifiable = True                    # a reading is a Level 5 a keyframe can be held against (the scene checks)

    def __init__(self, info_label, height, video_ratio, film_time=None):
        """film_time() -> the playing position in seconds or None, for the log."""
        self._info, self.height, self.video_ratio = info_label, height, video_ratio
        self._film_time = film_time

    @staticmethod
    def pace():
        """Seconds to the next look: the labels every follow.LABEL_STEP."""
        return follow.LABEL_STEP

    def film_time(self):
        return self._film_time() if self._film_time is not None else None

    @staticmethod
    def note(shown):
        """P3i's numbers as read() gave them, for the log."""
        if shown is None:
            return 'Level 5 not reported'
        return 'no Level 5 shown (the full frame)' if shown[0] == '0' else 'Level 5 %d/%d shown' % shown[1:]

    def read(self):
        """(picture, shown): one look at the labels as the measurement's kind of picture (reading) and P3i's own
        numbers, (has.l5, top, bottom), for the log; (None, None) when nothing is reported or it can not be read. The
        offsets only matter with Level 5 (has.l5 0 is the full frame): one label a look then."""
        has_l5 = self._info(HAS_L5)
        top, bottom = (self._info(L5_TOP), self._info(L5_BOTTOM)) if has_l5 == '1' else ('', '')
        picture = reading(has_l5, top, bottom, self.height, self.video_ratio)
        if picture is None:
            return None, None
        return picture, (has_l5, int(top or 0), int(bottom or 0))

    def shows(self, bars):
        """Whether the picture on screen now has these bars (top, bottom), as read() would read it."""
        picture = self.read()[0]
        return picture is not None and (picture.top, picture.bottom) == tuple(bars)


def reading(has_l5, top, bottom, height, video_ratio):
    """One look at the labels as the measurement's kind of picture (detect.Picture with its bars), or None: nothing
    reported, labels unreadable, or offsets that leave no picture. has.l5 0 is a scene without Level 5, which in Dolby
    Vision means the whole frame is picture (a film's IMAX scenes on the box carry none). P3i also shows it before a
    playback's first frame, 1.3 to 2.5 s at a cached resume where a follower may run already (follow.ZERO_TRUST), and
    for a moment around seeks, which the hold covers.

    The offsets count in the rows of the 16:9 frame of the video's width: a cropped file (3840x1606, no bars in it)
    shows 277/277 for its own whole picture (seen on the box). They become the video's own bars here, so a file
    with its bars encoded reads as before."""
    if not height:
        return None
    if has_l5 == '0':
        return detect.Picture(video_ratio, 0, 0, height)
    if has_l5 != '1':
        return None
    try:
        top, bottom = int(top), int(bottom)
    except (TypeError, ValueError):
        return None
    frame = max(height, int(round(height * video_ratio * 9 / 16)))
    if top < 0 or bottom < 0 or top + bottom >= frame:
        return None
    padding = (frame - height) // 2
    top, bottom = max(0, top - padding), max(0, bottom - (frame - height - padding))
    if 2 * max(top, bottom) >= height:     # a bar over half the picture: no reading
        return None
    return detect.Picture(video_ratio * height / (height - top - bottom), top, bottom, height)
