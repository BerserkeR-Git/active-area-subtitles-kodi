"""The one way the add-on runs work on a thread of its own: the service's Threads, given to everything that starts
one. In Kodi each piece of work gets a daemon thread; the tests and the whole-service histories put their own in
its place (run at once, or parked at every wait), so the follower, the checks and the searches run there too.

kind names the work, for the thread's name and for the doubles: 'placing' (a playback measured and placed),
'notice' (a notice window), 'follower' (a follow loop, followloop.py), 'check', 'search' and 'early start' (the box's
scene following, labelfollow.py) and 'lookahead' (a PC's film read ahead, screenfollow.py).
"""
import threading


class Threads:

    def start(self, kind, target, *args):
        threading.Thread(target=target, args=args, name='activearea ' + kind, daemon=True).start()
