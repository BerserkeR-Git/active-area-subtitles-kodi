"""Changing a Kodi setting for one playback and always putting it back.

While a value is changed, a small file holds the person's own value. The file
is the only record: it survives a crash or a forced quit, and the service puts
the value back the next time it starts. Without the file nothing is changed.
"""
import json
import os


class Keeper:

    def __init__(self, read, write, path):
        self._read = read      # () -> current value or None
        self._write = write    # (value) -> True when Kodi accepted it
        self._path = path

    def _load(self):
        try:
            with open(self._path, encoding='utf-8') as handle:
                data = json.load(handle)
            return float(data['own']), float(data['applied'])
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _save(self, own, applied):
        folder = os.path.dirname(self._path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(self._path, 'w', encoding='utf-8') as handle:
            json.dump({'own': own, 'applied': applied}, handle)

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass

    def changed(self):
        return self._load() is not None

    def own(self):
        """The person's own value, also while it is changed."""
        record = self._load()
        if record:
            return record[0]
        return self._read()

    def apply(self, value):
        """Set value for this playback. Returns False when nothing was changed."""
        record = self._load()
        own = record[0] if record else self._read()
        if own is None:
            return False
        if abs(value - own) < 0.001:
            self.restore()
            return False
        self._save(own, value)
        if self._write(value):
            return True
        # Kodi refused: leave everything as it was before this call.
        if record:
            self._save(*record)
        else:
            self._forget()
        return False

    def restore(self):
        """Put the person's value back. Returns True when something was put back."""
        record = self._load()
        if not record:
            return False
        own, applied = record
        current = self._read()
        put_back = False
        # Only undo our own change: if the value is no longer ours, the person set it.
        if current is not None and abs(current - applied) < 0.001:
            put_back = self._write(own)
        self._forget()
        return put_back


class Switch:
    """Turning a switch setting on for one playback, and off again only when it was off before.

    The same file record as Keeper: a crash leaves it on record, and the service turns the
    switch off again the next time it starts. A switch that was already on is not ours.
    """

    def __init__(self, read, write, path):
        self._read = read      # () -> True, False, or None when it can not be read
        self._write = write    # (value) -> True when Kodi accepted it
        self._path = path

    def on(self):
        """Switched on for this playback (or on already). False when it could not be."""
        now = self._read()
        if now is True:
            return True
        if now is not False:
            return False
        try:
            folder = os.path.dirname(self._path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            with open(self._path, 'w', encoding='utf-8') as handle:
                json.dump({'switched_on': True}, handle)
        except OSError:
            return False      # without a record it could not be switched off after a crash
        if self._write(True):
            return True
        self._forget()
        return False

    def restore(self):
        """Switch it off again if the add-on switched it on. True when it was switched off."""
        if not os.path.exists(self._path):
            return False
        now = self._read()
        if now is False:            # switched off meanwhile: nothing left to do
            self._forget()
            return False
        if not self._write(False):
            return False            # still on: kept on record, tried again next time
        self._forget()
        return True

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
