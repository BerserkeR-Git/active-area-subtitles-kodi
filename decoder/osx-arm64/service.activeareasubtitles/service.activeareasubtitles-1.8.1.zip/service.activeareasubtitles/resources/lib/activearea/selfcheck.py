"""The decoder's self-check on the box: is the size of a decoded keyframe the size Kodi gives for the stream it plays?

CoreELEC's own FFmpeg is read by offsets worked out by hand (libav.LAYOUT); a build whose structures differ within a
release would be misread without a sound, and a misread picture can put text in a black bar. The first keyframe the
add-on decodes after it starts is held against Kodi's stream info (checks.Checks.decoder_check): a size nothing
legitimate explains refuses the decoder until the add-on starts again. The keyframe is one the add-on decodes anyway
(filmreader.FilmReader asks with each keyframe), so a healthy box decodes nothing for it.

explained() is the rule. Refusing a decoder that reads well hands every film to CoreELEC until the add-on starts again,
so what a real file and Kodi may legitimately disagree on is allowed: a picture shown wider than it is stored, a coded
height a few rows over the picture's, a file cropped to its picture against the height of its 16:9 frame (either way
round), one field of an interlaced frame, and the same picture at another size (a 1080 layer or copy of a 4K film).
"""

ROWS_SLACK = 16      # rows (or columns) two sizes of one picture may differ by: a coded height of 1088 for 1080, 2176
                     # for 2160
SHAPE_SLACK = 0.01   # how far apart two sizes' shapes may be and still be one picture at another size
WIDEST = 4.0         # the widest picture a file is cropped to (2.76 is the widest film format), over it no picture


def _near(one, other):
    return abs(one - other) <= ROWS_SLACK


def explained(decoded, kodi):
    """What makes a decoded keyframe's size (width, height) and Kodi's for the stream it plays ((width or None, height))
    one video, for the log; None when nothing does."""
    width, height = decoded
    kodi_width, kodi_height = kodi
    if _near(height, kodi_height):
        return 'the same height'                    # a width Kodi shows it at, a coded height
    same_width = kodi_width is None or _near(width, kodi_width)
    if same_width and _near(max(height, kodi_height), width * 9 / 16) and width <= WIDEST * min(height, kodi_height):
        return 'a picture cropped from its 16:9 frame'
    if same_width and (_near(2 * height, kodi_height) or _near(height, 2 * kodi_height)):
        return 'one field of an interlaced frame'
    if kodi_width and abs(width * kodi_height - kodi_width * height) <= SHAPE_SLACK * kodi_width * height:
        return 'the same picture at another size'
    return None
