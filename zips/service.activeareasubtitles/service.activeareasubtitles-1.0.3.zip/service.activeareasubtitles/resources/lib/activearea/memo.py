"""Shapes measured earlier, so a film played again is not decoded again.

Keys are file identities that change when a file is replaced (size and date, or Plex's file key
with its update time), so a new version of a title is always measured afresh. What only holds
for this session (CoreELEC placing a film depends on its settings) stays in memory; entries put
as lasting are also kept in a small file, a few tens of kilobytes at most, and survive a restart.
That file belongs to one version of the add-on: an update measures everything afresh, since it
may measure better.
"""
import collections
import json
import threading

from .keeper import write_record

LIMIT = 500


class Memo:

    def __init__(self, path=None, version='', limit=LIMIT):
        self.limit, self.path, self.version = limit, path, version
        self.entries = collections.OrderedDict()
        self.lasting = set()
        self.lock = threading.Lock()
        self._load()

    def get(self, identity):
        with self.lock:
            if identity in self.entries:
                self.entries.move_to_end(identity)
                return self.entries[identity]
            return None

    def put(self, identity, value, lasting=False):
        with self.lock:
            was_lasting = identity in self.lasting
            self.entries[identity] = value
            self.entries.move_to_end(identity)
            if lasting:
                self.lasting.add(identity)
            else:
                self.lasting.discard(identity)
            while len(self.entries) > self.limit:
                dropped, _value = self.entries.popitem(last=False)
                self.lasting.discard(dropped)
            if lasting or was_lasting:
                self._save()

    def _load(self):
        if not self.path:
            return
        try:
            with open(self.path, encoding='utf-8') as handle:
                data = json.load(handle)
            if not isinstance(data, dict) or data.get('version') != self.version:
                return                     # another version's, or none: measured afresh
            for identity, value in data.get('entries', [])[-self.limit:]:
                if isinstance(identity, str) and isinstance(value, (float, int, str)) and not isinstance(value, bool):
                    self.entries[identity] = value
                    self.lasting.add(identity)
        except (OSError, ValueError, TypeError):   # missing, half written or malformed: as none
            self.entries.clear()
            self.lasting.clear()

    def _save(self):
        if not self.path:
            return
        try:
            write_record(self.path, {'version': self.version,
                                     'entries': [[k, v] for k, v in self.entries.items() if k in self.lasting]})
        except (OSError, TypeError, ValueError):   # kept for this session all the same
            pass
