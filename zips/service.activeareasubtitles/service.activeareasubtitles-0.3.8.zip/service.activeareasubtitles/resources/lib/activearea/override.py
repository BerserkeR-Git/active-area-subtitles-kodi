"""CoreELEC's Level 5 override, set for one playback and always cleared again.

The P3i build reads coreelec.amlogic.dolbyvision.level5.override ("top,bottom,left,right" in
the frame's pixels, empty for none) during playback, for the subtitle restriction and the
Level 5 sent to the TV. The add-on only sets it when it is empty, so a value someone else put
there (P3i's helpers, the person) is never replaced, and only clears it when it still holds
the add-on's own value. A small file records what was set, so it is cleared after a crash too.
"""
import json
import os
import posixpath

SETTING = 'coreelec.amlogic.dolbyvision.level5.override'
INI = 'override.ini'      # P3i's per-folder setting override add-on (service.p3i.override)


def set_by_override_ini(playing, read_text):
    """True when an override.ini next to the playing file, or one folder up (where P3i's
    per-folder override add-on looks), sets the Level 5 override: the person supplies their
    own Level 5 there, so it is trusted and nothing is checked or changed. read_text(path)
    returns the file's text, or None when there is none."""
    folder = posixpath.dirname(playing.partition('|')[0])
    for place in (folder, posixpath.dirname(folder.rstrip('/'))):
        if not place:
            continue
        text = read_text(posixpath.join(place, INI)) or ''
        for line in text.splitlines():
            key = line.split('=', 1)[0].strip()
            if '=' in line and key == SETTING:
                return True
    return False


def value_for(top, bottom):
    return '%d,%d,0,0' % (top, bottom)


class Override:

    def __init__(self, read, write, path):
        self._read = read      # () -> the setting's text, or None when it can not be read
        self._write = write    # (text) -> True when CoreELEC took it
        self._path = path

    def _current(self):
        value = self._read()
        return value if isinstance(value, str) else None

    def _load(self):
        try:
            with open(self._path, encoding='utf-8') as handle:
                applied = json.load(handle)['applied']
            return applied if isinstance(applied, str) and applied else None
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def apply(self, value):
        """Set value for this playback. False when the setting holds someone else's value."""
        now = self._current()
        if now and now != self._load():
            return False
        try:
            folder = os.path.dirname(self._path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            with open(self._path, 'w', encoding='utf-8') as handle:
                json.dump({'applied': value}, handle)
        except OSError:
            return False      # without a record it could not be cleared after a crash
        if self._write(value):
            return True
        self._forget()
        return False

    def restore(self):
        """Clear the add-on's own value. True when something was cleared."""
        applied = self._load()
        if applied is None:
            return False
        now = self._current()
        cleared = False
        if now is None or now == applied:      # unreadable, or still ours
            cleared = self._write('')
        self._forget()
        return cleared

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
