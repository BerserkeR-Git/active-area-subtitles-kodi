"""Finding the picture inside a captured video frame.

Everything here is plain Python without Kodi, so it can be tested on its own.
A frame is BGRA (4 bytes a pixel, from xbmc.RenderCapture) or BGR (3, from the
Amlogic capture device); only the green channel is read.
"""

# Common picture shapes. A measured shape close to one of these is snapped to it.
STANDARD_RATIOS = (1.33, 1.37, 1.43, 1.50, 1.66, 1.78, 1.85, 1.90, 2.00, 2.20, 2.35, 2.39, 2.40, 2.55, 2.76)
SNAP_TOLERANCE = 0.04

# Bars are flat black. A row counts as bar while no pixel in it is brighter than
# the bar's own level plus this much (green channel, 0 to 255), and never above BLACK_MAX.
BAR_NOISE = 6
BLACK_MAX = 32
# The first row of picture next to a bar must be lit across most of its width.
# A dark scene still lifts nearly every pixel above the flat black of a bar; a logo
# or credits on black light only a narrow part of the row.
EDGE_COVERAGE = 0.5
# Real bars are the same height at the top and the bottom.
SYMMETRY_ROWS = 2
# Bars taller than this share of the frame (each) are not believed.
MAX_BAR_SHARE = 0.22

AGREEING_SAMPLES = 4

# An empty capture buffer converted to colour comes out as solid green: red and blue near
# zero, green high. Seen from the Amlogic capture device with 4K HDR10 video on P3i
# (2026-10-08), where it can not read the decoder's frames. Real green scenes keep some red
# and blue, so the rule is strict.
EMPTY_GREEN_SHARE = 0.6


class Sample:
    """One analysed frame."""

    def __init__(self, clear, top, bottom, height, reason='', coverage=None):
        self.clear = clear
        self.top = top          # rows of black above the picture
        self.bottom = bottom    # rows of black below the picture
        self.height = height
        self.reason = reason
        self.coverage = coverage  # lit share of the top and bottom picture rows

    def picture_ratio(self, video_ratio):
        """The picture's shape, given the shape of the whole video frame."""
        rows = self.height - self.top - self.bottom
        return video_ratio * self.height / rows

    def __repr__(self):
        extra = ''
        if self.coverage:
            extra += ', lit %.2f/%.2f' % self.coverage
        if self.reason:
            extra += ', ' + self.reason
        return 'Sample(clear=%s, top=%d, bottom=%d, height=%d%s)' % (
            self.clear, self.top, self.bottom, self.height, extra)


def _greens(frame, width, row, channels=4):
    start = row * width * channels + 1
    return frame[start:start + width * channels:channels]


def empty_green(frame, width, height, channels=4):
    """True when the frame is the solid green of an empty capture buffer."""
    total = green = 0
    for row in range(0, height, 8):
        base = row * width * channels
        for x in range(0, width, 8):
            b, g, r = frame[base + x * channels], frame[base + x * channels + 1], frame[base + x * channels + 2]
            total += 1
            if r < 12 and b < 12 and g > 60:
                green += 1
    return total > 0 and green / total >= EMPTY_GREEN_SHARE


def analyse(frame, width, height, channels=4):
    """Measure the black bars at the top and bottom of one frame."""
    if not frame or len(frame) < width * height * channels:
        return Sample(False, 0, 0, height, 'no image')
    if empty_green(frame, width, height, channels):
        return Sample(False, 0, 0, height, 'no image (empty capture buffer)')
    limit = int(height * MAX_BAR_SHARE)

    # The bars' own level, from the outermost rows when they are dark at all.
    outer = max(max(_greens(frame, width, 0, channels)), max(_greens(frame, width, height - 1, channels)))
    bar_level = outer if outer <= BLACK_MAX else 0
    black = min(BLACK_MAX, bar_level + BAR_NOISE)

    top = 0
    while top <= limit and max(_greens(frame, width, top, channels)) <= black:
        top += 1
    bottom = 0
    while bottom <= limit and max(_greens(frame, width, height - 1 - bottom, channels)) <= black:
        bottom += 1

    if top > limit and bottom > limit:
        return Sample(False, top, bottom, height, 'black frame')
    if top > limit or bottom > limit:
        return Sample(False, top, bottom, height, 'bar too tall')
    if abs(top - bottom) > SYMMETRY_ROWS:
        return Sample(False, top, bottom, height, 'not symmetric')

    lit = bar_level + BAR_NOISE // 2
    coverage = tuple(sum(1 for g in _greens(frame, width, row, channels) if g > lit) / width
                     for row in (top, height - 1 - bottom))
    if min(coverage) < EDGE_COVERAGE:
        return Sample(False, top, bottom, height, 'edge not lit across', coverage)
    return Sample(True, top, bottom, height, coverage=coverage)


def snap(ratio):
    """The nearest standard shape, or the measured one if none is close."""
    best = min(STANDARD_RATIOS, key=lambda standard: abs(standard - ratio))
    if abs(best - ratio) / best <= SNAP_TOLERANCE:
        return best
    return round(ratio, 2)


class Agreement:
    """Waits until enough clear samples in a row show the same shape.

    Unclear samples are skipped without breaking the run; a clear sample with
    another shape starts a new run.
    """

    def __init__(self, needed=AGREEING_SAMPLES):
        self.needed = needed
        self.ratio = None
        self.count = 0

    def add(self, ratio):
        if ratio == self.ratio:
            self.count += 1
        else:
            self.ratio = ratio
            self.count = 1
        return self.settled()

    def settled(self):
        return self.count >= self.needed
