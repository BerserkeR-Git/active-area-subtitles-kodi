"""The read-ahead's searches run (Searching): what the frames or the keyframes between two read keyframes tell, each
of the four kinds of pending search, put on the map being read; and what a search is estimated to cost."""

import collections

from .. import libav, pictures
from ..scenemap import timecode
from .searches import LEAD, Job

RATE = 1.0            # seconds of decoding a second of film's frames costs until a search measured it (UHD on a
                      # small server: 1.2 to 1.6; 4K HEVC on a laptop, one core: about 5)
READ = 1.0            # seconds of playback a keyframe read costs until the sweep measured one
JOB_TRIES = 3         # times a search stopped short (Kodi held, a stall, the lead or playback too near) runs again
SHOTS_MOST = 8        # keyframes read between two read ones at most
INSIDE_FRAMES = 2     # strongly lit frames in a row of a narrower picture that make a shot inside a carried dark run
UNREAD = 0.5          # seconds of frames showing nothing before a narrower picture's first frame from which the map
                      # says nothing between the old picture's last frame and the new one's first (the screen's dim
                      # grabs tell there); shorter, the cut is at the new picture's first frame
WALK_MOST = 12        # keyframes read between two of a run of dark keyframes whose Level 5 is 0/0 before a full
                      # picture, at most (each must be dark with 0/0 or full: else the screen decides after the run's
                      # first keyframe)
SEARCHED = {'cut': 'the frames', 'walk': 'the keyframes inside the dark run', 'shots': 'the keyframes',
            'inside': 'the frames of the dark run'}       # what each kind of search reads, for the log
STOPPED = {'ended': 'the playback ended', 'off': 'following is off', 'held': 'playback held or troubled',
           'late': 'too late', 'index': 'the keyframe index did not match'}  # why a search stopped short, for the log


Cut = collections.namedtuple('Cut', 'at unread stopped')
Cut.__doc__ = ('What the frames between two keyframes told: at, the cut\'s film time or None; unread, (the old '
               'picture\'s last frame, the new one\'s first) where frames showing nothing lie between, else None; '
               'stopped, why the frames stopped short of the keyframe after (\'held\', \'late\') or None.')


def full_if(kept):
    """kept, what an edit of the map being read answered: a map that takes no more ends the read-ahead for good."""
    if not kept:
        raise libav.Unavailable('the scene map is full')


class Searching:
    """The four kinds of pending search, run where the read-ahead gives one its turn: 'cut' (the frames between two
    keyframes of different pictures), 'walk' (the keyframes inside a dark run), 'shots' (the keyframes between two read
    ones of the same picture), 'inside' (a carried dark run's frames). What each finds goes on the map being read; a
    cut search that finds a dark run's cut up to its first keyframe adds the walk after it. It measures the decoding
    rate on its frames, from which a search's cost is estimated."""

    def __init__(self, building, judge, trust, searches, log, now, change, index=lambda: None,
                 confirm=lambda keyframe, asked=None: True):
        """building: the map being read (scenemap.SceneMap, exact); judge, trust: the read-ahead's FrameJudge and
        Trust; searches: its Searches; log(line); now(): Kodi's playing position (told to the steady playback);
        change(before, after): the sweep's placing of two keyframes of different pictures with nothing dark between;
        index(): the file's keyframe index (KeyframeIndex) while it is believed, or None; confirm(keyframe, asked): whether
        it still is after a keyframe read at the index time asked (the read-ahead drops it where that read did not give
        that keyframe)."""
        self._building, self._judge, self._trust, self._searches = building, judge, trust, searches
        self._log, self._now, self._change = log, now, change
        self._index, self._confirm = index, confirm
        self._rate = None               # seconds of decoding per second of film, measured on the frame searches
        self.keyframes = self.frames = 0

    def run(self, film, job, go):
        """A pending search run, go() asked before its reads (the read-ahead's limits: why it stopped in go.why); True
        where it told the map something. Stopped short, it waits to run again, JOB_TRIES times at most (a seek drops
        it)."""
        if job.tries:
            self._log('scenes ahead: %s from %s to %s again' % (
                SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0])))
        read = {'cut': self._find, 'walk': self._walked, 'shots': self._shots, 'inside': self._inside}[job.kind]
        if read(film, job, go):
            return True
        elif job.tries < JOB_TRIES:
            self._searches.add(job.again())
        else:
            self._log('scenes ahead: %s from %s to %s not read, stopped short %d times' % (
                SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0]), job.tries + 1))
        return False

    def estimate(self, job, cost):
        """Seconds of playback a search is estimated to take: a keyframe read (cost, the sweep's measured one, or None)
        for each keyframe it reads (with the keyframe index, those it lists between, a walk none past one pair of more
        than WALK_MOST; without, a walk one more than the run has, a shots search two), or the frames it reads first
        (_first_frames) at the rate the frame searches measured (their keyframe in it), a keyframe and RATE until
        then."""
        read = READ if cost is None else cost
        if job.kind == 'walk':
            times = job.dark.times + [job.after[0]]
            known = [self._known(before, after) for before, after in zip(times, times[1:])]
            if all(inside is not None for inside in known):
                reads = 0
                for inside in known:
                    if len(inside) > WALK_MOST:
                        break
                    reads += len(inside)
                return read * reads
            return read * (len(job.dark.times) + 1)
        if job.kind == 'shots':
            inside = self._known(job.before[0], job.after[0])
            return read * (2 if inside is None else min(len(inside), SHOTS_MOST))
        span = (job.after[0] if job.kind == 'inside' else self._first_frames(job)[0]) - job.before[0]
        return read + span * RATE if self._rate is None else span * self._rate

    def _find(self, film, job, go):
        """The cut between two keyframes of different pictures from the frames between them (across the dark run
        between, if any): a coarse cut refined to its frame (SceneMap.refine: one the frames can not tell stays coarse),
        a silent span closed (SceneMap.bridge; into a narrower picture not found, it stays silent). After a run whose
        trusted Level 5 is 0/0 into the full picture the cut lies before the run's first keyframe, which shows the full
        picture already: only the frames up to it are decoded, and the keyframes inside the run wait as a walk (every
        frame up to the lit keyframe of a 6 s dark IMAX opening in UHD came too late after a seek, the text 6 s high);
        not found there, every frame across the run. False when stopped short of an answer."""
        before, after, dark = job.before, job.after, job.dark
        first = self._first_frames(job)
        if first is not after:
            cut = self._cut(film, before, first, go)
            if cut.at is not None:
                self._join(before, after, cut, upto=dark.first)
                self._searches.add(Job('walk', first, after, dark, 0))
                return True
            if cut.stopped is not None:
                return False
        cut = self._cut(film, before, after, go)
        if cut.stopped is not None and cut.at in (None, before[0]):
            return False
        if job.coarse:
            self._building.refine(before[0], after[0], cut.at)
        elif cut.at is not None:
            self._join(before, after, cut)
        return True

    def _first_frames(self, job):
        """The keyframe up to which a cut search reads the frames first ((film time, picture)): after a run whose
        trusted Level 5 is 0/0 into the full picture the run's first keyframe (it shows the full picture already), else
        the keyframe after (job.after itself)."""
        dark, after = job.dark, job.after
        if dark is not None and dark.trusted_zero and self._judge.full(after[1]):
            return dark.first, after[1]
        return after

    def _join(self, before, after, cut, upto=None):
        """A cut found across a silent span between the keyframes before and after: the two stretches join at it
        (SceneMap.bridge), the map silent between the old picture's last frame and the new one's first where frames
        showing nothing lie between, the new picture up to upto only where the frames told no further."""
        last, shown = cut.unread if cut.unread is not None else (None, cut.at)
        self._building.bridge(before[0], after[0], shown, after[1], last, upto)

    def _walked(self, film, job, go):
        """The keyframes inside a dark run whose cut was found up to its first keyframe (job.before): where every one is
        dark with Level 5 0/0 or the full picture, the stretch up to the run and the one from the keyframe after it
        join (SceneMap.bridge); any other, and the map stays silent after the run's first keyframe. False when stopped
        short."""
        walked = self._walk(film, job.dark, job.after[0], go)
        if walked is None:
            return False
        if walked:
            self._building.bridge(job.before[0], job.after[0], job.after[0], job.after[1])
        return True

    def _walk(self, film, dark, end, go):
        """Whether every keyframe inside the DarkRun dark (whose first one showed the full picture) up to the keyframe
        at film time end is dark with Level 5 0/0 or the full picture: any other (a fade back into the old picture,
        another picture), or more than WALK_MOST, and the screen decides after the run's first keyframe. None where go()
        stopped it."""
        times = dark.times + [end]
        for before, after in zip(times, times[1:]):
            known = self._known(before, after)
            if known is not None and len(known) > WALK_MOST:
                self._log('scenes ahead: the keyframes inside the dark run from %s to %s not read (more than %d), '
                          'left to the screen' % (timecode(dark.first), timecode(end), WALK_MOST))
                return False
            inside = self._between(film, before, after, go, WALK_MOST + 1)
            if inside is None:
                self._log('scenes ahead: the keyframes inside the dark run from %s to %s stopped short (%s)' % (
                    timecode(dark.first), timecode(end), STOPPED[go.why]))
                return None
            if len(inside) > WALK_MOST:
                self._log('scenes ahead: the keyframes inside the dark run from %s to %s not all read (more than %d), '
                          'left to the screen' % (timecode(dark.first), timecode(end), WALK_MOST))
                return False
            other = next((keyframe for keyframe in inside if not self._dark_or_full(keyframe)), None)
            if other is not None:
                self._log('scenes ahead: a keyframe at %s inside the dark run from %s to %s is not dark with Level 5 '
                          '0/0, left to the screen' % (timecode(other.at), timecode(dark.first), timecode(end)))
                return False
        return True

    def _dark_or_full(self, keyframe):
        self._trust.judge(keyframe)
        shown = self._judge.picture(keyframe, exact=True)
        if shown is None:
            return self._judge.full_if_dark(keyframe) is not None
        return self._judge.full(shown)

    def _known(self, before, after):
        """The index times of the keyframes between the ones decoded at film times before and after, where the keyframe
        index covers both; None where nothing is known."""
        index = self._index()
        if index is None or not index.covers(before) or not index.covers(after):
            return None
        return index.between(before, after)

    def _between(self, film, before, after, go, most):
        """The keyframes after film time before and before after, oldest first, the latest most at most; None where
        go() said no (asked before every read), or a keyframe read is not where the keyframe index said (go.why 'index':
        run again, it reads as without one). With the index, those it lists, read forward by their times; without, read
        back from after one seek at a time until the one read before (1.2 to 1.9 s a step on a laptop's share)."""
        index, known = self._index(), self._known(before, after)
        if known is None:
            return self._read_back(film, before, after, go, most)
        found = []
        for at in known[-most:]:
            if not go():
                return None
            keyframe = film.keyframe(index.read_at(at), uneven=True, faint=False)
            if not self._confirm(keyframe, at) or not before < keyframe.at < after:
                go.why = 'index'
                return None
            self.keyframes += 1
            found.append(keyframe)
        return found

    def _read_back(self, film, before, after, go, most):
        """_between without the keyframe index: read back from after."""
        found = []
        seconds = after
        while len(found) < most:
            if not go():
                return None
            keyframe = film.keyframe(seconds - 0.001, uneven=True, faint=False)
            if keyframe.frame is None or keyframe.at is None or not before < keyframe.at < seconds:
                break                           # the one read before (or none between): every one between is found
            self.keyframes += 1
            found.append(keyframe)
            seconds = keyframe.at
        return list(reversed(found))

    def _shots(self, film, job, go):
        """The keyframes between two read ones of the same picture (the latest SHOTS_MOST), so a shot shorter than
        SPARSE starting with a keyframe of its own gets on the map (a scope shot between two 1.90 keyframes would be
        mapped 1.90, the text in its bar; a 0.3 s 1.78 shot between two 2.20 keyframes would keep the text high, a map's
        picture winning over grabs of a narrower one): one showing another picture than the one before it is placed as
        the sweep places a keyframe (_change), its frames a pending search. False when stopped short."""
        found = self._between(film, job.before[0], job.after[0], go, SHOTS_MOST)
        if found is None:
            return False
        last = job.before
        for keyframe in found:
            self._trust.judge(keyframe)
            shown = self._judge.picture(keyframe, exact=True)
            if shown is None:
                continue                        # a dark one tells nothing here
            if not pictures.same(shown, last[1]):
                self._change(last, (keyframe.at, shown))
            last = (keyframe.at, shown)
        if not pictures.same(job.after[1], last[1]):
            self._change(last, job.after)
        return True

    def _inside(self, film, job, go):
        """The shots of a narrower picture among a carried dark run's frames (between two keyframes of the same
        picture), each put on the map (the old picture's keyframe was dark inside a shot lit on screen: the map held the
        text at the old picture's height over it, and a grab of a narrower picture never overrules a map, as its end
        would come unannounced, the text in the bar till the next grab). A shot is INSIDE_FRAMES strongly lit frames in
        a row of a known narrower shape (a weak reading can be wide, a single frame can misread), from the first of them
        to the first frame after its last one that no longer shows it (into the wider picture: early, inside the shot);
        one whose end the frames do not reach is not kept. False when stopped short (nothing kept: its next run finds
        them again)."""
        (start, old), end = job.before, job.after[0]
        # Only shapes the film is known to show, never one a frame of this search would make believed.
        shapes = self._judge.narrower_shapes(old)
        found, run, last_in = [], [], None
        frames, stopped = self._sequence(film, start, end, go)
        for frame in frames:
            self.frames += 1
            if frame.at is None or frame.at <= start:
                continue
            shape, strong = self._judge.seen_in(frame)
            seen = next((known for known in shapes if pictures.same(shape, known)), None) if strong else None
            narrower = seen is not None
            if narrower and (not run or pictures.same(seen, run[0][1])):
                run.append((frame.at, seen))
                if len(run) >= INSIDE_FRAMES:
                    last_in = frame.at
                continue
            if last_in is not None:
                found.append((run[0][0], frame.at, run[0][1]))
            run, last_in = ([(frame.at, seen)] if narrower else []), None
            if frame.at >= end:
                break
        if stopped is not None:
            return False
        for begin, finish, shot in found:
            self._full_if(self._building.add(begin, shot))
            self._full_if(self._building.add(finish, old))
        if found:
            self._log('scenes ahead: inside the dark run from %s to %s, %s' % (
                timecode(job.dark.first), timecode(end), ', '.join(
                    'picture %.2f from %s to %s' % (float(shot), timecode(begin), timecode(finish))
                    for begin, finish, shot in found)))
        return True

    def _cut(self, film, before, after, go):
        """The cut between two keyframes of different pictures, from every frame between them, as Cut: into a wider
        picture the first frame no longer showing the old one, into a narrower one the first showing the new one (into
        a full picture a dark frame whose trusted Level 5 is 0/0 counts, unless the old picture comes back after it).
        Where the frames can not tell (too far apart, dark throughout, stopped short): the first keyframe's time into a
        wider picture (the text up early, inside the old one), None into a narrower one."""
        (start, old), (end, new) = before, after
        wider = float(new) > float(old)
        full = self._judge.full(new)
        gone = shown = unread = None
        last = start                            # the last frame still showing the old picture
        kinds = collections.Counter()           # what the frames showed, for the log
        # Faint rows on: a frame between two keyframes is only told apart from the two pictures known (a B-frame's soft
        # edge reads as no edge at all without them: in an HEVC clip the cut came 1.4 s late).
        frames, stopped = self._sequence(film, start, end, go)
        for frame in frames:
            self.frames += 1
            if frame.at is None or frame.at <= start:
                continue
            picture = self._judge.picture(frame)
            kinds[self._judge.kind(frame, picture, old, new)] += 1
            if picture is not None and pictures.same(picture, old):
                gone = shown = None             # the old picture again: it had not ended yet
                last = frame.at
                continue
            if gone is None:
                gone = frame.at
            if picture is None and full and self._judge.full_if_dark(frame) is not None:
                # Shown: a 16:9 IMAX scene so dark its frames read black, Level 5 0/0 (seen on a PC). A dark scope scene
                # whose Level 5 says 0/0 too would put the text in its bar (3 of 422 well-fitting Dolby Vision films in
                # the corpus show 0/0 on a lit scope keyframe somewhere);
                # trust comes from keyframes of different shots for that (Trust.judge).
                shown = frame.at if shown is None else shown
                continue
            if picture is not None and pictures.same(picture, new):
                shown = frame.at if shown is None else shown
                break
        if wider:
            at = gone if gone is not None and shown is not None else start
        else:
            at = shown
            if shown is not None and gone is not None and shown - gone >= UNREAD:
                unread = (last, min(shown, end))
        if at is not None:
            at = min(at, end)                   # the keyframe after showed the new picture: never later than it
        # What the frames told, for the log: a cut at the keyframe's own frame and one from the keyframe before told
        # apart, and a search stopped short never read as none found.
        if at is None:
            told = 'its frame not found, left to the screen'
        elif at == start:
            told = 'its frame not told, from the keyframe before'
        else:
            told = 'its frame found' + (', the keyframe\'s own' if at == end else '')
        if stopped is not None:
            told += '; frames cut short after %d, %s' % (len(frames), STOPPED[stopped])
        self._log('scenes ahead: picture %.2f from %s (%s)' % (float(new), timecode(end if at is None else at), told))
        if not wider and (at is None or at == end or unread is not None):
            # Why nothing between the two keyframes was taken as the new picture (a dark IMAX opening's frames told
            # apart from a search a seek stopped).
            self._log('scenes ahead: frames from %s to %s: %s; %s' % (
                timecode(start), timecode(end), ', '.join('%d %s' % (count, kind) for kind, count in sorted(
                    kinds.items())) or 'none read', self._trust.note()))
        return Cut(at, unread, stopped)

    def _sequence(self, film, start, end, go):
        """(film.sequence(start, end), why its frames stopped short of end: go.why, 'late' where the file ended, or
        None), its cost measured against Kodi's time (playback goes on meanwhile): seconds of decoding per second of
        film, the higher of the new one and the mean with the one before (a search's cost is estimated by it)."""
        before = self._now()
        frames = film.sequence(start, end, faint=True, go=go)
        after = self._now()
        timed = [frame.at for frame in frames if frame.at is not None]
        stopped = None
        if not timed or timed[-1] < end - 0.001:
            if go.why is None:
                go()                            # short without asking it (the decoder stopped): why, now
            stopped = go.why or 'late'
        # Not across a hold: a seek forward during the frames would count its jump as decoding (27 s ahead, a rate of
        # 60, and no dark run searched across for the rest of the playback).
        if before is not None and after is not None and len(timed) > 1 and stopped not in ('held', 'ended', 'off'):
            spent, decoded = after - before, timed[-1] - timed[0]
            if 0 < spent <= 2 * LEAD and decoded > 0.2:             # not across a seek or a pause
                rate = spent / decoded
                self._rate = rate if self._rate is None else max(rate, (rate + self._rate) / 2)
        return frames, stopped

    _full_if = staticmethod(full_if)
