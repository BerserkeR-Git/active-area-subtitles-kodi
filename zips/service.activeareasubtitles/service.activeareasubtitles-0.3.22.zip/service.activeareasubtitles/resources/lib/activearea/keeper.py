"""Changing a Kodi setting for one playback and always putting it back.

While a value is changed, a small file holds the person's own value. The file
is the only record: it survives a crash or a forced quit, and the service puts
the value back the next time it starts. Without the file nothing is changed.
"""
import json
import os


def write_record(path, data):
    """Writes a record so that a power cut leaves the old one or the new one, never an empty
    file (which would lose the person's value). Raises OSError when it can not be written."""
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    temporary = path + '.new'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


class Keeper:
    """The record stays until the person's value is on disk again. Kodi writes its settings to
    disk only at a clean close (seen in a real Kodi 21), so a value put back during a session is
    lost if Kodi crashes before then; until it is known to be on disk the record is marked "put
    back" and the next start checks again. Restores take the moment: 'now' (during a session),
    'start' (what is in place was just loaded from disk) or 'closing' (Kodi has just saved what
    is in place)."""

    def __init__(self, read, write, path):
        self._read = read      # () -> current value or None
        self._write = write    # (value) -> True when Kodi accepted it
        self._path = path

    def _load(self):
        """(own, applied, put back already) or None."""
        try:
            with open(self._path, encoding='utf-8') as handle:
                data = json.load(handle)
            return float(data['own']), float(data['applied']), bool(data.get('put_back', False))
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            return None

    def _save(self, own, applied, put_back=False):
        write_record(self._path, {'own': own, 'applied': applied, 'put_back': put_back})

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass

    def _active(self):
        """The record of a change of ours still in place, or None."""
        record = self._load()
        return record if record and not record[2] else None

    def changed(self):
        return self._active() is not None

    def own(self):
        """The person's own value, also while it is changed."""
        return _own(self._active(), self._read())

    def apply(self, value):
        """Set value for this playback. Returns False when nothing was changed."""
        record, current = self._load(), self._read()
        if current is None:
            return False
        own = _own(record if record and not record[2] else None, current)
        if abs(value - own) < 0.001:
            self.restore()
            return False
        self._save(own, value)
        try:
            written = self._write(value)
        except Exception:  # as refused: the record must never claim a value that is not there
            written = False
        if written:
            return True
        # Kodi refused: leave everything as it was before this call.
        if record:
            self._save(*record)
        else:
            self._forget()
        return False

    def restore(self, moment='now'):
        """Put the person's value back. Returns True when it was written back."""
        record = self._load()
        if not record:
            return False
        own, applied, put_back = record
        current = self._read()
        if current is None:
            return False            # kept on record, tried again next time
        if abs(current - applied) < 0.001:   # ours in place, or back from disk after a crash
            if not self._write(own):
                return False        # still ours: kept on record, tried again next time
            _mark_put_back(lambda: self._save(own, applied, True))
            return True
        if put_back and abs(current - own) < 0.001 and moment == 'now':
            return False            # put back, but not on disk before Kodi's next clean close
        self._forget()              # the person's value on disk, or one the person chose
        return False


def _mark_put_back(save):
    try:
        save()
    except OSError:         # the record then still says "in place": the next look forgets it
        pass


def _own(record, current):
    """The person's value: the recorded one while ours is still in place (or unknown), else
    what is there now, since the person moved it meanwhile."""
    if record and (current is None or abs(current - record[1]) < 0.001):
        return record[0]
    return current


class Switch:
    """Turning a switch setting on for one playback, and off again only when it was off before.

    The same file record as Keeper, kept until the switch is off on disk too (see Keeper): a
    crash leaves it on record, and the service turns the switch off again the next time it
    starts. A switch that was already on is not ours.
    """

    def __init__(self, read, write, path):
        self._read = read      # () -> True, False, or None when it can not be read
        self._write = write    # (value) -> True when Kodi accepted it
        self._path = path

    def _put_back(self):
        """None without a record, else whether it was switched off again already."""
        if not os.path.exists(self._path):
            return None
        try:
            with open(self._path, encoding='utf-8') as handle:
                return bool(json.load(handle).get('put_back', False))
        except (OSError, ValueError, AttributeError):
            return False    # an unreadable record: still ours

    def on(self):
        """Switched on for this playback (or on already). False when it could not be."""
        now = self._read()
        if now is True:
            return True
        if now is not False:
            return False
        try:
            write_record(self._path, {'switched_on': True, 'put_back': False})
        except OSError:
            return False      # without a record it could not be switched off after a crash
        if self._write(True):
            return True
        self._forget()
        return False

    def restore(self, moment='now'):
        """Switch it off again if the add-on switched it on. True when it was switched off.
        moment: as Keeper.restore."""
        put_back = self._put_back()
        if put_back is None:
            return False
        now = self._read()
        if now is None and put_back:
            return False            # kept on record, looked at again next time
        if now is not False:        # on, or unreadable: switched off all the same
            if now is True and put_back and moment != 'start':
                self._forget()      # switched off by us, on again since: the person's choice
                return False
            if not self._write(False):
                return False        # still on: kept on record, tried again next time
            _mark_put_back(lambda: write_record(self._path, {'switched_on': True, 'put_back': True}))
            return True
        if put_back and moment == 'now':
            return False            # off, but not on disk before Kodi's next clean close
        self._forget()
        return False

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
