"""One playback, from Kodi's start of it to its end: what is known about it, and the work of placing its
subtitles, on threads of its own.

The service makes a Playback when Kodi starts one and drops it when it ends (Service.current). Every
thread works for one Playback and one of its epochs: placing the same playback again (another subtitle
track, another distance) starts a new epoch. Work for a playback that is no longer the current one, or for
an epoch that is no longer its newest, changes nothing (is_current). Nothing about one playback can be read
by the next: each starts with a fresh object (until 1.1.4 the state lived on the service and was reset by
hand).
"""
import functools
import os
import threading
import time
import types

import xbmc
import xbmcvfs

from . import choices, coreelec, diagnostics, geometry, kodi, level5, locate, measure, measurement, p3i, placement, subtitles
from .restores import number as _number

SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
FILE_ANALYSIS = 'video file analysis'
# The watch (see Service._watch_step) looks at the subtitle track only after a button press, early in a playback,
# and once in a while; asking costs about 0.1 ms, normal watching asks nothing at all.
WATCH_EARLY = 30.0             # seconds after the start during which it is looked at regardless
WATCH_EARLY_STEP = 2.0         # how often then
WATCH_SLOW = 30.0              # how often otherwise


def watch_due(now, watch, pressed_lately):
    """Whether the watch looks at the subtitle track now: after a button press, early in the playback (a player
    add-on adds subtitles then, without a press), or once in a while (a phone remote switches without one)."""
    since = now - watch.looked
    return pressed_lately or since >= WATCH_SLOW or (now - watch.started < WATCH_EARLY and since >= WATCH_EARLY_STEP)


class Playback:

    def __init__(self, service, carried_over=False):
        self.service = service               # Kodi's player, the lock, the restores, the P3i policy
        self.started = time.time()
        self.epoch = 0                       # placed again: a new epoch of the same playback
        # Carried over from the previous service (an update during the film): its first epoch keeps what that
        # service put in place; placed again, it gets the add-on's own placement.
        self.carried_epoch = 0 if carried_over else None
        self.watch = types.SimpleNamespace(started=self.started, looked=self.started, failed=False)
        self.shown = p3i.Shown()             # the kind of subtitle shown and the file's streams (P3i writes it)
        self.measured = None                 # (picture ratio, how) once its shape settled
        self.measuring = None                # the mark of the measurement running, if one is
        self.picture = None                  # (layout, picture ratio): the latest shape found
        self.level5 = level5.Correction(self)   # this playback's Level 5 correction (level5.py)
        self.memory = None                   # shapes.Memory: what is remembered for this file, once looked up
        self.waiting = None                  # the epoch that had no subtitles yet; measured once some appear
        self._target = None                  # the playing file once worked out (target)

    def still_playing(self):
        """This is the playback now and Kodi is not closing, whichever epoch is newest: what a header read waits on,
        so another subtitle track does not cut it short."""
        return self.service.current is self and not self.service.monitor.abortRequested()

    def is_current(self, epoch):
        """Whether work for epoch may still change anything: this is the playback now, epoch its newest."""
        return epoch == self.epoch and self.still_playing()

    def write(self, epoch, change):
        """The one way this playback writes to Kodi: change() under the lock, only while epoch is current, so a
        stop or a newer placing in between keeps it from writing. change()'s answer, or None when not current
        (until 1.1.4 the check was done by hand at each write, and one forgotten or done outside the lock raced
        with a stop)."""
        with self.service.lock:
            if not self.is_current(epoch):
                return None
            return change()

    def claim_waiting(self, epoch):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.service.lock:
            if self.waiting == epoch == self.epoch and self.service.current is self:
                self.waiting = None
                return True
            return False


    def restore_if_current(self, epoch, why):
        def back():
            if epoch == self.carried_epoch:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                kodi.log('%s: what the previous service set for this video stays' % why)
            elif self.service.restores.margin_back():
                kodi.log('%s: own subtitle margin put back' % why)
        self.write(epoch, back)

    # The work for one playback, on its own thread.

    def fit(self, epoch, again=False):
        """again: the same playback placed again for another subtitle track."""
        try:
            carried_over = epoch == self.carried_epoch
            if not (carried_over or again):     # a playlist's next video: the previous one's changes go
                self.write(epoch, self.service.restores.next_video)
            # A playback carried over from the previous service keeps CoreELEC's restriction as it was:
            # nothing moves during an update; the next video gets the add-on's own placement. Switched off in its
            # own settings: no P3i policy either, fit_once's layout check puts the margin back (until 1.1.4
            # a PGS film switched the restriction, and nothing put it back until Kodi started again).
            if (not carried_over and kodi.setting_bool('enabled') and self.service.p3i.offered()
                    and not self.service.p3i.by_kind(self, epoch, again)):
                return                    # an image subtitle left as on the disc: nothing to measure
            self.fit_once(epoch, again)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self.restore_if_current(epoch, 'unexpected error')
            except Exception:
                pass

    def while_measuring(self, epoch):
        """Another track or distance while the first measurement runs: CoreELEC's settings for the kind shown, and
        the shape found so far placed with what is chosen now."""
        try:
            # Only where P3i offers its restriction, as in fit (until 1.4.0 any system: a distance changed while a PC
            # measured wrote P3i's restriction, found by the whole-service histories).
            if self.service.p3i.offered() and not self.service.p3i.by_kind(self, epoch, again=True):
                return
            picture = self.picture
            if picture is not None:
                self._apply(epoch, picture[0], picture[1], 'the shape found so far', time.time(), final=False)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('subtitle track not placed: %r' % error, always=True)

    def place_again(self, epoch):
        """The same playback placed again (another subtitle track, another distance), on a thread of its own.
        While its first measurement runs, that measurement carries on (it reads the distances and the kind at
        every answer) and the shape found so far is placed now; once settled, with that shape and its Level 5
        as it is. Until 1.1.4 a distance change while measuring started a second measurement from the first
        keyframe. Before the measurement starts (the waits for subtitles, the shape and CoreELEC's scan in _layout)
        there is nothing to carry on: a new epoch starts the placing over, and the old one ends at its next check
        (deep review, 2026-10-13: harmless). epoch: the one this change was judged for; an older one changes nothing. Kodi
        failing here stays here (the failure sweep found is_current's question escaping the watch)."""
        try:
            with self.service.lock:
                if not self.is_current(epoch):
                    return
                if self.measuring is None:
                    self.epoch += 1
                    target, args = self.fit, (self.epoch, True)
                else:
                    target, args = self.while_measuring, (epoch,)
            threading.Thread(target=target, args=args, daemon=True).start()
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('not placed again: %r' % error, always=True)


    def fit_once(self, epoch, again=False):
        if not self.service.on_coreelec and self.service.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self.is_current(epoch):
            return
        layout = self._layout(epoch)
        if layout is None:
            return
        video_ratio = layout.video_ratio
        started = time.time()
        measured = self.measured
        if again and measured is not None:
            # Placed again for another subtitle track: the shape this playback settled on, not decoded again.
            self._apply(epoch, layout, measured[0], '%s, measured earlier in this playback' % measured[1],
                        started, level5=not self.level5.checked)
            return
        # A file in a shape of its own is usually cropped to its picture: that shape at once. It is
        # measured all the same, since a 4:3 or 1.85 file can hold a wider picture with black bars
        # of its own (letterboxed DVDs, older TV); without a clear answer its own shape stays.
        own_shape = measurement.own_shape(video_ratio)
        if own_shape:
            self._apply(epoch, layout, video_ratio, 'the file\'s own shape, measuring', started, final=False)

        def give_up(why):
            if own_shape:
                self._apply(epoch, layout, video_ratio, 'the file\'s own shape (%s)' % why, started)
            else:
                self.restore_if_current(epoch, why)

        current = lambda: self.is_current(epoch)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self.target()
        # Remembered from an earlier playback of this file (shapes.py): placed at once as the settled answer. On
        # CoreELEC that is the whole measurement (the keyframe decoding is what the memory saves); on a PC the
        # screen capture still runs, cheap, and may only widen what is remembered (a film stopped during a 16:9
        # opening would otherwise stay remembered as full-screen).
        self.memory = self.service.shapes.begin(target, self._length())
        floor = None
        if self.memory.entry is None:
            kodi.log('cache: %s, measuring' % self.memory.note)
        elif not self.is_current(epoch):
            return                          # stopped while the file was read to identify it
        else:
            kodi.log('cache: found (measured %s), %s' % (
                self.memory.entry.date, 'nothing decoded' if self.service.on_coreelec
                else 'the screen capture only watches for a wider picture'))
            floor = self.memory.entry.ratio
            how = 'cached (measured %s)' % self.memory.entry.date
            self._apply(epoch, layout, floor, how, started, final=True)
            self.measured = (floor, how)
            if self.service.on_coreelec:
                return
        ending = give_up if floor is None else self._keep_remembered
        keyframes = []      # what the file analysis decoded, for a Level 5 check without decoding again

        def place(ratio, how, final):
            self._apply(epoch, layout, ratio, how, started, final, keyframes)
            if final:
                self.measured = (ratio, how)

        run = measurement.Measurement(
            self._ways(video_ratio, current, record, target, unreadable, full_pictures, keyframes), video_ratio,
            own_shape, floor, lambda: self.memory, current)
        mine = self.measuring = object()    # this measurement's own mark: one per measurement, not per playback
        try:
            outcome = run.run(place)
            if outcome == measurement.NO_ANSWER:
                ending('no clear answer')
            elif outcome == measurement.NONE_WORKED:
                # The previous item of a playlist may have changed the margin: this one gets the person's own,
                # or the margin for the file's own shape.
                ending('not measured')
            elif outcome == measurement.COREELEC:
                self._coreelec_places(epoch)
                self.level5.after_coreelec_placed(epoch)
        finally:
            if self.measuring is mine:      # a newer measurement keeps its own mark
                self.measuring = None

    def _layout(self, epoch):
        """The placement.Layout for this epoch, or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self.service.finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, epoch):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self.restore_if_current(epoch, 'no subtitles')
            self.waiting = epoch
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self.claim_waiting(epoch)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self.restore_if_current(epoch, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        top = geometry.layout_top(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self.restore_if_current(epoch, 'position not handled')
            self.service.checks.manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self.restore_if_current(epoch, 'view mode not normal')
            return None
        if self.service.on_coreelec and self.shown.kind != subtitles.IMAGE and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.service.monitor.waitForAbort,
                lambda: self.is_current(epoch), kodi.log):
            self._coreelec_places(epoch)
            self.level5.after_coreelec_placed(epoch)
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, epoch)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self.restore_if_current(epoch, 'size unknown')
            return None
        return placement.Layout(area, screen_w, screen_h, video_ratio, top)

    def _wait_for(self, condition, seconds, epoch, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self.is_current(epoch):
            if condition():
                return True
            if waited >= seconds or self.service.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Worked out once per playback: its identity names the file for the decode guard, and it is what the file
        analysis reads. Until 1.4.1 up to four times per placing, each a look at the file on a share or a question
        to the Plex server behind a transcode. An unreadable answer is not kept: asked again next time."""
        if self._target is not None:
            return self._target, None
        try:
            self._target = locate.resolve(self.service.getPlayingFile(), stat=xbmcvfs.Stat)
            return self._target, None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    @staticmethod
    def _keep_remembered(why):
        """A screen capture without an answer leaves the remembered shape in place."""
        kodi.log('cache: kept (screen capture: %s)' % why)

    def _length(self):
        """The film's length in seconds, or None when Kodi can not say."""
        try:
            return float(self.service.getTotalTime())
        except Exception:  # not playing any more, or Kodi could not say
            return None

    def _min_length(self):
        """The shortest video the file analysis reads: shorter on CoreELEC, where it is the only way to measure."""
        return measure.FILM_MIN_LENGTH_ALONE if self.service.on_coreelec else measure.FILM_MIN_LENGTH

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures, keyframes=None):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.service.monitor.waitForAbort, record)

        def from_file():
            if target is None:
                raise measure.Unavailable(unreadable)
            if not self.service.guard.allowed(target.identity):
                raise measure.Unavailable('left to Kodi after an interrupted decode')
            try:
                length = self.service.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            def hands_over():
                # Asked when a keyframe carries Level 5 values, with the kind shown then (until 1.4.1 fixed here: a
                # switch to an image subtitle while measuring still handed over for a text one).
                return (self.service.on_coreelec and self.shown.kind != subtitles.IMAGE
                        and coreelec.restricts_with_level5(kodi.get_setting, xbmc.getInfoLabel))
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                functools.partial(self.service.guard.decoding, target.identity), full=full_pictures,
                                level5_hands_over=hands_over, keyframes=keyframes, min_length=self._min_length())

        if self.service.on_coreelec:
            return [(FILE_ANALYSIS, from_file)]
        return [('screen capture', screen), (FILE_ANALYSIS, from_file)]

    def _apply(self, epoch, layout, picture_ratio, how, started, final=True, keyframes=None, level5=True):
        """The shape found, placed for the kind of subtitle shown (see _place), then logged; a settled shape of
        Dolby Vision gets its Level 5 for the TV."""
        placed = self.write(epoch, lambda: self._place(layout, picture_ratio))
        if placed is None:
            return
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; %s' % (
            'settled:' if final else 'first estimate:', picture_ratio, layout.video_ratio, layout.screen_w, layout.screen_h, how,
            time.time() - started, placed))
        if final and level5:
            self.level5.for_the_tv(epoch, keyframes)

    def _place(self, layout, picture_ratio):
        """With the lock held, for a current epoch: the settings for the kind of subtitle shown, decided under the
        same lock as the writes (decided before it until 1.1.4, a switch in between put the text margin under an
        image subtitle). The end of the log line, or None when nothing could be placed.

        A text subtitle: Kodi's margin for this shape. An image subtitle on a P3i build: CoreELEC places it with its
        restriction, at least the distance chosen for this shape from the picture's edge (its bitmap margin, from
        build 5212 on; older builds keep it inside the picture without a distance); "As on the disc": the
        restriction off. The text margin is the person's meanwhile."""
        restores = self.service.restores
        self.picture = (layout, picture_ratio)
        if self.shown.kind == subtitles.IMAGE:
            full, distance = placement.image_distance(layout, picture_ratio, choices.image_distances())
            restores.margin_back()
            if distance is geometry.DISC:
                restores.disc()
                placed = 'as on the disc'
            else:
                margin = restores.image(distance)
                placed = ('inside the picture (this CoreELEC has no bitmap subtitle margin)' if margin is None
                          else '%.2f from the edge (bitmap subtitle margin %.1f %%)' % (distance, margin))
            return 'image subtitles of %s %s' % ('full-screen content' if full else 'content with black bars', placed)
        own = restores.own_margin()
        if own is None:
            kodi.log('could not read the subtitle margin, not handled')
            return None
        margin = placement.text_margin(layout, picture_ratio, choices.distances())
        changed = restores.apply_margin(margin.value)
        return 'margin %.2f -> %.2f%s (reach %.1f px, give %.1f px, %s)' % (
            own, margin.value, '' if changed else ' (unchanged)', margin.reach, margin.give,
            margin.font.family if margin.font else 'font not read')

    def _coreelec_places(self, epoch):
        """CoreELEC's own restriction covers this playback: it was on when the playback started (a film
        carried over from an update, the hold refused, or the person switched it on during the film). CoreELEC
        places the subtitles on its own edge with the person's settings, so the add-on's margin goes back to the
        person's (a carried-over film keeps what the previous service set)."""
        kodi.log('CoreELEC places the subtitles with its own settings')
        self.restore_if_current(epoch, 'CoreELEC places the subtitles')

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None
