"""Turning a picture shape into Kodi's subtitle margin setting.

Kodi's setting subtitles.marginvertical is a percentage, but for text
subtitles Kodi hands it to libass as MarginV = 10.8 * value * (1080 / 720)
on a 1080 line canvas (OverlayRenderer.cpp and DVDSubtitlesLibass.cpp,
Kodi 21). One unit of the setting therefore moves subtitles by 1.5 per cent
of the height they are laid out in: the whole screen for the "of screen"
positions, the video for the "of video" positions.
"""

MARGIN_SCALE = 1.5
MARGIN_MIN, MARGIN_MAX, MARGIN_STEP = 0.0, 50.0, 0.05

# subtitles.align values in Kodi 21.
ALIGN_MANUAL, ALIGN_BOTTOM_OF_VIDEO, ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_VIDEO, ALIGN_TOP_OF_SCREEN = range(5)


def layout_area(align):
    """'screen', 'video', or None when the position is Manual (not handled)."""
    if align in (ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_SCREEN):
        return 'screen'
    if align in (ALIGN_BOTTOM_OF_VIDEO, ALIGN_TOP_OF_VIDEO):
        return 'video'
    return None


def video_on_screen(screen_ratio, video_ratio):
    """Height of the video as a share of the screen (Kodi's normal view mode: fitted and centred)."""
    return 1.0 if video_ratio <= screen_ratio else screen_ratio / video_ratio


def bar_share(area, screen_ratio, video_ratio, picture_ratio):
    """Height of one black bar, as a share of the area subtitles are laid out in.

    Bars at the top and bottom are equal, so the same share applies to
    subtitles placed at the top.
    """
    picture_in_video = min(1.0, video_ratio / picture_ratio)
    if area == 'video':
        return (1.0 - picture_in_video) / 2
    return (1.0 - video_on_screen(screen_ratio, video_ratio) * picture_in_video) / 2


# Distance kept between the subtitles and the picture's edge with "Small gap from the black bar"
# on (without it they sit right on the edge, as CoreELEC places them), in setting units of the
# screen: 0.35 is about half a per cent of the screen height (7 to 8 px at 1440 lines).
# At 0 the descenders of g, j, p, q and y touch the edge (owner's test, 2026-10-07).
EDGE_GAP = 0.35


def margin_value(base, area, screen_ratio, video_ratio, picture_ratio, gap=EDGE_GAP):
    """The margin setting that puts subtitles just inside the picture.

    base is the person's own margin. When the picture fills the screen's height
    there are no bars to keep clear of and it is left as it is, never rounded.
    Otherwise the subtitles sit gap above the picture's edge, whether the
    bars are in the file or added by Kodi, and whether the "of video" position
    has already lifted them above Kodi's own bars. Bars thinner than half a per
    cent (rounding between a measured and a standard shape) count as none.
    """
    if bar_share('screen', screen_ratio, video_ratio, picture_ratio) < 0.005:
        return base
    area_share = bar_share(area, screen_ratio, video_ratio, picture_ratio)
    if area_share < 0.005:
        area_share = 0.0
    # The same distance on screen: units of the "of video" positions are shares of the video's height.
    scale = video_on_screen(screen_ratio, video_ratio) if area == 'video' else 1.0
    value = (gap / scale + area_share * 100 / MARGIN_SCALE)
    value = round(value / MARGIN_STEP) * MARGIN_STEP
    return round(min(MARGIN_MAX, max(MARGIN_MIN, value)), 2)
