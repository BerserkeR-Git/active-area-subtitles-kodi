"""The follow loop: one follower thread's looks, from its first to its last, the one loop the box, a PC and the film
simulator run. Each look reads the picture on screen (the reader: labels.Reader on the box, capture.ScreenReader on a
PC), lets follow.Follower decide whether the text moves, writes the margin through the epoch's Placing and logs what
it saw; nothing moves while Kodi holds the picture (paused, seeking, caching).

Following is one playback's scene following, the part both platforms share: what the epoch's Placing asks of it, the
scene rule its followers place by, and what a follow loop reads and asks at its looks. Two modules make it whole:
labelfollow.LabelFollowing on the box (P3i's Level 5 labels, the verdict, checks, the start-up search, the early
start) and screenfollow.ScreenFollowing on a PC (Kodi's screen, one reader carried across epochs, the read-ahead). The
film simulator follows through a ScreenFollowing of its own (tests/filmsim.py).
"""
import threading

from . import follow, kodi, pictures, placement, scenemap, subtitles


class Following:
    """One playback's scene following; Playback picks the box's or the PC's by on_coreelec.

    The epoch's Placing asks it once per placement: places(epoch), whether the follower places this epoch's text
    (estimates then write nothing; also asked under the write's lock); measuring(placing, keyframes), an estimate
    placed while the measurement goes on (keyframes: the file analysis' list, growing, or None); settled(placing,
    keyframes, picture), the settled shape, True when the follower places it (asked before the write where the follower
    places the epoch already, after it otherwise). Besides: unsettled(epoch), the measurement ended without a settled
    shape; chosen_again(placing), another track or distance while the follower places and the measurement runs;
    carries_on(placing, settled), placed again during a followed film, True when the follower carries on.

    A follow loop reads, at every look and margin: rule (placement.scene_rule's (distances, placed_as), a new object
    each time it is judged), still (only a wider picture moves the text), chosen (counts the text placed again with what
    is chosen now), settled_picture (the measured shape, None before it settles), verdict (follow.Verdict) and hinted
    (margins worked out as for CoreELEC); each look runs under looking. It asks Kodi: monitor (waitForAbort(seconds),
    the wait between two looks), clock(), log(line, always=False), held() (no reading counts) and seek() (Kodi's latest
    seek event, (clock, film time sought or None), for the text placed for the landing before it shows; None where
    nothing lands). It asks the playback: placed() (the picture placed when a follower starts), image() (an image
    subtitle shows: nothing to place) and played() (seconds the playback has run). And the moments of one follower, each
    given its loop: follows(loop) (it goes on), reader(loop) (its reader, or None when it is not this follower's to
    have), check(loop, picture) (a scene check for a reading the text went down to: True when started; asked only where
    the readings are verifiable, the box's), between_looks(loop, seconds) (the wait after a look, True when Kodi
    closes), before_look(loop) (outside looking), look_begins(loop, rule_changed) (under it, before the reading),
    holds(loop) (Kodi holds the picture at this look), wrote(loop, picture) (a picture written and taken), moved(loop,
    target) (a move in the log), failed(loop, error) (the loop stopped on a surprise) and finished(loop) (its thread
    ends, whatever ended it). follows and failed are here for both, ending a follower that is not the newest started,
    and film_seconds (the playing position the readers log and count by); measuring, settled (through _settle), reader
    and check are each platform's own; the other defaults are the box's: nothing carries on, nothing lands at a seek, a
    wait in one piece, nothing more to do at a look, a hold, a write or a follower's end."""

    hinted = False

    def __init__(self, playback):
        self.playback = playback             # its shape, memory, target and service; writes go through a Placing
        self.verdict = None                  # follow.Verdict: whether its scenes are followed (once judged)
        self.followed = None                # the epoch whose follower runs (started early or at the settled shape)
        self.loop = None                     # the newest follower started (FollowLoop), None once stopped without one
        self._lock = threading.Lock()        # the follower starts once, whether early or at the settled shape
        # Each look of a follower runs under it, so one reader has one follower at a time. A plain Lock: the histories
        # park at those (an RLock would escape their lock-order check).
        self.looking = threading.Lock()
        # placement.scene_rule for the follower, judged from the settled shape; a follower started early reads the
        # estimate's rule until then.
        self.rule = None
        self._judged_from = None             # the shape the rule was judged from
        self.chosen = 0                      # counts the follower's text placed again with what is chosen now (chosen)
        self.settled_picture = None          # the shape the measurement settled on, for a follower started before it
        self.still = False                   # only a picture wider than the measured one moves the text (only_wider_moves)

    def places(self, epoch):
        """Whether the follower places this epoch's text: estimates write nothing, the settled shape only confirms
        or stops it."""
        return self.followed == epoch

    def measuring(self, placing, keyframes):
        """An estimate placed (placing: the epoch's playback.Placing) while the measurement goes on (keyframes: the file
        analysis' list, growing, or None)."""
        raise NotImplementedError

    def settled(self, placing, keyframes, picture=None):
        """A settled placement (picture: the shape settled on; the one measured earlier, else the latest placed, when
        placed again without it): True when the follower places this epoch's text."""
        playback = self.playback
        if picture is None:
            picture = playback.measured[0] if playback.measured else playback.picture[1]
        return self._settle(placing, keyframes, picture)

    def _settle(self, placing, keyframes, picture):
        raise NotImplementedError

    @staticmethod
    def carries_on(_placing, _settled):
        """Placed again during a followed film: True when the follower carries on from the picture on screen. The
        box's: nothing carries on, the measured shape is placed and its follower starts from it."""
        return False

    def unsettled(self, epoch):
        """The measurement ended without a settled shape (no clear answer, nothing worked, CoreELEC's own placing), or
        with an unexpected error: an early follower of this epoch stops before the margin goes back (it moved the text
        again at the next cut otherwise)."""
        with self._lock:
            if self.followed == epoch:
                self.followed = None
                self._ended(self.loop)          # nothing carries its reader on
                self.loop = None
                kodi.log('scenes: following stopped, the measurement did not settle')

    def _judge(self, layout, picture, settled=False):
        if settled:
            self.settled_picture = picture   # before the rule: the follower looks at it when the rule changes
        self.rule, self._judged_from = placement.scene_rule(layout, picture, self.hinted), picture
        # From the measured shape only: an estimate may be narrower than the widest picture (a 2.20 estimate in a 2.39
        # film would slow the looks while a scope cut could still come).
        still = settled and placement.only_wider_moves(layout, picture)
        if still != self.still or settled:
            kodi.log('scenes: placed from picture %.2f%s' % (float(picture), (
                ', taller scenes at its height (Same as black bars): only a wider picture is followed' if still
                else ', taller scenes never above its height')))
        self.still = still

    def chosen_again(self, placing):
        """Another track or distance while the follower places this epoch and the measurement still runs
        (Playback.while_measuring): an image subtitle's settings written now (the follower skips image subtitles, and
        estimates write nothing once it places); for text the rule judged again from the same shape with the distances
        chosen now, and the follower writes its text again at its next look (its margin may be the person's meanwhile,
        put back for an image subtitle, while it still holds its own as placed)."""
        if self.playback.shown.kind == subtitles.IMAGE:
            placed = placing.write(self._judged_from or self.playback.picture[1])
            if placed is not None:
                kodi.log('placed again while the scene follower runs: %s' % placed)
            return
        with self._lock:
            if self._judged_from is not None:
                self._judge(placing.layout, self._judged_from)
            self.chosen += 1

    def failed(self, loop, _error):
        """A follower stopped on a surprise: following ends with it while it is the newest started (a newer one of its
        epoch follows on otherwise), and the text goes back at the measured picture, above every bar (left where the
        follower put it, an IMAX scene's margin stayed through every scope scene after it)."""
        placing, playback = loop.placing, self.playback
        with self._lock:
            ended = self.loop is loop
            if ended:
                self._ended(loop)
                ended = self.followed == placing.epoch
            if ended:
                self.followed = None       # the settled shape is written again, as for a film not followed
        settled = playback.measured[0] if playback.measured is not None else None
        if not ended or settled is None:
            return
        try:
            placed = placing.write(settled, when=lambda: self.followed is None)
            if placed is not None:
                kodi.log('scenes: placed for the measured picture %.2f again, %s' % (float(settled), placed),
                         always=True)
        except Exception:  # Kodi failing still: what is in place stays
            pass

    def _ended(self, loop):
        """The newest follower stopped for good (it failed, or its measurement did not settle), under the start lock:
        what it leaves behind for a next one."""

    def follows(self, loop):
        """A follower goes on while its epoch is current and followed and it is the newest started: an own-shape file's
        measurement ending unsettled, then its own shape placed as settled, starts another follower for the same epoch,
        and the one before must not read on beside it."""
        placing = loop.placing
        return placing.is_current() and self.followed == placing.epoch and self.loop is loop

    # What a follow loop asks of Kodi and of the playback.

    @property
    def monitor(self):
        return self.playback.service.monitor

    def clock(self):
        return self.playback.service.clock()

    @staticmethod
    def log(line, always=False):
        if always:
            kodi.log(line, always=True)
        else:
            kodi.log(line)

    def held(self):
        return self.playback.service.held()

    @staticmethod
    def seek():
        return None

    def placed(self):
        return self.playback.picture[1]

    def image(self):
        return self.playback.shown.kind == subtitles.IMAGE

    def played(self):
        return self.clock() - self.playback.steady.begun

    def film_seconds(self):
        """The playing position in seconds, or None when Kodi can not say (asked only while a film plays: Kodi logs an
        error for a position asked of nothing; its -1 before it knows is None too)."""
        service = self.playback.service
        try:
            if not service.isPlayingVideo():
                return None
            seconds = float(service.getTime())
        except Exception:  # not playing any more, or Kodi could not say
            return None
        return seconds if seconds >= 0 else None

    # A follower's moments: each platform's own, then those the box needs nothing at.

    def reader(self, loop):
        """The follower's reader, or None when it is not this follower's to have."""
        raise NotImplementedError

    def check(self, loop, picture):
        """A scene check for a reading the text went down to: True when started (asked only where the readings are
        verifiable)."""
        raise NotImplementedError

    def between_looks(self, loop, seconds):
        """The wait between a look and the next, True when Kodi closes."""
        return self.monitor.waitForAbort(seconds)

    def before_look(self, loop):
        """Before each look, outside looking."""

    def look_begins(self, loop, rule_changed):
        """At the start of each look, under looking (rule_changed: the rule was judged again since the last)."""

    def holds(self, loop):
        """Kodi holds the picture at this look."""

    def wrote(self, loop, picture):
        """A margin was written for picture and taken by Kodi."""

    def moved(self, loop, target):
        """A move written for target, after its line in the log."""

    def finished(self, loop):
        """A follower's thread ends, whatever ended it."""


class FollowLoop:
    """One follower thread: follow() runs it until the epoch ends, following stops or Kodi closes; Following.follows
    says which. following: the playback's Following; placing: the epoch's playback.Placing (its layout, write, taken,
    margin_placed); chosen: following.chosen when the thread was started (a change before its first look is seen too);
    picture: the picture on screen a follower carries on from (its reader taken over from the previous one), or None;
    height: the followed picture's rows, where the readings count in them (P3i's labels), or None. Its thread runs
    FollowLoop.follow with the loop as its one argument."""

    def __init__(self, following, placing, chosen=0, picture=None, height=None):
        self.following, self.placing, self.carried, self.height = following, placing, picture, height
        self.reader = self.follower = self.keep = None
        self.rule = None
        self.chosen = chosen
        self.shown = ()                 # the last reading logged
        self.seek = None                # Kodi's last seek event seen (Following.seek)
        self.level5 = False             # P3i showed Level 5 in this follower's looks
        self.calm = self.looked = 0.0   # seconds of the playback not held so far, and the clock at the last look

    def follow(self):
        """Moves the text with the film's scenes until the epoch ends, following stops or Kodi closes: a scene's margin as
        for any measured shape (the bar on the subtitle's side, the black bars or the full-screen distance), nothing
        while an image subtitle shows (P3i follows Level 5 for those itself). Both margins stay on the record, so each
        cut writes Kodi only. On a surprise the following puts the text back (Following.failed)."""
        following = self.following
        try:
            # The scene rule is asked at every margin: judged from the shape measured (the settled shape replaces an
            # early start's estimate), never from the last picture placed (placed again during an IMAX scene, that would
            # say full screen).
            rule = following.rule
            self.reader = reader = following.reader(self)
            if reader is None:
                return
            # A check holds a Level 5 against a keyframe: only where the readings are Level 5 (the box).
            self.follower = follow.Follower(self.margin_of, self.placing.margin_placed, following.verdict,
                                            self._check if reader.verifiable else None,
                                            placed_picture=self.carried if self.carried is not None
                                            else following.placed(), undo=reader.verifiable)
            if self.carried is None:
                following.wrote(self, self.follower.placed_picture)
            if not self.placing.taken():
                # Kodi did not take the placing's margin (refused, or no answer): none is known to be in place, so one
                # is written at the first look after follow.WRITE_AGAIN, whatever P3i shows then.
                self.follower.unplaced(following.clock())
            self.keep = {self.placing.margin_placed}
            # calm counts from the playback's start (all of it before this follower, at most), for P3i's "no Level 5"
            # before the first frame (follow.ZERO_TRUST).
            self.rule, self.seek = rule, following.seek()
            self.calm, self.looked = max(0.0, following.played()), following.clock()
            # Until the epoch ends or following stops (an early start the settled judgement or an unsettled measurement
            # said no to).
            while True:
                following.before_look(self)
                with following.looking:
                    if not following.follows(self):
                        break
                    step = self.look()
                if following.between_looks(self, step):
                    return
        except Exception as error:  # never let a surprise disturb playback
            following.log('scenes no longer followed: %r' % error, always=True)
            following.failed(self, error)
        finally:
            following.finished(self)

    def margin_of(self, picture):
        """Kodi's margin for a scene's picture under the scene rule in force, in the terms of the layout in force for the
        placing: one layout from the follower's first look to its last (layouts.py), as Kodi takes its writes."""
        distances, placed_as = self.following.rule
        return placement.text_margin(self.placing.layout, placed_as(picture), distances, self.following.hinted).value

    def _places(self):
        return self.following.places(self.placing.epoch)

    def write(self, picture):
        """(the picture placed for, the end of the log line or None): through the epoch's Placing, only while this
        follower's writes still count (asked under the write's lock: a reading taken before the settled judgement said
        no must not land after the settled shape)."""
        distances, placed_as = self.following.rule
        target = placed_as(picture)
        placed = self.placing.write(target, self.keep, distances, self._places)
        if placed is not None and not self.placing.taken():
            # Kodi refused the margin or did not answer: written again after follow.WRITE_AGAIN (taken as placed, a
            # scope scene after a tall one kept the tall margin, in its bar, until the next scene).
            self.following.log('scene: margin %.2f not taken by Kodi, written again shortly' % self.placing.margin_placed)
            self.follower.unplaced(self.following.clock())
            return target, None
        if placed is not None:
            self.following.wrote(self, picture)
        return target, placed

    def _check(self, picture):
        return self.following.check(self, picture)

    def _counts(self, now, held):
        """Whether P3i's reading now may count: "no Level 5" before P3i showed any in this playback counts only once the
        playback played ZERO_TRUST not held (before its first frame P3i shows none)."""
        clock = self.following.clock()
        if not held:
            self.calm += max(0.0, clock - self.looked)
        self.looked = clock
        if not self.reader.verifiable or not isinstance(now, tuple):
            return True
        if now[0] == '1':
            self.level5 = True
        return now[0] != '0' or self.level5 or self.calm >= follow.ZERO_TRUST

    def _landing(self):
        """Kodi seeks: the text up at once to the picture where it lands (the maps' there, else the widest the film is
        known to show), before the landing shows; never down before it shows (the hold after a seek and the grab after
        it kept a tall scene's text in a scope landing's bar for 0.5 to 0.8 s)."""
        seek = self.following.seek()
        if seek is None or seek is self.seek:
            return
        self.seek = seek
        picture = self.reader.landing(seek[1])
        if (self.margin_of(picture) > self.follower.placed + 0.001
                and self.follower.feed(picture, self.following.clock()) is not None):
            self.moved('a seek to %s' % scenemap.timecode(seek[1]))

    def moved(self, when):
        """The follower's picture written and its line in the log (when: the film time it was written at, Kodi's,
        counted, to set against the cut's)."""
        target, placed = self.write(self.follower.placed_picture)   # the reading, or the one before going back up
        if placed is None:
            return
        source = getattr(self.reader, 'source', None)
        self.following.log('scene: picture %.2f (bars %d/%d) at %s%s, %s' % (
            target, getattr(target, 'top', 0), getattr(target, 'bottom', 0), when,
            ' from the %s' % source if source else '', placed))
        self.following.moved(self, target)

    def look(self):
        """One look: the reading placed, every change in the log, moved or not; the seconds to the next."""
        following, reader, follower = self.following, self.reader, self.follower
        rule = following.rule
        changed = rule is not self.rule
        if changed:
            self.rule = rule            # the settled shape's rule: the margins are worked out again
            follower.rule_changed(following.settled_picture)
        following.look_begins(self, changed)
        if not following.image() and following.chosen != self.chosen:
            self.chosen = following.chosen   # another track or distance (Following.chosen_again): the text written again
            _target, placed = self.write(follower.placed_picture)
            if placed is not None:
                follower.placed_again(self.placing.margin_placed)
                following.log('scene: placed again with what is chosen now, %s' % placed)
        if not following.image():
            # now: as the reader shows them (P3i's numbers: a cropped file's are in its 16:9 frame's rows, the picture's
            # its own; a PC's: the grab's shape).
            held = following.held()
            if not held and self._seek_unseen():
                # Kodi's quiet after a seek passed between two looks (a look longer than the quiet: a slow grab): this
                # look is the first after the hold, its grab may still show the frame from before the seek and the
                # count stands there, so the reader is told of the hold and the landing placed as at a held look.
                following.log('scene: a seek between two looks, taken as held')
                following.holds(self)
                self._landing()
            picture, now = (None, 'held') if held else reader.read()
            if not self._counts(now, held):
                picture, now = None, 'no frame yet'
            # The film's time for the held line before the hold drops a PC's count; asked only for that line (on the
            # box it asks Kodi).
            when = reader.film_time() if now == 'held' and self.shown != 'held' else None
            if now == 'held':
                following.holds(self)
            if now == 'held' and self.shown != 'held' and follower.hold(following.clock()) is not None:
                _target, placed = self.write(follower.placed_picture)  # a move down just before a seek: undone
                if placed is not None:
                    following.log('scene: back up at a seek, %s' % placed)
            if now == 'held':
                self._landing()
            changed = now != self.shown
            if changed:
                self.shown = now
                following.log('scene: %s at %s' % (
                    'held (paused or seeking)' if now == 'held'
                    else 'no Level 5 shown yet, taken for no frame shown yet' if now == 'no frame yet'
                    else reader.note(now), scenemap.timecode(when if now == 'held' else reader.film_time())))
            if follower.feed(picture, following.clock()) is not None:
                self.moved(scenemap.timecode(reader.film_time()))
            elif changed and picture is not None and says_unmoved(follower, picture):
                # Once per new reading: a refused Level 5 and a scene kept at the height in place look the same in the
                # log otherwise.
                following.log('scene: not moved, %s' % (
                    'Level 5 %d/%d was seen missing its picture in this film' % (picture.top, picture.bottom)
                    if follower.unmoved == 'refused'
                    else 'its margin is the one in place (%.2f)' % follower.placed))
        else:
            self.seek = following.seek()    # nothing placed: a seek now lands nothing later
        return reader.pace()

    def _seek_unseen(self):
        """Whether Kodi's latest seek event came after the last this follower placed a landing for."""
        seek = self.following.seek()
        return seek is not None and seek is not self.seek


def says_unmoved(follower, picture):
    """Whether the log says why a new reading moved nothing: a refused Level 5, or another picture than the one placed
    at the margin in place (a taller scene at the scope height); not a row of jitter or the first look."""
    if follower.unmoved == 'refused':
        return True
    placed = follower.placed_picture
    return follower.unmoved == 'same' and placed is not None and not pictures.same(picture, placed)
