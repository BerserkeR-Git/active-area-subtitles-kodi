"""Finding and loading the FFmpeg libraries the file analysis decodes with (libavformat, libavcodec, libavutil).

First the decoder shipped inside the add-on (resources/decoder/: one self-contained library holding all three, with
a manifest), never on CoreELEC, whose own FFmpeg is the one to use there. It is loaded only once its manifest is
for this system, a release this add-on knows, the very structure layout and functions the decoder reads, and the
library's own hash; loaded privately (RTLD_LOCAL), so its symbols never meet Kodi's own FFmpeg.

Then the system's libraries, found without assumptions about where they live: a remembered path first, then the
copy Kodi itself has loaded (from this process's memory map), then the usual folders. Only releases whose
structures ffmpeg.py knows are used (KNOWN_MAJORS), and the three libraries must come from one release.

Kept apart from ffmpeg.py, which decodes: ffmpeg.py is part of the detector's fingerprint (shapes.DETECTOR_MODULES),
so a change to how the libraries are found does not make every cached shape measure again.
"""
import collections
import ctypes
import glob
import hashlib
import json
import os
import platform
import sys

KNOWN_MAJORS = (61, 62)
FOLDERS = ('/usr/lib', '/usr/lib/kodi', '/usr/local/lib', '/lib', '/usr/lib/arm-linux-gnueabihf',
           '/usr/lib/aarch64-linux-gnu', '/usr/lib/x86_64-linux-gnu')


MANIFEST = 'manifest.json'
SCHEMA = 1
AV_LOG_QUIET = -8
# The systems a decoder ships for, the one table (the loader, the build, the zips and the release check read it):
# Kodi's platform tag for the add-on's version with the decoder, sys.platform's prefix and platform.machine() in
# lower case there, the library's file name, and the oldest macOS it runs on. Every one is built by
# tools/ffmpeg_ship/make.sh. No row for linux-aarch64: there is no cross-compiler for it in the build image, and the
# box, the one aarch64 Kodi the add-on knows, keeps its own FFmpeg.
System = collections.namedtuple('System', 'tag platform machine library macos_minimum')
SYSTEMS = (
    System('windows-x86_64', 'win32', 'amd64', 'aasvideo.dll', None),
    System('osx-arm64', 'darwin', 'arm64', 'libaasvideo.dylib', '11.0'),
    System('osx-x86_64', 'darwin', 'x86_64', 'libaasvideo.dylib', '10.14'),
    System('linux-x86_64', 'linux', 'x86_64', 'libaasvideo.so', None),
)
# Every function ffmpeg.py calls: the shipped library exports exactly these.
EXPORTS = (
    'avformat_version', 'avformat_alloc_context', 'avformat_open_input', 'avformat_find_stream_info',
    'av_find_best_stream', 'av_seek_frame', 'av_read_frame', 'avformat_close_input', 'avio_alloc_context',
    'avio_context_free', 'avcodec_version', 'avcodec_alloc_context3', 'avcodec_parameters_to_context',
    'avcodec_open2', 'avcodec_send_packet', 'avcodec_receive_frame', 'avcodec_flush_buffers',
    'avcodec_free_context', 'av_packet_alloc', 'av_packet_unref', 'av_packet_free', 'avcodec_get_name',
    'avutil_version', 'av_frame_alloc', 'av_frame_free', 'av_malloc', 'av_free', 'av_dict_set', 'av_dict_free',
    'av_opt_set_int', 'av_get_pix_fmt_name', 'av_frame_get_side_data', 'av_frame_side_data_name', 'av_dict_get',
    'av_dovi_find_level', 'av_log_set_level')

# What one load found: the three handles (one and the same for a shipped decoder), the text for the log, where it
# came from ('shipped' or 'system'), and whether it opens network addresses itself (a shipped decoder does not:
# those go through Kodi's own file access).
Libraries = collections.namedtuple('Libraries', 'avformat avcodec avutil description origin network')
_refused = []        # why the shipped decoder was not used, once per process


def system(platform_name=None, machine=None):
    """(Kodi's platform tag, the library's file name) of this system's decoder, or None where none ships."""
    platform_name = sys.platform if platform_name is None else platform_name
    machine = (platform.machine() if machine is None else machine).lower()
    for row in SYSTEMS:
        if platform_name.startswith(row.platform) and machine == row.machine:
            return row.tag, row.library
    return None


def library_name(tag):
    """The decoder library's file name for a system's tag, or None for a system no decoder ships for."""
    return next((row.library for row in SYSTEMS if row.tag == tag), None)


def layout(pointer_size, machine):
    """Every structure offset ffmpeg.py reads, by name (libavformat 61 and 62, FFmpeg 7 and 8). 64-bit numbers sit
    on 8 bytes except on 32-bit x86."""
    p = pointer_size
    x86 = p == 4 and machine.lower() in ('i386', 'i486', 'i586', 'i686', 'x86')
    align = 4 if x86 else 8
    pts = 4 if x86 else 8
    # AVPacket: buf, pts, dts, data, size, stream_index.
    stream_index = 36 if p == 8 else (28 if x86 else 32)
    # AVStream: av_class, index, id, codecpar, priv_data, time_base (two ints), then start_time, duration and
    # nb_frames (64-bit), disposition, discard, sample_aspect_ratio (two ints) and metadata.
    start_time = -(-(3 * p + 16) // align) * align
    disposition = start_time + 24
    return {
        'AVFormatContext.pb': 4 * p, 'AVFormatContext.nb_streams': 5 * p + 4, 'AVFormatContext.streams': 5 * p + 8,
        'AVStream.codecpar': p + 8, 'AVStream.disposition': disposition, 'AVStream.discard': disposition + 4,
        'AVStream.metadata': -(-(disposition + 16) // p) * p,
        'AVCodecParameters.codec_type': 0, 'AVCodecParameters.codec_id': 4,
        'AVPacket.pts': pts, 'AVPacket.dts': pts + 8, 'AVPacket.stream_index': stream_index,
        'AVFrame.data': 0, 'AVFrame.linesize': 8 * p, 'AVFrame.width': 9 * p + 32, 'AVFrame.height': 9 * p + 36,
        'AVFrame.format': 9 * p + 44, 'AVFrameSideData.data': p, 'AVDictionaryEntry.value': p, 'AVIOContext.buffer': p,
        # AVDOVIDmData: the level (uint8_t), then a union aligned to 4; AVDOVIDmLevel5 is four uint16_t offsets.
        'AVDOVIDmData.level': 0, 'AVDOVIDmLevel5.left_offset': 4, 'AVDOVIDmLevel5.right_offset': 6,
        'AVDOVIDmLevel5.top_offset': 8, 'AVDOVIDmLevel5.bottom_offset': 10,
    }


LAYOUT = layout(ctypes.sizeof(ctypes.c_void_p), platform.machine())


def refusal():
    """Why the shipped decoder was refused in this process, or None."""
    return _refused[0] if _refused else None


def forget_refusal():
    """Forgets why the decoder was refused, so it loads again in this process: a hook for the tests and
    tools/fuzz_decoder.py; the add-on itself never calls it."""
    del _refused[:]


def manifest(system_name, library_path, ffmpeg_version, avformat_major, layout=None):
    """The manifest a build writes beside its library (and a test, beside a fake one)."""
    return {'schema': SCHEMA, 'system': system_name, 'ffmpeg': ffmpeg_version, 'avformat_major': avformat_major,
            'library': os.path.basename(library_path), 'sha256': _sha256(library_path),
            'layout': dict(LAYOUT if layout is None else layout), 'exports': list(EXPORTS), 'network': False}


def lower_priority(platform_name=None):
    """The calling thread at the lowest priority, so decoding never competes with playback; a failure only means it
    stays as it was."""
    platform_name = sys.platform if platform_name is None else platform_name
    try:
        if platform_name.startswith('linux'):
            import threading
            os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)
        elif platform_name.startswith('win32'):
            kernel32 = ctypes.windll.kernel32
            kernel32.SetThreadPriority(kernel32.GetCurrentThread(), -2)       # THREAD_PRIORITY_LOWEST
        elif platform_name.startswith('darwin'):
            ctypes.CDLL('/usr/lib/libSystem.B.dylib').pthread_set_qos_class_self_np(0x09, 0)   # QOS_CLASS_BACKGROUND
    except (AttributeError, OSError):
        pass


class Unavailable(Exception):
    """The file can not be measured this way. The message is for the log."""


# Finding the libraries -------------------------------------------------------------------


def _loaded_by_kodi(name):
    found = []
    try:
        with open('/proc/self/maps', encoding='utf-8', errors='replace') as handle:
            for line in handle:
                path = line.rsplit(' ', 1)[-1].strip()
                if '/lib%s.so' % name in path and path not in found:
                    found.append(path)
    except OSError:
        pass
    return found


def _candidates(name, remembered):
    """The paths to try for a library, best first, found as they are asked for: the external tools find_library starts
    (ldconfig, gcc, ld, as Kodi's children) only run when nothing before them loaded."""
    seen = set()

    def fresh(paths):
        for path in paths:
            if path and path not in seen:
                seen.add(path)
                yield path
    yield from fresh([remembered.get(name)])
    yield from fresh(_loaded_by_kodi(name))
    yield from fresh(p for folder in FOLDERS for p in sorted(glob.glob('%s/lib%s.so*' % (folder, name)), reverse=True))
    yield from fresh(_found_by_system(name))


def _found_by_system(name):
    try:
        import ctypes.util
        found = ctypes.util.find_library(name)
        return [found] if found else []
    except Exception:  # find_library runs external tools; any failure only means "not found"
        return []


def _load(name, remembered, check):
    for path in _candidates(name, remembered):
        try:
            library = ctypes.CDLL(path)
            if not check(library):
                continue
        except (OSError, AttributeError):
            continue
        remembered[name] = path
        return library
    remembered.pop(name, None)
    return None


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, data):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except OSError:
        pass


def matching_majors(avformat_major):
    """The libavcodec and libavutil major versions of the same FFmpeg release: FFmpeg bumps
    libavformat and libavcodec together, with libavutil two lower (FFmpeg 7: 61, 61, 59;
    FFmpeg 8: 62, 62, 60). Mixing releases would hand one release's structures to another."""
    return avformat_major, avformat_major - 2


def decoder_folder():
    """The add-on's own resources/decoder/ folder, or None outside Kodi."""
    try:
        from . import kodi
        return os.path.join(kodi.addon().getAddonInfo('path'), 'resources', 'decoder')
    except Exception:  # no Kodi (the tools), or it could not say: no shipped decoder
        return None


def _on_coreelec():
    from . import coreelec
    return coreelec.is_coreelec()


AUTO = object()


def libraries(memory_path, folder=AUTO, on_coreelec=AUTO, system_row=AUTO):
    """Libraries: the shipped decoder when it passes its checks, else the system's. Raises Unavailable.
    folder, on_coreelec and system_row: worked out here unless given (tests give them)."""
    on_coreelec = _on_coreelec() if on_coreelec is AUTO else on_coreelec
    if not on_coreelec:
        folder = decoder_folder() if folder is AUTO else folder
        row = system() if system_row is AUTO else system_row
        if folder and row:
            shipped = _shipped(folder, row, memory_path)
            if shipped is not None:
                return shipped
    return _system_libraries(memory_path)


def _refuse(reason):
    if not _refused:
        _refused.append(reason)
    return None


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def _manifest(folder):
    with open(os.path.join(folder, MANIFEST), encoding='utf-8') as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError('not an object')
    return data


def check_manifest(folder, system_name, layout=None, hashed=None, library=None):
    """Why the decoder in folder would be refused on system_name, or None: the loader's rules, the only validator (the
    loader, the build and the publishing all ask it). layout: the structure offsets the loader there reads (this
    system's own unless given: the build checks a decoder for another system); hashed(path, sha256): whether the
    library matches (a fresh sha256 unless given: the loader remembers it); library: its file name there (the
    table's unless given)."""
    try:
        data = _manifest(folder)
    except (OSError, ValueError) as error:
        return 'manifest unreadable (%s)' % error
    if data.get('schema') != SCHEMA:
        return 'manifest version %r not known' % data.get('schema')
    if data.get('system') != system_name:
        return 'built for %s, this is %s' % (data.get('system'), system_name)
    if data.get('avformat_major') not in KNOWN_MAJORS:
        return 'libavformat %r not known' % data.get('avformat_major')
    expected = LAYOUT if layout is None else layout
    found = data.get('layout') if isinstance(data.get('layout'), dict) else {}
    differs = sorted(key for key in set(expected) | set(found) if found.get(key) != expected.get(key))
    if differs:
        return 'structure layout differs (%s)' % ', '.join(differs[:3])
    exports = data.get('exports') if isinstance(data.get('exports'), list) else []
    missing = [name for name in EXPORTS if name not in exports]
    if missing:
        return 'functions missing (%s)' % ', '.join(missing[:3])
    name = data.get('library')
    if not isinstance(name, str) or os.path.basename(name) != name or not name:
        return 'library name not allowed'
    expected_name = library or library_name(system_name)
    if name != expected_name:
        return 'library %s, expected %s' % (name, expected_name)
    path = os.path.join(folder, name)
    if not (hashed(path, data.get('sha256')) if hashed else _sha256_matches(path, data.get('sha256'))):
        return 'library does not match its manifest'
    return None


def _sha256_matches(path, expected):
    try:
        return _sha256(path) == expected
    except OSError:
        return False


def _shipped(folder, row, memory_path):
    """The shipped decoder's Libraries, or None (missing: quietly; refused: with its reason, see refusal())."""
    system_name, file_name = row
    if not os.path.exists(os.path.join(folder, MANIFEST)):
        return None
    problem = check_manifest(folder, system_name, hashed=lambda path, sha256: _hash_matches(path, sha256, memory_path),
                             library=file_name)
    if problem:
        return _refuse(problem)
    data = _manifest(folder)
    major, path = data['avformat_major'], os.path.join(folder, data['library'])
    try:
        if sys.platform.startswith('win32'):
            library = ctypes.CDLL(path)
        else:
            library = ctypes.CDLL(path, mode=ctypes.RTLD_LOCAL)
        loaded = library.avformat_version() >> 16
        codec_major, util_major = matching_majors(loaded)
        if loaded != major or (library.avcodec_version() >> 16) != codec_major or \
                (library.avutil_version() >> 16) != util_major:
            return _refuse('libavformat %d loaded, manifest says %d' % (loaded, major))
        library.av_log_set_level(AV_LOG_QUIET)       # FFmpeg would write to Kodi's stderr, nobody's log
    except (OSError, AttributeError) as error:
        return _refuse('library would not load (%s)' % error)
    return Libraries(library, library, library, 'FFmpeg %s (shipped)' % data.get('ffmpeg', '?'), 'shipped',
                     bool(data.get('network', False)))


def _hash_matches(path, expected, memory_path):
    """Whether the library's sha256 is the manifest's; worked out once per file size and date (remembered)."""
    try:
        status = os.stat(path)
    except OSError:
        return False
    stamp = [status.st_size, int(status.st_mtime)]
    remembered = _read_json(memory_path)
    known = remembered.get('decoder')
    if isinstance(known, dict) and known.get('stamp') == stamp and known.get('sha256') == expected:
        return True
    try:
        actual = _sha256(path)
    except OSError:
        return False
    if actual != expected:
        return False
    remembered['decoder'] = {'stamp': stamp, 'sha256': actual}
    _write_json(memory_path, remembered)
    return True


def _system_libraries(memory_path):
    """The system's libraries as Libraries. Raises Unavailable."""
    remembered = _read_json(memory_path)
    before = dict(remembered)
    avformat = _load('avformat', remembered, lambda lib: (lib.avformat_version() >> 16) in KNOWN_MAJORS)
    avcodec = avutil = None
    if avformat:
        codec_major, util_major = matching_majors(avformat.avformat_version() >> 16)
        avcodec = _load('avcodec', remembered, lambda lib: (lib.avcodec_version() >> 16) == codec_major)
        avutil = _load('avutil', remembered, lambda lib: (lib.avutil_version() >> 16) == util_major)
    if remembered != before:
        _write_json(memory_path, remembered)
    if not (avformat and avcodec and avutil):
        raise Unavailable('no FFmpeg 7 or 8 libraries found')
    return Libraries(avformat, avcodec, avutil, 'FFmpeg (libavformat %d)' % (avformat.avformat_version() >> 16),
                     'system', True)


def found(memory_path):
    """The Libraries a playback would decode with, or None when there are none."""
    try:
        return libraries(memory_path)
    except Unavailable:
        return None


def usable(memory_path):
    """True when an FFmpeg release this add-on knows can be loaded."""
    try:
        libraries(memory_path)
        return True
    except Unavailable:
        return False


def newer_release(memory_path):
    """The libavformat major of a newer FFmpeg than this add-on knows when that is all the system has
    (FFmpeg 9 and up: its structures are not known here, so nothing is read with it), else None."""
    try:
        libraries(memory_path)
        return None
    except Unavailable:
        pass
    majors = []
    for path in _candidates('avformat', {}):
        try:
            majors.append(ctypes.CDLL(path).avformat_version() >> 16)
        except (OSError, AttributeError):
            continue
    newer = [major for major in majors if major > max(KNOWN_MAJORS)]
    return max(newer) if newer else None
