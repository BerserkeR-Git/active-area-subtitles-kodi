"""The file's own keyframe index as the read-ahead uses it (KeyframeIndex): where its keyframes lie, so the sweep reads
the next one instead of guessing, and a search knows the keyframes between two read ones before it reads any.

Index times are approximate (an MP4's are decoding times, a frame or two before a keyframe's own) and a decoded
keyframe's time is the truth: a keyframe decoded at a time the index covers but does not hold ends its use for the
playback, and every decision taken from it can only read a keyframe more or place a cut earlier, never later."""

import bisect

MATCH = 0.25          # seconds an index time may lie before a decoded keyframe's own and still be that keyframe's (an
                      # MP4's decoding times with B-frames: a frame or two)
NUDGE = MATCH         # seconds past an index time a read asks for until the offset is known (at most half the gap to
                      # the next), so the seek lands on that keyframe and not the one before: an MP4's seek counts the
                      # keyframes' own times while its index lists decoding times (0.02 and 0.05 s past landed on the
                      # keyframe before with the shipped FFmpeg, 0.1 s on it)
PAST = 0.02           # seconds past a keyframe's own time a read asks for once the offset is known
SAME = 1e-6           # seconds within which a time asked for is an index time itself


class KeyframeIndex:
    """The film times of the file's keyframes, in order (at least two, increasing). A decoded keyframe at film time at
    is the index time nearest at less the file's offset (its entry), within MATCH: the offset is how far a keyframe's
    index time lies before its own (0 in Matroska, an MP4's decoding delay), learnt from the reads asked for an index
    time (lands), the largest seen (a read that gave a keyframe a frame after the one asked shows less). Until a read
    tells, the index time at or before it: with two keyframes a frame apart and an MP4's delay that may be the other's,
    and the read-ahead then stops using the index (no read is ever placed by a wrong entry)."""

    def __init__(self, times):
        self.times = list(times)
        self.offset = None          # seconds a keyframe's index time lies before its own, once a read told

    @classmethod
    def of(cls, times):
        """A KeyframeIndex of the decoder's times (filmreader.FilmReader.keyframe_times), or None where they can not
        be one: none, fewer than two, or not increasing."""
        if not times or len(times) < 2:
            return None
        try:
            times = [float(at) for at in times]
        except (TypeError, ValueError):
            return None
        if any(later <= at for at, later in zip(times, times[1:])):
            return None
        return cls(times)

    def __len__(self):
        return len(self.times)

    @property
    def apart(self):
        """Seconds between two keyframes on average."""
        return (self.times[-1] - self.times[0]) / (len(self.times) - 1)

    def covers(self, at):
        """Whether film time at lies within the index (a partial one lists the keyframes up to its last only)."""
        return self.times[0] - MATCH <= at <= self.times[-1] + MATCH

    def _entry(self, at):
        """The position of the keyframe decoded at film time at, or None where no index time is its."""
        if self.offset is None:
            number = bisect.bisect_right(self.times, at + SAME) - 1
        else:
            wanted = at - self.offset
            number = bisect.bisect_left(self.times, wanted)
            if number == len(self.times) or (number and wanted - self.times[number - 1] < self.times[number] - wanted):
                number -= 1
        if number < 0 or not -SAME <= at - self.times[number] <= MATCH:
            return None
        return number

    def matches(self, at):
        """Whether a keyframe decoded at film time at is one the index holds."""
        return self._entry(at) is not None

    def holds(self, seconds):
        """Whether film time seconds is one of the index's times."""
        number = bisect.bisect_left(self.times, seconds - SAME)
        return number < len(self.times) and abs(self.times[number] - seconds) <= SAME

    def lands(self, at, asked):
        """Whether a read asked for the keyframe at index time asked gave it (decoded at film time at): at most MATCH
        after it; the offset learnt from it."""
        if not -SAME <= at - asked <= MATCH:
            return False
        self.offset = max(self.offset or 0.0, at - asked)
        return True

    def between(self, before, after):
        """The index times of the keyframes after the one decoded at before and before the one decoded at after, in
        order; None where either is not in the index (nothing known there)."""
        first, last = self._entry(before), self._entry(after)
        if first is None or last is None:
            return None
        return self.times[first + 1:last]

    def before(self, at):
        """The index time of the keyframe just before the one decoded at at, or None."""
        number = self._entry(at)
        return self.times[number - 1] if number else None

    def next_read(self, at, step):
        """The index time of the keyframe to read after the one decoded at at: the latest at or before at + step
        where that is a later one, else the one right after it; None at the index's end, or where at is not in it."""
        number = self._entry(at)
        if number is None or number + 1 >= len(self.times):
            return None
        latest = bisect.bisect_right(self.times, at + step + SAME) - 1
        return self.times[max(latest, number + 1)]

    def after(self, seconds):
        """The first index time after film time seconds, or None."""
        number = bisect.bisect_right(self.times, seconds + SAME)
        return self.times[number] if number < len(self.times) else None

    def read_at(self, seconds):
        """The film time to ask the decoder for to read the keyframe at index time seconds, so a seek to the keyframe at
        or before lands on it (an MP4's index time lies a frame or two before the keyframe's own): once the offset is
        known, PAST after the keyframe's own time; until then NUDGE past the index time, at most half the gap to the
        next. Any other time as it is."""
        number = bisect.bisect_left(self.times, seconds - SAME)
        if number >= len(self.times) or abs(self.times[number] - seconds) > SAME:
            return seconds
        gap = self.times[number + 1] - seconds if number + 1 < len(self.times) else NUDGE * 2
        if self.offset is not None:
            return seconds + self.offset + min(PAST, gap / 2)
        return seconds + min(NUDGE, gap / 2)
