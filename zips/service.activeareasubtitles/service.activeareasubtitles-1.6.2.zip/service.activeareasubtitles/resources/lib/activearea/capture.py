"""Kodi's frame grab: KodiScreen, the one Kodi adapter of the screen route (measure.screen); first_look, a PC's one
grab as its first estimate; and ScreenReader, the scene follower's readings on a PC (the grab reader's picture, placed
on time by the film's scene map), read by the follow loop as it reads the live labels reader (labels.Reader) and told
the rest by screenfollow.ScreenFollowing. first_look and the grab reader read the screen through measure.look and
measure.exact_picture, the screen route's own one look. Kept outside the detector's modules (shapes.DETECTOR_MODULES),
so a change here measures no cached shape again. The tests hand a list of frames instead. Loads without Kodi: the log
is handed in.
"""
import time

from . import detect, measure, pictures, scenemap

SCREEN_SETTLE = 1.0           # the longest Kodi gets to render into a capture: it hands it over as soon as it has (30
                              # to 85 ms in the test rig). A fixed 0.15 s first is too short under load: the grabs come
                              # back empty, nothing measured


class KodiScreen:
    """Kodi's frame grab (xbmc.RenderCapture), the screen route's adapter; the tests hand screen a list of frames
    instead. grab(width, height) -> (the frame Kodi rendered into a capture that size, empty when none came within
    SCREEN_SETTLE, whether Kodi is closing); width() -> the screen's own width, or None when Kodi can not say."""

    def __init__(self, wait):
        import xbmc   # only here: the module loads without Kodi (test_measure reads SCREEN_SETTLE on its own)
        self._xbmc, self._wait = xbmc, wait

    def grab(self, width, height):
        capture = self._xbmc.RenderCapture()
        capture.capture(width, height)
        frame = capture.getImage(int(SCREEN_SETTLE * 1000))
        del capture                       # releasing it stops Kodi copying frames
        return frame, not frame and self._wait(0.001)

    def width(self):
        try:
            return int(self._xbmc.getInfoLabel('System.ScreenWidth'))
        except Exception:  # Kodi could not say: the small grab's answer stands
            return None


def first_look(screen, video_ratio):
    """One grab as a first estimate for a PC that reads the file first (its first keyframe waits for smooth
    playback): the picture with its exact edge where that is strongly lit, when the grab is clear and strongly lit;
    else None. One grab is no answer (measure.screen wants AGREEING_SAMPLES); the measurement confirms or corrects it."""
    _frame, _width, _height, sample = measure.look(screen, video_ratio)
    if not (sample.clear and sample.strong):
        return None
    return measure.exact_picture(screen, video_ratio, sample) or detect.shape(sample, video_ratio)


def finer_rows(screen, video_ratio, shape):
    """The rows of the full-size grab Kodi's window allows now, where they are more than those of the smaller screen
    grab that read shape's rows (pictures.Grabbed); else 0. Never the file's edges (exact at its rows), nor a picture
    without bars; nothing asked of Kodi for a shape read at the largest grab already."""
    if not pictures.from_grab(shape) or not (shape.top or shape.bottom) \
            or shape.height >= int(round(measure.SCREEN_EXACT_WIDTH / video_ratio)):
        return 0
    width = screen.width()
    rows = int(round(min(width, measure.SCREEN_EXACT_WIDTH) / video_ratio)) if width else 0
    return rows if rows > shape.height else 0


def read_finer(screen, video_ratio, shape):
    """shape's picture read again in one full-size grab, taken at a strongly lit small look of it (exact_bars reads
    between that look's analysed rows); None when the look is not strongly lit or shows another picture (nothing
    grabbed at full size), shape itself when the full-size grab gave no edge of that picture."""
    _frame, _width, _height, sample = measure.look(screen, video_ratio)
    if not (sample.clear and sample.strong) or not pictures.same(detect.shape(sample, video_ratio), shape):
        return None
    finer = measure.exact_picture(screen, video_ratio, sample)
    return pictures.grabbed(finer) if finer is not None and pictures.same(finer, shape) else shape


FAST_STEP = 0.1               # seconds between a look and the next on a PC (with the grab, a look about every 0.15 s)
SLOW_STEP = 0.85              # the same where no cut is to be expected (a look about every second): until a film shows a
                              # second shape where a move waits for the next line anyway, and with a scene map away from
                              # its cuts (ScreenReader.pace)
NARROWER_GRABS = 2            # strongly lit grabs in a row that agree on a narrower picture never seen before the text
                              # moves down; one is enough for a shape the film is known to show
DIM_NARROWER_GRABS = 3        # dimly lit grabs in a row that agree on a narrower picture
EMPTY_FOR = 10.0              # seconds of grabs with no image, none with one before in the playback, after which Kodi's
                              # grab gives nothing here (a renderer without a capture: DRM PRIME, Android's MediaCodec
                              # surface); a seek empties them for a moment only
EMPTY_STEP = 10.0             # seconds between looks then (each costs Kodi an error line in its log): the first grab with
                              # an image brings the pace back
ANCHOR_EVERY = 2.0            # seconds between two questions for the film's time while a PC follows (counted between
                              # them; at 30 s fast forward, a tempo, a seek no look saw would leave every planned move
                              # off that long); at every look for FRESH seconds after a start or a hold
FRESH = 1.5
FRESH_STEP = 0.0              # meanwhile at every look
FRESHEST = 20.0               # seconds of answers the count is taken from: the freshest of them (Kodi's answer is the
                              # time at its last update, every 0.2 s: 0 to 0.2 s old, more under load; re-taken at
                              # random ones, the count would hop 0.2 s and planned moves with it)
ANSWER_JUMP = 0.5             # seconds an answer can be off the count before it says the film jumped, went slower or
                              # back
LAG_MOST = 0.25               # seconds an answer lags the count at most while the film plays on (Kodi's update step, 0.2
                              # s, and a little): two in a row further behind and the film stood still a moment
STALL_BACK = 3 * ANCHOR_EVERY + ANSWER_JUMP   # seconds before the count starts over behind itself within which the
                              # screen's lead may have been measured against a count running on through a stall: the
                              # second answer behind comes at most three questions after the stall began, and the
                              # stall lasted ANSWER_JUMP at most (a longer one starts the count over at one answer)
SHOWN_AHEAD = 0.1             # seconds the picture on screen is ahead of the film's time Kodi gives, until the grabs
                              # measured it at the cuts of a map read from the file (in the test rig 0.10 to 0.14 s,
                              # five cuts agreeing); SHOWN_AHEAD_MOST the most believed
SHOWN_AHEAD_MOST = 0.5
PROBE_LATE = 0.03             # seconds a probe's grab may hold a move into a narrower picture up, at most (about a frame)
SLOW_GRAB_KEPT = 3.0          # seconds a slow grab keeps the probes off (about 20 looks): a probe's grab as slow would hold
                              # the move into a narrower picture up by as much
PROBE_FIRST = 0.25            # seconds of lead the first probe tests
SHOWN_AHEAD_LEAST = -0.2      # seconds: the least lead believed, a picture behind Kodi's time (a display latency
                              # setting); the probes measure it, as a lead taken for 0 there brings every move down
                              # early, into the bar
SHOWN_KEPT = 8                # the latest cuts it is measured from
SHOWN_TIGHT = 0.1             # seconds between the bounds from which the lead is taken halfway between them
DUE_SLACK = 0.02              # seconds a wake for a planned move may come before it and still count as at it
HOLD_JUMP = 2.0               # seconds the film's time moved across a hold beyond which it was a seek: what the grabs
                              # showed before it says nothing of where playback went
SEEK_ANSWER_WAIT = 3.0        # seconds after a seek reaches the follower (ScreenReader.landing) within which a move into a
                              # narrower picture waits for Kodi's time to leave the place before the seek: until then the
                              # screen still shows the frame from before it (in the test rig under load the time moved
                              # 1.1 to 1.4 s after the seek began, the new picture 0 to 0.25 s after it). A time that
                              # never moves holds nothing down for longer
PLANNED_NEAR = 1.0            # seconds before a planned move into a narrower picture from which the follower waits for
                              # it, grabbing nothing but its probe (ScreenReader._next_look): a look with its grab takes
                              # 0.3 to 0.4 s in the test rig, and one ending past the cut sees it first, the move then
                              # late by the rest of that look


class GrabReader:
    """Kodi's rendered picture as scene readings for the scene follower on a PC, which has no Level 5 labels: one small
    grab a look (KodiScreen, as the screen route's), analysed as the screen route does. read() gives the picture the
    text should be placed for, with a note for the log. A wider picture (into a scope scene, where a lower text would
    sit in the bar) counts at the first strongly lit grab; a narrower one (into a tall scene, where the text stays
    inside the picture meanwhile) at the first strongly lit grab when the film is known to show that shape (seen before,
    read from the file, in the scene map), else once NARROWER_GRABS strongly lit grabs in a row agree on it. A dimly lit
    grab moves the text up only to a wider shape already seen (a dark scope scene after a tall one), and down once
    DIM_NARROWER_GRABS of them in a row agree (a dark IMAX scene with nobody talking, so the text is down before the
    next line), to a shape never seen too, placed but not learned until a lit grab shows it (provisional); at once
    where it reads the narrower picture a map's silent span leads into (read's coming) and the picture placed is not
    lit either (a dark scene, no dissolve). A dim grab can read a bar too wide, never picture where the bars are
    black. In the real-film corpus no strongly lit reading showed its picture taller than it is by more than a grab
    row, so a steady film never moves. The first time a shape is seen, one full-size grab finds its exact edge
    (measure.exact_picture); every later visit uses it, unless that grab was smaller than Kodi's window allows now
    (finer)."""

    def __init__(self, screen, video_ratio, placed):
        """screen: the grab (KodiScreen); placed: the picture placed now (the measured shape, with its bars)."""
        self._screen, self._video_ratio = screen, video_ratio
        if not hasattr(placed, 'top'):           # a shape without its bars (no exact grab came back): none known
            placed = detect.Picture(float(placed), 0, 0, 0)
        self.picture = placed
        self.known = pictures.Versions([placed])
        self._candidate, self._count = None, 0
        self.run_back = 0               # looks since the first grab of the run that changed picture last
        self._exact = pictures.Versions()   # the known shapes the file gave (its keyframes, the settled shape)
        self.lit = None                 # the latest picture a strongly lit grab showed, and its count of such grabs
        self.provisional = False        # picture is a taller one only dim grabs showed, never seen lit (not known)
        self.lit_sightings = 0
        self.at_edge = False            # the latest grab read the full picture from its edge alone (read), for the log
        self.clear = False              # the latest grab showed a picture (a black or empty one says nothing)
        self.empty = False              # the latest grab came back with no image at all
        self._finer_tried = set()       # (shape's rows, full-size grab's rows) read again once each (finer)

    def read(self, coming=None):
        """(the picture to place for, ('picture', its shape) for the log); coming: the narrower picture a map's silent
        span leads into where this grab is taken, or None. An unclear grab whose picture reaches the
        frame's top or bottom edge through the thinnest bar of every letterboxed picture known (detect.lit_edges) is a
        strongly lit grab of the full picture: a 16:9 IMAX scene lit only at one edge (sky at the top, the ground below
        as dark as a bar) reads 'not symmetric', and the text would stay at the scope height until its bottom lit up
        (10 s on a PC). A letterboxed picture's bar there is black, so it is none of them; with bars at both edges in
        each, it is the full one (pictures.lit_at_edge, as for the file's frames in lookahead.FrameJudge)."""
        frame, width, height, sample = measure.look(self._screen, self._video_ratio)
        self.empty = sample.reason.startswith('no image')
        if not sample.clear and pictures.lit_at_edge(frame, width, height, 4, self.known + [self.picture],
                                                     self._video_ratio):
            sample = detect.Sample(True, 0, 0, height, 'picture at the frame\'s edge', exact=True)
        self.at_edge = sample.reason == 'picture at the frame\'s edge'
        self.clear = sample.clear
        if sample.clear:
            if coming is not None and not sample.strong and self._placed_lit(frame, width, height, sample):
                # A dissolve, no dark scene: the picture placed still lit inside the dim one fading in through its
                # bars, which are nearly black yet (a night scene's few lights read as a dim taller picture).
                coming = None
            self._judge(sample, coming)
        return self.picture, ('picture', round(float(self.picture), 2))

    def _placed_lit(self, frame, width, height, sample):
        """Whether the rows of the picture placed now next to its bars are strongly lit in this grab, as
        detect.analyse's strong edge is: lit across (detect.EDGE_COVERAGE of the row) above the level a bar row may
        reach by detect.BAR_NOISE // 2."""
        picture = self.picture
        if pictures.has_rows(picture):
            top, bottom = (int(round(rows * height / picture.height)) for rows in (picture.top, picture.bottom))
        else:
            top = bottom = int(round(height * (1 - self._video_ratio / float(picture)) / 2))
        rows = (min(height - 1, top + 1), max(0, height - 2 - bottom))      # a row inside each edge
        level = min(255, sample.black + detect.BAR_NOISE // 2)
        return all(sum(1 for green in frame[row * width * 4 + 1:(row + 1) * width * 4:4] if green > level)
                   >= detect.EDGE_COVERAGE * width for row in rows)

    @staticmethod
    def note(shown):
        return 'picture %.2f on screen' % shown[1]

    def prefer(self, shape):
        """The file analysis' settled shape: it replaces the same picture among the known ones (a keyframe's too: the
        settled shape takes the taller bar on each side among them), and the picture placed now when that is the one."""
        self._replace(shape)

    def from_file(self, shapes):
        """Keyframe shapes the file analysis read with an exact edge: each replaces what the grabs, the map or the
        estimate knew of the same picture (the decoder's edges, not the small grab's), unless the file gave that
        picture already."""
        for shape in shapes:
            if pictures.has_rows(shape) and self._exact.find(shape) is None:
                self._replace(shape)

    def _replace(self, shape):
        self.known.put(shape)
        self._exact.put(shape)
        if pictures.same(shape, self.picture):
            self.picture = shape
        if self.lit is not None and pictures.same(shape, self.lit):
            self.lit = shape

    def version(self, picture):
        """This reader's version of picture: the known shape of the same picture (the settled shape, the file's edges
        before a map's or a grab's), so one picture is placed at one margin whichever map or grab names it (a row-less
        shape from a grab, or a keyframe's edges a row apart, would place it a step higher)."""
        # Rows over none: a planned picture with its rows over a known one without (a row-less first estimate must
        # not replace the map's exact edges).
        return pictures.version(picture, self._exact, self.known)

    def learn(self, shapes):
        """Shapes known from before (a scene map): a grab of the same picture places that shape's own edges."""
        self.known.extend([shape for shape in shapes if self.known.find(shape) is None])

    def _judge(self, sample, coming=None):
        ratio = detect.shape(sample, self._video_ratio)
        known = self.known.find(ratio)
        if known is None and not sample.strong and ratio > float(self.picture):
            # A dim reading wider than the picture placed and like no shape known: it reads a bar too wide, so the
            # picture is one no wider than it; the widest known such shape wider than the one placed (a dark scope
            # scene after a tall one reads 2.45 for 2.39, and the text would stay in its bar).
            wider = [shape for shape in self.known
                     if pictures.wider(shape, self.picture) and float(shape) <= ratio * 1.02]
            known = max(wider, key=float) if wider else None
        if sample.strong:
            self.lit = known or detect.Picture(ratio)   # the grab's rows are analysed ones: its shape
            self.lit_sightings += 1
        if pictures.same(ratio, self.picture):
            self._candidate = None
            if self.provisional and sample.strong:
                self._confirm(known, ratio, sample)     # now seen lit: known, with its edges
            elif sample.strong:
                # At a look that moves nothing: a move into a wider picture never waits for the full-size grab.
                self.picture = self._finer(self.picture, sample)
            return
        if ratio > float(self.picture):              # wider
            self._candidate = None
            if sample.strong:
                self._confirm(known, ratio, sample)
            elif known is not None:
                self.picture, self.run_back, self.provisional = known, 0, False
            return
        if self._candidate is not None and pictures.same(ratio, self._candidate):
            self._count += 1
        else:
            self._candidate, self._count = ratio, 1
        # A dim grab of a shape never seen counts too: it can read a bar too wide, never picture in a bar, so the
        # picture is at least that tall (a dark IMAX scene on a first playback would keep the scope height until lit).
        needed = (NARROWER_GRABS if sample.strong else DIM_NARROWER_GRABS) if known is None \
            else 1 if sample.strong else DIM_NARROWER_GRABS
        if known is not None and coming is not None and pictures.same(known, coming):
            # The map says this picture comes after its silent span, and a dim reading is no taller than the picture:
            # one such grab is that picture (a dark first shot's three took the text down 0.35 to 0.54 s late).
            needed = 1
        if self._count >= needed:
            self._confirm(known, ratio, sample, self._count - 1)

    def _confirm(self, known, ratio, sample, back=0):
        self._candidate, self.run_back = None, back
        if known is None and not sample.strong:
            # Placed, not known: a dim reading may still be a little wide of the picture (a lit grab finishes the
            # move), and neither the map nor the next epoch learns it.
            self.picture, self.provisional = detect.Picture(ratio), True
            return
        if known is None:
            # A grab with its edges in its own rows (the full picture lit at one edge) needs no full-size one.
            known = (detect.picture_of(sample, self._video_ratio) if sample.exact
                     else measure.exact_picture(self._screen, self._video_ratio, sample)) or detect.Picture(ratio)
            self.known.append(known)
        self.picture = known
        self.provisional = False

    def _finer(self, shape, sample):
        """shape, or the same picture read again in one full-size grab where its rows came from a grab smaller than
        Kodi's window allows now (read in a smaller window, kept in a map from one): a grab's edge row that is partly
        picture reads as picture, so its bars read up to one of its rows thin, and at 720 rows that is a row at 2160
        under the distance on the full screen. Once for each shape and size; never the file's edges, nor a picture
        without bars (the full one read at the frame's edge: its rows are exact at any size)."""
        best = int(round(measure.SCREEN_EXACT_WIDTH / self._video_ratio))
        if not pictures.has_rows(shape) or shape.height >= best or not (shape.top or shape.bottom) \
                or self._exact.find(shape) is not None:
            return shape
        width = self._screen.width()
        rows = int(round(min(width, measure.SCREEN_EXACT_WIDTH) / self._video_ratio)) if width else 0
        tried = (shape.top, shape.bottom, shape.height, rows)
        if rows <= shape.height or tried in self._finer_tried:
            return shape
        self._finer_tried.add(tried)
        finer = measure.exact_picture(self._screen, self._video_ratio, sample)
        if finer is None or not pictures.same(finer, shape):
            return shape
        self.known.put(finer)
        self.lit = finer                # the look that read it again saw this very picture lit (_judge)
        return finer


class _FilmClock:
    """The film's time for the scene map without asking Kodi at every look: Kodi logs an error for a position asked
    as playback ends (between "is it playing" and the question, seen in the test rig).
    Counted on the service's clock from the freshest answer of the last FRESHEST seconds: Kodi's answer is never ahead
    of the film, only late by up to its update step, so the answer that puts the film furthest on is the nearest.
    Asked at every look for FRESH seconds after a start or a hold (answers at many phases of Kodi's step), then every
    ANCHOR_EVERY; an answer more than ANSWER_JUMP behind the count, or a jump ahead, starts over (a seek no look saw, a
    slower film), as do two answers in a row more than LAG_MOST behind it (a stall Kodi does not report as holding:
    the answers before it would put the film on by the stall for FRESHEST seconds, every planned move that much
    early). answer(): Kodi's own answer, asked now (a move into a narrower picture waits for it,
    ScreenReader._confirmed: the count runs on through a stall's first answers). hop(): how far the count moved since
    the last call (the screen's lead was measured against it)."""

    def __init__(self, ask, clock):
        self._ask, self._clock = ask, clock
        self._answers = []              # (the service's clock, the answer less it), the latest FRESHEST seconds
        self._asked = self._fresh_until = None
        self._answer = None             # Kodi's latest answer
        self._best = None
        self._hop = 0.0
        self._behind = False            # the last answer lagged the count by more than LAG_MOST
        self._went_back = None          # the service's clock when the count last started over behind itself

    def hold(self):
        self._answers, self._best = [], None

    def now(self):
        counted = self._clock()
        every = FRESH_STEP if self._fresh_until is not None and counted < self._fresh_until - 1e-6 else ANCHOR_EVERY
        if self._best is None or self._asked is None or counted - self._asked >= every - 1e-6:
            if self._take(counted) is None:
                return None
        return counted + self._best

    def answer(self):
        """Kodi's own answer asked now (or None where it can not say), taken into the count as now() takes one; one
        question at a moment of the service's clock."""
        counted = self._clock()
        if self._asked is None or counted > self._asked:
            self._take(counted)
        return self._answer

    def _take(self, counted):
        """Kodi asked at clock time counted; its answer, or None (the count gone: hold)."""
        at = self._answer = self._ask()
        self._asked = counted
        if at is None:
            self.hold()
            return None
        offset = at - counted
        behind = self._best is not None and offset < self._best - LAG_MOST
        stalled, self._behind = behind and self._behind, behind
        if (self._best is None or offset < self._best - ANSWER_JUMP or offset > self._best + ANSWER_JUMP
                or stalled):
            # The start, a hold, a jump, another speed, a stall.
            if self._best is not None and (stalled or offset < self._best - ANSWER_JUMP):
                self._went_back = counted
            self._answers, self._fresh_until, self._behind = [], counted + FRESH, False
        self._answers = [answer for answer in self._answers if counted - answer[0] <= FRESHEST]
        self._answers.append((counted, offset))
        best = max(answer[1] for answer in self._answers)
        # A hop only once settled: while FRESH answers bring a count begun stale up to the freshest, what was
        # measured against the freshest count before the hold holds for it again.
        if self._best is not None and abs(best - self._best) < ANSWER_JUMP and counted >= self._fresh_until:
            self._hop += best - self._best
        self._best = best
        return at

    def hop(self):
        hop, self._hop = self._hop, 0.0
        return hop

    def ask(self):
        """Kodi's own answer asked now, not taken into the count (one at a seek's target while the landing does not
        show yet is ahead of the film), or None where it can not say."""
        return self._ask()

    def went_back(self):
        """The service's clock when the count last started over behind itself (Kodi's time stood still a moment while
        it ran on: a stall it does not report, or the film went slower or back unseen), once; else None."""
        went, self._went_back = self._went_back, None
        return went

    def peek(self):
        """The counted film time without asking Kodi (for the log, also while it holds), or None."""
        if self._best is None:
            return None
        return self._clock() + self._best


class ScreenLead:
    """How far the picture on screen runs ahead of Kodi's film time (a display's latency, Kodi's own step): SHOWN_AHEAD
    until the grabs measured it at the cuts of a map read from the file, then from the bounds each such cut gives (the
    latest SHOWN_KEPT of each kind, the older going where two disagree), never outside SHOWN_AHEAD_LEAST and
    SHOWN_AHEAD_MOST. value is the lead now; probe_target() the lead the next probe's grab tests."""

    def __init__(self):
        self.value = SHOWN_AHEAD
        self._low, self._high = [], []          # [order, seconds]: the latest bounds, in the order measured
        self._order = 0
        self._kept = []                         # (the service's clock, value, low, high) before each measure: undo

    def bounds(self):
        """(the least the lead can be, the most it can be), each None until a cut bounded it."""
        return (max(low for _order, low in self._low) if self._low else None,
                min(high for _order, high in self._high) if self._high else None)

    def measure(self, cut, seen_at, before_at, probe=False, when=None):
        """A cut at film time cut, known to the frame: the grab at film time seen_at showed its new picture, so the
        screen was past the cut (ahead by at least cut - seen_at); the look at before_at (None: no look before it)
        still showed the old one (ahead by less than cut - before_at). A pair no screen can give (behind Kodi, or more
        than SHOWN_AHEAD_MOST ahead) is not taken. probe: the grab was a probe's (pace), which bounds the lead either
        way. when: the service's clock at the sighting, so undo can take it back. True when the lead moved by a log's
        worth (5 ms)."""
        low, high = cut - seen_at, None if before_at is None else cut - before_at
        if low > SHOWN_AHEAD_MOST or (high is not None and (high < SHOWN_AHEAD_LEAST or before_at >= seen_at)):
            return False
        if when is not None:
            self._kept = (self._kept + [(when, self.value, [list(bound) for bound in self._low],
                                         [list(bound) for bound in self._high])])[-SHOWN_KEPT:]
        # Each bound on its own: a grab after the cut (none is taken in the second before a planned move but the probe,
        # pace) bounds the lead below by less than nothing and says nothing; the measure would fall to 0 at the first
        # cut on it, every planned move then a few frames late. A probe's says it either way: a screen behind Kodi's
        # time is measured from it.
        if low >= 0 or (probe and low >= SHOWN_AHEAD_LEAST):
            self._order += 1
            self._low = (self._low + [[self._order, low]])[-SHOWN_KEPT:]
        # A high beyond the most a screen leads says nothing, and would push the telling ones out (the look a second
        # before each planned move gives 0.8 to 1.0 s in the film simulator).
        if high is not None and high <= SHOWN_AHEAD_MOST:
            self._order += 1
            self._high = (self._high + [[self._order, high]])[-SHOWN_KEPT:]
        # Bounds that disagree: the older of the two goes (the lead changed, or one was measured wrong).
        while self._high and self._low:
            least = max(self._low, key=lambda bound: bound[1])
            most = min(self._high, key=lambda bound: bound[1])
            if least[1] <= most[1]:
                break
            (self._low if least[0] < most[0] else self._high).remove(least if least[0] < most[0] else most)
        # The default where the bounds allow it, else a little inside the one it breaks; halfway between them once the
        # probes closed them in to SHOWN_TIGHT (a loose high from the look a second before a move, halved with a low,
        # says 0.5 s in the film simulator).
        low, high = self.bounds()
        guess = SHOWN_AHEAD
        if high is not None:
            guess = min(guess, high - 0.02)
        if low is not None:
            guess = max(guess, low + 0.02)
        if low is not None and high is not None and high - low <= SHOWN_TIGHT:
            guess = (low + high) / 2
        ahead = max(SHOWN_AHEAD_LEAST, min(guess, SHOWN_AHEAD_MOST))
        moved = abs(ahead - self.value) >= 0.005
        self.value = ahead
        return moved

    def shift(self, hop):
        """The count moved by hop (a fresher answer of Kodi's, _FilmClock): the lead measured against the old count is
        that much less against the new one."""
        if hop:
            self._low = [[order, low - hop] for order, low in self._low]
            self._high = [[order, high - hop] for order, high in self._high]
            self.value = max(SHOWN_AHEAD_LEAST, min(self.value - hop, SHOWN_AHEAD_MOST))
            self._kept = [(when, max(SHOWN_AHEAD_LEAST, min(value - hop, SHOWN_AHEAD_MOST)),
                           [[order, bound - hop] for order, bound in low],
                           [[order, bound - hop] for order, bound in high])
                          for when, value, low, high in self._kept]

    def undo(self, since):
        """The lead as it was before the first sighting at or after the service's clock since, with the bounds those
        sightings pushed out (measured against a count that ran on through a stall, each was late by it): True when
        any went."""
        undone = [entry for entry in self._kept if entry[0] >= since - 1e-6]
        if not undone:
            return False
        _when, self.value, self._low, self._high = undone[0]
        self._kept = [entry for entry in self._kept if entry[0] < since - 1e-6]
        return True

    def forget(self):
        """Another layout (Kodi's window changed): its picture may run ahead by another lead; the one believed is where
        it starts, every bound gone."""
        self._low, self._high, self._kept = [], [], []

    def probe_target(self):
        """The lead the next probe tests: PROBE_FIRST before anything is bounded (a screen further ahead is learnt at
        once, and one less far leaves the default as it is: an upper bound above it changes nothing), then halfway
        between the least and the most still possible, a halving search over the film's cuts."""
        if not (self._low or self._high):
            return PROBE_FIRST
        low, high = self.bounds()
        low = SHOWN_AHEAD_LEAST if low is None else low
        high = SHOWN_AHEAD_MOST if high is None else high
        return max(SHOWN_AHEAD_LEAST, min((low + high) / 2, SHOWN_AHEAD_MOST))


class ScreenReader:
    """The scene follower's readings on a PC. The follow loop reads it as it reads the live labels reader (labels.Reader):
    read(), note(shown), pace(), film_time(), verifiable, and landing(target) at a seek; the PC's following
    (screenfollow.ScreenFollowing) tells it the rest: settled(picture), only_wider, hold(), placed(picture),
    widened(picture), resume(moves_shown), on_screen(moves_shown), shapes(), keep(memory, stopping). Behind it the grab
    reader (GrabReader) and the film's scene map (scenemap.py): the one a playback before recorded, which places the
    text on time, and the one this playback records from the screen, kept with the file when following ends. Built on
    the follower's own thread: the CPU its looks cost, for the log, is this thread's."""

    verifiable = False               # a reading is no Level 5: nothing a keyframe could be held against

    def __init__(self, screen, video_ratio, placed, film_time, clock, log, known=None, decoded=(),
                 moves_shown=False, seen=(), live=None):
        """screen: the grab (KodiScreen); placed: the picture placed now (the measured shape, with its bars);
        film_time() -> the playing position in seconds or None (asked through _FilmClock on clock()); log(line,
        always): the add-on's log; known: the scene map from the cache, or None; decoded: the pictures the file
        analysis read with an exact edge (the grabs tell which shows, the decoder gave its edges), or a function giving
        them as they are read (a follower started before the measurement settled); moves_shown: a new margin moves the
        line on screen (Kodi's Manual position), so the map moves the text just before a cut; seen: the shapes a
        follower of this film saw before (an earlier epoch's: a window changed, another track); live(): the scene map
        read from the file ahead of playback (lookahead.Lookahead.map), or None: before the cache's map where it says
        anything, and its cuts at their frames."""
        self._grabs = GrabReader(screen, video_ratio, placed)
        self._decoded = decoded if callable(decoded) else (lambda: decoded)
        self._grabs.from_file(self._decoded())
        self.known = known
        self._live = live or (lambda: None)
        self._due_at = None                      # the film time of the planned move woken for: placed before any grab
        self._returned = None                    # the picture read() gave last
        self._placed = None                      # the picture the follower placed last (placed)
        self._lead = ScreenLead()                # the picture on screen ahead of Kodi's film time (measured, _measure)
        self._probing = False                    # the next look is a probe's (pace): its sighting bounds the lead
                                                 # either way
        self._slowest_grab = 0.0                 # seconds the slowest grab of this playback took: how long a look may
                                                 # take before a move into a wider picture (a rare slow grab comes back)
        self._slow_grab = (0.0, None)            # (seconds, the service's clock): the slowest grab of the last
                                                 # SLOW_GRAB_KEPT, how long a probe's may take (judged by the slowest of
                                                 # the playback, one slow grab would end the probes for good)
        self._shown = ('picture', round(float(self._grabs.picture), 2))
        self._moves_shown = moves_shown
        self.recording = scenemap.SceneMap()
        # The latest picture a strongly lit grab showed, its film time, and the grab reader's count of such grabs then:
        # the evidence against the maps (a dim grab can read a dark IMAX scene as wide as scope). The picture placed
        # when the reader was built is no sighting (the measured shape written again after Kodi's window changed, or a
        # cached one at a resume, counted as a lit grab at the first look's film time, would keep a dark IMAX scene at
        # the scope height).
        self._lit, self._lit_at, self._lit_sightings = None, None, self._grabs.lit_sightings
        self._at = None                          # the film's time at the last look
        self._held_at = None                     # the film's time when Kodi last held, until the next look
        self._grab_change_at = None              # the film's time the grab reader's picture last changed
        self._since = None                       # the film's time playback has run on from (this reader's first look, a
                                                 # seek's landing): what a map read before it ended on says nothing now
        self._clock = _FilmClock(film_time, clock)
        self._now = clock
        self._times = []                         # the service's clock at the latest looks whose grab showed a picture
                                                 # (how long a change took, and the look before it)
        self._change = None                      # (grabs, seconds from the first to now, seconds from the look before)
        self._log = log
        self._widest = placed                    # a wider shape seen while following is the one the cache keeps
        self.source = 'grabs'                    # what placed the latest picture read: grabs, read ahead, cached map
        self.only_wider = False                  # only a picture wider than the measured one moves the text: slow pace
        self.looks = 0
        self._cpu = time.thread_time()
        self._imaged = False                     # a grab of this playback came back with an image
        self._empty_since = None                 # the service's clock at the first of the empty grabs in a row
        self._empty_told = False
        self._seek_from = None                   # (Kodi's answer when a seek reached the follower, the service's clock
                                                 # then) until that answer moves (_seek_stands)
        if known:
            self._grabs.learn(known.shapes)      # one shape, one margin: the map's exact edges for what the grabs see
        self._grabs.learn(seen)

    def read(self):
        """(the picture to place for, ('picture', the grab reader's shape) for the log): the map's plan for the film
        time now (scenemap.SceneMap.plan, with the latest lit grab's picture as evidence; a move into a narrower picture
        once Kodi's own answer reaches it, _confirmed), else the grab reader's picture (outside the map, or without a
        film time: Kodi could not say). After a seek nothing narrower than the picture placed while Kodi's time still
        stands at the place before it (_seek_stands): the grab shows the frame from before the seek, the plan that
        place."""
        stands = self._seek_stands()
        picture, shown = self._read()
        placed = self._placed
        if stands and placed is not None and picture is not None and pictures.narrower(picture, placed):
            self._returned = picture = placed
        return picture, shown

    def _seek_stands(self):
        """Whether Kodi's time still stands where it was when the latest seek reached the follower (landing), for
        SEEK_ANSWER_WAIT at most; asked at each look until it moves. The grabs go on meanwhile: one held back until the
        time moves would come just before the new picture, which shows up to a quarter of a second after it in the
        test rig, and the next grab a whole look later."""
        if self._seek_from is None:
            return False
        before, since = self._seek_from
        answer = self._clock.ask()
        if answer is None or abs(answer - before) > 0.001 or self._now() - since >= SEEK_ANSWER_WAIT:
            self._seek_from = None
            return False
        return True

    def _read(self):
        self._grabs.from_file(self._decoded())   # the file analysis may have read more meanwhile
        live = self._live()
        if live:
            self._grabs.from_file(live.shapes)   # the shapes read ahead: known, with the file's edges
        self._change = None
        if self._due_at is not None:
            # Woken for a move a map planned: placed now, the grab at the next look (its wait would make it late). At
            # the planned moment itself at least (the count can land a hair before it).
            due, self._due_at = self._due_at, None
            now = self._clock.now()
            if now is not None:
                # Woken early (Kodi asked again, the count moved), never planned ahead of the time it is.
                planned = self._plan(due if 0 <= due - now <= DUE_SLACK else now, grabbed=False)
                if planned is not self._returned:
                    self._returned = planned
                    return planned, self._shown
        before = self._grabs.picture
        probing, self._probing = self._probing, False
        grabbed_at = self._now()                 # the grab shows the screen as it is when it begins
        # Inside a silent span of a map, the narrower picture it leads into: one dim grab of that picture is enough.
        counted = self._clock.peek()
        _picture, shown = self._grabs.read(None if counted is None else self._plans().silent_into(counted))
        took = self._now() - grabbed_at
        self._slowest_grab = max(self._slowest_grab, took)
        slow, slow_at = self._slow_grab
        if slow_at is None or took >= slow or grabbed_at - slow_at > SLOW_GRAB_KEPT:
            self._slow_grab = (took, grabbed_at)    # a slower one, or the old one aged out: the latest stands
        self._shown = shown
        self.looks += 1
        if not self._grabs.empty:
            self._imaged, self._empty_since = True, None
        elif self._empty_since is None:
            self._empty_since = grabbed_at
        if self._grabs.clear:
            # A black grab is no sighting of the picture before a cut: one just after a cut into a scene that opens on
            # black frames, counted as the look before, bounded the screen's lead too low for the rest of the playback.
            self._times = (self._times + [grabbed_at])[-(DIM_NARROWER_GRABS + 1):]
        at = self._clock.now()
        self._lead.shift(self._clock.hop())
        went_back = self._clock.went_back()
        if went_back is not None and self._lead.undo(went_back - STALL_BACK):
            # The film stood still a moment while the count ran on: a lead measured meanwhile was measured against it.
            self._log('scenes: the picture on screen %.2f s ahead of Kodi\'s time again, after a stall'
                      % self._lead.value)
        if self._grabs.picture is not before:
            self._grab_change_at = at
            grabs = self._grabs.run_back + 1
            first = self._times[-grabs] if grabs <= len(self._times) else None
            gap = self._times[-grabs - 1] if grabs < len(self._times) else None
            self._change = (grabs, None if first is None else self._now() - first,
                            None if first is None or gap is None else first - gap)
            if at is not None and self._change[1] is not None:
                # The film time of the change's first grab and of the look before it, counted back on the service's
                # clock.
                first_at = at - self._change[1]
                self._measure(first_at, None if self._change[2] is None else first_at - self._change[2],
                              probing and grabs == 1)
        self._returned = self._plan(at)
        return self._returned, shown

    @property
    def shown_ahead(self):
        """Seconds the picture on screen is ahead of Kodi's film time (ScreenLead), as believed now."""
        return self._lead.value

    @shown_ahead.setter
    def shown_ahead(self, seconds):
        """A lead given instead of measured: the tests set one to see what the plans and the probes do with it (a
        measured one needs a map known to the frame and grabs around its cut)."""
        self._lead.value = seconds

    def _measure(self, seen_at, before_at, probe=False):
        """The screen's lead measured at a cut a map read from the file knows to the frame (ScreenLead.measure): the
        grab at film time seen_at showed the grab reader's new picture, the look at before_at the old one; the cut is
        the one into that picture nearest the sighting."""
        live = self._live()
        if not live or not live.exact:
            return
        picture = self._grabs.picture
        # Only cuts at their frames: a stretch's first entry is where reading began (in the film simulator a stretch
        # begun after a fall behind measured the lead at 0.23 s, and planned moves came early, one into the bar), and a
        # coarse cut lies up to a keyframe gap before its frame.
        cuts = [when for when, index in live.at_frames() if abs(when - seen_at) < 1.0
                and pictures.same(live.shapes[index], picture)]
        if not cuts:
            return
        cut = min(cuts, key=lambda when: abs(when - seen_at))
        if self._lead.measure(cut, seen_at, before_at, probe, when=self._now()):
            self._log('scenes: the picture on screen %.2f s ahead of Kodi\'s time' % self._lead.value)

    def _plans(self):
        return scenemap.Plans(self._live(), self.known, self._moves_shown, self.shown_ahead)

    def _plan(self, at, grabbed=True):
        grabs = self._grabs
        if at is not None and self._held_at is not None:
            if abs(at - self._held_at) > HOLD_JUMP:
                # A seek: what the grabs showed before it says nothing of where playback went (in the film simulator a
                # lit scope grab from before a rewind held the text at the scope height for 6 s over the map's dark tall
                # scene it landed in).
                self._lit = self._lit_at = None
                self._since = at
            self._held_at = None
        self._at = at
        if at is None:
            self.source = 'grabs'
            return grabs.picture
        if self._since is None:
            self._since = at
        sighted = None                          # the picture a lit grab at this look showed
        if grabbed:
            # A grab that showed it, not a shape's edges replaced (a stale sighting would win).
            if grabs.lit_sightings != self._lit_sightings:
                self._lit_sightings, self._lit, self._lit_at = grabs.lit_sightings, grabs.lit, at
                sighted = grabs.lit
            if grabs.provisional:
                self.recording.hold()           # what dim grabs showed is no shape for the map
            else:
                self.recording.observe(at, grabs.picture, back=grabs.run_back)
        plans = self._plans()
        planned = self._confirmed(plans, plans.picture(at, (self._lit, self._lit_at)), self._returned, sighted)
        if planned is None:
            # A map whose stretch ends within its lead, or behind playback, says nothing, but knows the picture now or
            # where it stopped: never a grab's narrower than it that is older (with the
            # read-ahead behind and grabs empty under load, a stale tall grab would go back over the map's scope, 1.1 s
            # in the bar); a grab that changed since is newer (a dark opening's dim grabs, the map silent over it).
            known = plans.last_known(at, self._since)
            if (known is not None and pictures.wider(known[0], grabs.picture)
                    and (self._grab_change_at is None or self._grab_change_at <= known[1])):
                planned = known[0]
        self.source = 'grabs' if planned is None else 'read ahead' if plans.read_ahead() else 'cached map'
        return grabs.picture if planned is None else grabs.version(planned)

    def _confirmed(self, plans, planned, placed, sighted=None):
        """planned, the maps' plan at the counted film time; a move into a narrower picture than placed only once
        Kodi's own answer, asked now, is not behind the count, or a lit grab at this look showed that picture
        (sighted) while the answer lags the count by Kodi's step at most (LAG_MOST), else the plan at that answer. The
        count runs on through a stall Kodi does not report: the text would go down into the frozen wider picture's
        bar, the next lit grab take it back up, the plan down again; and a frozen frame of the narrower picture
        before a short wider shot is no sighting of the one after it. Never urgent: late by Kodi's answer step at
        most (0.2 s)."""
        if planned is None or placed is None or not pictures.narrower(planned, placed):
            return planned
        counted = self._clock.peek()
        answer = self._clock.answer()           # asked whatever the grab showed: the count stays fresh
        if answer is None:
            return None                         # Kodi can not say (the playback ending): the grabs decide
        if answer >= counted - scenemap.EPS:
            return planned
        if sighted is not None and pictures.same(sighted, planned) and counted - answer <= LAG_MOST:
            return planned                      # the film is there: on screen
        return plans.picture(answer, (self._lit, self._lit_at))

    def landing(self, target):
        """The picture for a seek to film time target (Kodi's; None: a chapter) before the landing shows: the maps'
        plan there, else the widest picture this film is known to show (the follower only moves up for it: the text
        never in the landing's bar, a moment high at most). What the grabs showed before the seek says nothing there,
        nor do they until Kodi's time leaves the place before it (read)."""
        answer = self._clock.ask()
        self._seek_from = None if answer is None else (answer, self._now())
        if target is not None:
            plans = self._plans()
            planned = plans.picture(target)
            if planned is not None:
                self.source = 'read ahead' if plans.read_ahead() else 'cached map'
                return self._grabs.version(planned)
        self.source = 'widest known picture'
        return self._grabs.known.widest()

    def resume(self, moves_shown):
        """A newer epoch's follower carries on with this reader (Kodi's window, a distance, the position changed): its
        grabs, the shapes seen, the evidence, the screen's lead and the recording go on; the layout may move lines on
        screen or not now; Kodi's time is asked again at the next look (its window switch can hold the picture); the
        looks and the CPU count from here for this thread's log line."""
        self._moves_shown = moves_shown
        self._due_at = None
        self._clock.hold()
        # Another layout (a window): its picture may run ahead by another lead; the one believed is where it starts.
        self._lead.forget()
        self._probing = False
        self.looks, self._cpu = 0, time.thread_time()

    def placed(self, picture):
        """The follower wrote the margin for picture (before the scene rule) and Kodi took it."""
        self._placed = picture

    def on_screen(self, moves_shown):
        """The picture to place now without a grab, for a layout that moves lines on screen or not: the maps' plan at
        the counted film time (a move into a narrower picture once Kodi's own answer reaches it, _confirmed), else the
        picture the follower placed last (placed); None before it placed one."""
        placed = self._placed
        if placed is None:
            return None
        at = self._clock.peek()
        if at is None:
            return placed
        plans = scenemap.Plans(self._live(), self.known, moves_shown, self.shown_ahead)
        planned = self._confirmed(plans, plans.picture(at, (self._lit, self._lit_at)), placed)
        return placed if planned is None else self._grabs.version(planned)

    def note(self, shown):
        """The log's words for a reading; a change of picture says how many grabs it took and how long, and the
        time since the look before them (the cut came in between)."""
        change, self._change = self._change, None
        if change is None or change[1] is None:
            return GrabReader.note(shown) + self._overruled(shown)
        return '%s (%d %s over %.2f s%s%s)%s' % (
            GrabReader.note(shown), change[0], 'grab' if change[0] == 1 else 'grabs', change[1],
            '' if change[2] is None else ', the look before %.2f s earlier' % change[2],
            ', lit at the frame\'s edge only' if self._grabs.at_edge else '', self._overruled(shown))

    def _overruled(self, shown):
        """', the read ahead says 2.20' where a map placed another picture than the grabs show (a shot it missed shows
        in the log as grabs nothing placed), else ''."""
        planned = self._returned
        if (self.source == 'grabs' or planned is None or shown[0] != 'picture'
                or pictures.same(planned, shown[1])):
            return ''
        return ', the %s says %.2f' % (self.source, float(planned))

    def pace(self):
        """Seconds to the next look (_next_look), the wake it plans kept for the next read: a planned move placed at
        once, or a probe's grab."""
        seconds, due, probing = self._next_look()
        if probing:
            self._probing = True
        if due is not None:
            self._due_at = due
        return seconds

    def _next_look(self):
        """(seconds to the next look, the film time of a planned move woken for or None, whether that look is a
        probe's). Seconds to the next look: the fast pace once the film has shown a second shape (grabs, the decoder's
        keyframes, a map), except where a map knows no cut is coming; the slow one otherwise. A steady film, most of
        them, is looked at once a second; an IMAX film about three times a second around its cuts; with no map, every
        EMPTY_STEP where Kodi's grab gives nothing (_grab_gives_nothing). Where a margin moves the line on screen
        (Kodi's Manual position) the fast pace throughout: the first cut is up to a second late at the slow one, and a
        look costs about 1.5 ms. A move a map plans before the next look would end wakes
        the follower for it, to the moment (the film's time counted, not asked again: Kodi's answers come in coarser
        steps than the count); one into a narrower picture from PLANNED_NEAR before it, with one probe's look."""
        plans = self._plans()
        if not plans and self._grab_gives_nothing():
            pace = EMPTY_STEP
        elif self.only_wider and not self._wider_known():
            # Same as black bars with the widest picture measured: nothing to follow but a wider one, once a second
            # (grabbing six times a second for a whole film would move nothing); at the fast pace
            # again once the film is known to show a wider one (the file's keyframes, a map).
            pace = SLOW_STEP
        elif self._moves_shown:
            pace = FAST_STEP                     # a scene the maps miss (shorter than lookahead.SPARSE) moves too
        elif len(self._grabs.known) < 2 and not plans:
            pace = SLOW_STEP
        elif self._at is not None and plans.calm(self._at):
            pace = SLOW_STEP
        else:
            pace = FAST_STEP
        now = self._clock.peek() if self._at is not None else None
        soon = plans.next_move(now) if now is not None else None
        if soon is None:
            return pace, None, False
        # Waited for, grabbing nothing: a move into a narrower picture from PLANNED_NEAR before it (its probe below),
        # any other only where the next look would end past it (a look ending past the cut sees it first, the move then
        # late by the rest of that look; one ending before it sees a short scope shot the map does not know, which
        # PLANNED_NEAR's blind second left in its bar). A look is judged by the slowest grab of the playback: judged by
        # the latest 20, a look taken once a rare slow one had passed out of them was as slow and ran past the move. The
        # blind wait is PLANNED_NEAR at most, however slow the grabs.
        look = min(pace + self._slowest_grab + DUE_SLACK, PLANNED_NEAR)
        narrower = exact = False
        if soon < max(pace, PLANNED_NEAR):                       # near enough for its direction to matter
            narrower, exact = self._planned_move(plans, now, soon)
        if soon >= max(pace, PLANNED_NEAR if narrower else look):
            return pace, None, False
        # A look before a move into a narrower picture whose grab tests a lead halfway between the least and the most
        # still possible: the cut on screen then or not (_measure), a halving search over the film's cuts (without it
        # nothing near a planned cut is grabbed and the lead stays a guess). A move up is never put off for it: its text
        # would sit in the bar.
        before = scenemap.EXACT_AFTER - self._lead.value + self._lead.probe_target()
        # Not where grabs come back so slow that its grab would hold the move up by more than PROBE_LATE (a 0.55 s grab
        # would make the move down 0.5 s late).
        if exact and before > 0.005 and soon > before + 0.005 and self._slow_grab[0] < before + PROBE_LATE:
            return soon - before, None, True
        return max(0.005, soon), now + soon, False

    def _wider_known(self):
        return pictures.wider_than(self._widest, self._grabs.known)

    def _grab_gives_nothing(self):
        """Whether Kodi's grab gives nothing here: no grab of this playback came back with an image, and they have come
        back empty for EMPTY_FOR (a seek empties them for a moment, and never for good: the first image brings the pace
        back). Told once in the log."""
        if self._imaged or self._empty_since is None or self._now() - self._empty_since < EMPTY_FOR - 1e-6:
            return False
        if not self._empty_told:
            self._empty_told = True
            self._log('scenes: Kodi\'s screen grab gives no image here, looking every %d s' % EMPTY_STEP, always=True)
        return True

    @staticmethod
    def _planned_move(plans, now, soon):
        """(whether the move planned soon seconds from film time now is into a narrower picture, whether that is from
        the map read from the file: the cut at its frame, the screen's lead measured against it)."""
        before = plans.picture(now)
        after = plans.picture(now + soon + 0.002)
        narrower = before is not None and after is not None and pictures.narrower(after, before)
        return narrower, narrower and plans.answered is not None and plans.answered.exact

    def hold(self):
        """Kodi holds the picture still (a pause, a seek): the stretch watched so far ends, the film's time is asked
        again after, and no planned move is waited for meanwhile (it would spin at the wake for the whole pause)."""
        self.recording.hold()
        self._clock.hold()
        if self._at is not None:
            self._held_at = self._at
        self._at = self._due_at = None
        self._probing = False
        # The looks before it are no look before a change after it (in the film simulator a landing just after a cut
        # counted the last grab before the seek back from the landing, the lead measured 0.2 s low).
        self._times = []

    def film_time(self):
        """The film time for the log: counted, never asked of Kodi (asked during a seek, it anchored the count to a
        position mid-seek)."""
        return self._clock.peek()

    def widened(self, picture):
        """True once for a picture wider than any this film was known to show: the cache keeps it."""
        # Another picture, not a version of the same one (a grab's shape without rows, edges a row apart): the cache
        # would keep a row-less 2.40 over the measured 2.39.
        if pictures.wider(picture, self._widest):
            self._widest = picture
            return True
        return False

    def settled(self, picture):
        """The measurement settled on picture after following started (at the first estimate): the file's exact edges
        replace what the grabs read of the same picture, so the next look places them; and the cache keeps a wider scene
        only than that (the estimate may have been an IMAX opening: a 1.90 scene would then replace the settled 2.39 in
        the cache). None: not settled yet."""
        if picture is None:
            return
        if pictures.has_rows(picture):
            self._grabs.prefer(picture)
        if float(picture) > float(self._widest):
            self._widest = picture

    def shapes(self):
        """The shapes this film showed so far, for the next epoch's reader."""
        return list(self._grabs.known)

    def keep(self, memory, stopping):
        """Following ended: the looks and their CPU in the log (without asking for the detailed log setting), then
        this reader's recording handed to the playback's cache memory (shapes.Memory.keep_scenes: merged and kept for
        the next playback). Not while Kodi stops the add-on (stopping(): switched off, removed, updated): Kodi refuses
        an add-on's settings then, with an error of its own in its log. A map that can not be
        kept is logged, never raised."""
        used = time.thread_time() - self._cpu
        self._log('scenes: %d looks at the screen, %.1f s of CPU on this thread (%.1f ms a look)' % (
            self.looks, used, 1000 * used / max(self.looks, 1)), always=True)
        try:
            if stopping() or memory is None:
                return
            memory.keep_scenes(self.recording)
            live = self._live()
            if live:
                memory.keep_scenes(live)         # the file's cuts over the grabs' where both watched
        except Exception as error:  # the map is a nicety: never a reason to complain at a stop
            self._log('scene map not kept: %r' % error)
