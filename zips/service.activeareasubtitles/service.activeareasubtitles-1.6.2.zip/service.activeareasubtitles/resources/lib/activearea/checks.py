"""What the add-on checks about CoreELEC's settings (at the start, when settings change, when Kodi's settings
screens close) and the notices that come of it, shown in the add-on's own window with OK, one at a time and
only while no video plays (a window over a film would interrupt it)."""
import json
import os
import threading
import time

import xbmc

from . import coreelec, geometry, kodi, level5, libav, question, status, updates
from .choices import image_distances
from .keeper import write_record

P3I_SETTINGS_SEEN = 'p3i_settings.json'   # the unfamiliar CoreELEC settings last shown
RESTRICT_NOTICE = 'restrict_notice.json'   # CoreELEC's restriction now only for image subtitles: told once
LEVEL5_NOTICE = 'level5_notice.json'       # the Level 5 correction can not work with CoreELEC's handling off: told once
IMAGE_MARGIN_NOTICE = 'image_margin_notice.json'   # image distances chosen, no bitmap margin in this CoreELEC: told once
FFMPEG_NOTICE = 'ffmpeg_notice.json'       # CoreELEC's FFmpeg newer than this add-on knows: told once per release
# Kodi's own settings screens where CoreELEC's settings sit (Settings > System, Settings > Player; names seen in a
# real Kodi 21). Kodi tells an add-on only about its own settings, so the service looks again when these close.
UPDATE_LOOK_S = 10.0           # how often the service looks whether an update the button asked for arrived
SETTINGS_SCREENS = 'Window.IsActive(systemsettings) | Window.IsActive(playersettings)'


class Notices:

    def __init__(self, playing_video, start):
        self.playing_video = playing_video
        self.start = start                   # start(kind, target): the service's threads (threads.py)
        self.waiting = []                    # (string id, done() -> False to drop it, after() once OK is pressed)
        self.telling = False
        self.lock = threading.Lock()
        self.window = None                   # the notice open now (close_at_stop closes it)
        self.stopped = False                 # the service stopped: no notice opens any more

    def add(self, string_id, done=None, after=None):
        """A notice for the next moment without video (see tell_waiting); the same one only once in the queue.
        after: what follows once it is read (a window of Kodi's opened, say)."""
        if all(waiting != string_id for waiting, _done, _after in self.waiting):
            self.waiting.append((string_id, done, after))

    def tell_waiting(self):
        """The first waiting notice, in the add-on's own window with OK, while no video plays and no other
        notice is open. done() records it as shown, before the window opens: False drops it (a notice that
        can not be recorded would come back at every start)."""
        if self.telling or not self.waiting or self.playing_video():
            return
        string_id, done, after = self.waiting.pop(0)
        if done is not None and not done():
            return
        self.telling = True

        def tell():
            try:
                if question.tell(kodi.text(string_id), self._opened) and after is not None:
                    after()
            except Exception as error:  # a notice must never stop the service
                kodi.log('notice %d not shown: %r' % (string_id, error), always=True)
            finally:
                with self.lock:
                    self.window = None
                self.telling = False

        self.start('notice', tell)

    def _opened(self, window):
        """Whether window may open: not once the service has stopped."""
        with self.lock:
            if self.stopped:
                return False
            self.window = window
            return True

    def close_at_stop(self):
        """The service stopping for good: no notice opens any more, and the one open closes. Kodi would keep it on
        screen until OK or until Kodi quits, after an update, a switch off or a removal alike. Not while a film plays:
        its close would send Kodi back a window, out of the full-screen video (Kodi closes it when it gives up on the
        thread or quits)."""
        with self.lock:
            self.stopped = True
            window = self.window
        if window is not None and not self.playing_video():
            window.close_at_stop()

    def once(self, name, string_id, data=True):
        """A notice told once: again only after clear(name), or when data differs from what was told then (a
        record that can not be read counts as not told)."""
        path = kodi.data_path(name)
        try:
            with open(path, encoding='utf-8') as handle:
                if json.load(handle) == data:
                    return
        except (OSError, ValueError):
            pass
        self.add(string_id, lambda: _recorded(path, data))

    @staticmethod
    def clear(name):
        """What a once-notice was about is resolved: it is told again if it comes back."""
        try:
            os.remove(kodi.data_path(name))
        except OSError:
            pass


class Checks:

    def __init__(self, service, notices):
        self.service = service               # on CoreELEC or not, the P3i policy, the decode guard
        self.notices = notices
        self.in_settings = False             # one of Kodi's settings screens open at the last step
        self.manual_notice_shown = False
        self.ffmpeg_usable = True            # on CoreELEC, whether its FFmpeg can be used (check_ffmpeg, at each start)
        self.file_first = False              # on a PC, the shipped decoder loaded at start: the file analysis first
        self.file_fallback = False           # on a PC, the system's FFmpeg loaded at start: the file after the screen
        self.refusal_told = None             # the shipped decoder's refusal, logged once
        self.update_looked = None            # when update_outcome last looked

    def update_outcome(self, now=None):
        """Whether the update the button asked Kodi for arrived (updates.outcome), looked at every UPDATE_LOOK_S. Not
        installed: told, then the add-on's page in its repository opens, where it can be installed by hand."""
        now = time.monotonic() if now is None else now
        if self.update_looked is not None and now - self.update_looked < UPDATE_LOOK_S:
            return
        self.update_looked = now
        path = kodi.data_path(updates.ASKED_FILE)
        if not os.path.exists(path):
            return
        found = updates.outcome(path, self.service.version)
        if found == updates.INSTALLED:
            kodi.log('update to %s installed' % self.service.version, always=True)
        elif found == updates.NOT_INSTALLED:
            kodi.log('the update Kodi was asked for did not install; the repository page is opened', always=True)
            self.notices.add(32163, after=lambda: xbmc.executebuiltin(updates.REPOSITORY_PAGE))

    def restrict_notice(self):
        """Said once, so a person who finds that CoreELEC setting off again knows why (and does
        not take it for a fault in CoreELEC)."""
        self.notices.once(RESTRICT_NOTICE, 32132)

    def check_level5_handling(self):
        """"Correct faulty Dolby Vision Level 5" on while CoreELEC's Level 5 handling is off: CoreELEC then takes
        no correction. Told once (again if it happens again after being resolved). The handling is never switched
        on here: it decides how every Dolby Vision video is sent to the TV, so it stays the person's choice."""
        if not (self.service.on_coreelec and level5.enabled()
                and kodi.get_setting(coreelec.LEVEL5_HANDLING, quiet=True) is False):
            self.notices.clear(LEVEL5_NOTICE)
            return
        kodi.log('"Correct faulty Dolby Vision Level 5" is on, but CoreELEC\'s Level 5 handling is off: '
                 'nothing can be corrected', always=True)
        self.notices.once(LEVEL5_NOTICE, 32133)

    def settings_left(self):
        """Kodi's settings screens just closed: CoreELEC's Level 5 handling may have been switched off there, while
        "Correct faulty Dolby Vision Level 5" is on (otherwise nobody would know until Kodi restarts)."""
        if not self.service.on_coreelec:
            return
        open_now = kodi.holds(SETTINGS_SCREENS)
        if self.in_settings and not open_now:
            self.check_level5_handling()
            self.service.stale_correction()
        self.in_settings = open_now

    def check_image_margin(self):
        """A distance chosen for image subtitles on a P3i build without "Bitmap subtitle margin" (before build 5212):
        they are still kept inside the picture, but at no distance. Told once (again if it happens again after
        being resolved)."""
        if not (self.service.p3i.offered() and self.service.enabled()
                and any(distance is not geometry.DISC for distance in image_distances())
                and kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True) is None):
            self.notices.clear(IMAGE_MARGIN_NOTICE)
            return
        kodi.log('this CoreELEC has no bitmap subtitle margin: image subtitles are kept inside the picture '
                 'without a distance', always=True)
        self.notices.once(IMAGE_MARGIN_NOTICE, 32146)

    def check_ffmpeg(self):
        """CoreELEC's FFmpeg newer than this add-on knows (a CoreELEC update): no film can be measured, and every
        playback would only log it. Told once per FFmpeg release (again if it happens again after being resolved)."""
        memory = kodi.data_path('ffmpeg.json')
        if not self.service.on_coreelec:
            found = libav.found(memory)
            refused = libav.refusal()
            if refused and refused != self.refusal_told:
                kodi.log('decoder not used: %s' % refused, always=True)
                self.refusal_told = refused
            # Only the decoder that ships with the add-on (and is tested with it) puts the file analysis first; a
            # system's own FFmpeg keeps the order it always had, the screen capture first.
            self.file_first = found is not None and found.origin == 'shipped'
            self.file_fallback = found is not None and not self.file_first
            if self.file_first:
                kodi.log('decoder: %s, the file analysis first, the screen capture as fallback' % found.description,
                         always=True)
        self.ffmpeg_usable = not self.service.on_coreelec or libav.usable(memory)
        if not self.ffmpeg_usable:
            kodi.log('CoreELEC\'s FFmpeg can not be used: CoreELEC places the subtitles as you set it', always=True)
        major = None if self.ffmpeg_usable else libav.newer_release(memory)
        if major is None:
            self.notices.clear(FFMPEG_NOTICE)
            return
        kodi.log('CoreELEC\'s FFmpeg (libavformat %d) is newer than this add-on knows: nothing can be measured' % major,
                 always=True)
        self.notices.once(FFMPEG_NOTICE, 32147, major)

    def show_status(self):
        p3i = self.service.p3i.offered()
        system, method = status.describe(self.service.on_coreelec, p3i, not self.service.guard.paused(), xbmc.getCondVisibility,
                                         self.file_first, self.file_fallback)
        rows = [('status_system', kodi.text(system)), ('status_method', kodi.text(method)),
                ('status_shapes', str(self.service.shapes.count()))]
        for setting_id, wanted in rows:
            try:
                if kodi.addon().getSetting(setting_id) != wanted:     # Kodi writes its settings file on every change
                    kodi.addon().setSetting(setting_id, wanted)
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        try:
            self._show_p3i(p3i)
        except Exception:  # the rows stay as they were
            pass
        # Its start's claim makes the line its own: Kodi folds a line identical to the one before, the thread not counted,
        # so two starts logged back to back would read as one. Without a claim, the clock's milliseconds.
        claim = self.service.claim if self.service.claim is not None else int(time.monotonic() * 1000)
        kodi.log('started: version %s, %s, %s, start %d' % (self.service.version, kodi.text(system),
                                                            kodi.text(method).lower(), claim))
        # Quiet: P3i's own setting is only readable while P3i shows it, and its absence says enough. A P3i build that
        # renamed its restriction offers none, and is known by its name.
        if p3i or self.service.on_coreelec and coreelec.is_p3i(lambda setting: kodi.get_setting(setting, quiet=True),
                                                             xbmc.getInfoLabel('System.BuildVersion')):
            self.check_p3i_settings()

    @staticmethod
    def _show_p3i(p3i):
        addon = kodi.addon()
        try:
            shown = addon.getSettingBool(status.P3I_SHOWN)
        except Exception:  # not stored yet
            shown = None
        if shown is not p3i:                    # Kodi writes its settings file on every change
            addon.setSettingBool(status.P3I_SHOWN, p3i)

    def check_p3i_settings(self):
        """P3i's builds change often. A subtitle or Level 5 setting this add-on does not know is only logged, at
        every start: new builds add harmless ones (a message for each would irritate). One it
        relies on that is gone, also what a rename looks like, is logged and told once (again if it happens again
        after being resolved)."""
        found = kodi.rpc('Settings.GetSettings', {'level': 'expert'}, quiet=True)
        if not isinstance(found, dict):
            return
        ids = [item.get('id', '') for item in found.get('settings', []) if isinstance(item, dict)]
        new = coreelec.unfamiliar_settings(ids)
        missing = coreelec.missing_settings(ids, lambda setting: kodi.get_setting(setting, quiet=True))
        if new:
            kodi.log('CoreELEC offers subtitle settings this add-on does not know: %s' % ', '.join(new), always=True)
        if missing:
            kodi.log('CoreELEC no longer offers settings this add-on relies on: %s' % ', '.join(missing), always=True)
        changes = ['missing: %s' % setting_id for setting_id in missing]
        if not changes:
            self.notices.clear(P3I_SETTINGS_SEEN)
            return
        self.notices.once(P3I_SETTINGS_SEEN, 32131, changes)

    def manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        self.notices.add(32040)


def _recorded(path, data):
    """write_record, True when it was written."""
    try:
        write_record(path, data)
        return True
    except OSError:
        return False
