"""Protection against the one part that could take Kodi down: decoding through FFmpeg.

A marker file names the files being decoded while any decode runs, one per start of the
service, with the Kodi process it runs in. Finding one of another Kodi process when the
service starts means Kodi stopped in the middle of a decode without closing normally: a
crash in FFmpeg, or just a power cut. Either way it heals itself:

- the file being decoded then is left to Kodi from now on (one film, not the add-on), so a
  file that crashes FFmpeg can not crash Kodi again and again;
- only when it happens twice in a row (no decode finished in between, so FFmpeg itself is the
  problem, not one file) does decoding pause, for a day, and then it is simply tried again;
- an update of the add-on starts with a clean slate, since it may bring the fix.

A normal close removes the marker, even when a decode is still running then (a slow network
read), so that is never taken for a crash. A marker of this Kodi process is another start of
the add-on still decoding (an update, or a start whose stop Kodi lost), never a crash: it is
left alone, and goes when that start's decode ends or at the newest start's close.
"""
import contextlib
import json
import os
import threading
import time
import uuid

PAUSE_S = 24 * 60 * 60     # after two interrupted decodes in a row
SKIPPED_LIMIT = 50         # files left to Kodi, newest kept
OLD_MARKER = 'decoding.marker'       # versions up to 1.6.0: one for every start, without the process
MARKER = 'decoding-%s.marker'        # one per start, named by its claim


def process():
    """This Kodi process as a marker names it: its id, and where the system says the boot it runs in (a box switched
    off and on can give Kodi the same id again). Every start of the add-on in one Kodi runs in its process."""
    try:
        with open('/proc/sys/kernel/random/boot_id', encoding='ascii') as handle:
            boot = handle.read().strip()
    except OSError:
        boot = ''
    return '%d %s' % (os.getpid(), boot)


class DecodeGuard:

    def __init__(self, folder, version, clock=time.time, start=None, kodi_process=None):
        """start: its start's claim (kodi.claim_service), which names its marker and orders it among this Kodi's
        starts; None: a name of its own. kodi_process: Kodi's own id for this Kodi (kodi.process_id), which a Kodi
        started again never shares, where the system's can (a container, Windows' ids coming round); None: process()."""
        self.start = start
        self.marker = os.path.join(folder, MARKER % (start if start is not None else uuid.uuid4().hex))
        self.record = os.path.join(folder, 'decoding.json')
        self.folder, self.version, self.clock = folder, version, clock
        self.process = kodi_process or process()
        self.lock = threading.Lock()
        self.running = []   # identities being decoded: an older playback's may still be finishing
        self.closing = False  # Kodi is closing normally: no decode may write the marker again

    def check_last_run(self):
        """At start: what an interrupted decode last time led to, for the log, or None.

        'skipped' when the file being decoded is left to Kodi from now on, 'paused' when it was
        the second time in a row and decoding pauses for a day."""
        _remove(os.path.join(self.folder, 'decoding.disabled'))   # versions before 0.3.20
        found, files = False, []
        for path, marked in self._markers():
            if marked.get('process') == self.process:
                continue            # another start in this Kodi, decoding now
            found = True
            files += marked.get('files') if isinstance(marked.get('files'), list) else []
            _remove(path)
        if not found:
            return None
        state = self._load()
        skipped = [f for f in state['skipped'] if f not in files] + [f for f in files if isinstance(f, str)]
        state['skipped'] = skipped[-SKIPPED_LIMIT:]
        state['strikes'] += 1
        paused = state['strikes'] >= 2
        if paused:
            state['paused_until'] = self.clock() + PAUSE_S
        self._save(state)
        return 'paused' if paused else 'skipped'

    def paused(self):
        """True while decoding pauses after two interrupted decodes in a row."""
        return self.clock() < self._load()['paused_until']

    def allowed(self, identity=None):
        """False while paused, and for a file that was being decoded when Kodi stopped."""
        state = self._load()
        return self.clock() >= state['paused_until'] and identity not in state['skipped']

    @contextlib.contextmanager
    def decoding(self, identity=None):
        with self.lock:
            self.running.append(identity)
            self._mark()
        try:
            yield
        finally:
            with self.lock:
                self.running.remove(identity)
                self._mark()
            # FFmpeg came back (with a picture or with an error): the count of interruptions
            # in a row starts again.
            state = self._load()
            if state['strikes']:
                state['strikes'] = 0
                self._save(state)

    def wait_until_idle(self, seconds=4.0):
        """At a normal close: let a running decode finish (about two seconds at most), then
        remove the marker in any case, since Kodi did not stop in the middle of one."""
        deadline = time.time() + seconds
        while self.running and time.time() < deadline:
            time.sleep(0.1)
        with self.lock:
            self.closing = True       # a read that ends (or starts) later must not name the others again
            _remove(self.marker)
            # An older start in this Kodi whose stop Kodi lost leaves through its run() without this wait.
            for path, marked in self._markers():
                if marked.get('process') == self.process and self.start is not None \
                        and isinstance(marked.get('start'), int) and marked['start'] < self.start:
                    _remove(path)

    def _mark(self):
        """The marker names what is being decoded; it is gone while nothing is, and once Kodi closes normally. Written
        whole or not at all: another start reads it at its own start."""
        if not self.running or self.closing:
            _remove(self.marker)
            return
        try:
            self._ensure_folder()
            with open(self.marker + '.part', 'w', encoding='utf-8') as handle:
                json.dump({'files': [f for f in self.running if f], 'process': self.process, 'start': self.start},
                          handle)
            os.replace(self.marker + '.part', self.marker)
        except OSError:
            pass

    def _markers(self):
        """Every marker in the folder, this start's and older versions' included: [(path, its content)], the content
        {} where it can not be read (counted as another process's)."""
        try:
            names = [name for name in os.listdir(self.folder)
                     if name == OLD_MARKER or (name.startswith('decoding-') and name.endswith('.marker'))]
        except OSError:
            return []
        found = []
        for name in sorted(names):
            path = os.path.join(self.folder, name)
            try:
                with open(path, encoding='utf-8') as handle:
                    marked = json.load(handle)
            except (OSError, ValueError):
                marked = {}
            found.append((path, marked if isinstance(marked, dict) else {}))
        return found

    def _load(self):
        fresh = {'version': self.version, 'skipped': [], 'strikes': 0, 'paused_until': 0.0}
        try:
            with open(self.record, encoding='utf-8') as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            return fresh
        if not isinstance(state, dict) or state.get('version') != self.version:
            return fresh          # an update: a clean slate
        try:
            return {'version': self.version, 'skipped': [f for f in state.get('skipped', []) if isinstance(f, str)],
                    'strikes': int(state.get('strikes', 0)), 'paused_until': float(state.get('paused_until', 0.0))}
        except (TypeError, ValueError):
            return fresh

    def _save(self, state):
        try:
            self._ensure_folder()
            with open(self.record, 'w', encoding='utf-8') as handle:
                json.dump(state, handle)
        except OSError:
            pass

    def _ensure_folder(self):
        if self.folder and not os.path.isdir(self.folder):
            os.makedirs(self.folder)


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass
