"""Changing a Kodi setting for one playback and always putting it back.

While a value is changed, a small file holds the person's own value. The file
is the only record: it survives a crash or a forced quit, and the service puts
the value back the next time it starts. Without the file nothing is changed.
"""
import collections
import functools
import json
import os


def write_record(path, data):
    """Writes a record so that a power cut leaves the old one or the new one, never an empty
    file (which would lose the person's value). Raises OSError when it can not be written."""
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    temporary = path + '.new'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def took(write, value):
    """True when Kodi took the value. Raising counts as refused: a record must never claim a value
    that is not there, and a put back that raised is tried again next time."""
    try:
        return bool(write(value))
    except Exception:
        return False


class File:
    """A record that is a file of its own (Keeper's, override.Override's)."""

    def __init__(self, path):
        self.path = path

    def read(self):
        """The file's JSON, None without a file. Raises OSError or ValueError for one that can not be read."""
        if not os.path.exists(self.path):
            return None
        with open(self.path, encoding='utf-8') as handle:
            return json.load(handle)

    def write(self, data):
        """data on disk (write_record), or the file gone when None. Raises OSError."""
        if data is None:
            os.remove(self.path)
        else:
            write_record(self.path, data)


class Busy(Exception):
    """A record that exists but can not be read just now (another program holds the file: a Windows antivirus, a
    backup): nothing is changed until it can (waiting)."""


def waiting(answer):
    """A Keeper's or an Override's method that answers answer, having done nothing, while its record is Busy (taken
    for no record, the add-on's own value in Kodi would become the person's)."""
    def wrap(method):
        @functools.wraps(method)
        def run(self, *args, **kwargs):
            try:
                return method(self, *args, **kwargs)
            except Busy:
                return answer
        return run
    return wrap


class Record:
    """One record of the add-on's change to a setting, over its slot: a File, or one polarity of a Held (one key of the
    file both share). The one place a record is changed, marked and forgotten, for Keeper, override.Override and Held.

    decode(data) turns the slot's JSON into the kind's own record, raising ValueError, KeyError, TypeError or
    AttributeError for one it can not use (or returning None). waits: a slot that can not be read raises Busy (Keeper's
    and Override's, through waiting) instead of counting as unreadable."""

    def __init__(self, slot, decode, unreadable=None, waits=False):
        self._slot = slot
        self._decode = decode
        self._unreadable = unreadable      # what a record that exists but can not be used counts as
        self._waits = waits

    def load(self):
        """The decoded record, or None without one."""
        try:
            data = self._slot.read()
        except OSError:
            if self._waits:
                raise Busy()
            return self._unreadable
        except ValueError:
            return self._unreadable
        try:
            return None if data is None else self._decode(data)
        except (ValueError, KeyError, TypeError, AttributeError):
            return self._unreadable

    def change(self, data, write, value, before=None):
        """Records data, then write(value). True when Kodi took it. The record is on disk before
        Kodi is written: without it the change could not be put back after a crash, so nothing is
        changed when it can not be written. When Kodi refuses, the record goes back to before (no
        record when None)."""
        try:
            self._slot.write(data)
        except OSError:
            return False
        if took(write, value):
            return True
        if before is None:
            self.forget()
        else:
            try:
                self._slot.write(before)
            except OSError:
                pass        # the new record stays, as a refusal with no disk to undo it leaves it
        return False

    def mark(self, data):
        """Records that ours was put back. When it can not be written the record still says "in
        place", and the next look sees it is not."""
        try:
            self._slot.write(data)
        except OSError:
            pass

    def forget(self):
        try:
            self._slot.write(None)
        except OSError:
            pass


def look_again(load, put_back, restore):
    """The look every 30 s at one record (restores.Restores.settle), the same rule for every kind: restore() only
    where the record says it was put back already (Keeper.restore and _Hold.restore then forget it once the person set
    one of our values again in the session that put it back, or once their value is on disk too); a change of ours in
    place is left alone. load() gives the decoded record or None (and may forget one the person took over);
    put_back(record) says whether it was put back."""
    record = load()
    if record is not None and put_back(record):
        restore()


def still_saved(values, on_disk, same):
    """The values of ours Kodi's settings file may still hold: all of them when on_disk (what
    the file holds) is None, unknown."""
    return [v for v in values if on_disk is None or same(on_disk, v)]


class Change(collections.namedtuple('Change', 'own applied put_back earlier session')):
    """The add-on's change to a setting as a Ledger records it: own, the person's value (None where it is always the
    empty one, override.Override's); applied, ours; put_back, put back already; earlier, older values of ours Kodi's
    settings file may still hold; session, the Kodi session of the put back, or None."""
    __slots__ = ()

    def data(self):
        """The change as its record file holds it."""
        data = {} if self.own is None else {'own': self.own}
        data.update(applied=self.applied, put_back=self.put_back, earlier=list(self.earlier))
        if self.session is not None:
            data['session'] = self.session
        return data


class Values:
    """How a Ledger compares and reads the values of its setting: same(a, b), and decode(data) giving the Change a
    record file holds (raising ValueError, KeyError, TypeError or AttributeError, or None, for one it can not use)."""

    def __init__(self, same, decode):
        self.same, self.decode = same, decode


def _same(a, b):
    return abs(a - b) < 0.001


def _decode_number(data):
    earlier = [float(v) for v in data.get('earlier', [])]
    return Change(float(data['own']), float(data['applied']), bool(data.get('put_back', False)), earlier,
                  session_of(data))


def _decode_text(data):
    applied = data['applied']
    earlier = [v for v in data.get('earlier', []) if isinstance(v, str) and v]
    if isinstance(applied, str) and applied:
        return Change(None, applied, bool(data.get('put_back', False)), earlier, session_of(data))
    return None


NUMBER = Values(_same, _decode_number)                  # a number Kodi keeps: the same within 0.001
TEXT = Values(lambda a, b: a == b, _decode_text)        # a text setting: the same when equal; the empty text is nobody's


class Ledger:
    """The record of one setting the add-on changes for a playback, a file of its own, for Keeper and
    override.Override (Held keeps both polarities of a switch in one file: ADR 0003). It holds the change (Change)
    with the values of ours Kodi's settings file may still hold, forgets it once one of ours was set again in the Kodi
    session that put it back (Kodi loads its settings file while it runs only at a profile load, which stops the
    service as a close does and so ends the session: kodi_session.end_session; so only someone else can have set it),
    and keeps it after a put back until neither Kodi's memory nor its settings file holds one of ours. What may be
    written over and what the person's value is stay with Keeper and Override.

    read() gives the setting's value now (None when it can not be read); saved() what Kodi's settings file holds (None
    when unknown: every value of ours counts as possibly there); session() Kodi's session (kodi_session.session, None
    when unknown). A record that can not be read just now raises Busy (keeper.waiting answers for the caller)."""

    def __init__(self, read, path, values, saved=None, session=None):
        self.read = read
        self.values = values
        self.saved = saved or read
        self.session = session or (lambda: None)
        self._record = Record(File(path), values.decode, waits=True)

    @staticmethod
    def ours(change):
        """The values of ours a change may have left in Kodi: the one applied and the earlier ones."""
        return [change.applied] + change.earlier

    def holds(self, value, values):
        return any(self.values.same(value, v) for v in values)

    def load(self):
        """The change on record, or None; one whose value someone set again since the put back, in the Kodi session
        that put it back, is forgotten."""
        change = self._record.load()
        if change is not None and self._set_again(change):
            self._record.forget()
            return None
        return change

    def _set_again(self, change):
        """One of our values in memory after the put back, in the Kodi session that put it back. In another session (a
        crash or a close: Kodi started from its file) or an unknown one (a record without a session, or Kodi could not
        say) it is ours, back from disk."""
        if not change.put_back or change.session is None or change.session != self.session():
            return False
        current = self.read()
        return current is not None and self.holds(current, self.ours(change))

    def still_saved(self, values):
        """The values among these Kodi's settings file may still hold."""
        return still_saved(values, self.saved(), self.values.same)

    def change(self, own, value, earlier, before, write):
        """Records the change to value (own the person's value, earlier the older values of ours still to watch), then
        write(value) (Record.change: the record first, back to before when Kodi refuses). True when Kodi took it."""
        return self._record.change(Change(own, value, False, list(earlier), None).data(), write, value,
                                   before.data() if before else None)

    def put_back(self, change, own):
        """After the person's value (own) is back in memory: the record stays, put back in this session, while one of
        ours may still be in Kodi's settings file (a crash would bring it back unrecognised), else it is done. Written
        only when it says something new, not at every look."""
        left = self.still_saved(self.ours(change))
        if left:
            marked = Change(own, change.applied, True, [v for v in left if not self.values.same(v, change.applied)],
                            self.session())
            if marked.data() != change.data():
                self._record.mark(marked.data())
        else:
            self._record.forget()

    def settle(self, restore):
        """look_again on this record: restore() only where it was put back already."""
        look_again(self.load, lambda change: change.put_back, restore)


class Keeper:
    """The record stays until neither Kodi's memory nor its settings file holds the add-on's value (Ledger).

    Kodi writes its settings to disk only at a clean close and from its settings window (seen in
    a real Kodi 21): a value put back during a session is not on disk yet, and Kodi saves before
    add-ons stop, so a crash, or a close during a film, brings the add-on's value back at the next
    start. saved() reads what the settings file holds (None when unknown: the record stays);
    without it, the file is taken to follow memory. session() is Kodi's session (kodi_session.session, None
    when unknown): one of our values found after the put back in the same session is the person's choice."""

    def __init__(self, read, write, path, saved=None, session=None):
        self._read = read      # () -> current value or None
        self._write = write    # (value) -> True when Kodi accepted it
        self._ledger = Ledger(read, path, NUMBER, saved, session)

    def _active(self):
        """The change of ours still in place, or None."""
        change = self._ledger.load()
        return change if change and not change.put_back else None

    @waiting(False)
    def changed(self):
        return self._active() is not None

    @waiting(None)
    def own(self):
        """The person's own value, also while it is changed."""
        return _own(self._ledger.load(), self._read())

    @waiting(False)
    def apply(self, value, keep=()):
        """Set value for this playback. True when the value in Kodi moved: to value, or back to the person's own
        when value is theirs.

        keep: other values of ours this playback moves between (a followed film's scenes), held on the record with
        value. Moving to a value already on record while one of ours is in place writes Kodi only: no record, no
        read of Kodi's settings file, at every cut."""
        change, current = self._ledger.load(), self._read()
        if current is None:
            return False
        if change and not change.put_back:
            ours = self._ledger.ours(change)
            if self._ledger.holds(current, ours) and self._ledger.holds(value, ours):
                return took(self._write, value)
        own = _own(change, current)
        if _same(value, own):
            return self.restore()
        # Values of ours from before stay on record while Kodi's settings file may hold one of them (a close during a
        # film saves one, the next film's value replaces the record, and a crash would bring the saved one back
        # unrecognised).
        earlier = []
        if change:
            earlier = self._ledger.still_saved([v for v in change.earlier + [change.applied] if not _same(v, value)])
        earlier += [v for v in keep if not _same(v, value) and not _same(v, own)
                    and not any(_same(v, e) for e in earlier)]
        return self._ledger.change(own, value, earlier, change, self._write)

    @waiting(None)
    def settle(self):
        """look_again: writes Kodi only for one of ours back from disk in another session, as the start's repair
        would."""
        self._ledger.settle(self.restore)

    @waiting(False)
    def restore(self):
        """Put the person's value back. Returns True when it was written back."""
        change = self._ledger.load()
        if not change:
            return False
        current = self._read()
        if current is None:
            return False            # kept on record, tried again next time
        own, written = change.own, False
        if self._ledger.holds(current, self._ledger.ours(change)):   # ours in place, or back from disk
            if not took(self._write, own):
                return False        # still ours: kept on record, tried again next time
            written = True
        elif not change.put_back or not _same(current, own):
            own = current           # moved by the person, while ours was in place or since the put back: theirs
        self._ledger.put_back(change, own)
        return written


def session_of(data):
    """The Kodi session a record's put back was made in, None when it holds none (the session was unknown, or a version
    before 1.6.0 held the settings file's stamp instead: another session as far as anyone can tell)."""
    session = data.get('session')
    return session if isinstance(session, str) and session else None


def _own(change, current):
    """The person's value: the recorded one while one of ours is in place (or nothing can be
    read), else what is there now, since the person moved it meanwhile."""
    if change and (current is None or any(_same(current, v) for v in Ledger.ours(change)) or
                   (change.put_back and _same(current, change.own))):
        return change.own
    return current


class Held:
    """A switch setting the add-on holds at a value of its own for a while: either polarity, one record file.

    hold(value) switches the setting to value when it is the other one, the person's own; let_go(value) puts the
    person's value back where the add-on holds value. Each polarity is kept as a hold of its own inside the one
    file, with the rules below, so the person's value survives a crash or a close whichever way round it was held:
    holding one value first lets go of the other, and a let go whose value may still be on disk stays on record
    beside a hold of the other value.

    A hold's record is kept, as Keeper's, until the setting is back in memory and on disk, and holds no value
    (the polarity is its place in the file): {'switched_on': True, 'put_back': ...} plus the Kodi session once put
    back. A switch already at value is not ours. Found at value again after the add-on put it back: the person's
    choice in the same Kodi session (Kodi loads its settings file while it runs only at a profile load, which ends the
    session: kodi_session.end_session), else ours coming back from disk after a crash, a close or a profile load.
    session() is Kodi's session (kodi_session.session; None when unknown, and a record without one counts as another
    session). A record file that can not be read counts as a hold of ours in place for each value in lost, the values
    the add-on holds this setting at (a hold of a value it never holds would put the other value over the person's own
    at its let go); one whose content can not be used is kept aside once as <file>.unreadable, told through log, before
    it is written again.
    """

    def __init__(self, read, write, path, saved=None, session=None, lost=(False, True), log=None):
        self._read = read      # () -> True, False, or None when it can not be read
        self.path, self.lost = path, tuple(lost)
        # {} for a slot that can not be read: a hold of ours in place, the safe side (ADR 0003). Not reached today,
        # since _Polarity reads an unusable file as the holds in lost itself, but kept should a read ever raise.
        self._holds = {value: _Hold(read, write, Record(_Polarity(path, value, self.lost, log), dict, {}),
                                    saved or read, session or (lambda: None), value) for value in (False, True)}

    def hold(self, value):
        """The other value let go first, then value held when the setting is the other one. True when it was switched
        to value just now."""
        return self.switch(value)[1]

    def switch(self, value):
        """hold(value), telling both what it did: (the other value let go just now, switched to value just now)."""
        back = self._holds[not value].restore()
        now = self._read()
        if now is value:
            self._holds[value].found_held()
            return back, False
        return back, now is (not value) and self._holds[value].on()

    def let_go(self, value):
        """The person's value back where the add-on holds value. True when it was written back."""
        return self._holds[value].restore()

    def holds(self, value):
        """Whether the add-on holds the setting at value: on record, not put back."""
        return self._holds[value].in_place()

    def settle(self):
        """Each hold already put back looked at again (as Keeper.settle); a hold in place found at the other value is
        the person's from this look on (_Hold.settle), any other in place is left alone."""
        for hold in self._holds.values():
            hold.settle()


class _Hold:
    """One polarity of a Held: the setting held at value."""

    def __init__(self, read, write, record, saved, session, value):
        self._value, self._other = value, not value
        self._read, self._write, self._saved, self._session = read, write, saved, session
        self._record = record

    def on(self):
        """Held at value for this playback, the setting being the other one (Held.hold looked). False when it could
        not be."""
        # A record from before (put back, ours possibly still on disk) is kept when Kodi refuses.
        return self._record.change({'switched_on': True, 'put_back': False}, self._write, self._value,
                                   self._record.load())

    def in_place(self):
        record = self._record.load()
        # {} is a record that can not be read: in place, as restore treats it.
        return record is not None and not record.get('put_back')

    def found_held(self):
        """The setting found at value where the add-on holds value (Held.hold). A put back of ours found at value again
        is the person's in the Kodi session that put it back (forgotten, as restore would), else ours back from disk:
        held again, in place, so the look every 30 s leaves it while the add-on holds it, and a let go puts the
        person's value back. Kept on record as put back instead, after a crash during an image subtitle with the
        add-on's "off" in Kodi's file from the last stop, the look would put the person's "on" back during the next
        text film, and P3i would lift the text a second time."""
        record = self._record.load()
        if not record or not record.get('put_back'):
            return
        session = session_of(record)
        if session is not None and session == self._session():
            self._record.forget()
        else:
            self._record.mark({'switched_on': True, 'put_back': False})

    def settle(self):
        record = self._record.load()
        if record and not record.get('put_back') and self._read() is self._other:
            # Held, and found at the other value: the person set theirs while it was held (Kodi's settings window
            # between films). Theirs from now on, as a put back is: left in place, a later change of theirs back to
            # value looked like the hold and the let go put the other value over it.
            self.restore()
            return
        look_again(self._record.load, lambda record: record.get('put_back'), self.restore)

    def restore(self):
        """The other value back if the add-on held value. True when it was written back."""
        record = self._record.load()
        if record is None:
            return False
        put_back, session = bool(record.get('put_back')), session_of(record)
        now = self._read()
        if now is None and put_back:
            return False            # kept on record, looked at again next time
        here = self._session()
        written = False
        if now is not self._other:  # held, or unreadable: put back all the same
            if now is self._value and put_back and session is not None and session == here:
                self._record.forget()   # at value again since we put it back, in the same Kodi session: the person's
                return False
            if not took(self._write, self._other):
                return False        # still held: kept on record, tried again next time
            written = True
        # The other value now: put back by us just now, or by the person while ours was held (theirs either way). The
        # record stays, put back, while ours may still be in Kodi's settings file.
        if self._saved() is self._other:
            self._record.forget()   # back in memory and on disk: done
        elif not put_back or written or session != here:
            # With this session: the person's value is in memory now, in it.
            self._record.mark({'switched_on': True, 'put_back': True, 'session': here})
        return written


_KEYS = {False: 'false', True: 'true'}


class _Polarity:
    """One polarity's slot inside a Held's file ({'false': record, 'true': record}, either key missing when not held
    that way), for its Record. A file that exists but can not be used reads as a hold of ours in place for each value
    in lost (never one the Held never holds: its let go would put the other value over the person's own), and a write
    then writes those as in place too; the file is kept aside once as <file>.unreadable, told once through log, before
    it is written over, and with nothing in lost at the first read, since nothing would write it again."""

    def __init__(self, path, value, lost, log=None):
        self.path, self._value, self._lost, self._log = path, value, lost, log

    def read(self):
        return self._load().get(self._value)

    def write(self, data):
        """Raises OSError."""
        holds = self._load()
        if data is None:
            holds.pop(self._value, None)
        else:
            holds[self._value] = data
        self._save(holds)

    def _load(self):
        """{value: record}. A file that exists but can not be used: a hold of ours in place for each value in lost
        (written so at the next save), and with nothing in lost kept aside at once (nothing would write it again)."""
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, encoding='utf-8') as handle:
                data = json.load(handle)
            return {value: data[key] for value, key in _KEYS.items() if isinstance(data.get(key), dict)}
        except (OSError, ValueError, AttributeError):
            if not self._lost:
                self._keep_unusable()
            return {value: {} for value in self._lost}

    def _save(self, holds):
        """Raises OSError when it can not be written."""
        self._keep_unusable()
        if holds:
            write_record(self.path, {_KEYS[value]: record for value, record in holds.items()})
        else:
            try:
                os.remove(self.path)
            except OSError:
                pass

    def _keep_unusable(self):
        """A file whose content can not be used (cut short, edited by hand) kept aside before it is written over, the
        first one only, and told once: what wrote it may be worth a look."""
        try:
            with open(self.path, encoding='utf-8') as handle:
                if isinstance(json.load(handle), dict):
                    return
        except OSError:
            return              # missing, or held by another program for a moment: nothing to keep
        except ValueError:
            pass
        aside = self.path + '.unreadable'
        if os.path.exists(aside):
            return
        try:
            os.replace(self.path, aside)
        except OSError:
            return
        if self._log is not None:
            self._log('%s could not be read: kept as %s' % (os.path.basename(self.path), os.path.basename(aside)))
