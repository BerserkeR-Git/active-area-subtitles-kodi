"""The margin for a picture: which Kodi setting feeds which part of the renderer model (geometry.py), the font file
Kodi draws with (fonts.py), and the distance chosen for the picture's shape. Reads Kodi's subtitle settings and the
fonts folders, writes nothing; the playback writes what comes out of here under its lock.
"""
import collections
import os
import threading

import xbmc
import xbmcgui
import xbmcvfs

from . import calibration, choices, fonts, geometry, kodi

# What _layout decides once per epoch: the area Kodi lays subtitles out in ('screen' or 'video'), the screen, the
# video's shape, whether the subtitles sit at the top (their outline reaches up to the picture's edge), and manual: the
# rows of the canvas Kodi draws subtitles on when text is placed through Kodi's Manual position, its subtitle bar at
# that canvas's bottom (choose_area), else None.
Layout = collections.namedtuple('Layout', 'area screen_w screen_h video_ratio top manual', defaults=(None,))
# The margin for a text subtitle and what made it: reach and give in canvas pixels, the font's metrics or None when
# its file could not be read.
Margin = collections.namedtuple('Margin', 'value reach give font')
# choose_area's answer: the area ('screen' or 'video'; None: the position is not handled), whether the text sits at the
# top, Layout.manual, and the line for the log (None: nothing to say).
Area = collections.namedtuple('Area', 'area top manual note')

FONT_DEFAULT_FILE = 'arial.ttf'                        # Kodi's name for its default subtitle font (FontUtils.h)
SYSTEM_FONTS, USER_FONTS = 'special://xbmc/media/Fonts/', 'special://home/media/Fonts/'
_fonts = {}                                            # (path, face, modification time) -> fonts.Metrics or None
_found = {}                                            # (folder, its modification time, family, bold) -> fonts.find
_font_lock = threading.Lock()                          # margins are worked out on several threads
MOST_FONTS = 8


def text_margin(layout, picture_ratio, distances, hinted):
    """Kodi's margin setting that puts a text subtitle the chosen distance inside the picture. distances: the two
    text distances (content with black bars, full-screen content), choices.distances(). The bar on the subtitle's
    side decides: a picture's bars can differ, and the text sits on one of them. hinted: the box, whose renderer draws
    small letters higher than the font math (geometry's lift); a PC draws them on it (Kodi for Windows at 1440 lines
    and the test rig at 1080, 1440 and 2160 lines)."""
    bars_gap, full_gap = distances
    reach, give, font = text_reach(layout.top, hinted)
    placed_ratio = geometry.placed_ratio(picture_ratio, layout.video_ratio, layout.top)
    screen_ratio = layout.screen_w / layout.screen_h
    if layout.manual is not None:
        # Manual lays the text out on the screen whatever the person's own bottom position.
        needed = geometry.needed_pixels('screen', screen_ratio, layout.video_ratio, placed_ratio, bars_gap, full_gap,
                                        reach, give)
        return Margin(geometry.manual_value(needed, layout.manual, layout.manual), reach, give, font)
    value = geometry.margin_value(layout.area, screen_ratio, layout.video_ratio, placed_ratio, bars_gap, full_gap,
                                  reach, give)
    return Margin(value, reach, give, font)


def choose_area(align, pc, taken, canvas):
    """Where Kodi lays a placing's text subtitle out, decided in one place (ADR 0004). align: the person's own
    position (subtitles.align, -1 when unknown); pc: not CoreELEC (P3i moves a line on screen with every position, so
    the box keeps the person's); taken: why the person's own position is kept for the rest of this playback (they set
    it themselves during it: no Manual over a bottom position they picked; Kodi refused Manual), or None; canvas(): (the rows of the canvas Kodi draws subtitles on
    where its subtitle bar can be nothing but that canvas's bottom, else None; what decided it), asked only where
    Manual would be used (manual_canvas). A PC places every bottom position and Manual itself through Manual."""
    area, top = geometry.layout_area(align), geometry.layout_top(align)
    if area is None and (not pc or align != geometry.ALIGN_MANUAL):
        return Area(None, top, None, '%d (Manual or unknown)' % align)
    if not pc:
        return Area(area, top, None, None)
    if top or (taken and area is not None):
        return Area(area, top, None, 'text on the subtitle position %d (Manual not used: %s)' % (
            align, 'a top position' if top else taken))
    rows, why = canvas()
    if rows is None:
        if area is None:
            return Area(None, top, None, 'Manual, calibration %s' % why)
        return Area(area, top, None, 'text on the subtitle position %d (Manual not used: %s)' % (align, why))
    return Area(area or 'screen', top, rows,
                'text through Kodi\'s Manual position, subtitle bar at row %d of %d (%s)' % (rows, rows, why))


def canvas():
    """What a layout depends on of Kodi's window, to tell when it changed: the screen's size (System.ScreenWidth and
    Height, a window's own when windowed), the canvas Kodi draws its GUI and subtitles on, and whether it is windowed (a
    window's System.ScreenResolution names no refresh rate; the rate itself is left out: Kodi switches it as a film
    starts)."""
    return (xbmc.getInfoLabel('System.ScreenWidth'), xbmc.getInfoLabel('System.ScreenHeight'),
            xbmcgui.getScreenWidth(), xbmcgui.getScreenHeight(),
            'Hz' not in (xbmc.getInfoLabel('System.ScreenResolution') or ''))


def manual_canvas():
    """(the rows of the canvas Kodi draws its GUI and subtitles on, where its subtitle bar can be nothing but that
    canvas's bottom, else None; what decided it), from Kodi's calibrations (calibration.py). The canvas is smaller
    than the screen (System.ScreenWidth and Height) where Kodi limits its GUI size (Linux GBM, Android): Manual
    counts its margin in its rows, and a calibration may be named by either size."""
    screen = (kodi.number(xbmc.getInfoLabel('System.ScreenWidth')),
              kodi.number(xbmc.getInfoLabel('System.ScreenHeight')))
    gui = (xbmcgui.getScreenWidth(), xbmcgui.getScreenHeight())
    sizes = [size for size in (screen, gui) if None not in size]
    return calibration.subtitle_bar(kodi.saved_settings_text(), sizes, gui[1],
                                    xbmc.getInfoLabel('System.ScreenResolution'))


def scene_rule(layout, settled, hinted=False):
    """How a followed film's scenes are placed: (the text distances for its scenes, placed_as(picture), the picture a
    scene's margin is worked out for). settled: the film's measured shape; hinted as for text_margin. The IMAX scenes
    distance only in a film whose measured picture has bars: a Dolby Vision film that fills the screen throughout is
    followed too, and its scenes keep the full-screen distance. Same as black bars: a picture taller than the measured
    one (an IMAX scene) is placed as the measured one, so the text keeps the scope scenes' height. And so is one whose
    own margin would put the text higher than in the measured picture (a large IMAX distance, a 2.20 film's 1.90
    scenes at the defaults would move the text up into the taller picture)."""
    letterboxed = not geometry.full_screen(layout.screen_w / layout.screen_h, layout.video_ratio, float(settled))
    distances = choices.scene_distances() if letterboxed else choices.distances()
    keeps_height = letterboxed and choices.keeps_bars_height()
    margins = {}

    def margin(picture, rows=distances):
        key = (float(picture), getattr(picture, 'top', 0), getattr(picture, 'bottom', 0), getattr(picture, 'height', 0),
               rows)
        if key not in margins:
            margins[key] = text_margin(layout, picture, rows, hinted).value
        return margins[key]

    def placed_as(picture):
        if not letterboxed or float(picture) >= float(settled) - 1e-6:
            return picture
        if not (keeps_height or margin(picture) >= margin(settled) - 0.001):
            return picture
        # Never below the picture's own edge at the black-bars distance: a taller picture can still have the thicker
        # bottom bar (a 2.33 scene's text 18 rows into its bar at a 2.39 film's height otherwise).
        bars = (distances[0], distances[0])
        return picture if margin(picture, bars) > margin(settled) + 0.001 else settled
    return distances, placed_as


def only_wider_moves(layout, settled):
    """Whether only a picture wider than the measured one can move a followed film's text: Same as black bars in a
    film with bars, where the measured shape is the widest seen (measure.decide). Nothing to read ahead then, and a
    look a second is enough until a wider picture shows."""
    return (not geometry.full_screen(layout.screen_w / layout.screen_h, layout.video_ratio, float(settled))
            and choices.keeps_bars_height())


def image_distance(layout, picture_ratio, distances):
    """(whether the content is full-screen, the image distance for it or geometry.DISC). distances: the two image
    distances, choices.image_distances()."""
    full = geometry.full_screen(layout.screen_w / layout.screen_h, layout.video_ratio, picture_ratio)
    return full, distances[1 if full else 0]


def font_metrics(name, bold=False):
    """The metrics of the font Kodi draws text subtitles with (fonts.Metrics), or None when its file can not be found
    or read; one log line per font file. name: subtitles.fontname, DEFAULT or a family from the user fonts folder;
    bold: the face of that weight when the family has one."""
    with _font_lock:
        if name in (None, '', geometry.KODI_FONT):
            found = (os.path.join(xbmcvfs.translatePath(SYSTEM_FONTS), FONT_DEFAULT_FILE), 0)
        else:
            found = _find(xbmcvfs.translatePath(USER_FONTS), name, bold)
            if found is None:
                _remember(('family', name), None, 'font %s: no file of that family in %s, outline added in full' % (
                    name, USER_FONTS))
                return None
        path, face = found
        key = (path, face, _stamp(path))
        if key in _fonts:
            return _fonts[key]
        try:
            metrics = fonts.read(path, face)
            _remember(key, metrics, 'font %s from %s: %d units per em, ascent %d, descent %d, lowest letter %s, '
                      'tallest %s%s' % (metrics.family, path, metrics.units_per_em, metrics.ascent, metrics.descent,
                                        metrics.depth, metrics.height, ', bold' if metrics.bold else ''))
        except fonts.Broken as why:
            metrics = None
            _remember(key, None, 'font file %s not read (%s), outline added in full' % (path, why))
        return metrics


def _stamp(path):
    try:
        return os.path.getmtime(path)
    except OSError:
        return None


def _folder_stamp(folder):
    """The folder's font files by name and time, or None when it can not be listed: a file replaced under its name
    changes it, which the folder's own time does not."""
    try:
        return tuple((name, _stamp(os.path.join(folder, name))) for name in sorted(os.listdir(folder))
                     if name.lower().endswith(fonts.EXTENSIONS))
    except OSError:
        return None


def _find(folder, name, bold):
    """fonts.find, looked up again only when the folder's font files changed (a font added, removed or replaced):
    it reads every font file in the folder."""
    key = (folder, _folder_stamp(folder), name, bold)
    if key not in _found:
        if len(_found) >= MOST_FONTS:
            _found.clear()
        _found[key] = fonts.find(folder, name, bold)
    return _found[key]


def _remember(key, metrics, line):
    """Keep what a font file gave, and say so once (a family whose file is gone is looked for every time, in case
    it comes back, but reported once)."""
    if key in _fonts:
        return
    if len(_fonts) >= MOST_FONTS:
        _fonts.clear()
    _fonts[key] = metrics
    kodi.log(line, always=True)


STYLE_SETTINGS = ('fontname', 'fontsize', 'style', 'bordersize', 'backgroundtype', 'shadowsize')


def style():
    """Kodi's subtitle settings a text margin depends on (text_reach), to tell when one changed during a film."""
    return tuple(kodi.get_setting('subtitles.' + name, quiet=True) for name in STYLE_SETTINGS)


def text_reach(top=False, hinted=True):
    """(how far the ink of a text subtitle reaches past its line box towards the edge, how much of it may end up past
    the edge, its font's metrics or None): geometry.text_reach and edge_give from Kodi's subtitle settings and the font
    file; Kodi's defaults for settings an older Kodi does not have."""
    def setting(name, default):
        value = kodi.get_setting('subtitles.' + name, quiet=True)
        return default if value is None else value
    style = kodi.number(setting('style', geometry.KODI_STYLE))
    bold = style in (geometry.STYLE_BOLD, geometry.STYLE_BOLD_ITALIC)
    metrics = font_metrics(setting('fontname', geometry.KODI_FONT), bold)
    border = setting('bordersize', geometry.KODI_BORDER_SIZE)
    background = setting('backgroundtype', geometry.KODI_BACKGROUND)
    shadow = setting('shadowsize', geometry.KODI_SHADOW_SIZE)
    return (geometry.text_reach(metrics, setting('fontsize', geometry.KODI_FONT_SIZE), border, background, shadow, bold,
                                top, hinted),
            geometry.edge_give(border, background, shadow), metrics)
