"""Turning a picture shape into Kodi's subtitle margin setting.

Kodi's setting subtitles.marginvertical is a percentage, but for text
subtitles Kodi hands it to libass as MarginV = 10.8 * value * (1080 / 720)
on a 1080 line canvas (OverlayRenderer.cpp and DVDSubtitlesLibass.cpp,
Kodi 21). One unit of the setting therefore moves subtitles by 1.5 per cent
of the height they are laid out in: the whole screen for the "of screen"
positions, the video for the "of video" positions.
"""

import math
import struct

from . import pictures

MARGIN_SCALE = 1.5                  # Kodi 21's scale of the margin and the font size settings (see CANVAS below)
MARGIN_MAX, MARGIN_STEP = 50.0, 0.05    # subtitles.marginvertical's maximum and step in Kodi 21's settings.xml

# subtitles.align values in Kodi 21.
ALIGN_MANUAL, ALIGN_BOTTOM_OF_VIDEO, ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_VIDEO, ALIGN_TOP_OF_SCREEN = range(5)


def layout_area(align):
    """'screen', 'video', or None when the position is Manual (on a PC placed all the same: placement.choose_area)."""
    if align in (ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_SCREEN):
        return 'screen'
    if align in (ALIGN_BOTTOM_OF_VIDEO, ALIGN_TOP_OF_VIDEO):
        return 'video'
    return None


def layout_top(align):
    """Whether subtitles sit at the top (their outline reaches up towards the picture's edge)."""
    return align in (ALIGN_TOP_OF_VIDEO, ALIGN_TOP_OF_SCREEN)


def video_on_screen(screen_ratio, video_ratio):
    """Height of the video as a share of the screen (Kodi's normal view mode: fitted and centred)."""
    return 1.0 if video_ratio <= screen_ratio else screen_ratio / video_ratio


def placed_ratio(picture_ratio, video_ratio, top_aligned):
    """The shape to place subtitles from: the bar on the subtitle's side on both sides.

    A picture's bars can differ (often by a row or more in real films), and
    bar_share assumes they are equal, so a shape that knows its own bars (detect.Picture) is replaced by the
    symmetric shape whose bar is the one the subtitles sit on. A plain ratio, or a Picture without rows
    (analysed rows, a cropped file's own shape), is already the answer."""
    if not pictures.has_rows(picture_ratio):
        return picture_ratio
    height = picture_ratio.height
    bar = picture_ratio.top if top_aligned else picture_ratio.bottom
    if 2 * bar >= height:       # no picture left with that bar on both sides: the shape as a whole
        return float(picture_ratio)
    return video_ratio * height / (height - 2 * bar)


def bar_share(area, screen_ratio, video_ratio, picture_ratio):
    """Height of one black bar, as a share of the area subtitles are laid out in.

    Bars at the top and bottom are equal (callers pass placed_ratio's answer where they can differ), so the same
    share applies to subtitles placed at the top.
    """
    picture_in_video = min(1.0, video_ratio / picture_ratio)
    if area == 'video':
        return (1.0 - picture_in_video) / 2
    return (1.0 - video_on_screen(screen_ratio, video_ratio) * picture_in_video) / 2


# Distances kept between the subtitles and the picture's edge, in setting units of the screen,
# as offered in the menu. Content with black bars: None or Small gap. At 0 the descenders of g, j,
# p, q and y touch the edge, outline included (checked on a box; the outline: see text_outline). Small gap is
# 0.75: about 1 per cent of the screen height (12 px
# at 1080, 24 at 2160), a quarter of a text line at Kodi's default font, halfway to Low; 0.35 was
# the outline's own thickness, a patch for the outline in the bar while distances were measured to
# the white of the letters. Full-screen content: None, Small gap, Low, Medium, Standard (Kodi's own
# default margin), High, then Custom (any value in CUSTOM_RANGE).
EDGE_GAP = 0.75
BAR_DISTANCES = (0.0, EDGE_GAP)                      # then Custom
FULL_DISTANCES = (0.0, EDGE_GAP, 1.5, 3.0, 4.95, 6.5)   # the steps agreed with the person for 0.3.24, then Custom
FULL_DEFAULT, CUSTOM = 4, 6                            # Standard, agreed as the default; Custom's place, after them
CUSTOM_RANGE = (0.0, 10.0)
# Content counts as full-screen when each bar is at most this share of the screen's height:
# 16:9, 1.85 and 1.90 on a 16:9 screen (bars up to 3.2 %), not 2.00 (5.6 %) and wider.
FULL_SCREEN_BARS = 0.04


BAR_CUSTOM = len(BAR_DISTANCES)

# Kodi lays text subtitles out on a 1080-line canvas of the area they are positioned in (the screen, or the video
# for the "of video" positions) and places the line box, from the font's ascent above the baseline to its descent
# below, at the margin above the area's bottom. The letters' ink stops short of the line box by the font's own
# slack and the outline reaches past the ink by Kodi's border size, so a distance measured from the outline's
# bottom (every text distance) adds what text_reach computes from the font file (fonts.py) and Kodi's
# subtitle settings. Kodi 21 (OverlayRenderer.cpp, DVDSubtitlesLibass.cpp, the same on master): the margin setting
# goes through a float cast, 10.8 px per unit truncated to whole pixels, then times 1.5 truncated again
# (kodi_margin_pixels: 8.65 and 8.70 both give 139, 8.75 gives 141, 8.80 gives 142, so one step moves the text 0, 1
# or 2 px); the font size is 1.5 px per unit of the setting, scaled by libass so that the font's ascent plus descent
# fills it; the outline is 0.15 px per unit of Border size; a Shadow sits 0.15 px per unit of Shadow size lower; a
# Box runs 6 px past the line box and casts the shadow; a Square box runs the outline's rounded thickness plus 6 px
# past it. A bold style on a face that is not bold is emboldened by the em over 128 on each side (libass
# ass_glyph_embolden). Checked against every row measured on the box and in the test rig.
CANVAS = 1080.0
PIXELS_PER_UNIT = 10.8 * MARGIN_SCALE               # margin setting units, on the 1080-line canvas
FONT_PIXELS_PER_UNIT = MARGIN_SCALE                  # font size setting units
OUTLINE_PER_BORDER = 0.1 * MARGIN_SCALE              # Border size and Shadow size units
BOX_OUTLINE = 4 * MARGIN_SCALE                       # Kodi's fixed outline of a Box, and the growth of a Square box
EMBOLDEN = 1 / 128                                   # of the em, each side, for a synthetic bold
# Canvas pixels of the outline (or shadow) that may end up past the picture's edge, in the bar: black on black, it
# is invisible there, while Kodi's unreachable steps would otherwise leave up to 2 px of picture under the outline
# (4K box screenshots: a sliver under every letter at sizes 32 and 74). Never any of
# the letters themselves, and nothing of a box (its colour shows against the bar).
EDGE_GIVE = 1.0
BACKGROUND_SHADOW, BACKGROUND_BOX, BACKGROUND_SQUARE_BOX = range(1, 4)   # subtitles.backgroundtype (0: none)
STYLE_BOLD, STYLE_BOLD_ITALIC = 1, 3                                                   # subtitles.style
# Kodi's own defaults: subtitles.fontname, fontsize, bordersize, shadowsize, backgroundtype, style.
KODI_FONT, KODI_FONT_SIZE, KODI_BORDER_SIZE, KODI_SHADOW_SIZE, KODI_BACKGROUND, KODI_STYLE = 'DEFAULT', 42, 25, 15, 0, 0


def _whole(value, default, floor=0):
    try:
        return max(floor, int(value))
    except (TypeError, ValueError):
        return default


def kodi_margin_pixels(value):
    """The pixels of its 1080-line canvas Kodi keeps between the line box and the area's edge for a margin setting:
    the setting cast to a float, 1080 / 100 of it truncated to whole pixels (OverlayRenderer.cpp), then 1080 / 720 of
    that truncated again (DVDSubtitlesLibass.cpp). Every third whole pixel is unreachable."""
    try:
        value = struct.unpack('f', struct.pack('f', max(0.0, float(value))))[0]
        return int(int(CANVAS / 100 * value) * (CANVAS / 720))
    except (TypeError, ValueError, OverflowError):
        return 0


def edge_give(border=KODI_BORDER_SIZE, background=KODI_BACKGROUND, shadow=KODI_SHADOW_SIZE):
    """How far the ink past the letters may end up beyond the picture's edge, in canvas px: up to EDGE_GIVE of the
    outline and shadow (dark on the black bar), nothing of a box."""
    if background in (BACKGROUND_BOX, BACKGROUND_SQUARE_BOX):
        return 0.0
    dark = OUTLINE_PER_BORDER * _whole(border, KODI_BORDER_SIZE)
    if background == BACKGROUND_SHADOW:
        dark += OUTLINE_PER_BORDER * _whole(shadow, KODI_SHADOW_SIZE)
    return min(EDGE_GIVE, dark)


def text_reach(metrics, size=KODI_FONT_SIZE, border=KODI_BORDER_SIZE, background=KODI_BACKGROUND,
               shadow=KODI_SHADOW_SIZE, bold=False, top=False, hinted=True):
    """How far a text subtitle's ink reaches past its line box towards the picture's edge, in pixels of the screen's
    1080-line canvas: below the box for the bottom positions, above it for the top ones. Negative when the outline is
    thinner than the font's slack: the ink stops inside the line box. metrics: the font's (fonts.Metrics); None when
    its file could not be read leaves the slack out (the safe side: the outline added in full). The same in every
    layout area: for the "of video" positions Kodi scales the font by the screen's height over the video's, and
    libass applies that scale to the outline, shadow and boxes as well (in the test rig a cropped 2.39 file under
    Bottom of video draws the letters and the outline at their screen size)."""
    size = _whole(size, KODI_FONT_SIZE, 1)
    border = _whole(border, KODI_BORDER_SIZE)
    shadow = _whole(shadow, KODI_SHADOW_SIZE)
    outline = OUTLINE_PER_BORDER * border
    if background in (BACKGROUND_BOX, BACKGROUND_SQUARE_BOX):
        if background == BACKGROUND_SQUARE_BOX:
            return BOX_OUTLINE + int(outline + 0.5)          # libass rounds the border half up
        return BOX_OUTLINE + (0.0 if top else OUTLINE_PER_BORDER * shadow)
    pixels = FONT_PIXELS_PER_UNIT * size
    slack = embolden = 0.0
    letters_known = False
    if metrics and metrics.ascent + metrics.descent > 0:
        total = metrics.ascent + metrics.descent
        extent = metrics.height if top else metrics.depth
        if extent is not None:
            slack = ((metrics.ascent if top else metrics.descent) - extent) * pixels / total
            letters_known = True
        if bold and not metrics.bold:
            embolden = EMBOLDEN * metrics.units_per_em * pixels / total
    reach = outline - slack + embolden
    dark_below = outline
    if background == BACKGROUND_SHADOW and not top:
        reach += OUTLINE_PER_BORDER * shadow
        dark_below += OUTLINE_PER_BORDER * shadow
    if letters_known and not top and hinted:    # hinted: the box's renderer (see _hinting_lift); a PC draws on the math
        reach -= _hinting_lift(size, dark_below)
    return reach


# On the box, small font sizes render their letters higher than the unhinted font math says. Box measurements
# (DejaVu, 4K): about 1.6 px at size 32, border 25, where sizes 56 and 74 match the model to the row.
# The lift lowers the modelled reach by that much, so On the edge takes the step the rendering really allows (size
# 32, border 25 sat a whole step high). Box only (text_reach's hinted): a PC draws the letters on the font math, within
# 0.1 px at sizes 20 to 74 on Kodi for Windows at 1440 lines (lossless shots) and within a row in the test rig at
# 1080, 1440 and 2160; applied there it puts the outline 2.7 px into the bar at 32/25. Capped so that even a
# face rendered with no lift at all could not put the letters past the picture's edge: the overshoot the give and the
# lift allow together never exceeds the dark ink below the letters.
HINT_LIFT_PER_SIZE = 0.1          # canvas px per font-size unit below HINT_LIFT_UNTIL (1.2 at size 32:
                                  # the box saw 139 px flatten about 1.1 on 1.3.1 and 141 px leave a 1.2 to 1.5 px
                                  # sliver on 1.4.0, both fitting letters rendered about 1 px above the font math)
HINT_LIFT_UNTIL = 44              # sizes measured exact on the box (56, 74) stay exactly as measured
HINT_LIFT_MOST = 1.5              # never far past the measured gap at tiny sizes


def _hinting_lift(size, dark_below):
    lift = min((HINT_LIFT_UNTIL - size) * HINT_LIFT_PER_SIZE, HINT_LIFT_MOST, dark_below - EDGE_GIVE)
    return max(0.0, lift)


def bar_distance(choice, custom=EDGE_GAP):
    if choice == BAR_CUSTOM:
        typed = custom_distance(custom)
        return EDGE_GAP if typed is None else typed
    return BAR_DISTANCES[choice] if choice in range(len(BAR_DISTANCES)) else BAR_DISTANCES[0]


def custom_distance(value, maximum=CUSTOM_RANGE[1]):
    """A typed distance in Kodi's steps, from 0 to maximum; None when it is not a number."""
    try:
        value = float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return None
    if value != value:      # NaN
        return None
    value = min(maximum, max(CUSTOM_RANGE[0], value))
    return round(round(value / MARGIN_STEP) * MARGIN_STEP, 2)


def full_distance(choice, custom):
    if choice == CUSTOM:
        typed = custom_distance(custom)
        return FULL_DISTANCES[FULL_DEFAULT] if typed is None else typed
    return FULL_DISTANCES[choice] if choice in range(len(FULL_DISTANCES)) else FULL_DISTANCES[FULL_DEFAULT]


# Image subtitles (PGS, DVD) on P3i builds: P3i places them with its "Restrict subtitles to active picture"
# and keeps them at least its "Bitmap subtitle margin" (a share of the screen's height) from the picture's
# edge. The distances use the scale of the text distances, so a choice keeps the same space on screen;
# DISC ("As on the disc") switches the restriction off, so they stay where the disc puts them. Image
# subtitles carry their own padding: the steps stop lower than for text. P3i's margin goes up to 10 per
# cent of the screen's height, 6.65 on this scale.
DISC = None
IMAGE_BAR_DISTANCES = (DISC, 0.0, EDGE_GAP, 1.5, 3.0)                 # then Custom
IMAGE_FULL_DISTANCES = (DISC, 0.0, EDGE_GAP, 1.5, 3.0, 4.95, 6.5)     # then Custom
IMAGE_DEFAULT = 0          # As on the disc: most image subtitles sit inside the picture already
BITMAP_MARGIN_MAX = 10.0   # P3i's Bitmap subtitle margin goes up to 10 per cent of the screen's height
IMAGE_CUSTOM_MAX = 6.65    # that 10 per cent on the text distances' scale


def image_distance(choice, distances, custom):
    """The distance for image subtitles, or DISC. choice indexes distances, one past them is Custom."""
    if choice == len(distances):
        typed = custom_distance(custom, IMAGE_CUSTOM_MAX)
        return EDGE_GAP if typed is None else typed     # unreadable: the field's default, as the menu shows it
    return distances[choice] if choice in range(len(distances)) else distances[IMAGE_DEFAULT]


def bitmap_margin(distance):
    """P3i's bitmap subtitle margin (per cent of the screen's height, steps of 0.1) for a distance."""
    return round(min(BITMAP_MARGIN_MAX, max(0.0, distance * MARGIN_SCALE)), 1)


def full_screen(screen_ratio, video_ratio, picture_ratio):
    return bar_share('screen', screen_ratio, video_ratio, picture_ratio) <= FULL_SCREEN_BARS


ROUNDING = 0.01        # a picture this close to its video's own shape is that shape (a bar of half a per cent)


def needed_pixels(area, screen_ratio, video_ratio, picture_ratio, bars_gap, full_gap, reach=0.0, give=0.0):
    """How far above the bottom of its layout area the line box must sit to put subtitles the chosen distance inside
    the picture, in pixels of the area's 1080-line canvas.

    The distance is full_gap for full-screen content and bars_gap for content with black bars, measured from the
    picture's edge, whether the bars are in the file or added by Kodi, and whether the "of video" position has
    already lifted them above Kodi's own bars, to where the ink reaches past the line box (reach, in pixels of the
    screen's 1080-line canvas, text_reach), less what may end up past the edge (give, edge_give). A picture within
    ROUNDING of the video's own shape is that shape (a measured 1.79 in a 1.78 file); bars Kodi adds itself always
    count, however thin (a cropped 2.39 film's 0.42 per cent bars on a 21:9 screen would otherwise take descenders
    into them at On the edge)."""
    if abs(float(picture_ratio) - video_ratio) <= ROUNDING * video_ratio:
        picture_ratio = video_ratio
    gap = full_gap if full_screen(screen_ratio, video_ratio, picture_ratio) else bars_gap
    area_share = bar_share(area, screen_ratio, video_ratio, picture_ratio)
    # The same distance on screen: the "of video" canvas covers the video's share of the screen's height.
    scale = video_on_screen(screen_ratio, video_ratio) if area == 'video' else 1.0
    return area_share * CANVAS + (gap * PIXELS_PER_UNIT + reach - give) / scale


def margin_value(area, screen_ratio, video_ratio, picture_ratio, bars_gap, full_gap, reach=0.0, give=0.0):
    """The margin setting that puts subtitles the chosen distance inside the picture (needed_pixels): the smallest
    setting on Kodi's 0.05 grid whose whole-pixel margin (kodi_margin_pixels) holds the distance, up to the next step,
    never down (on the box 8.6735 rounded to 8.65 puts the outline a row into the bar at On the edge)."""
    needed = needed_pixels(area, screen_ratio, video_ratio, picture_ratio, bars_gap, full_gap, reach, give)
    steps = max(0, math.ceil(needed / PIXELS_PER_UNIT / MARGIN_STEP - 1e-9))
    most = int(round(MARGIN_MAX / MARGIN_STEP))
    while steps < most and kodi_margin_pixels(round(steps * MARGIN_STEP, 2)) < needed - 1e-6:
        steps += 1
    return round(min(most, steps) * MARGIN_STEP, 2)


# Kodi's "Manual" position, which the add-on holds on a PC during a film: there a new margin moves a line already on
# screen at once, where every other position keeps it at its first place until the next line (libass keeps a shown line
# where it first put it unless its renderer is reconfigured, and on Manual every margin change gives libass a new line
# position, which reconfigures it; seen in the test rig with libass 0.17.1 and 0.17.3, .srt and embedded). Kodi 21 puts
# the line box's bottom at the calibration's subtitle bar less the margin in whole screen pixels (OverlayRenderer.cpp
# ResetSubtitlePosition, float maths), and turns that into a libass line position against a margin libass also applies
# (ConvertLibass): the two differ by libass's whole pixel, so the box lands a fraction of a pixel lower for some values.
# Checked against every fresh line of a sweep in the test rig (0 to 20 at 1080 lines: the text's bottom row 4 px above
# the box, as on Bottom of screen).


def _float32(value):
    return struct.unpack('f', struct.pack('f', value))[0]


def manual_bottom(value, screen_h, bar):
    """The screen row (from the top, fractional) of the line box's bottom on Manual for a margin setting: bar is the
    calibration's subtitle bar in screen rows (the screen's height unless the person moved it)."""
    try:
        value = _float32(max(0.0, float(value)))
    except (TypeError, ValueError, OverflowError):
        value = 0.0
    shift = int(_float32(_float32(_float32(float(screen_h)) / 100) * value))
    pixels = int(CANVAS / 100 * value)                               # the style's margin, before libass
    libass = int(pixels * MARGIN_SCALE) * screen_h / CANVAS          # the margin libass applies, whole canvas pixels
    kodi_side = pixels * MARGIN_SCALE * screen_h / CANVAS            # the one Kodi compensates for
    return (bar - shift) * (screen_h - libass) / (screen_h - kodi_side)


def manual_value(needed, screen_h, bar):
    """The smallest margin setting on Kodi's 0.05 grid whose Manual line box sits at least needed canvas pixels
    (needed_pixels, the screen's canvas) above the screen's bottom edge; 0 when the bar is already above that (a
    calibration bar the person moved up)."""
    target = screen_h - needed * screen_h / CANVAS                   # the lowest row the box's bottom may reach
    rows_per_step = screen_h / 100.0 * MARGIN_STEP
    steps = max(0, int((bar - target) / rows_per_step) - 2)
    most = int(round(MARGIN_MAX / MARGIN_STEP))
    while steps < most and manual_bottom(round(steps * MARGIN_STEP, 2), screen_h, bar) > target + 1e-6:
        steps += 1
    return round(min(most, steps) * MARGIN_STEP, 2)
