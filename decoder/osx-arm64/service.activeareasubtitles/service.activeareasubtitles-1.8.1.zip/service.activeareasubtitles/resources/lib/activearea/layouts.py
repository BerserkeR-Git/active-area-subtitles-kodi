"""The layouts of one playback: what each placing's layout (placement.Layout) is made from, the changes during the
film that call for a new one (the person's subtitle position or style, Kodi's window), and Kodi refusing its Manual
position, which no layout of the playback asks for again.

The layout in force for an epoch's placings is the one Playback._layout made for that epoch (made, in_force), or that
layout without Manual from the moment Kodi refuses Manual (refused); none before its own placing made it. It is made
at the epoch's first write, before Kodi can refuse anything, and before the measurement starts where nothing was
written by then. Kodi refuses Manual only at the first write of a placing that reaches Kodi (restores.TextMargin.apply:
once Manual is held nothing more is asked of the position), and a follower starts only after its placing's first write.
So a follower that reads its placing's layout at every margin reads one layout from its first look to its last, and its
margins (follow.Follower.placed among them) are all in that layout's terms.
"""
from . import kodi, kodi_session, placement


class Layouts:
    """One playback's layouts (Playback.layouts). playing: the file Kodi plays; keeps_taken: the playback carries on
    from an earlier service or from the add-on switched off and on in its own settings, so a position the person set
    during this film is still theirs (kodi_session.position_taken_in); start_position: the person's position as the
    playback began. Asked under the service's lock where it says so."""

    def __init__(self, playing, keeps_taken, own_position):
        self._playing = playing
        # The person set Kodi's subtitle position during this playback: theirs for the rest of it, no Manual over a
        # bottom position. Kept for the film in Kodi's session (kodi_session.position_taken_in), so a playback carried
        # over from the previous service (an update, a restart, switched off and on) knows it.
        if keeps_taken:
            self.position_taken = kodi_session.position_taken_in(playing)
        else:
            self.position_taken = False
            kodi_session.mark_position_taken(None)  # a new film
        # The person's position when the playback began, and the one its latest layout was made with: one that differs
        # was set during the film (before the add-on ever held Manual, nothing on record tells it).
        self.start_position = own_position()
        self.position = None
        self.style = None                    # Kodi's subtitle style the latest layout was made with (placement.style)
        # Kodi's window as the latest layout saw it (placement.canvas), and a change seen (with the service's clock
        # then), placed again once it held hold seconds (window_changed).
        self.canvas = self.canvas_seen = None
        self.normal_view = None              # whether the latest layout saw Kodi's view mode at Normal (viewed)
        self.manual_refused = False          # Kodi refused its Manual position in this playback (refused)
        self._in_force = (None, None)        # (epoch, its layout in force): the newest epoch laid out

    def take_position(self):
        """The person's position is theirs for the rest of this film, also for a service started again during it."""
        self.position_taken = True
        kodi_session.mark_position_taken(self._playing)

    def choose(self, align, pc):
        """placement.choose_area for a new layout, with the person's position align (theirs, also while Manual is held;
        None when Kodi does not say) on a PC or the box; the position and style it is made with are kept, and a position
        that differs from the one the playback began with is the person's for the rest of it."""
        if align is not None and self.start_position is not None and abs(align - self.start_position) > 0.001:
            self.take_position()
        self.position = align
        self.style = placement.style()
        kept = 'set during the film' if self.position_taken else 'refused by Kodi' if self.manual_refused else None
        return placement.choose_area(int(align) if align is not None else -1, pc, kept, placement.manual_canvas)

    def changed(self, style, margin):
        """(moved, restyled), under the lock: the person set Kodi's subtitle position during the film (taken from Manual
        the add-on held, margin.taken(), or simply not the one the latest layout was made with; theirs from now on), or
        changed its subtitle style (style: placement.style() now). A question Kodi did not answer is no change."""
        moved = margin.taken()
        if not moved:
            # Before the first layout, against the position the playback began with: one set during the first
            # measurement and back again would go unseen otherwise, Manual held over it.
            now = margin.own_position()
            then = self.position if self.position is not None else self.start_position
            moved = not (then is None or now is None or abs(now - then) < 0.001)
        restyled = (not moved and self.style is not None and None not in style
                    and None not in self.style and style != self.style)
        if moved:
            self.take_position()
        return moved, restyled

    def laid_out(self, canvas):
        """Kodi's window as a new layout is made (under the lock, for the newest epoch)."""
        self.canvas, self.canvas_seen = canvas, None

    def window_changed(self, now, clock, playing, hold, measured):
        """Under the lock: whether Kodi's window (now: placement.canvas()) changed since the latest layout and has stayed
        as it is for hold seconds of clock, the playback still playing with its shape measured (placing again while the
        first measurement runs would read the file again); it is then the window laid out for. The first look at a
        change says so in the log."""
        if not playing or self.canvas is None or now == self.canvas:
            self.canvas_seen = None
            return False
        if self.canvas_seen is None or now != self.canvas_seen[0]:
            first = self.canvas_seen is None
            self.canvas_seen = (now, clock)
            if first:
                # Kodi's own switch ended here; hold from now (a 3 to 4 s correction tells which took it).
                kodi.log('Kodi\'s window is changing (%sx%s, canvas %dx%d)' % now[:4])
            return False
        if clock - self.canvas_seen[1] < hold or not measured:
            return False
        self.canvas, self.canvas_seen = now, None
        return True

    def viewed(self, normal):
        """Kodi's view mode as a new layout is made (under the lock, for the newest epoch): Normal or not."""
        self.normal_view = normal

    def view_changed(self, normal):
        """Under the lock: whether Kodi's view mode (normal: Normal now, None when Kodi did not say) left Normal or came
        back to it since the latest layout saw it; it is then the view mode laid out for. Nothing before a layout saw
        one."""
        if normal is None or self.normal_view is None or normal == self.normal_view:
            return False
        self.normal_view = normal
        return True

    def made(self, epoch, layout):
        """The layout Playback._layout made for epoch (under the lock, the epoch current): in force for its placings,
        unless one is in force for epoch already (made at its first write, maybe refused since)."""
        if self._in_force[0] != epoch:
            self._in_force = (epoch, layout)

    def in_force(self, epoch):
        """The layout in force for epoch's placings, or None before its own placing made one: a placing of an older
        epoch's layout would write that layout's margin and position over what changed since (a position the person
        set during the first measurement, Manual written back over it). One read, no lock needed: the write that uses it
        asks again under the lock whether its epoch is current."""
        made, layout = self._in_force
        return layout if made == epoch else None

    def refused(self, layout):
        """Kodi refused its Manual position at a placing's first write that reached it (Placing._settings): the layout in
        force for that placing from now on, without Manual, and no Manual in any later layout of the playback."""
        self.manual_refused = True
        kept = layout._replace(manual=None)
        if self._in_force[1] is layout:
            self._in_force = (self._in_force[0], kept)
        return kept
