"""Is a newer Active Area Subtitles out? Asked of the repository this device installed it from.

Kodi itself looks at a repository at most once a day, so a new version can take a day
to show up. This asks the repository directly; the update itself is left to Kodi
(see actions.py). Plain Python, no Kodi, so it can be tested on its own.
"""
import http.client
import json
import os
import re
import time
import urllib.request
import xml.etree.ElementTree as ElementTree

from .keeper import write_record

ADDON_ID = 'service.activeareasubtitles'
REPOSITORY_ID = 'repository.activeareasubtitles'
# The add-on in its repository, in Kodi's add-on browser: Update there, or Install for a copy installed from a zip (Kodi
# replaces it, data kept when its question is answered No). Kodi's list of updates leaves such a copy out.
REPOSITORY_PAGE = 'ActivateWindow(AddonBrowser,addons://%s/xbmc.service/,return)' % REPOSITORY_ID
UPDATE_RECENT_S = 600.0        # a package this new belongs to the update now under way
ASKED_FILE = 'update_asked.json'   # the version the update button asked Kodi to install, for the service to check
ASKED_WAIT_S = 120.0           # Kodi installs within seconds of finding it; still the old version after this: it did not
INSTALLED, NOT_INSTALLED = 'installed', 'not_installed'
MAX_BYTES = 2 * 1024 * 1024
TIMEOUT_S = 8

# Reasons a check could not be done; actions.py turns them into the person's language.
NO_CONNECTION, NOT_NOW, NO_SOURCE = 'no_connection', 'not_now', 'no_source'


class UpdateProblem(Exception):
    """The check could not be done. args[0] is one of the reasons above."""


def repository_address(repository_addon_xml):
    """The address of the repository's addons.xml, from the repository add-on's own addon.xml."""
    try:
        root = ElementTree.fromstring(repository_addon_xml)
    except ElementTree.ParseError:
        return None
    info = root.find(".//extension[@point='xbmc.addon.repository']/dir/info")
    address = (info.text or '').strip() if info is not None else ''
    return address if address.startswith('https://') else None


def published_version(addons_xml, addon_id=ADDON_ID):
    try:
        root = ElementTree.fromstring(addons_xml)
    except ElementTree.ParseError:
        return None
    for addon in root.iter('addon'):
        if addon.get('id') == addon_id:
            return addon.get('version')
    return None


def parts(version):
    try:
        return tuple(int(p) for p in str(version).split('.')[:3])
    except ValueError:
        return None


def newer(available, installed):
    mine, theirs = parts(installed), parts(available)
    return bool(mine and theirs and theirs > mine)


def arriving(folder, version, now=None):
    """True when folder (Kodi's packages folder) holds a package of this add-on newer than version, downloaded less
    than UPDATE_RECENT_S ago: Kodi is installing an update. Anything unreadable is not an update."""
    try:
        now = time.time() if now is None else now
        mine = parts(version)
        for name in os.listdir(folder):
            found = re.match(r'%s-([0-9][0-9.]*)\.zip$' % re.escape(ADDON_ID), name)
            if found and mine and (parts(found.group(1).rstrip('.')) or ()) > mine and \
                    now - os.path.getmtime(os.path.join(folder, name)) < UPDATE_RECENT_S:
                return True
    except Exception:  # unknown: not an update
        pass
    return False


def asked(path, version, now=None):
    """Records that Kodi was asked to install version. Kodi installs only once the asking script has ended, and only
    from the repository the add-on came from (one installed from a zip announced "updating" and stayed as it was), so
    the service looks later (outcome). Raises OSError when it can not be written."""
    write_record(path, {'version': version, 'at': time.time() if now is None else now})


def outcome(path, installed, now=None):
    """INSTALLED once the asked version (or a newer one) runs, NOT_INSTALLED when it still does not ASKED_WAIT_S after
    asking (or the clock went back past that), None while nothing was asked or it is too early to say. Either answer,
    or a record that can not be read, removes the record: it is told once."""
    now = time.time() if now is None else now
    try:
        with open(path, encoding='utf-8') as handle:
            record = json.load(handle)
        version, at = str(record['version']), float(record['at'])
    except OSError:
        return None
    except (ValueError, KeyError, TypeError):
        version = at = None
    if version is None:
        answer = None
    elif not newer(version, installed):
        answer = INSTALLED
    elif abs(now - at) >= ASKED_WAIT_S:
        answer = NOT_INSTALLED
    else:
        return None
    try:
        os.remove(path)
    except OSError:
        pass
    return answer


def fetch(address, opener=urllib.request.urlopen):
    """The text at address, at most MAX_BYTES. Certificates are checked as usual."""
    try:
        with opener(address, timeout=TIMEOUT_S) as response:
            data = response.read(MAX_BYTES + 1)
    except (OSError, ValueError, http.client.HTTPException):   # the last: a reply cut off or garbled
        raise UpdateProblem(NO_CONNECTION) from None
    if len(data) > MAX_BYTES:
        raise UpdateProblem(NOT_NOW)
    return data.decode('utf-8', 'replace')


def latest(repository_addon_xml, opener=urllib.request.urlopen):
    """The version the repository offers now."""
    address = repository_address(repository_addon_xml)
    if not address:
        raise UpdateProblem(NO_SOURCE)
    version = published_version(fetch(address, opener))
    if not version:
        raise UpdateProblem(NOT_NOW)
    return version
