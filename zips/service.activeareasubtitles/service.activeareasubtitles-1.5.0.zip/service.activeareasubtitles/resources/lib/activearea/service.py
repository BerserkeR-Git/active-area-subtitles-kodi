"""The background service: find the picture's shape once per playback, then step aside.

Per playback: check that there is anything to do, work out the picture's shape (a file in a
shape of its own gets that shape at once and is measured all the same), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command. Once the shape is known nothing moves again,
except that screen capture keeps looking, slowly, for a wider picture (IMAX scenes), and that
on P3i builds another subtitle track of the other kind (text or image) is placed again.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there), elsewhere from tiny screen captures with the video file as a fallback where the
system has FFmpeg. Everything runs on its own thread; any failure leaves Kodi's normal
subtitle position.
"""
import os
import threading
import time

import xbmc
import xbmcvfs

from . import coreelec, kodi, level5, shapes, updates
from .checks import Checks, Notices
from .choices import distances, image_distances
from .guard import DecodeGuard
from .p3i import P3i
from .playback import Playback, watch_due
from .restores import Restores

UPDATE_PACKAGES = 'special://home/addons/packages/'   # where Kodi downloads an update before installing it
# Kodi says nothing when the subtitle track changes or subtitles are added during playback (no
# callback, no notification; rig, Kodi 21, 2026-10-12), so the service looks, as cheaply as it can:
# each step only Kodi's time since the last button press (a counter), the track itself only after a
# press, early in a playback (a player add-on adds subtitles then, without a press), and once in a
# while (a phone remote switches over JSON-RPC, which is not a press). Asking for the current track
# costs about 0.1 ms; normal watching asks nothing at all.
WATCH_STEP = 1.0               # seconds between looks at the time since the last button press
RECENT_INPUT = 3               # seconds after a press during which the track is looked at every step (watch_due)


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = _Monitor(self._settings_changed)
        self.enabled = kodi.setting_bool('enabled')
        self.distances = distances()
        # Every setting it changes, with its record, and the lock shared with the playbacks (restores.py).
        self.restores = Restores()
        self.lock = self.restores.lock
        self.p3i = P3i(self)                 # CoreELEC's own settings for the kind of subtitle shown (p3i.py)
        self.notices = Notices(self._playing_video)      # shown one at a time, never over a film (checks.py)
        self.checks = Checks(self, self.notices)        # CoreELEC's settings looked at, told when it matters
        self.image_distances = image_distances()
        self.current = None                  # the Playback now, or None; replaced only under the lock
        self.on_coreelec = coreelec.is_coreelec()
        self.version = kodi.addon().getAddonInfo('version')
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), self.version)
        # The picture shapes remembered across playbacks (shapes.py); the setting is read at every use.
        self.shapes = shapes.Shapes(kodi.data_path(shapes.FILE_NAME),
                                    lambda: kodi.setting_bool('remember_shapes', default=True), kodi.log)

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        self._started_playback()

    def _started_playback(self, carried_over=False):
        playback = self.begin(carried_over)
        if self._playing_video():
            threading.Thread(target=playback.fit, args=(playback.epoch,), daemon=True).start()

    def begin(self, carried_over=False):
        """A new Playback, now the current one: whatever an older one's threads still do changes nothing."""
        with self.lock:
            self.current = Playback(self, carried_over)
            return self.current

    def onAVChange(self):
        # Streams changed (Kodi says so at the start, not when subtitles are added later): see _watch_step.
        self._subtitles_arrived()

    def _subtitles_arrived(self):
        """Subtitles switched on later in a playback that had none at the start: measured now."""
        playback = self.current
        epoch = playback.waiting if playback is not None else None
        if epoch is not None and kodi.holds('VideoPlayer.HasSubtitles') and playback.claim_waiting(epoch):
            threading.Thread(target=playback.fit, args=(epoch,), daemon=True).start()

    def _watch_step(self, now=None):
        """One look during playback (see WATCH_STEP): subtitles that arrived late, and on P3i builds a
        subtitle track of the other kind."""
        playback = self.current
        if playback is None:
            return
        watch = playback.watch
        now = time.time() if now is None else now
        if not watch_due(now, watch, _pressed_lately()):
            return
        watch.looked = now
        self._subtitles_arrived()
        if playback.shown.kind is None or not self.on_coreelec:
            return                      # nothing placed by kind yet, or nothing placed by kind at all
        self.p3i.looked(playback, playback.epoch)

    def onPlayBackStopped(self):
        self.finish('playback stopped')
        self._hold_p3i_restriction()

    def onPlayBackEnded(self):
        self.finish('playback ended')
        self._hold_p3i_restriction()

    def onPlayBackError(self):
        self.finish('playback error')
        self._hold_p3i_restriction()

    def run(self):
        self.start()
        while not self.monitor.waitForAbort(WATCH_STEP):
            try:
                self.checks.settings_left()
                self.checks.update_outcome()
                self.notices.tell_waiting()
                self._watch_step()
            except Exception as error:  # Kodi could not say: looked at again next step, logged once per playback
                playback = self.current
                watch = playback.watch if playback is not None else None
                if watch is not None and not watch.failed:
                    watch.failed = True
                    kodi.log('subtitle watch: %r' % error, always=True)
        try:
            self.stopping()
        finally:
            self.guard.wait_until_idle()

    def start(self):
        """The service's start. Started during playback: Kodi updated the add-on (it does so by
        itself), it was switched on, or the service started again after a failure. What is in
        place belongs to that playback, so it is carried on: no repair, no "next video" clearing,
        measured again (the same answer changes nothing on screen)."""
        playing = self._playing_video()
        # The checks run in one order either way, so their notices queue alike (until 1.4.1 the FFmpeg check ran last
        # when a film played at the start).
        steps = (self._release_old_scan_hold, self._release_when_off, self._check_last_run, self.checks.show_status,
                 self.checks.check_ffmpeg, self.checks.check_level5_handling, self.checks.check_image_margin) if playing \
            else (self._release_old_scan_hold, self._release_when_off, self.restores.repair, self._check_last_run,
                  self.checks.show_status, self.checks.check_ffmpeg, self._hold_p3i_restriction,
                  self.checks.check_level5_handling, self.checks.check_image_margin)
        # Each step at the start on its own: one failing must not keep the others from running.
        for step in steps:
            try:
                step()
            except Exception as error:
                kodi.log('start: %s not done: %r' % (step.__name__.strip('_').replace('_', ' '), error), always=True)
        self.distances, self.image_distances = distances(), image_distances()   # no reason to place again
        self.enabled = kodi.setting_bool('enabled')     # read when the service was made: a change since counts
        if playing:
            self._started_playback(carried_over=True)

    def stopping(self):
        """The service is asked to stop. Kodi closing (it has saved its settings by now) or an
        update (the next service carries on): everything stays as it is, on record, for the next
        start. Switched off or removed in Kodi's add-ons: nobody else would put things back.

        Seen in a real Kodi 21: during an update the add-on is already unknown to Kodi when its
        service stops, as after removing it; what tells them apart is the new version's package,
        which Kodi has just downloaded. When unsure, everything is put back."""
        details = kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID, 'properties': ['enabled']},
                           quiet=True)
        addon = details.get('addon') if isinstance(details, dict) else None
        if isinstance(addon, dict) and addon.get('enabled') is True:
            why = 'Kodi closing'
        elif addon is None and updates.arriving(self._packages_folder(), self.version):
            why = 'the add-on updating'
        else:
            self.finish('add-on switched off or removed', always=True)
            self.restores.release_restriction('add-on switched off or removed', always=True)
            self.restores.release_scan('add-on switched off or removed', always=True)
            return
        with self.lock:
            self.current = None               # a measurement still running changes nothing more
        kodi.log('stopping (%s): changes stay on record for the next start' % why, always=True)

    @staticmethod
    def _packages_folder():
        """Where Kodi downloads an update before installing it, or None when Kodi can not say."""
        try:
            return xbmcvfs.translatePath(UPDATE_PACKAGES)
        except Exception:  # unknown: not an update
            return None

    def _hold_p3i_restriction(self):
        """See P3i.hold. Switched off, the person's restriction and bitmap margin are put back instead, so a write
        Kodi refused when the add-on was switched off is tried again after every playback, not only at Kodi's next
        start (history simulator, 2026-10-14). A step of the start under this name: its name is in the log line
        when it fails."""
        self._release_when_off()
        self.p3i.hold()

    def _release_when_off(self):
        """Switched off in its settings: CoreELEC's settings stay the person's. Switching off puts them back in Kodi's
        memory; when Kodi had saved the add-on's value before and then stopped without saving again (a crash),
        it starts with that value, and this finishes putting it back (found by the history simulator, 2026-10-13)."""
        if not kodi.setting_bool('enabled'):
            self.restores.release_restriction('turned off in settings', always=True)
            self.restores.release_bitmap('turned off in settings', always=True)

    def _release_old_scan_hold(self):
        self.restores.release_scan('no longer needed')

    def _check_last_run(self):
        interrupted = self.guard.check_last_run()
        if interrupted == 'skipped':
            kodi.log('Kodi stopped during a decode last time; that video is left to Kodi from now on', always=True)
        elif interrupted == 'paused':
            kodi.log('Kodi stopped during a decode twice in a row; video file analysis pauses for a day', always=True)

    def _settings_changed(self):
        """Switched off: the own margin goes back at once. Switched on during a video: measure it.
        A distance changed during a video: placed again with it. Level 5 correction off: a
        correction in place is cleared. Other changes (the status fields the service writes
        itself, among them) do nothing."""
        changed = self.distances != distances() or self.image_distances != image_distances()
        self.distances, self.image_distances = distances(), image_distances()
        if not any(self.distances):
            self.restores.distances_none()
        if not level5.enabled():
            self.restores.fix_off()
        self.checks.check_level5_handling()
        self.checks.check_image_margin()
        enabled = kodi.setting_bool('enabled')
        if enabled == self.enabled:
            playback = self.current
            if changed and enabled and self._playing_video() and playback is not None:
                kodi.log('distances changed to %.2f and %.2f: placed again' % self.distances)
                playback.place_again(playback.epoch)
            return
        self.enabled = enabled
        if not enabled:
            self.finish('turned off in settings')
            self.restores.release_restriction('turned off in settings')
            self.restores.release_scan('turned off in settings')
            return
        self._hold_p3i_restriction()
        if self._playing_video():
            self._started_playback()        # the service's own start: onAVStarted is Kodi's to call

    def _playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return False

    # Bookkeeping.

    def finish(self, why, always=False):
        # Also called by Playback._layout when the add-on is switched off while a playback starts.
        """always: log without asking for the detailed log setting (Kodi logs an error for that
        while the add-on is being switched off, even though the answer is not needed)."""
        def ended():
            self.current = None
        self.restores.finish(why, ended, always)


def _pressed_lately():
    """Whether a button was pressed in the last RECENT_INPUT seconds."""
    try:
        return xbmc.getGlobalIdleTime() < RECENT_INPUT
    except Exception:  # Kodi could not say: looked at once in a while all the same
        return False


RESTART_S, RESTART_MAX_S = 30, 1800    # after an unexpected failure of the service as a whole


def run():
    """The service, started again after anything unexpected (waiting longer each time), so one
    failure never leaves it off for the rest of the session."""
    monitor, pause = xbmc.Monitor(), RESTART_S
    while not monitor.abortRequested():
        try:
            Service().run()
            return
        except Exception as error:
            kodi.log('stopped by an unexpected error, starting again in %d s: %r' % (pause, error), always=True)
        if monitor.waitForAbort(pause):
            return
        pause = min(pause * 2, RESTART_MAX_S)
