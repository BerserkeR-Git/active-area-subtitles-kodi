"""What this Kodi knows across the add-on's interpreters, which share no Python: its session, its own process, the
newest start's claim and the position the person took during a film. Each is a property of Kodi's home window, which
lives as long as Kodi runs (a profile load included) and which every interpreter reads. Each question answers what it
does when Kodi can not say (no window manager yet, or Kodi closing), never raises."""
import time
import uuid

import xbmcgui

HOME_WINDOW = 10000
SESSION = 'activearea.kodi.session'
PROCESS = 'activearea.kodi.process'
SERVICE = 'activearea.service'
TAKEN = 'activearea.position.taken'


def _made_once(name):
    """The id the home window property name holds, made by the first to ask; None when Kodi can not say."""
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        found = home.getProperty(name)
        if not found:
            found = uuid.uuid4().hex
            home.setProperty(name, found)
        return found
    except Exception:  # Kodi closing, or no window manager yet
        return None


def session():
    """This Kodi session's id: the same until Kodi itself starts again or loads a profile (an update or a switch off
    and on of the add-on keeps it), or None when Kodi can not say. The first to ask makes it, and end_session drops it.
    Should Kodi ever drop it while running, the next is a new session: the put backs then treat what they find as ours,
    the safe side."""
    return _made_once(SESSION)


def end_session():
    """This Kodi session's id dropped: Kodi stopped the service while the add-on stays enabled (closing, or loading a
    profile, which loads that profile's settings file while Kodi runs and keeps the home window's properties). The next
    start makes a new one, so ours in memory then counts as back from disk."""
    try:
        xbmcgui.Window(HOME_WINDOW).clearProperty(SESSION)
    except Exception:  # Kodi closing, or no window manager yet
        pass


def session_known():
    """Whether this Kodi session's id was made before (by an earlier service: an update, a switch off and on, a restart
    after an error), False when the first to ask will make it (Kodi itself started, or the add-on switched on for the
    first time since), None when Kodi can not say."""
    try:
        return bool(xbmcgui.Window(HOME_WINDOW).getProperty(SESSION))
    except Exception:  # Kodi closing, or no window manager yet
        return None


def process_id():
    """This Kodi's own id: made by the first to ask and dropped by nothing, so it lives exactly as long as this Kodi
    runs (a profile load keeps it, a Kodi started again has none), on every system. None when Kodi can not say. The
    decode guard tells a crashed Kodi from this one by it (guard.DecodeGuard)."""
    return _made_once(PROCESS)


def claim_service():
    """A new start of the add-on's service, in charge from now on: a claim greater than any made before it in this
    Kodi. From the clock every interpreter shares, and above what the property holds, so two starts within a millisecond
    still order. The claim, or None when Kodi can not say (that start never learns it was taken over, as before)."""
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        claim = max(int(time.monotonic() * 1000), _claim_in(home.getProperty(SERVICE)) + 1)
        home.setProperty(SERVICE, str(claim))
        return claim
    except Exception:  # Kodi closing, or no window manager yet
        return None


def claim_held(claim):
    """Whether claim (claim_service's) is still the newest start's: no greater one in Kodi's property. Where the
    property holds none (Kodi lost its properties while it runs) or a smaller one (a start that looked after such a loss
    put its own back), claim goes back in, so whichever looks next the newest start ends up the only one in charge. True
    when claim is None or Kodi can not say: a question Kodi can not answer never stops the service in charge."""
    if claim is None:
        return True
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        found = _claim_in(home.getProperty(SERVICE))
        if found < claim:
            home.setProperty(SERVICE, str(claim))
    except Exception:  # Kodi closing, or no window manager yet
        return True
    return found <= claim


def _claim_in(text):
    """The claim the property's text holds, 0 for none."""
    try:
        return int(text)
    except (TypeError, ValueError):
        return 0


def position_taken_in(playing):
    """Whether the person set Kodi's subtitle position during the playback of playing (the file Kodi plays) in this
    Kodi session, so a service started again during that film (an update, switched off and on in Kodi's add-ons, a
    restart after an error) knows it. False when Kodi can not say."""
    try:
        return bool(playing) and xbmcgui.Window(HOME_WINDOW).getProperty(TAKEN) == playing
    except Exception:  # no window manager yet, or Kodi closing
        return False


def mark_position_taken(playing):
    """position_taken_in(playing) from now on; playing None: for no playback (a new film began)."""
    try:
        xbmcgui.Window(HOME_WINDOW).setProperty(TAKEN, playing or '')
    except Exception:  # no window manager yet, or Kodi closing: this service still knows (Playback.position_taken)
        pass
