"""Remembering the picture shape a file settled on, so the same file is not measured again.

What is remembered is the shape (the picture's ratio) and, when one was made, the Dolby Vision Level 5
judgement; never a margin: the margin is computed from the shape and the settings at every placement, so
a changed distance, font or border, or a switch between text and image subtitles, needs nothing forgotten.
The key is the file's content, not its address: a hash over its size and its first PROBE_BYTES, read the way the
measurement reads the file (a local open, Kodi's file access for anything it mounts, an HTTP range request for a
Plex part or a web file). The same file over NFS, SMB, a local disk or Plex gives the same key; two muxes of one
film never do. No path, host or date is stored. Every entry carries the detection code's version (a hash of its
source), so a change to the detection forgets everything on its own.

The file (picture-shapes.json in the add-on's data folder) is read at every use and written atomically
(keeper.write_record): a clear from the settings removes it, and a playback that looked it up before the clear
writes nothing more. Nothing is kept in memory between playbacks.
"""
import hashlib
import json
import os
import time
import urllib.parse
import urllib.request

from . import detect, keeper, locate

FILE_NAME = 'picture-shapes.json'
SCHEMA = 1
MOST_ENTRIES = 400
PROBE_BYTES = 64 * 1024
HTTP_TIMEOUT = 10.0
DETECTOR_MODULES = ('detect.py', 'measure.py', 'ffmpeg.py')
HERE = os.path.dirname(os.path.abspath(__file__))


def detector_version(folder=HERE, modules=DETECTOR_MODULES):
    """A short hash of the detection code's source; 'unknown' when it can not be read (nothing is then remembered
    or trusted)."""
    digest = hashlib.sha256()
    try:
        for name in modules:
            with open(os.path.join(folder, name), 'rb') as handle:
                digest.update(name.encode() + b'\0' + handle.read() + b'\0')
    except OSError:
        return 'unknown'
    return digest.hexdigest()[:12]


def file_key(size, head):
    """The key of a file from its size and first bytes; None without either."""
    if not head or not size or size <= 0:
        return None
    return hashlib.sha256(b'%d\n' % size + head).hexdigest()[:32]


def _size_from_headers(headers, got):
    """The whole file's size from a range reply, or the length of a reply that ignored the range."""
    content_range = headers.get('Content-Range', '') if headers else ''
    if '/' in content_range:
        try:
            return int(content_range.rsplit('/', 1)[1])
        except ValueError:
            return None
    try:
        length = int(headers.get('Content-Length', '')) if headers else 0
    except ValueError:
        return None
    return length if length >= got else None


def head_of(target, opener=None, limit=PROBE_BYTES):
    """(size, first bytes) of a target as the measurement reads it, or None when it can not be read (then it can
    not be measured either). The address may carry a token: never logged."""
    if target is None:
        return None
    try:
        if target.kind == locate.DIRECT:
            scheme = urllib.parse.urlsplit(target.address).scheme.lower()
            if scheme in ('http', 'https'):
                request = urllib.request.Request(target.address, headers={'Range': 'bytes=0-%d' % (limit - 1)})
                with (opener or urllib.request.urlopen)(request, timeout=HTTP_TIMEOUT) as reply:
                    head = reply.read(limit)
                    size = _size_from_headers(reply.headers, len(head))
            else:
                with open(target.address, 'rb') as handle:
                    head = handle.read(limit)
                size = os.path.getsize(target.address)
        else:
            import xbmcvfs
            handle = xbmcvfs.File(target.address)
            try:
                size = int(handle.size())
                head = bytes(handle.readBytes(limit))
            finally:
                handle.close()
    except Exception:  # unreadable, unreachable, or Kodi could not say
        return None
    if not head or not size or size <= 0:
        return None
    return size, head


class Entry:
    """What is remembered about one file."""

    def __init__(self, ratio, how, measured, level5=None):
        self.ratio = ratio
        self.how = how
        self.measured = measured            # seconds since the epoch
        self.level5 = level5                # ((top, bottom) or None, reason), or None when never judged

    @property
    def date(self):
        return time.strftime('%Y-%m-%d', time.localtime(self.measured))


class Memory:
    """One playback's view of the memory: the entry found for its file (or None), and the writes it may make.
    Nothing is written for a playback that looked the file up before a clear, nor without a key."""

    def __init__(self, shapes, key, length, entry, existed):
        self.shapes, self.key, self.length, self.entry, self.existed = shapes, key, length, entry, existed
        self.level5 = None                  # a judgement made before the shape was written, written with it
        self.note = ''                      # why nothing was found, for the log ("not cached yet", "off" ...)

    def remember(self, ratio, how):
        return self.shapes.remember(self, ratio, how)

    def remember_level5(self, bars, reason):
        return self.shapes.remember_level5(self, bars, reason)


class Shapes:

    def __init__(self, path, enabled, log, version=None, clock=time.time, opener=None):
        self.path = path
        self.opener = opener                # for HTTP range requests; None for urllib's own
        self.enabled = enabled              # read at every use: the setting, never cached
        self.log = log
        self.version = version or detector_version()
        self.clock = clock
        self.complained = set()             # each kind of failure is told once per service

    # Reading.

    def _read(self):
        """The entries on disk, {key: entry dict}; an unreadable or malformed file counts as empty (told once)."""
        try:
            with open(self.path, encoding='utf-8') as handle:
                data = json.load(handle)
            entries = data.get('entries') if isinstance(data, dict) and data.get('schema') == SCHEMA else None
            if not isinstance(entries, dict):
                raise ValueError('not a shapes file')
            return {key: value for key, value in entries.items() if self._valid(value)}
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as why:
            self._complain('read', 'cache: not read (%s), starting afresh' % why)
            return {}

    @staticmethod
    def _valid(value):
        try:
            return (isinstance(value, dict) and 1.0 <= float(value['ratio']) <= 4.0 and isinstance(value['how'], str)
                    and float(value['measured']) > 0 and isinstance(value['version'], str))
        except (KeyError, TypeError, ValueError):
            return False

    @staticmethod
    def _entry(value):
        level5 = value.get('level5')
        judged = None
        if isinstance(level5, dict) and isinstance(level5.get('reason'), str):
            bars = level5.get('bars')
            if bars is None:
                judged = (None, level5['reason'])
            elif isinstance(bars, list) and len(bars) == 2 and all(isinstance(bar, int) for bar in bars):
                judged = ((bars[0], bars[1]), level5['reason'])
        ratio = float(value['ratio'])
        bars = value.get('bars')
        if (isinstance(bars, list) and len(bars) == 3 and all(isinstance(bar, int) for bar in bars)
                and 0 <= bars[0] and 0 <= bars[1] and bars[0] + bars[1] < bars[2]):
            ratio = detect.Picture(ratio, *bars)
        return Entry(ratio, value['how'], float(value['measured']), judged)

    def count(self):
        return len(self._read())

    def begin(self, target, length):
        """A playback's Memory for its file: the key from the file's first bytes (read only while the setting is on)
        and the entry remembered for it, if its version is current and its length agrees."""
        if not self.enabled():
            return self._noted(Memory(self, None, length, None, False), 'off')
        found = head_of(target, self.opener) if target is not None else None
        key = file_key(*found) if found else None
        if key is None:
            return self._noted(Memory(self, None, length, None, False), 'the file could not be read to identify it')
        existed = os.path.exists(self.path)
        value = self._read().get(key) if existed else None
        memory = Memory(self, key, length, None, existed)
        if value is None:
            return self._noted(memory, 'not cached yet')
        if value.get('version') != self.version:
            return self._noted(memory, 'cached by a version that measured differently')
        if length is not None and value.get('length') is not None and abs(float(value['length']) - length) > 2.0:
            return self._noted(memory, 'the film\'s length changed')
        memory.entry = self._entry(value)
        return memory

    @staticmethod
    def _noted(memory, note):
        memory.note = note
        return memory

    # Writing.

    def remember(self, memory, ratio, how):
        """The shape a playback settled on. False when nothing was written: the setting off, no key, or the memory
        cleared since the playback looked it up."""
        if memory.key is None or not self.enabled():
            return False
        if memory.existed and not os.path.exists(self.path):
            self.log('cache: not saved, the cache was cleared during this playback')
            return False
        entries = self._read()
        value = entries.get(memory.key) if entries.get(memory.key, {}).get('version') == self.version else {}
        value = dict(value, ratio=round(float(ratio), 4), how=how, measured=self.clock(), version=self.version,
                     length=memory.length)
        # The picture's own bars, when the shape knows them (detect.Picture): placement uses the bar on the
        # subtitle's side, which the symmetric ratio alone cannot give back.
        value.pop('bars', None)
        if getattr(ratio, 'height', 0):
            value['bars'] = [int(ratio.top), int(ratio.bottom), int(ratio.height)]
        # A new measurement replaces the entry: a Level 5 judgement goes with it only when this playback made one
        # (an earlier playback's judgement is not carried over; the property test RememberedShapes found it).
        value.pop('level5', None)
        if memory.level5 is not None:
            value['level5'] = memory.level5
        entries[memory.key] = value
        if not self._write(entries):
            return False
        memory.existed = True               # written: a clear from now on stops this playback's writes
        self.log('cache: saved for the next playback of this file (%d %s cached)' % (
            min(len(entries), MOST_ENTRIES), 'file' if len(entries) == 1 else 'files'))
        return True

    def remember_level5(self, memory, bars, reason):
        """A Level 5 judgement: (top, bottom) or None, with its reason. The check runs as the shape settles, before
        the shape is written: then it is kept on the Memory and written with the shape."""
        if memory.key is None or not self.enabled():
            return False
        if memory.existed and not os.path.exists(self.path):
            return False
        memory.level5 = {'bars': [int(bars[0]), int(bars[1])] if bars else None, 'reason': str(reason)}
        entries = self._read()
        value = entries.get(memory.key)
        if value is None or value.get('version') != self.version:
            return False
        value['level5'] = memory.level5
        if not self._write(entries):
            return False
        self.log('cache: Level 5 judgement saved with the shape')
        return True

    def forget(self):
        """Removes every remembered shape and the file itself; the number forgotten."""
        count = self.count()
        for path in (self.path, self.path + '.new'):
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            except OSError as why:
                self._complain('remove', 'cache: not removed (%s)' % why)
        return count

    def _write(self, entries):
        if len(entries) > MOST_ENTRIES:
            newest = sorted(entries, key=lambda key: entries[key]['measured'], reverse=True)[:MOST_ENTRIES]
            entries = {key: entries[key] for key in newest}
        try:
            keeper.write_record(self.path, {'schema': SCHEMA, 'entries': entries})
            return True
        except OSError as why:
            self._complain('save', 'cache: not saved (%s)' % why)
            return False

    def _complain(self, kind, line):
        if kind not in self.complained:
            self.complained.add(kind)
            self.log(line, always=True)
