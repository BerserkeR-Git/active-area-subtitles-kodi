"""A measured frame as a small picture file, for the detailed log.

Only used while "Write details to the Kodi log" is on. Plain Python, no Kodi.
"""
import struct
import zlib


def png(frame, width, height, channels):
    """The frame (BGR or BGRA) as PNG bytes, in RGB."""
    raw = bytearray()
    stride = width * channels
    for row in range(height):
        raw.append(0)
        line = frame[row * stride:(row + 1) * stride]
        for x in range(0, stride, channels):
            raw += bytes((line[x + 2], line[x + 1], line[x]))

    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xFFFFFFFF)

    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(bytes(raw), 6)) + chunk(b'IEND', b''))
