"""Small helpers around Kodi's Python and JSON-RPC interfaces."""
import contextlib
import ctypes
import json
import os
import sys
import time
import uuid
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import coreelec

ADDON_ID = 'service.activeareasubtitles'
PREFIX = '[Active Area Subtitles] '


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def setting_bool(name, default=True):
    try:
        return addon().getSettingBool(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_int(name, default=0):
    try:
        return addon().getSettingInt(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_number(name, default=0.0):
    try:
        return addon().getSettingNumber(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    return folder + name


def picture_folder():
    """Where diagnostic pictures go: somewhere easy to reach from another computer.

    CoreELEC's Screenshots share (/storage/screenshots), else Kodi's own screenshot
    folder when one is set, else the add-on's data folder.
    """
    if coreelec.is_coreelec() and os.path.isdir('/storage/screenshots'):
        return '/storage/screenshots/'
    chosen = get_setting('debug.screenshotpath')
    if chosen:
        folder = xbmcvfs.translatePath(chosen)
        if os.path.isdir(folder):
            return os.path.join(folder, '')
    return data_path('')


stopping = lambda: False     # noqa: E731  Kodi stopping the add-on: the service puts its monitor's abortRequested here


def log(message, always=False):
    """A line in Kodi's log: always, or when Detailed logging is on. While Kodi stops the add-on (switched off,
    removed, updated) only the always lines: Kodi refuses the add-on's settings then, with an error in its own log
    (a thread logging while the add-on updates would leave one)."""
    if always or (not _stopping() and setting_bool('diagnostics')):
        xbmc.log(PREFIX + message, xbmc.LOGINFO)


def _stopping():
    try:
        return stopping()
    except Exception:  # Kodi refusing its own monitor: it is going away, as stopping
        return True


def rpc(method, params=None, quiet=False):
    """Call Kodi's JSON-RPC. Returns the result, or None on an error. quiet: an error is an
    expected answer, not logged (logging asks for a setting, which Kodi refuses with an error
    of its own while the add-on is being updated or removed)."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as error:  # a malformed answer, or Kodi raising (closing, say): as refused
        if not quiet:
            log('%s failed: %r' % (method, error))
        return None
    if not isinstance(reply, dict):
        return None
    if 'error' in reply:
        if not quiet:
            log('%s refused: %s' % (method, reply['error'].get('message')))
        return None
    return reply.get('result')


SAVED_SETTINGS = 'special://profile/guisettings.xml'
_saved = [None]                 # while the put backs read the file once (read_once): {} until read, then its settings


def saved_setting(setting_id):
    """What Kodi's settings file holds for setting_id (its text), or None when that is not known.

    Kodi keeps settings changed through JSON-RPC in memory only and writes them to this file at a
    clean close and from its settings window (seen in Kodi 21), with every setting in it, defaults
    included. It also writes the file on its own, holding what it has in memory (in Kodi 21
    six seconds after a start, before add-on services start), so when the file was written says nothing of who chose
    what is in it. So the file, not the value in memory, says what Kodi starts with next time. Parsed once for all
    the records inside read_once."""
    once = _saved[0]
    if once is not None and 'values' in once:
        values = once['values']
    else:
        try:
            values = {}
            for node in ElementTree.parse(xbmcvfs.translatePath(SAVED_SETTINGS)).getroot().iter('setting'):
                values.setdefault(node.get('id'), node.text or '')     # the first, as Kodi reads it
        except Exception:  # missing, half written, or Kodi could not say: unknown
            values = None
        if once is not None:
            once['values'] = values
    return None if values is None else values.get(setting_id)


@contextlib.contextmanager
def read_once():
    """Kodi's settings file parsed at most once inside (saved_setting): the put backs and the look every 30 s ask it
    for every record, for weeks on a box after a close during a film. Under the
    restores' lock, the only place records are read."""
    _saved[0] = {}
    try:
        yield
    finally:
        _saved[0] = None


def saved_settings_text():
    """Kodi's settings file as text, or None when it can not be read (the screen calibrations, calibration.py)."""
    try:
        with open(xbmcvfs.translatePath(SAVED_SETTINGS), encoding='utf-8', errors='replace') as handle:
            return handle.read()
    except Exception:  # missing, or Kodi could not say
        return None


HOME_WINDOW = 10000
SESSION = 'activearea.kodi.session'


def session():
    """This Kodi session's id: the same until Kodi itself starts again (an update or a switch off and on of the add-on
    keeps it), or None when Kodi can not say. Kept as a property of Kodi's home window, which lives as long as Kodi
    runs; the first to ask makes it. Should Kodi ever drop it while running, the next is a new session: the put backs
    then treat what they find as ours, the safe side."""
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        found = home.getProperty(SESSION)
        if not found:
            found = uuid.uuid4().hex
            home.setProperty(SESSION, found)
        return found
    except Exception:  # Kodi closing, or no window manager yet
        return None


SERVICE = 'activearea.service'


def claim_service():
    """A new start of the add-on's service, in charge from now on: a claim greater than any made before it in this
    Kodi, kept as a property of Kodi's home window, which every interpreter in this Kodi reads (they share no Python).
    From the clock every interpreter shares, and above what the property holds, so two starts within a millisecond
    still order. The claim, or None when Kodi can not say (that start never learns it was taken over, as before)."""
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        claim = max(int(time.monotonic() * 1000), _claim_in(home.getProperty(SERVICE)) + 1)
        home.setProperty(SERVICE, str(claim))
        return claim
    except Exception:  # Kodi closing, or no window manager yet
        return None


def claim_held(claim):
    """Whether claim (claim_service's) is still the newest start's: no greater one in Kodi's property. Where the
    property holds none (Kodi lost its properties while it runs) or a smaller one (a start that looked after such a loss
    put its own back), claim goes back in, so whichever looks next the newest start ends up the only one in charge. True
    when claim is None or Kodi can not say: a question Kodi can not answer never stops the service in charge."""
    if claim is None:
        return True
    try:
        home = xbmcgui.Window(HOME_WINDOW)
        found = _claim_in(home.getProperty(SERVICE))
        if found < claim:
            home.setProperty(SERVICE, str(claim))
    except Exception:  # Kodi closing, or no window manager yet
        return True
    return found <= claim


def _claim_in(text):
    """The claim the property's text holds, 0 for none."""
    try:
        return int(text)
    except (TypeError, ValueError):
        return 0


def session_known():
    """Whether this Kodi session's id was made before (by an earlier service: an update, a switch off and on, a restart
    after an error), False when the first to ask will make it (Kodi itself started, or the add-on switched on for the
    first time since), None when Kodi can not say."""
    try:
        return bool(xbmcgui.Window(HOME_WINDOW).getProperty(SESSION))
    except Exception:  # Kodi closing, or no window manager yet
        return None


# Seconds Kodi must have run before a record from an older version (before the session rule) is held against its start:
# a start of Kodi itself runs the add-on within seconds, where a box without a clock of its own may not have set the
# time yet; an update while Kodi runs comes later.
RUNNING_FOR = 600


def session_of_stamp(stamp):
    """This session for a switch's record from an older version, which held the settings file's stamp at its put back
    (keeper.session_of): when Kodi has run RUNNING_FOR and started before that stamp, the put back was made while this
    Kodi ran (the add-on updated meanwhile); else None, another session as far as anyone can tell (a crash or a close
    after it), as every record without a session."""
    age = _process_age()
    if age is None or age < RUNNING_FOR:
        return None
    now = time.time()
    return session() if now - age <= stamp <= now else None


def _process_age():
    """Seconds since Kodi's process started (the add-on runs inside it), or None where that can not be read. Linux
    and Android from the kernel's own clock since boot, Windows from the process's creation time; macOS: None."""
    try:
        with open('/proc/self/stat', encoding='ascii') as handle:
            ticks = int(handle.read().rsplit(')', 1)[1].split()[19])     # field 22, the start in clock ticks since boot
        with open('/proc/uptime', encoding='ascii') as handle:
            return float(handle.read().split()[0]) - ticks / os.sysconf('SC_CLK_TCK')
    except (OSError, ValueError, IndexError, AttributeError):
        pass
    if sys.platform != 'win32':
        return None
    try:
        created, ignored = ctypes.c_ulonglong(), [ctypes.c_ulonglong() for _ in range(3)]
        kernel = ctypes.windll.kernel32
        if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), ctypes.byref(created),
                                      *[ctypes.byref(value) for value in ignored]):
            return None
        return time.time() - (created.value / 1e7 - 11644473600)     # 100 ns steps since 1601
    except Exception:  # no ctypes for Windows here: unknown
        return None


TAKEN = 'activearea.position.taken'


def position_taken_in(playing):
    """Whether the person set Kodi's subtitle position during the playback of playing (the file Kodi plays) in this
    Kodi session: a home window property, so a service started again during that film (an update, switched off and
    on in Kodi's add-ons, a restart after an error) knows it. False when Kodi can not say."""
    try:
        return bool(playing) and xbmcgui.Window(HOME_WINDOW).getProperty(TAKEN) == playing
    except Exception:  # no window manager yet, or Kodi closing
        return False


def mark_position_taken(playing):
    """position_taken_in(playing) from now on; playing None: for no playback (a new film began)."""
    try:
        xbmcgui.Window(HOME_WINDOW).setProperty(TAKEN, playing or '')
    except Exception:  # no window manager yet, or Kodi closing: this service still knows (Playback.position_taken)
        pass


def video_player(ask=None):
    """Kodi's video player's id (JSON-RPC's Player.GetActivePlayers, asked through ask, rpc unless given), or None when
    no video plays or Kodi does not say: the one lookup of it (the stream info, the subtitle watch)."""
    players = (ask or rpc)('Player.GetActivePlayers', quiet=True)
    return next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                 and entry.get('type') == 'video'), None)


def number(text):
    """A number Kodi gave as text or a value (a label, a setting), or None when it is not one."""
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def get_setting(setting_id, quiet=False):
    result = rpc('Settings.GetSettingValue', {'setting': setting_id}, quiet=quiet)
    return result.get('value') if isinstance(result, dict) else None


def set_setting(setting_id, value):
    return rpc('Settings.SetSettingValue', {'setting': setting_id, 'value': value}) is True


def holds(condition):
    """Whether a Kodi condition holds; False when Kodi could not say."""
    try:
        return xbmc.getCondVisibility(condition)
    except Exception:  # Kodi could not say
        return False
