"""Reading, from the font file itself, the metrics libass lays a text subtitle out with.

Kodi hands text subtitles to libass with the font's family name (Kodi 21, DVDSubtitlesLibass.cpp), and libass
scales the face so that its ascent plus descent equals the font size in pixels (ass_face_set_size,
FT_SIZE_REQUEST_TYPE_REAL_DIM). The ascent and descent are the OS/2 table's usWinAscent and usWinDescent when
their sum is not zero, else hhea's pair, else the OS/2 typo pair, else the head table's bounding box (ass_font.c
set_font_metrics, after FreeType's own defaults). The line box Kodi's margin places runs from the ascent above the
baseline to the descent below it; the lowest letters stop short of its bottom by the font's own descender slack,
which only the glyph outlines tell. This module reads what is needed and nothing else, with seeks (Kodi's own
arial.ttf is 5.9 MB): the table directory, head, hhea, OS/2, maxp, cmap, loca, the headers of a handful of glyphs,
and the name table for the family. Pure Python, no Kodi imports.
"""
import collections
import os
import struct

# The letters whose ink reaches lowest and highest in a subtitle. The lowest over the set can only lower the
# estimate of where the ink stops, never raise it past the truth for any of these letters.
DESCENDERS = 'gjpqyç()[]'
ASCENDERS = 'ÀÅÉÊÎÔÜ()[]|{}bdfhklj'
EXTENSIONS = ('.ttf', '.ttc', '.otf')
NAME_FAMILY = 1
# Kodi reads the family from the Microsoft or Apple Unicode platform in English first, Macintosh Roman English
# second (FontUtils.cpp GetFamilyNameFromSfnt); the setting subtitles.fontname holds what it read.
UNICODE_PLATFORMS, MAC_PLATFORM = (0, 3), 1
ENGLISH = (0, 0x409, 0x809)
MOST_FACES, MOST_TABLES, MOST_SUBTABLES, MOST_NAMES, MOST_GROUPS = 64, 512, 64, 4096, 200000

# ascent, descent: font units above and below the baseline that libass scales to the font size (both positive).
# depth: how far below the baseline the lowest of DESCENDERS present reaches (positive); height: how far above the
# baseline the tallest of ASCENDERS reaches. Both None when the file carries no glyph outlines this module reads
# (CFF-flavoured OpenType) or none of the letters. bold: the face is a bold one (OS/2 fsSelection or head macStyle),
# so libass does not embolden it for a bold style.
Metrics = collections.namedtuple('Metrics', 'family units_per_em ascent descent depth height bold')
BOLD_SELECTION, BOLD_MAC_STYLE = 0x20, 0x01


class Broken(Exception):
    """The file is not a font this module can read: missing, truncated, another format."""


class _File:

    def __init__(self, handle):
        self.handle = handle

    def bytes(self, offset, length):
        if offset < 0 or length < 0:
            raise Broken('offset %d' % offset)
        self.handle.seek(offset)
        data = self.handle.read(length)
        if len(data) != length:
            raise Broken('truncated at %d' % offset)
        return data

    def unpack(self, layout, offset):
        return struct.unpack(layout, self.bytes(offset, struct.calcsize(layout)))

    def u16(self, offset):
        return self.unpack('>H', offset)[0]

    def i16(self, offset):
        return self.unpack('>h', offset)[0]

    def u32(self, offset):
        return self.unpack('>I', offset)[0]


def _faces(file):
    """Offsets of the table directories: one per face of a collection, one for a single font."""
    tag = file.bytes(0, 4)
    if tag == b'ttcf':
        count = file.u32(8)
        if not 0 < count <= MOST_FACES:
            raise Broken('collection of %d' % count)
        return [file.u32(12 + 4 * index) for index in range(count)]
    if tag in (b'\x00\x01\x00\x00', b'true', b'OTTO'):
        return [0]
    raise Broken('not a font (%r)' % tag)


def _tables(file, offset):
    count = file.u16(offset + 4)
    if not 0 < count <= MOST_TABLES:
        raise Broken('%d tables' % count)
    tables = {}
    for index in range(count):
        tag, _checksum, start, length = file.unpack('>4sIII', offset + 12 + 16 * index)
        tables[tag.decode('latin-1')] = (start, length)
    return tables


def _ascent_descent(file, tables):
    """libass's choice (set_font_metrics over FreeType's defaults): Windows metrics, hhea, typo, bounding box."""
    os2 = tables.get('OS/2')
    if os2 and os2[1] >= 78:
        win_ascent, win_descent = file.unpack('>hh', os2[0] + 74)      # read as signed, as libass casts them
        if win_ascent + win_descent != 0:
            return win_ascent, win_descent
    hhea = tables.get('hhea')
    if hhea and hhea[1] >= 8:
        ascender, descender = file.unpack('>hh', hhea[0] + 4)
        if ascender - descender != 0:
            return ascender, -descender
    if os2 and os2[1] >= 78:
        typo_ascender, typo_descender = file.unpack('>hh', os2[0] + 68)
        if typo_ascender - typo_descender != 0:
            return typo_ascender, -typo_descender
    y_min, y_max = file.i16(tables['head'][0] + 38), file.i16(tables['head'][0] + 42)
    if y_max - y_min == 0:
        raise Broken('no vertical metrics')
    return y_max, -y_min


def _cmap(file, tables):
    """(format, offset) of the character map to read: Unicode, the full range first."""
    if 'cmap' not in tables:
        raise Broken('no cmap table')
    start = tables['cmap'][0]
    count = file.u16(start + 2)
    if count > MOST_SUBTABLES:
        raise Broken('%d cmap subtables' % count)
    best = None
    for index in range(count):
        platform, encoding, offset = file.unpack('>HHI', start + 4 + 8 * index)
        layout = file.u16(start + offset)
        rank = {(3, 10, 12): 0, (0, 4, 12): 1, (3, 1, 4): 2, (0, 3, 4): 3}.get((platform, encoding, layout))
        if rank is None and layout in (4, 12) and platform in UNICODE_PLATFORMS:
            rank = 4
        if rank is not None and (best is None or rank < best[0]):
            best = (rank, layout, start + offset)
    if best is None:
        raise Broken('no Unicode cmap')
    return best[1], best[2]


def _lookup4(file, offset, codepoints):
    segments_x2 = file.u16(offset + 6)
    segments = segments_x2 // 2
    ends = file.unpack('>%dH' % segments, offset + 14)
    starts = file.unpack('>%dH' % segments, offset + 16 + segments_x2)
    deltas = file.unpack('>%dh' % segments, offset + 16 + 2 * segments_x2)
    ranges_at = offset + 16 + 3 * segments_x2
    ranges = file.unpack('>%dH' % segments, ranges_at)
    found = {}
    for code in codepoints:
        for index in range(segments):
            if starts[index] <= code <= ends[index]:
                if ranges[index] == 0:
                    glyph = (code + deltas[index]) & 0xFFFF
                else:
                    glyph = file.u16(ranges_at + 2 * index + ranges[index] + 2 * (code - starts[index]))
                    glyph = (glyph + deltas[index]) & 0xFFFF if glyph else 0
                if glyph:
                    found[code] = glyph
                break
    return found


def _lookup12(file, offset, codepoints):
    groups = file.u32(offset + 12)
    if groups > MOST_GROUPS:
        raise Broken('%d cmap groups' % groups)
    data = file.unpack('>%dI' % (3 * groups), offset + 16)
    found = {}
    for code in codepoints:
        for index in range(groups):
            start, end, first = data[3 * index:3 * index + 3]
            if start <= code <= end:
                if first + code - start:
                    found[code] = first + code - start
                break
    return found


def _glyph_box(file, tables, long_offsets, count, glyph):
    """(y_min, y_max) of a glyph's outline, or None when it has none (a space) or the index is out of range."""
    if glyph is None or glyph >= count:
        return None
    loca, glyf = tables['loca'], tables['glyf']
    if long_offsets:
        start, end = file.unpack('>II', loca[0] + 4 * glyph)
    else:
        start, end = (2 * value for value in file.unpack('>HH', loca[0] + 2 * glyph))
    if end - start < 10:
        return None
    _contours, _x_min, y_min, _x_max, y_max = file.unpack('>5h', glyf[0] + start)
    return y_min, y_max


def _bold(file, tables):
    os2 = tables.get('OS/2')
    if os2 and os2[1] >= 64 and file.u16(os2[0] + 62) & BOLD_SELECTION:
        return True
    return bool(file.u16(tables['head'][0] + 44) & BOLD_MAC_STYLE)


def _family(file, tables):
    name = tables.get('name')
    if not name:
        return None
    start = name[0]
    count = file.u16(start + 2)
    if count > MOST_NAMES:
        raise Broken('%d names' % count)
    strings = start + file.u16(start + 4)
    macintosh = None
    for index in range(count):
        platform, encoding, language, name_id, length, offset = file.unpack('>6H', start + 6 + 12 * index)
        if name_id != NAME_FAMILY:
            continue
        if platform in UNICODE_PLATFORMS and language in ENGLISH:
            try:
                return file.bytes(strings + offset, length).decode('utf-16-be')
            except UnicodeDecodeError:
                continue
        if platform == MAC_PLATFORM and encoding == 0 and language == 0 and macintosh is None:
            macintosh = file.bytes(strings + offset, length).decode('mac-roman', 'replace')
    return macintosh


def _metrics(file, face):
    offsets = _faces(file)
    if face >= len(offsets):
        raise Broken('no face %d' % face)
    tables = _tables(file, offsets[face])
    if 'head' not in tables:
        raise Broken('no head table')
    head = tables['head'][0]
    units = file.u16(head + 18)
    if not units:
        raise Broken('no units per em')
    ascent, descent = _ascent_descent(file, tables)
    depth = height = None
    if all(table in tables for table in ('glyf', 'loca', 'maxp')):
        long_offsets = file.i16(head + 50) == 1
        count = file.u16(tables['maxp'][0] + 4)
        layout, offset = _cmap(file, tables)
        lookup = _lookup12 if layout == 12 else _lookup4
        glyphs = lookup(file, offset, sorted({ord(letter) for letter in DESCENDERS + ASCENDERS}))
        lows = [box[0] for box in (_glyph_box(file, tables, long_offsets, count, glyphs.get(ord(letter)))
                                   for letter in DESCENDERS) if box]
        highs = [box[1] for box in (_glyph_box(file, tables, long_offsets, count, glyphs.get(ord(letter)))
                                    for letter in ASCENDERS) if box]
        depth = -min(lows) if lows else None
        height = max(highs) if highs else None
    return Metrics(_family(file, tables), units, ascent, descent, depth, height, _bold(file, tables))


def read(path, face=0):
    """The Metrics of one face of a font file; Broken says why it can not be read."""
    try:
        with open(path, 'rb') as handle:
            return _metrics(_File(handle), face)
    except OSError as error:
        raise Broken(str(error))


def families(path):
    """(family name, bold) of each face of a font file, the names as Kodi lists them (None for a face without one)."""
    try:
        with open(path, 'rb') as handle:
            file = _File(handle)
            faces = []
            for offset in _faces(file):
                tables = _tables(file, offset)
                if 'head' not in tables:
                    raise Broken('no head table')
                faces.append((_family(file, tables), _bold(file, tables)))
            return faces
    except OSError as error:
        raise Broken(str(error))


def find(folder, family, bold=False):
    """(path, face) of the font in a folder with this family name, as Kodi's list of user fonts shows it: the face
    of the asked weight when the family has one (libass picks it the same way), else the first face of the family.
    None when the folder has none (or can not be read)."""
    wanted = (family or '').casefold()
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        return None
    first = None
    for name in names:
        if not name.lower().endswith(EXTENSIONS):
            continue
        path = os.path.join(folder, name)
        try:
            for index, (found, heavy) in enumerate(families(path)):
                if found and found.casefold() == wanted:
                    if heavy == bold:
                        return path, index
                    first = first or (path, index)
        except Broken:
            continue
    return first
