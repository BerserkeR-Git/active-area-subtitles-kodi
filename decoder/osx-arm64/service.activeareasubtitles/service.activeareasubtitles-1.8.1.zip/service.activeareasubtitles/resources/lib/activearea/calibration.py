"""The subtitle bar of Kodi's screen calibration, where Kodi's Manual subtitle position starts from
(geometry.manual_bottom). Reads Kodi's settings file, writes nothing.

Kodi 21 keeps a calibration per resolution in guisettings.xml under <resolutions>, each named by its description
("output: 1920x1080 @ 60.00Hz", WinSystem.cpp and its Windows, X11 and GBM versions), and applies the one whose
description is exactly the resolution's (DisplaySettings.cpp); a resolution without one keeps its bar at the bottom of
the canvas Kodi draws its GUI and subtitles on (iHeight, GraphicContext.cpp). No info label or setting gives that
description (videoscreen.monitor says "Default" in the test rig), and a near match is not Kodi's: the test rig's screen
is "screen: 1920x1080", without the refresh rate Kodi leaves out at 0 Hz, so a calibration planted as "screen: 1920x1080
@ 0.00Hz" would be matched here, not by Kodi, and the text would land 20 rows low, in the bar. So the bar is known only
where it can not be anything but the canvas's bottom: no calibration at the screen's size or the canvas's (they differ
where Kodi limits its GUI size, Linux GBM and Android, whose names carry the screen's; Windows names carry the
canvas's), at any output or refresh rate, moves it or the overscan. Anything else keeps the person's position and the
add-on's placement before Manual.
"""
import re
import xml.etree.ElementTree as ElementTree

MODE = re.compile(r'(\d+)x(\d+)')
OVERSCAN, BAR = 'screen calibrated with overscan', 'subtitle bar calibrated'   # a calibration that moves the subtitles


def subtitle_bar(settings_text, sizes, rows, resolution_label):
    """(the bar's row on the canvas, what decided it), the row None when it can not be told. settings_text: Kodi's
    settings file, None when it could not be read; sizes: the (width, height) pairs a calibration of this screen may
    be named by (the screen's and the canvas's); rows: the canvas's height (xbmcgui.getScreenHeight), where an
    uncalibrated bar sits; resolution_label: System.ScreenResolution ("1920x1080 @ 60.00 Hz - Full screen", or
    "1920x1080 - Windowed", a window having no calibration of its own)."""
    rows = int(rows)
    sizes = {(int(width), int(height)) for width, height in sizes}
    if MODE.search(resolution_label or '') is None:
        return None, 'resolution unknown (%r)' % resolution_label
    if 'Hz' not in resolution_label:
        return rows, 'windowed'
    if settings_text is None:
        return None, 'settings file not read'
    try:
        root = ElementTree.fromstring(settings_text)
    except ElementTree.ParseError:
        return None, 'settings file not read'
    seen = False
    for node in root.iter('resolution'):
        mode = MODE.search(node.findtext('description') or '')
        if mode is None:
            continue
        size = (int(mode.group(1)), int(mode.group(2)))
        if size not in sizes:
            continue
        seen = True
        try:
            bar = int(node.findtext('subtitles', str(rows)))
            overscan = node.find('overscan')
            edges = tuple(int(overscan.findtext(side, default)) for side, default in (
                ('left', '0'), ('top', '0'), ('right', str(size[0])), ('bottom', str(size[1])))) \
                if overscan is not None else None
        except ValueError:
            return None, 'calibration not readable'
        # Kodi's default overscan is the resolution's own width and height (GraphicContext.ResetOverscan).
        if edges is not None and (edges[:2] != (0, 0) or edges[2:] not in sizes):
            return None, OVERSCAN
        if bar != rows:
            return None, '%s (row %d)' % (BAR, bar)
    return rows, 'calibrated at the bottom' if seen else 'not calibrated'


def moves_subtitles(why):
    """Whether why (subtitle_bar's, or a note quoting it) says a calibration moves the subtitles on this screen."""
    return OVERSCAN in why or BAR in why
