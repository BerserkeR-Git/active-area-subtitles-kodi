"""The two ways of finding the picture's shape, and when to trust what they see.

Each way is a generator of (ratio, how, final): a ratio may be offered early and confirmed
or corrected later, and the caller applies every one it gets. Unavailable means the way
does not work for this playback, so the next one may be tried.

- screen: tiny frame grabs of what Kodi renders (PCs and most Kodi systems).
- film: single keyframes decoded from the playing file with the system's FFmpeg
  (CoreELEC, where the video plane is out of Kodi's reach). Frames come from across the
  whole film, so an opening in another shape can not mislead it.
"""
import time

from . import detect, ffmpeg

SIXTEEN_NINE = 16.0 / 9.0

SCREEN_WIDTH = 256
SCREEN_SETTLE = 0.15          # time Kodi gets to render into a capture before it is read
SCREEN_INTERVAL = 0.3         # between grabs during the first minute
SCREEN_SLOW_INTERVAL = 2.0    # after that (long logos or a dark opening)
SCREEN_FAST_PERIOD = 60.0
SCREEN_GIVE_UP = 600.0
SCREEN_EMPTY_LIMIT = 3        # grabs in a row without an image: the grab does not work here
SCREEN_BLACK_LIMIT = 40       # first grabs all black: nothing useful comes back
SCREEN_BLACK_AFTER = 10       # black grabs in a row that end the watch for a wider shape (credits, a long fade)

# Where in the film keyframes are taken, as shares of its length, in this order.
FILM_POSITIONS = (0.5, 0.25, 0.75, 0.35, 0.65, 0.15, 0.85)
# Read as well when the widest shape was seen only once: a cinemascope scene of an IMAX film that
# one keyframe landed on usually turns up again, a misread frame does not.
FILM_MORE_POSITIONS = (0.45, 0.55, 0.3, 0.7, 0.2, 0.8)
FILM_MIN_LENGTH = 120.0       # seconds; shorter videos are measured from the screen only


class Unavailable(Exception):
    """This way of measuring does not work for the current playback."""


class LeftToCoreELEC(Exception):
    """The film's Dolby Vision Level 5 has values, so CoreELEC places the subtitles itself."""


def decide(ratios, last=False):
    """The shape to use from the clear samples so far, and whether it is settled.

    The widest shape seen (largest bars) is what keeps subtitles inside the picture in every
    scene, IMAX ones included, so it is offered first and settled once seen twice. If the
    samples run out first, the widest shape seen at least twice is used, so one misread frame
    can not decide on its own.
    """
    if not ratios:
        return None, False
    counts = _counts(ratios)
    widest = max(counts)
    if counts[widest] >= 2:
        return widest, True
    if last:
        repeated = [ratio for ratio, count in counts.items() if count >= 2]
        return (max(repeated) if repeated else widest), True
    return widest, False


def _counts(ratios):
    counts = {}
    for ratio in ratios:
        counts[ratio] = counts.get(ratio, 0) + 1
    return counts


def sure(keyframes, video_ratio):
    """True when the keyframes film() decoded settle their widest shape by seeing it twice, not as a
    last resort: only such a shape is worth keeping beyond this playback."""
    ratios = [detect.snap(entry[3].picture_ratio(video_ratio)) for entry in keyframes if entry[3].clear]
    return not unsure(ratios)


def unsure(ratios):
    """True when the widest shape among ratios was seen only once (or none was clear)."""
    return not ratios or _counts(ratios)[max(ratios)] < 2


def screen(video_ratio, current, wait, record):
    """Frame grabs until enough clear ones in a row agree. After that the grabs go on at the slow pace,
    until SCREEN_GIVE_UP or a long run of black, and a wider shape agreed on the same way is offered
    as well: an IMAX film that opens in a tall scene ends on its widest shape, as on CoreELEC. It only
    ever widens, and once settled only wider grabs go to the detailed log."""
    import xbmc   # only here: the rest of this module works without Kodi
    width, height = SCREEN_WIDTH, max(16, int(round(SCREEN_WIDTH / video_ratio)))
    agreement = detect.Agreement()
    started = time.time()
    grabs = clear = empty_run = black_run = 0
    all_black = True
    settled = None                    # the shape offered as final so far
    while current():
        elapsed = time.time() - started
        if elapsed > SCREEN_GIVE_UP:
            return
        capture = xbmc.RenderCapture()
        capture.capture(width, height)
        wait(SCREEN_SETTLE)
        frame = capture.getImage(0)
        del capture                       # releasing it stops Kodi copying frames
        grabs += 1
        sample = detect.analyse(frame, width, height)
        ratio = detect.snap(sample.picture_ratio(video_ratio)) if sample.clear else None
        if settled is None or (ratio is not None and ratio > settled):
            record(grabs, frame, width, height, 4, sample)
        nothing = sample.reason.startswith('no image')
        empty_run = empty_run + 1 if nothing else 0
        black_run = black_run + 1 if sample.reason == 'black frame' else 0
        all_black = all_black and (nothing or sample.reason == 'black frame')
        if settled is not None and (empty_run >= SCREEN_EMPTY_LIMIT or black_run >= SCREEN_BLACK_AFTER):
            return                        # settled already: the answer stands, only the widening ends
        if empty_run >= SCREEN_EMPTY_LIMIT:
            raise Unavailable('the frame grab returns no image here')
        if all_black and grabs >= SCREEN_BLACK_LIMIT:
            raise Unavailable('the frame grab returns only black here')
        if ratio is not None:
            clear += 1
            if agreement.add(ratio):
                if settled is None or agreement.ratio > settled:
                    how = 'screen, %d grabs, %d clear, %.1f s%s' % (grabs, clear, elapsed,
                                                                 '' if settled is None else ', wider')
                    settled = agreement.ratio
                    yield settled, how, True
                agreement = detect.Agreement()
        if wait(SCREEN_SLOW_INTERVAL if settled is not None or elapsed >= SCREEN_FAST_PERIOD
                else SCREEN_INTERVAL):
            return


def _level5_text(decoder):
    """What the keyframe said about Dolby Vision Level 5, for the detailed log."""
    if not getattr(decoder, 'dovi', None):
        return 'Dolby Vision metadata not readable with this FFmpeg'
    level5 = getattr(decoder, 'level5', None)
    if level5 is None:
        return 'no Dolby Vision Level 5'
    return 'Level 5 top %d, bottom %d' % tuple(level5[:2])


def film(target, length, video_ratio, memory_path, current, record, guard, full=False, level5_hands_over=False,
         keyframes=None):
    """Keyframes from across the film; the widest clear shape is offered at once, and settled once
    every keyframe is in (about 0.3 s each on a box), so an IMAX film whose first keyframes land in
    its tall scenes still ends on its widest shape.

    target is a locate.Target. guard() wraps every decode (see guard.DecodeGuard.decoding).
    level5_hands_over: CoreELEC restricts subtitles once Level 5 has values, and it was zero at
    the start. Each keyframe's Level 5 is read along with it (no extra decoding); values in any
    of them raise LeftToCoreELEC, before that keyframe's shape is offered.
    keyframes: a list that gets what each decoded keyframe said, for level5_correction, so a Level 5
    check after measuring needs no second decode.
    """
    if length < FILM_MIN_LENGTH:
        raise Unavailable('no film length to sample from')
    try:
        decoder = ffmpeg.Decoder(target, memory_path, full=full)
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    ratios, offered, number, decoded = [], None, 0, 0
    try:
        with guard():
            decoder.__enter__()
        try:
            for share in FILM_POSITIONS + FILM_MORE_POSITIONS:
                if number == len(FILM_POSITIONS) and not (decoded and unsure(ratios)):
                    break                     # sure already, or this file gives no keyframes
                number += 1
                if not current():
                    return
                with guard():
                    frame, detail = decoder.sample(length * share)
                if frame is None:
                    record(number, None, decoder.out_w, decoder.out_h, 3, None, detail)
                    continue
                decoded += 1
                level5 = getattr(decoder, 'level5', None)
                if level5_hands_over and level5 and any(level5[:2]):   # top or bottom, as CoreELEC restricts
                    raise LeftToCoreELEC('Level 5 at %d s: top %d, bottom %d' % (length * share, level5[0], level5[1]))
                sample = detect.analyse(frame, decoder.out_w, decoder.out_h, 3)
                if keyframes is not None:
                    keyframes.append(_keyframe(decoder, sample))
                record(number, frame, decoder.out_w, decoder.out_h, 3, sample, '%s, %s' % (detail, _level5_text(decoder)))
                if sample.clear:
                    ratios.append(detect.snap(sample.picture_ratio(video_ratio)))
                ratio, _settled = decide(ratios)
                how = 'file, %d keyframes, %d clear, %s, %s' % (number, len(ratios), target.description,
                                                              decoder.description)
                if ratio is not None and ratio != offered:
                    offered = ratio
                    yield ratio, how, False
        finally:
            decoder.close()
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    ratio, _settled = decide(ratios, last=True)
    if ratio is not None:
        yield ratio, 'file, %d clear of %d keyframes, %s, %s' % (len(ratios), number, target.description,
                                                              decoder.description), True


LEVEL5_AGREEING = 3      # clear keyframes that must agree before a film's Level 5 is corrected
LEVEL5_ROWS_APART = 2    # rows of the analysed frame (144) Level 5 must be off by, at the top or the
                         # bottom, in every keyframe: finer is measuring precision (15 pixels at 2160)


def level5_bars(target, length, memory_path, current, guard, keyframes=4):
    """The tallest Level 5 bar among a few keyframes, as a share of the frame's height, or None
    when none of them carries Level 5. Raises Unavailable."""
    if length < FILM_MIN_LENGTH:
        raise Unavailable('no film length to sample from')
    tallest = None
    try:
        decoder = ffmpeg.Decoder(target, memory_path)
        with guard():
            decoder.__enter__()
        try:
            for share in FILM_POSITIONS[:keyframes]:
                if not current():
                    return tallest
                with guard():
                    frame, _detail = decoder.sample(length * share)
                level5, size = decoder.level5, decoder.frame_size
                if frame is None or not level5 or not size or not size[1]:
                    continue
                bar = max(level5[0], level5[1]) / size[1]
                tallest = bar if tallest is None else max(tallest, bar)
        finally:
            decoder.close()
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    return tallest


def _keyframe(decoder, sample):
    """What one decoded keyframe says for level5_correction: (Level 5 or None, whether it carried
    Dolby Vision metadata, the frame's own size, the analysed sample, the analysed height)."""
    return (decoder.level5, bool(getattr(decoder, 'dovi_frame', False)), decoder.frame_size, sample, decoder.out_h)


def level5_correction(target, length, memory_path, current, guard, keyframes=None):
    """Whether a Dolby Vision film's own Level 5 is wrong, and what it should be.

    Returns ((top, bottom) or None, reason for the log). (top, bottom) are the picture's bars
    in the frame's own pixels, for CoreELEC's Level 5 override, which also goes to the TV. A film
    is corrected when every clear keyframe (at least three) shows the same picture and the Level 5
    of at least one of them does not fit it: wrong, dropping to zero in some scenes, or missing in
    a Dolby Vision stream. Each keyframe's Level 5 is held against its own picture, so correct
    Level 5 that follows IMAX scenes is never touched; films whose picture changes are left as
    they are, as is Level 5 with side bars and a stream whose Dolby Vision metadata this FFmpeg
    can not read. keyframes: what measuring already decoded (see film); without them the
    keyframes are decoded here. Raises Unavailable.
    """
    if keyframes:
        return judge_level5(keyframes)
    if length < FILM_MIN_LENGTH:
        raise Unavailable('no film length to sample from')
    keyframes = []
    try:
        decoder = ffmpeg.Decoder(target, memory_path)
        with guard():
            decoder.__enter__()
        try:
            for share in FILM_POSITIONS:
                if not current():
                    return None, 'playback changed'
                with guard():
                    frame, _detail = decoder.sample(length * share)
                if frame is None:
                    continue
                keyframes.append(_keyframe(decoder, detect.analyse(frame, decoder.out_w, decoder.out_h, 3)))
                if judge_level5(keyframes, complete=False) is not None:
                    break                     # decided already: no need to decode the rest
        finally:
            decoder.close()
    except ffmpeg.Unavailable as reason:
        raise Unavailable(str(reason))
    return judge_level5(keyframes)


def judge_level5(keyframes, complete=True):
    """level5_correction's verdict on what the keyframes said (see _keyframe). Not complete: the
    verdict only when more keyframes could not change it, else None."""
    seen = []
    for level5, dovi_frame, size, sample, analysed_height in keyframes:
        if level5 is None:
            if not dovi_frame:
                return None, 'no Dolby Vision metadata readable'
            level5 = (0, 0, 0, 0)        # Dolby Vision without Level 5: taken as the full frame
        if any(level5[2:]):
            return None, 'Level 5 with side bars'
        if not sample.clear or not size:
            continue
        width, height = size
        seen.append((tuple(level5), detect.snap(sample.picture_ratio(width / height)), size,
                     (sample.top, sample.bottom), analysed_height))
        if len({entry[1] for entry in seen}) > 1:
            return None, 'the picture changes during the film'
    if not complete:
        return None
    if len(seen) < LEVEL5_AGREEING:
        return None, 'too few clear keyframes to judge'
    _level5, picture, (width, height), _rows, _analysed = seen[0]
    off = [any(abs(level5[side] * analysed / height - rows[side]) > LEVEL5_ROWS_APART for side in (0, 1))
           for level5, _picture, _size, rows, analysed in seen]
    if not any(off):
        return None, 'Level 5 matches the picture (%.2f)' % picture
    bars = max(0, height - round(width / picture))
    if bars < height * 0.005:    # rounding between a standard shape and the frame's own: no bars
        bars = 0
    given = ' and '.join(sorted({'%d/%d' % level5[:2] for level5, _picture, _size, _rows, _analysed in seen}))
    return (bars // 2, bars - bars // 2), 'Level 5 says %s, the picture is %.2f' % (given, picture)
