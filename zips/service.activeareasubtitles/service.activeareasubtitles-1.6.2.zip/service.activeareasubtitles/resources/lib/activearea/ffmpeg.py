"""Decoding single keyframes from the playing file with FFmpeg's libraries: the decoder shipped inside the add-on
where there is one for the system, else the system's own (always on CoreELEC). libav.py finds and loads them;
keyframes.py's film reader is what the rest of the add-on decodes through, and each keyframe comes back as a
keyframes.Keyframe.

Used where Kodi's own frame grab cannot see the video (CoreELEC, Amlogic's hardware video
plane), first on a PC with a decoder, and as the fallback where the frame grab gives no picture.

Files are opened directly (local paths, web addresses) or read through Kodi's own file
access (smb://, nfs://, ...) via a custom FFmpeg I/O context. Probing is kept short: only
the video stream's settings are needed, and they sit in the file's header.

A few FFmpeg structures are read directly. Their layout is only relied on for libavformat 61
and 62 (FFmpeg 7 and 8), and every pointer and size read is checked before it is used. The
playing address can carry an access token: it is never logged or stored.
"""
import bisect
import ctypes
import math
import re
import time

from . import detect, keyframes, libav, locate

P = ctypes.sizeof(ctypes.c_void_p)
AVMEDIA_TYPE_VIDEO = 0
AVMEDIA_TYPE_SUBTITLE = 3
AV_DISPOSITION_DEFAULT, AV_DISPOSITION_ATTACHED_PIC = 0x1, 0x400
AV_DISPOSITION_FORCED, AV_DISPOSITION_HEARING_IMPAIRED = 0x40, 0x80
DISPOSITION_KNOWN = (1 << 22) - 1    # every AV_DISPOSITION flag of FFmpeg 7 and 8 lies below this
AVSEEK_FLAG_BACKWARD = 1
AVDISCARD_DEFAULT = 0
AVDISCARD_NONKEY = 32
AVDISCARD_ALL = 48
AVERROR_EAGAIN = -11      # the decoder wants more input first
MAX_PACKETS_PER_SAMPLE = 600
DRAIN_WITHIN = 60.0       # seconds before the position a keyframe held back is drained at once (see sample)
SEQUENCE_MOST = 480       # frames sequence() decodes at most (20 s at 24 frames a second, 8 at 60)
SEQUENCE_EARLIER = (0.0, 2.0, 5.0)   # seconds before its start a sequence seeks again when the seek landed past it
SEQUENCE_AT = 0.001       # seconds past its start a sequence's first frame (its keyframe) may be: none (0.05 let a
                          # stretch start a frame past its keyframe)


Unavailable = libav.Unavailable


# Decoding --------------------------------------------------------------------------------

AVSEEK_SIZE = 0x10000
AVERROR_EOF = -0x20464F45
IO_BUFFER = 64 * 1024
PROBE_OPTIONS = ((b'probesize', b'2000000'), (b'analyzeduration', b'1000000'),
                 (b'rw_timeout', b'5000000'))   # a stalled network read gives up after 5 s
# Brightness planes this module can read: 8 to 16 bits, little endian, luma first.
PLANAR_YUV = ('yuv', 'nv12', 'nv21', 'nv16', 'nv24', 'p010le', 'p012le', 'p016le', 'gray')
EDGE_SHARE = 0.25          # rows near the top and bottom edges that bars can occupy (detect uses 22 %)


def _pointer(address, offset):
    if not address:
        raise Unavailable('unexpected empty pointer')
    return ctypes.c_void_p.from_address(address + offset).value


def _integer(address, offset):
    return ctypes.c_int.from_address(address + offset).value


def _start_seconds(stream, wraps=True):
    """An AVStream's start time in seconds: None when it has none or a damaged one, 0 for a negative one (an MP4's
    edit list). wraps: the file's clock wraps at START_MOST (_wraps), so a start past it is damaged."""
    start = ctypes.c_int64.from_address(stream + START_TIME_AT).value
    num, den = _integer(stream, TIME_BASE_AT), _integer(stream, TIME_BASE_AT + 4)
    if start == AV_NOPTS_VALUE or num <= 0 or den <= 0:
        return None
    seconds = start * num / den
    if wraps and seconds >= START_MOST:
        return None
    return max(0.0, seconds)


def _earliest_start(fmt, count, wraps=True):
    """The file's own first time in seconds, which Kodi's times count from: the earliest start over its count
    streams, as FFmpeg's AVFormatContext.start_time (Kodi's demuxer subtracts it from every time); 0 when no stream
    has one. The video stream's own start shifted every position by what the audio started earlier."""
    streams = _pointer(fmt, STREAMS_AT)
    starts = [_start_seconds(_pointer(streams, index * P), wraps) for index in range(min(count, 256))]
    found = [start for start in starts if start is not None]
    return min(found) if found else 0.0


# Every structure offset read below comes from libav.LAYOUT, the one list a shipped decoder is built and checked
# against.
_L = libav.LAYOUT
PB_AT, NB_STREAMS_AT, STREAMS_AT = _L['AVFormatContext.pb'], _L['AVFormatContext.nb_streams'], _L['AVFormatContext.streams']
CODECPAR_AT = _L['AVStream.codecpar']
DISPOSITION_AT, DISCARD_AT, METADATA_AT = _L['AVStream.disposition'], _L['AVStream.discard'], _L['AVStream.metadata']
CODEC_TYPE_AT, CODEC_ID_AT = _L['AVCodecParameters.codec_type'], _L['AVCodecParameters.codec_id']
PTS_AT, DTS_AT, STREAM_INDEX_AT = _L['AVPacket.pts'], _L['AVPacket.dts'], _L['AVPacket.stream_index']
FLAGS_AT = STREAM_INDEX_AT + 4      # AVPacket.flags, the int after stream_index in FFmpeg 4 to 8
AV_PKT_FLAG_KEY = 1
FRAME_DATA_AT, LINESIZE_AT = _L['AVFrame.data'], _L['AVFrame.linesize']
WIDTH_AT, HEIGHT_AT, FORMAT_AT = _L['AVFrame.width'], _L['AVFrame.height'], _L['AVFrame.format']
SIDE_DATA_AT, ENTRY_VALUE_AT, IO_BUFFER_AT = _L['AVFrameSideData.data'], _L['AVDictionaryEntry.value'], _L['AVIOContext.buffer']
LEVEL_AT = _L['AVDOVIDmData.level']
LEVEL5_LEFT_AT, LEVEL5_RIGHT_AT = _L['AVDOVIDmLevel5.left_offset'], _L['AVDOVIDmLevel5.right_offset']
LEVEL5_TOP_AT, LEVEL5_BOTTOM_AT = _L['AVDOVIDmLevel5.top_offset'], _L['AVDOVIDmLevel5.bottom_offset']
AV_NOPTS_VALUE = -(1 << 63)
# AVFrame.pts where FFmpeg 7 and 8 put it after format (key_frame, gone in 8, pict_type, sample_aspect_ratio): read only
# where it says one of the packet times sent (checked once per file), so a shipped decoder needs no new entry.
FRAME_PTS_CANDIDATES = sorted({WIDTH_AT + 32, WIDTH_AT + 28})
# AVStream.time_base (two ints) and start_time (64-bit), placed by what libav.layout builds AVStream.disposition from:
# time_base after av_class, index, id, codecpar and priv_data, start_time 24 bytes before disposition. A manifest whose
# disposition passed its check places these too, so a shipped decoder needs no new entry.
TIME_BASE_AT, START_TIME_AT = CODECPAR_AT + 2 * P, DISPOSITION_AT - 24
# A transport stream's 33-bit 90 kHz PTS wraps here (about 26.5 h), and a broadcast capture's first time can lie
# anywhere below it; a start past it is a damaged header, read as none (at 24 h a capture whose first time lay above
# it had every seek land on its first keyframe). Only for the formats with that clock (_wraps): Matroska and MP4 count
# in 64 bits, and a start of 28 h there is the file's own.
START_MOST = 2 ** 33 / 90000 + 1
WRAPPING_FORMATS = ('mpegts', 'mpegtsraw', 'mpeg', 'hls')
# AVFormatContext.iformat, two pointers ahead of priv_data and pb in FFmpeg 7 and 8; AVInputFormat's name comes first.
IFORMAT_AT = PB_AT - 3 * P
# A first time under this (a decoding delay, audio a little ahead of the picture) moves no position out of the film,
# so Kodi's length is used as it is (Decoder.playable).
OFFSET_START = 60.0
# The side data type of a frame's display matrix, looked up by its name (_side_data_kind).
DISPLAY_MATRIX = b'3x3 displaymatrix'


def _wraps(fmt):
    """True when the file's clock is a transport or program stream's 90 kHz one, which wraps at START_MOST (and when
    the format can not be told, as before)."""
    iformat = _pointer(fmt, IFORMAT_AT)
    name = ctypes.c_void_p.from_address(iformat).value if iformat else None
    if not name:
        return True
    return any(part in WRAPPING_FORMATS for part in ctypes.string_at(name).decode('ascii', 'replace').split(','))


def _kodi_video_stream(fmt, count):
    """The video stream Kodi plays, as VideoPlayer's OpenDefaultStreams picks it: the first flagged default, else the
    first in file order, never a cover picture (Kodi will not open one). FFmpeg's own pick (av_find_best_stream) ranks
    by frames and bit rate as well, and decoded a default-flagged still ahead of the film only where Kodi played the
    still too. -1 (FFmpeg's pick) without a video stream, or where a disposition does not read as one (another
    layout)."""
    first = -1
    for index in range(min(count, 256)):
        stream = _pointer(_pointer(fmt, STREAMS_AT), index * P)
        codecpar = _pointer(stream, CODECPAR_AT)
        if not codecpar or _integer(codecpar, CODEC_TYPE_AT) != AVMEDIA_TYPE_VIDEO:
            continue
        disposition = _integer(stream, DISPOSITION_AT)
        if disposition & ~DISPOSITION_KNOWN:
            return -1
        if disposition & AV_DISPOSITION_ATTACHED_PIC:
            continue
        if disposition & AV_DISPOSITION_DEFAULT:
            return index
        if first < 0:
            first = index
    return first


def orientation(matrix):
    """How far Kodi turns the picture, in degrees, from a display matrix (nine 32-bit numbers, 16.16 fixed point where
    it matters), worked out as Kodi's demuxer does with av_display_rotation_get: 0, 90, 180 or 270 for a real file.
    0 for a matrix whose scale is none."""
    a, b, _u, c, d = (value / 65536 for value in matrix[:5])
    across, down = math.hypot(a, c), math.hypot(b, d)
    if not across or not down:
        return 0
    return int(math.degrees(math.atan2(b / down, a / across))) % 360


READ_PACKET = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int)
SEEK = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_void_p, ctypes.c_int64, ctypes.c_int)


def _declare(avformat, avcodec, avutil):
    vp, i = ctypes.c_void_p, ctypes.c_int
    pp = ctypes.POINTER(vp)
    for function, result, arguments in (
            (avformat.avformat_alloc_context, vp, []),
            (avformat.avformat_open_input, i, [pp, ctypes.c_char_p, vp, pp]),
            (avformat.avformat_find_stream_info, i, [vp, vp]),
            (avformat.av_find_best_stream, i, [vp, i, i, i, pp, i]),
            (avformat.av_seek_frame, i, [vp, i, ctypes.c_int64, i]),
            (avformat.av_read_frame, i, [vp, vp]),
            (avformat.avformat_close_input, None, [pp]),
            (avformat.avio_alloc_context, vp, [vp, i, i, vp, READ_PACKET, vp, SEEK]),
            (avformat.avio_context_free, None, [pp]),
            (avcodec.avcodec_alloc_context3, vp, [vp]),
            (avcodec.avcodec_parameters_to_context, i, [vp, vp]),
            (avcodec.avcodec_open2, i, [vp, vp, vp]),
            (avcodec.avcodec_send_packet, i, [vp, vp]),
            (avcodec.avcodec_receive_frame, i, [vp, vp]),
            (avcodec.avcodec_flush_buffers, None, [vp]),
            (avcodec.avcodec_free_context, None, [pp]),
            (avcodec.av_packet_alloc, vp, []),
            (avcodec.av_packet_unref, None, [vp]),
            (avcodec.av_packet_free, None, [pp]),
            (avutil.av_frame_alloc, vp, []),
            (avutil.av_frame_free, None, [pp]),
            (avutil.av_malloc, vp, [ctypes.c_size_t]),
            (avutil.av_free, None, [vp]),
            (avutil.av_dict_set, i, [pp, ctypes.c_char_p, ctypes.c_char_p, i]),
            (avutil.av_dict_free, None, [pp]),
            (avutil.av_opt_set_int, i, [vp, ctypes.c_char_p, ctypes.c_int64, i]),
            (avutil.av_get_pix_fmt_name, ctypes.c_char_p, [i]),
            (avutil.av_frame_get_side_data, vp, [vp, i]),
            (avutil.av_frame_side_data_name, ctypes.c_char_p, [i]),
            (avutil.av_dict_get, vp, [vp, ctypes.c_char_p, vp, i]),
            (avcodec.avcodec_get_name, ctypes.c_char_p, [i])):
        function.restype, function.argtypes = result, arguments


def _side_data_kind(avutil, name):
    """The frame side data type with this name, or None: looked up by its name, so a renumbered list in a later FFmpeg
    can not make it read the wrong data."""
    return next((number for number in range(64) if avutil.av_frame_side_data_name(number) == name), None)


def _dovi_reader(avutil):
    """(side data type, av_dovi_find_level) for reading Dolby Vision metadata, or None where this
    FFmpeg has no way to (av_dovi_find_level arrived with FFmpeg 7). The type is looked up by
    its name, so a renumbered list in a later FFmpeg can not make it read the wrong data."""
    try:
        find_level = avutil.av_dovi_find_level
    except AttributeError:
        return None
    find_level.restype, find_level.argtypes = ctypes.c_void_p, [ctypes.c_void_p, ctypes.c_uint8]
    for number in range(64):
        if avutil.av_frame_side_data_name(number) == b'Dolby Vision Metadata':
            return number, find_level
    return None




def readable_format(name):
    """True for picture formats whose first plane is brightness, little endian, 8 to 16 bits."""
    return name.startswith(PLANAR_YUV) and not name.endswith('be')


def frame_layout_ok(data, width, height, line, wide):
    """The decoded frame's plane pointer, size and row length make sense before any byte is read."""
    return bool(data) and 16 <= width <= 16384 and 16 <= height <= 16384 and line >= width * wide


def pixel_depth(name):
    """Bits a brightness sample spans, for the shift to 8 bits: yuv420p10le and gray12le carry it at the end
    (their samples sit in the low bits); everything else (yuv420p, nv12, gray) is 8 bits. p010le, p012le and
    p016le keep their samples in the high bits of 16, so they span 16 (read as 10 they came out up to 16383)."""
    if re.match(r'p0(10|12|16)le$', name):
        return 16
    match = re.search(r'(?:p|gray)(9|10|12|14|16)le$', name)
    return int(match.group(1)) if match else 8


def grey_frame(read_row, width, height, depth, out_w, out_h, full=False):
    """A small BGR frame of the brightness plane, out_w x out_h.

    read_row(y) returns the raw bytes of source row y. Without full, only the rows near the
    top and bottom edges are read (where bars can be); the middle is filled with one row, as
    the bar detection never looks there. depth is 8 to 16 bits.
    """
    wide = 2 if depth > 8 else 1
    shift = depth - 8
    step = max(1, width // out_w)
    edge = int(out_h * EDGE_SHARE) + 1

    def row(y):
        data = memoryview(read_row((2 * y + 1) * height // (2 * out_h)))   # the middle of each band
        values = (data.cast('H') if wide == 2 else data)[::step][:out_w]
        grey = bytes(map(shift.__rrshift__, values)) if wide == 2 else bytes(values)   # v >> shift, at C speed
        grey = grey.ljust(out_w, grey[-1:] or b'\0')
        bgr = bytearray(out_w * 3)          # each value three times, at C speed
        bgr[0::3] = bgr[1::3] = bgr[2::3] = grey
        return bytes(bgr)

    if full:
        return b''.join(row(y) for y in range(out_h))
    middle = row(out_h // 2)
    rows = [row(y) if y < edge or y >= out_h - edge else middle for y in range(out_h)]
    return b''.join(rows)


CURRENT_EVERY = 0.5     # seconds between the reader's checks that its playback is still current


def _nothing(detail):
    return keyframes.Keyframe(None, detail)


class KodiReader:
    """Kodi's file access, for FFmpeg's custom I/O. Errors read as end of file.

    current: asked at most every CURRENT_EVERY seconds while reading; once it says no, every read
    is the end of the file, so a slow share ends the decode within one read instead of carrying on
    for a playback that is gone. A read already stalled inside Kodi can not be cut short.
    """

    def __init__(self, address, current=None):
        import xbmcvfs
        self.current, self.checked, self.stopped = current, time.monotonic(), False
        self.file = xbmcvfs.File(address)
        try:
            self.length = int(self.file.size())
        except Exception:  # Kodi could not say
            self.length = -1
        if self.length == 0:
            self.file.close()
            raise Unavailable('Kodi can not read the source')

    def read(self, size):
        if self.current is not None and not self.stopped and time.monotonic() - self.checked >= CURRENT_EVERY:
            self.checked = time.monotonic()
            try:
                self.stopped = not self.current()
            except Exception:  # Kodi could not say: the measuring loop asks again before the next keyframe
                pass
        if self.stopped:
            return b''
        try:
            return bytes(self.file.readBytes(size))
        except Exception:  # an unreachable share reads as the end of the file
            return b''

    def seek(self, offset, whence):
        if whence & AVSEEK_SIZE:
            return self.length
        try:
            return int(self.file.seek(offset, whence & 3))
        except Exception:
            return -1

    def close(self):
        try:
            self.file.close()
        except Exception:
            pass


class Decoder:
    """One open file. sample(seconds) returns a small grey BGR frame of a keyframe there.

    target: a locate.Target (kind 'direct' opens target.address with FFmpeg, 'kodi' reads it
    through Kodi). Use as a context manager; everything allocated is freed on exit.
    """

    start = 0.0         # seconds: the file's own first time (a .ts file's can be 600, _earliest_start), set at open
    wraps = True        # the file's clock wraps at START_MOST (_wraps), set at open
    display = None      # the side data type of a frame's display matrix in this FFmpeg (_side_data_kind)

    def __init__(self, target, memory_path, width=128, height=288, full=False, background=True, current=None):
        """background: decoding lowers the calling thread's priority (set for the thread's whole life).
        current: whether the playback is still current, for reads through Kodi (see KodiReader)."""
        self.background, self.current = background, current
        found = libav.libraries(memory_path)
        self.avformat, self.avcodec, self.avutil, self.description = found[:4]
        self.network = found.network     # False: network addresses are read through Kodi (a shipped decoder)
        _declare(self.avformat, self.avcodec, self.avutil)
        self.target, self.out_w, self.out_h, self.full = target, width, height, full
        self.fmt, self.ctx = ctypes.c_void_p(), ctypes.c_void_p()
        self.pkt, self.frame, self.avio = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
        self.reader, self.callbacks, self.index = None, None, -1
        self.dovi = _dovi_reader(self.avutil)
        self.display = _side_data_kind(self.avutil, DISPLAY_MATRIX)
        self.seen_pts = set()   # the packet times of the keyframes decoded: the same one again is no new sample
        self.rows = None        # (read_row, width, height, depth) of the keyframe just decoded, for exact()
        self.time_base = None   # the video stream's (numerator, denominator), for a keyframe's film time
        self.frame_pts_at = None  # where a decoded frame's own time is (FRAME_PTS_CANDIDATES), once one said a packet's
        self._frame_pts_misses = 0

    def __enter__(self):
        if self.background:
            libav.lower_priority()
        try:
            self._open()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def _custom_io(self):
        self.reader = KodiReader(self.target.address, self.current)
        reader = self.reader

        def read_packet(_opaque, buffer, size):
            data = reader.read(size)
            if not data:
                return AVERROR_EOF
            ctypes.memmove(buffer, data, len(data))
            return len(data)

        def seek(_opaque, offset, whence):
            return reader.seek(offset, whence)

        self.callbacks = (READ_PACKET(read_packet), SEEK(seek))   # kept alive while FFmpeg uses them
        buffer = self.avutil.av_malloc(IO_BUFFER)
        if not buffer:
            raise Unavailable('out of memory')
        read_packet, seek_callback = self.callbacks
        self.avio = ctypes.c_void_p(self.avformat.avio_alloc_context(buffer, IO_BUFFER, 0, None, read_packet, None,
                                                                     seek_callback))   # no write callback
        if not self.avio.value:
            self.avutil.av_free(buffer)
            raise Unavailable('out of memory')
        self.fmt = ctypes.c_void_p(self.avformat.avformat_alloc_context())
        if not self.fmt.value:
            raise Unavailable('out of memory')
        ctypes.c_void_p.from_address(self.fmt.value + PB_AT).value = self.avio.value

    def _open(self):
        options = ctypes.c_void_p()
        for key, value in PROBE_OPTIONS:
            self.avutil.av_dict_set(ctypes.byref(options), key, value, 0)
        try:
            if self.target.kind == locate.KODI or (not self.network and '://' in self.target.address):
                # A decoder without network protocols reads web addresses through Kodi as well.
                self._custom_io()
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), b'', None, ctypes.byref(options))
            else:
                try:
                    address = self.target.address.encode('utf-8')
                except UnicodeEncodeError:
                    raise Unavailable('the file name can not be passed to FFmpeg')
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), address, None, ctypes.byref(options))
        finally:
            self.avutil.av_dict_free(ctypes.byref(options))
        if opened < 0:
            self.fmt = ctypes.c_void_p()      # FFmpeg frees the context when opening fails
            raise Unavailable('FFmpeg could not open the file')
        if self.avformat.avformat_find_stream_info(self.fmt, None) < 0:
            raise Unavailable('FFmpeg found no stream information')
        decoder = ctypes.c_void_p()
        count = _integer(self.fmt.value, NB_STREAMS_AT)
        wanted = _kodi_video_stream(self.fmt.value, count) if count <= 256 else -1
        self.index = self.avformat.av_find_best_stream(self.fmt, AVMEDIA_TYPE_VIDEO, wanted, -1, ctypes.byref(decoder),
                                                       0)
        if self.index < 0 or not decoder.value or not 0 <= self.index < count or count > 256:
            raise Unavailable('no video stream FFmpeg can decode')
        stream = _pointer(_pointer(self.fmt.value, STREAMS_AT), self.index * P)
        self.wraps = _wraps(self.fmt.value)
        self.start = _earliest_start(self.fmt.value, count, self.wraps)
        num, den = _integer(stream, TIME_BASE_AT), _integer(stream, TIME_BASE_AT + 4)
        self.time_base = (num, den) if num > 0 and den > 0 else None
        codecpar = _pointer(stream, CODECPAR_AT)
        if not codecpar:
            raise Unavailable('no codec parameters')
        self.ctx = ctypes.c_void_p(self.avcodec.avcodec_alloc_context3(decoder))
        if not self.ctx.value or self.avcodec.avcodec_parameters_to_context(self.ctx, codecpar) < 0:
            raise Unavailable('decoder could not be set up')
        # Cheapest decoding that still gives a true picture: one thread, keyframes only,
        # no loop filter (its smoothing does not move the edges of black bars).
        for option, value in ((b'threads', 1), (b'skip_frame', AVDISCARD_NONKEY), (b'skip_loop_filter', AVDISCARD_ALL)):
            self.avutil.av_opt_set_int(self.ctx, option, value, 0)
        if self.avcodec.avcodec_open2(self.ctx, decoder, None) < 0:
            raise Unavailable('decoder would not open')
        self.pkt = ctypes.c_void_p(self.avcodec.av_packet_alloc())
        self.frame = ctypes.c_void_p(self.avutil.av_frame_alloc())
        if not (self.pkt.value and self.frame.value):
            raise Unavailable('out of memory')
        self._discard_other_streams(count)

    def _discard_other_streams(self, count):
        """Every stream but the video marked AVDISCARD_ALL (AVStream.discard, the int after disposition), so the
        demuxer hands over no audio or subtitle packets after a seek and, for Matroska and MP4, reads none of
        their bytes: the keyframe comes in one packet instead of among hundreds (a remux with many streams gave
        11 video packets in 600 until 0.3.27's drain, which stays as the net under it)."""
        for index in range(min(count, 256)):
            if index == self.index:
                continue
            stream = _pointer(_pointer(self.fmt.value, STREAMS_AT), index * P)
            ctypes.c_int.from_address(stream + DISCARD_AT).value = AVDISCARD_ALL

    def playable(self, length):
        """The part of Kodi's length (seconds) the film plays in. Kodi's length is the file's duration and its times
        count from the file's first time; a Matroska or MP4 file muxed with an offset has a duration that runs from
        zero, so its film lies in the first length less start seconds and every later position is past its end.
        Where the duration runs from the first time instead, the shorter part still lies inside the film. A
        transport or program stream's duration comes from its own times, from its first."""
        if self.wraps or self.start < OFFSET_START or length <= self.start:
            return length
        return length - self.start

    def subtitle_streams(self):
        """The file's own subtitle streams in file order: (codec name, language, forced, hearing impaired, title)."""
        streams = []
        count = _integer(self.fmt.value, NB_STREAMS_AT)
        for index in range(min(count, 256)):
            stream = _pointer(_pointer(self.fmt.value, STREAMS_AT), index * P)
            codecpar = _pointer(stream, CODECPAR_AT)
            if not codecpar or _integer(codecpar, CODEC_TYPE_AT) != AVMEDIA_TYPE_SUBTITLE:
                continue
            name = self.avcodec.avcodec_get_name(_integer(codecpar, CODEC_ID_AT)) or b''
            disposition = _integer(stream, DISPOSITION_AT)
            if disposition & ~DISPOSITION_KNOWN:
                # Not a disposition: this layout is not the one expected, so its pointers are not followed
                # (the language stays unknown, and Kodi's list will not line up: the kind stays unknown).
                streams.append((name.decode('ascii', 'replace'), '?', False, False, ''))
                continue
            metadata = ctypes.c_void_p(_pointer(stream, METADATA_AT))
            language, title = (self._tag(metadata, key) for key in (b'language', b'title'))
            streams.append((name.decode('ascii', 'replace'), language[:16],
                            bool(disposition & AV_DISPOSITION_FORCED), bool(disposition & AV_DISPOSITION_HEARING_IMPAIRED),
                            title[:200]))
        return streams

    def _tag(self, metadata, key):
        """A stream's metadata tag as text, '' when missing."""
        entry = self.avutil.av_dict_get(metadata, key, None, 0)
        value = _pointer(entry, ENTRY_VALUE_AT) if entry else None
        return ctypes.string_at(value).decode('utf-8', 'replace') if value else ''

    def sample(self, seconds):
        """A keyframes.Keyframe for the position; its frame is None when no keyframe came out there."""
        started = time.time()
        self.rows = None
        # Kodi's times count from the film's start; the file's own may not (a transport stream starting at 600 s).
        sought = self.avformat.av_seek_frame(self.fmt, -1, int((seconds + self.start) * 1000000), AVSEEK_FLAG_BACKWARD)
        if sought < 0:
            # The file can not be seeked (a stream, a damaged index): what would come next is wherever the
            # last read stopped, not a keyframe from this position, so it is no sample (1.1.5).
            return _nothing('no keyframe decoded (%.1f s; the file could not be seeked, %d)' % (
                time.time() - started, sought))
        self.avcodec.avcodec_flush_buffers(self.ctx)
        stream_index_at = STREAM_INDEX_AT
        got = False
        # Why nothing came out, for the log: packets read, those of the video, the last answers.
        packets = video = 0
        read = sent = received = 0
        # first: the keyframe's own time, its packet's: the first flagged a keyframe after the seek (a transport stream
        # seeks by time and can hand over packets of the group before first), else the first video packet (a demuxer
        # that flags no keyframe). own: the frame's own time where it says one of the packet times sent.
        pts = first = own = None
        keyed = drain = False
        sent_times = set()
        for _ in range(MAX_PACKETS_PER_SAMPLE):
            read = self.avformat.av_read_frame(self.fmt, self.pkt)
            if read < 0:
                break
            packets += 1
            try:
                if drain:
                    # The keyframe held back for reordering (B-frames), or another keyframe's frame came out: drained
                    # once a packet shows the file goes on (at its end there is no picture, rather than the last one
                    # again), so no packet past it is decoded (each sample read on to the next keyframes, the whole
                    # video stream once more) and nothing of it stays in the decoder for the next sample (long open
                    # groups of pictures: the next keyframe came out first and the asked one was named by the next
                    # sample).
                    got, own = self._drain(sent_times, first)
                    if not got:
                        received = AVERROR_EAGAIN
                        break
                elif _integer(self.pkt.value, stream_index_at) == self.index:
                    video += 1
                    pts = ctypes.c_int64.from_address(self.pkt.value + PTS_AT).value   # AVPacket.pts, after buf
                    if pts == AV_NOPTS_VALUE:
                        # VC-1 in Matroska carries no presentation time at all, only the decoding time (in a real
                        # library every keyframe but the first was refused as the same one).
                        pts = ctypes.c_int64.from_address(self.pkt.value + DTS_AT).value
                    if pts == AV_NOPTS_VALUE:
                        pts = None
                    key = not keyed and bool(_integer(self.pkt.value, FLAGS_AT) & AV_PKT_FLAG_KEY)
                    if key or (video == 1 and not keyed):
                        if key:
                            keyed = True
                        first = pts
                        if first is not None and first in self.seen_pts:
                            # Keyframes far apart: the same one as an earlier sample, known before it is decoded
                            # (decoding it again read a 10 s group of pictures five times over).
                            return _nothing('no keyframe decoded (%.1f s; the same keyframe as an earlier sample)' % (
                                time.time() - started))
                    if pts is not None:
                        sent_times.add(pts)
                    sent = self.avcodec.avcodec_send_packet(self.ctx, self.pkt)
                    received = self.avcodec.avcodec_receive_frame(self.ctx, self.frame)
                    got = received == 0
                    if got:
                        got, own = self._ours(sent_times, first if keyed else None)
                    # Not where the keyframe lies far before the position (past the file's end the seek lands on its
                    # last keyframe): read on as before, and at the file's end there is no picture.
                    at = self._seconds(first)
                    drain = not got and key and (at is None or seconds - at <= DRAIN_WITHIN)
            finally:
                self.avcodec.av_packet_unref(self.pkt)
            if got:
                break
        else:
            if video and received == AVERROR_EAGAIN:
                # The limit ran out, not the file, with a keyframe held back for the frames to come:
                # drained, then ready for the next sample. A file with many other streams has few video
                # packets within the limit (a Dolby Vision film over Plex: 11 of 600, every
                # keyframe empty until 0.3.27). At the file's end nothing is drained: past the end
                # there is no picture, rather than the last one again.
                got, own = self._drain(sent_times, first if keyed else None)
        if not got:
            return _nothing('no keyframe decoded (%.1f s; %d packets, %d of the video; read %d, send %d, receive %d)' % (
                time.time() - started, packets, video, read, sent, received))
        # Keyframes far apart (a minute and more): two positions land on the same one, which would count as a shape
        # seen twice. One sample per keyframe (1.1.5), known by its own packet's time (no time at all: it counts).
        if first is not None:
            self.seen_pts.add(first)
        level5, carried = self._level5()
        frame, size = self._small()
        # The frame's time is its own where the frame says it, else the keyframe packet's.
        return keyframes.Keyframe(frame, '%.2f s' % (time.time() - started), level5, carried, size,
                                  self._seconds(own if own is not None else first))

    def _ours(self, sent, key):
        """(whether the frame just received is the keyframe whose packet time is key, its own time or None). A frame
        that says another time than key is not it (once the frame's time is known to be readable, a time no packet of
        this sample had too: a frame kept from before); one that says none, or with no key time known, counts."""
        own = self._frame_time(sent)
        if key is None:
            return True, own
        if own is None and self.frame_pts_at:
            value = ctypes.c_int64.from_address(self.frame.value + self.frame_pts_at).value
            return value == AV_NOPTS_VALUE, None
        return own is None or own == key, own

    def _drain(self, sent, key):
        """The decoder drained for the keyframe whose packet time is key, then flushed for the next sample: (whether
        its frame came out, its own time). The frame stays in self.frame."""
        self.avcodec.avcodec_send_packet(self.ctx, None)
        got, own = False, None
        while self.avcodec.avcodec_receive_frame(self.ctx, self.frame) == 0:
            got, own = self._ours(sent, key)
            if got:
                break
        self.avcodec.avcodec_flush_buffers(self.ctx)
        return got, own

    def _frame_time(self, sent):
        """The decoded frame's own time (AVFrame.pts) where it is one of the packet times sent, else None. Its place is
        found once per file among FRAME_PTS_CANDIDATES and given up after three frames in a row that say no packet's."""
        if self.frame_pts_at is False or not sent:
            return None
        for at in ([self.frame_pts_at] if self.frame_pts_at else FRAME_PTS_CANDIDATES):
            value = ctypes.c_int64.from_address(self.frame.value + at).value
            if value in sent:
                self.frame_pts_at, self._frame_pts_misses = at, 0
                return value
        self._frame_pts_misses += 1
        if self._frame_pts_misses >= 3:
            self.frame_pts_at = False
        return None

    def _seconds(self, pts):
        """A packet time as Kodi's film time (seconds from the file's own start), or None when unknown."""
        if pts is None or self.time_base is None:
            return None
        return pts * self.time_base[0] / self.time_base[1] - self.start

    def sequence(self, seconds, until, most=SEQUENCE_MOST, go=None):
        """Every frame from the keyframe at or before seconds on, in presentation order, until the first past until
        (film seconds) or most frames: a keyframes.Keyframe each, with its film time: the frame's own where it says one
        of the packet times sent (_frame_time), else the n-th earliest packet time at or after the keyframe's for the
        n-th frame out (a decoder hands frames over in presentation order; leading pictures of an open group come before
        the keyframe and are left out, as HEVC's decoder drops them after a seek). Every frame is decoded for this
        stretch, with the loop filter (soft B-frame edges read as none), then keyframes only again. Nothing is sent to
        the decoder before the first packet flagged a keyframe, and a stretch counts only where that keyframe is at or
        before seconds: a seek that lands past it (a transport stream seeks by time, not to a keyframe: it came at the
        next keyframe, or just past this one, whose frames HEVC then decoded without their references as a full grey
        picture) is made again 2, then 5 s earlier. Nothing after a failed seek; it stops at once when go() says no (the
        playback ended, Kodi holds). Where a cut lies between two keyframes the scene reader ahead of playback
        (lookahead.py) asks for its frame."""
        for earlier in SEQUENCE_EARLIER:
            frames = self._decode_from(max(0.0, seconds - earlier), until, most, go)
            first = next(frames, None)
            if first is None:
                return
            if first.at is None or first.at <= seconds + SEQUENCE_AT or earlier == SEQUENCE_EARLIER[-1]:
                yield first
                yield from frames
                return
            frames.close()

    def _decode_from(self, target, until, most, go):
        """sequence() from one seek to target."""
        if self.avformat.av_seek_frame(self.fmt, -1, int((target + self.start) * 1000000), AVSEEK_FLAG_BACKWARD) < 0:
            return
        self.avcodec.avcodec_flush_buffers(self.ctx)
        self.avutil.av_opt_set_int(self.ctx, b'skip_frame', AVDISCARD_DEFAULT, 0)
        self.avutil.av_opt_set_int(self.ctx, b'skip_loop_filter', AVDISCARD_DEFAULT, 0)   # B-frames' edges clean
        stream_index_at = STREAM_INDEX_AT
        pending, first, out = [], None, 0
        keyed = False
        sent = set()
        try:
            for _ in range(most * 8):           # packets: the other streams' are discarded at the demuxer
                if go is not None and not go():
                    return
                if self.avformat.av_read_frame(self.fmt, self.pkt) < 0:
                    # The file's end: the frames the decoder still holds back for reordering come out (drained).
                    self.avcodec.avcodec_send_packet(self.ctx, None)
                    while self.avcodec.avcodec_receive_frame(self.ctx, self.frame) == 0 and out < most:
                        keyframe = self._sequence_frame(sent, pending, first)
                        if keyframe is not None:
                            yield keyframe
                            out += 1
                    return
                try:
                    if _integer(self.pkt.value, stream_index_at) != self.index:
                        continue
                    if not keyed:
                        if not _integer(self.pkt.value, FLAGS_AT) & AV_PKT_FLAG_KEY:
                            continue                    # before the keyframe: no references for it
                        keyed = True
                    pts = ctypes.c_int64.from_address(self.pkt.value + PTS_AT).value
                    if pts == AV_NOPTS_VALUE:
                        pts = ctypes.c_int64.from_address(self.pkt.value + DTS_AT).value
                    if pts != AV_NOPTS_VALUE:
                        if first is None:
                            first = pts                 # the keyframe comes first
                        if pts >= first:
                            bisect.insort(pending, pts)
                        sent.add(pts)
                    self.avcodec.avcodec_send_packet(self.ctx, self.pkt)
                finally:
                    self.avcodec.av_packet_unref(self.pkt)
                while self.avcodec.avcodec_receive_frame(self.ctx, self.frame) == 0:
                    keyframe = self._sequence_frame(sent, pending, first)
                    if keyframe is None:
                        continue
                    yield keyframe
                    out += 1
                    if out >= most or (keyframe.at is not None and keyframe.at > until):
                        return
        finally:
            self.avutil.av_opt_set_int(self.ctx, b'skip_frame', AVDISCARD_NONKEY, 0)
            self.avutil.av_opt_set_int(self.ctx, b'skip_loop_filter', AVDISCARD_ALL, 0)
            self.avcodec.avcodec_flush_buffers(self.ctx)

    def _sequence_frame(self, sent, pending, first=None):
        """The frame just received as a keyframes.Keyframe: its own time where it says a packet's sent, else the
        earliest packet time not yet given out. None for a frame whose own time is before the keyframe's (first): a
        leading picture decoded without the references before the seek."""
        own = self._frame_time(sent)
        if own is not None:
            if first is not None and own < first:
                return None
            if own in pending:
                pending.remove(own)
            at = self._seconds(own)
        else:
            at = self._seconds(pending.pop(0)) if pending else None
        level5, carried = self._level5()
        frame, size = self._small()
        return keyframes.Keyframe(frame, '', level5, carried, size, at)

    def _level5(self):
        """(the keyframe's Dolby Vision Level 5 offsets (top, bottom, left, right) or None without them, whether the
        keyframe carried Dolby Vision metadata at all)."""
        if not self.dovi:
            return None, False
        kind, find_level = self.dovi
        side = self.avutil.av_frame_get_side_data(self.frame, kind)
        if not side:
            return None, False
        metadata = _pointer(side, SIDE_DATA_AT)
        if not metadata:
            return None, False
        block = find_level(metadata, 5)
        if not block or ctypes.c_uint8.from_address(block + LEVEL_AT).value != 5:
            return None, True
        return tuple(ctypes.c_uint16.from_address(block + at).value
                     for at in (LEVEL5_TOP_AT, LEVEL5_BOTTOM_AT, LEVEL5_LEFT_AT, LEVEL5_RIGHT_AT)), True

    def _small(self):
        """(the grey frame, the keyframe's own size)."""
        base = self.frame.value
        data, line = _pointer(base, FRAME_DATA_AT), _integer(base, LINESIZE_AT)
        width, height = _integer(base, WIDTH_AT), _integer(base, HEIGHT_AT)
        name = (self.avutil.av_get_pix_fmt_name(_integer(base, FORMAT_AT)) or b'').decode('ascii', 'replace')
        if not readable_format(name):
            raise Unavailable('picture format %s not read' % (name or 'unknown'))
        depth = pixel_depth(name)
        wide = 2 if depth > 8 else 1
        if not frame_layout_ok(data, width, height, line, wide):
            raise Unavailable('unexpected frame layout (%dx%d, %s)' % (width, height, name))

        turn = self._turn()
        if turn not in (0, 180):
            raise Unavailable('the picture is turned %d degrees' % turn)

        def read_row(y):
            if turn:                    # upside down on the screen: the frame's last row is the top one there
                y = height - 1 - y
            return ctypes.string_at(data + y * line, width * wide)
        self.rows = (read_row, width, height, depth)
        return grey_frame(read_row, width, height, depth, self.out_w, self.out_h, self.full), (width, height)

    def _turn(self):
        """How far Kodi turns the frame just decoded (orientation), from its display matrix; 0 without one. Kodi reads
        the stream's matrix, which FFmpeg 7.1 puts on every decoded frame (an FFmpeg that does not reads as upright,
        as before); a rotation the video itself signals would be on the frame too, where Kodi may not turn the
        picture (none seen)."""
        if self.display is None:
            return 0
        side = self.avutil.av_frame_get_side_data(self.frame, self.display)
        matrix = _pointer(side, SIDE_DATA_AT) if side else None
        return orientation((ctypes.c_int32 * 9).from_address(matrix)) if matrix else 0

    def exact(self, sample):
        """detect.exact_bars for the keyframe sample() just returned, analysed as sample: a few of its rows read
        again at full width (the frame stays in memory until the next sample). None when there is nothing to
        refine."""
        if self.rows is None:
            return None
        read_row, width, height, depth = self.rows
        if depth > 8:
            shift = depth - 8

            def values(y):
                return bytes(map(shift.__rrshift__, memoryview(read_row(y)).cast('H')))
        else:
            def values(y):
                return read_row(y)
        return detect.exact_bars(values, width, height, sample, limited=True)

    def close(self):
        if self.frame.value:
            self.avutil.av_frame_free(ctypes.byref(self.frame))
        if self.pkt.value:
            self.avcodec.av_packet_free(ctypes.byref(self.pkt))
        if self.ctx.value:
            self.avcodec.avcodec_free_context(ctypes.byref(self.ctx))
        if self.fmt.value:
            self.avformat.avformat_close_input(ctypes.byref(self.fmt))
        if self.avio.value:
            buffer = ctypes.c_void_p.from_address(self.avio.value + IO_BUFFER_AT).value   # may have been replaced
            if buffer:
                self.avutil.av_free(buffer)
            self.avformat.avio_context_free(ctypes.byref(self.avio))
        if self.reader:
            self.reader.close()
            self.reader = None
