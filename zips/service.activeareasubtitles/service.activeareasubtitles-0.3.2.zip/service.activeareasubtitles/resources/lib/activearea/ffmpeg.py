"""Decoding single keyframes from the playing file with the FFmpeg libraries already on the system.

Used where Kodi's own frame grab cannot see the video (CoreELEC, Amlogic's hardware video
plane). The system's libavformat, libavcodec and libavutil are loaded through ctypes and
found without assumptions about where they live: a remembered path first, then the copy
Kodi itself has loaded (from this process's memory map), then the usual folders.

Files are opened directly (local paths, web addresses) or read through Kodi's own file
access (smb://, nfs://, ...) via a custom FFmpeg I/O context. Probing is kept short: only
the video stream's settings are needed, and they sit in the file's header.

A few FFmpeg structures are read directly. Their layout is only relied on for libavformat 61
and 62 (FFmpeg 7 and 8), and every pointer and size read is checked before it is used. The
playing address can carry an access token: it is never logged or stored.
"""
import ctypes
import glob
import json
import os
import platform
import re
import sys
import threading
import time

P = ctypes.sizeof(ctypes.c_void_p)
KNOWN_MAJORS = (61, 62)
AVMEDIA_TYPE_VIDEO = 0
AVSEEK_FLAG_BACKWARD = 1
AVDISCARD_NONKEY = 32
AVDISCARD_ALL = 48
MAX_PACKETS_PER_SAMPLE = 600
FOLDERS = ('/usr/lib', '/usr/lib/kodi', '/usr/local/lib', '/lib', '/usr/lib/arm-linux-gnueabihf',
           '/usr/lib/aarch64-linux-gnu', '/usr/lib/x86_64-linux-gnu')


class Unavailable(Exception):
    """The file can not be measured this way. The message is for the log."""


# Finding the libraries -------------------------------------------------------------------

def _loaded_by_kodi(name):
    found = []
    try:
        with open('/proc/self/maps', encoding='utf-8', errors='replace') as handle:
            for line in handle:
                path = line.rsplit(' ', 1)[-1].strip()
                if '/lib%s.so' % name in path and path not in found:
                    found.append(path)
    except OSError:
        pass
    return found


def _candidates(name, remembered):
    first = [remembered[name]] if remembered.get(name) else []
    folders = [p for folder in FOLDERS for p in sorted(glob.glob('%s/lib%s.so*' % (folder, name)), reverse=True)]
    system = []
    try:
        import ctypes.util
        found = ctypes.util.find_library(name)
        system = [found] if found else []
    except Exception:  # find_library runs external tools; any failure only means "not found"
        pass
    seen, order = set(), []
    for path in first + _loaded_by_kodi(name) + folders + system:
        if path and path not in seen:
            seen.add(path)
            order.append(path)
    return order


def _load(name, remembered, check):
    for path in _candidates(name, remembered):
        try:
            library = ctypes.CDLL(path)
            if not check(library):
                continue
        except (OSError, AttributeError):
            continue
        remembered[name] = path
        return library
    remembered.pop(name, None)
    return None


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, data):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except OSError:
        pass


def libraries(memory_path):
    """(avformat, avcodec, avutil, description). Raises Unavailable."""
    remembered = _read_json(memory_path)
    before = dict(remembered)
    avformat = _load('avformat', remembered, lambda lib: (lib.avformat_version() >> 16) in KNOWN_MAJORS)
    avcodec = _load('avcodec', remembered, lambda lib: bool(lib.avcodec_version()))
    avutil = _load('avutil', remembered, lambda lib: bool(lib.avutil_version()))
    if remembered != before:
        _write_json(memory_path, remembered)
    if not (avformat and avcodec and avutil):
        raise Unavailable('no FFmpeg 7 or 8 libraries found')
    return avformat, avcodec, avutil, 'FFmpeg (libavformat %d)' % (avformat.avformat_version() >> 16)


# Decoding --------------------------------------------------------------------------------

AVSEEK_SIZE = 0x10000
AVERROR_EOF = -0x20464F45
IO_BUFFER = 64 * 1024
PROBE_OPTIONS = ((b'probesize', b'2000000'), (b'analyzeduration', b'1000000'),
                 (b'rw_timeout', b'5000000'))   # a stalled network read gives up after 5 s
# Brightness planes this module can read: 8 to 16 bits, little endian, luma first.
PLANAR_YUV = ('yuv', 'nv12', 'nv21', 'nv16', 'nv24', 'p010le', 'p012le', 'p016le', 'gray')
EDGE_SHARE = 0.25          # rows near the top and bottom edges that bars can occupy (detect uses 22 %)


def _pointer(address, offset=0):
    if not address:
        raise Unavailable('unexpected empty pointer')
    return ctypes.c_void_p.from_address(address + offset).value


def _integer(address, offset):
    return ctypes.c_int.from_address(address + offset).value


def _stream_index_offset(pointer_size, machine):
    """AVPacket: buf, pts, dts, data, size, stream_index. 64-bit numbers sit on 8 bytes except on 32-bit x86."""
    if pointer_size == 8:
        return 36
    return 28 if machine.lower() in ('i386', 'i486', 'i586', 'i686', 'x86') else 32


STREAM_INDEX_AT = _stream_index_offset(P, platform.machine())


READ_PACKET = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int)
SEEK = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_void_p, ctypes.c_int64, ctypes.c_int)


def _declare(avformat, avcodec, avutil):
    vp, i = ctypes.c_void_p, ctypes.c_int
    pp = ctypes.POINTER(vp)
    for function, result, arguments in (
            (avformat.avformat_alloc_context, vp, []),
            (avformat.avformat_open_input, i, [pp, ctypes.c_char_p, vp, pp]),
            (avformat.avformat_find_stream_info, i, [vp, vp]),
            (avformat.av_find_best_stream, i, [vp, i, i, i, pp, i]),
            (avformat.av_seek_frame, i, [vp, i, ctypes.c_int64, i]),
            (avformat.av_read_frame, i, [vp, vp]),
            (avformat.avformat_close_input, None, [pp]),
            (avformat.avio_alloc_context, vp, [vp, i, i, vp, READ_PACKET, vp, SEEK]),
            (avformat.avio_context_free, None, [pp]),
            (avcodec.avcodec_alloc_context3, vp, [vp]),
            (avcodec.avcodec_parameters_to_context, i, [vp, vp]),
            (avcodec.avcodec_open2, i, [vp, vp, vp]),
            (avcodec.avcodec_send_packet, i, [vp, vp]),
            (avcodec.avcodec_receive_frame, i, [vp, vp]),
            (avcodec.avcodec_flush_buffers, None, [vp]),
            (avcodec.avcodec_free_context, None, [pp]),
            (avcodec.av_packet_alloc, vp, []),
            (avcodec.av_packet_unref, None, [vp]),
            (avcodec.av_packet_free, None, [pp]),
            (avutil.av_frame_alloc, vp, []),
            (avutil.av_frame_free, None, [pp]),
            (avutil.av_malloc, vp, [ctypes.c_size_t]),
            (avutil.av_free, None, [vp]),
            (avutil.av_dict_set, i, [pp, ctypes.c_char_p, ctypes.c_char_p, i]),
            (avutil.av_dict_free, None, [pp]),
            (avutil.av_opt_set_int, i, [vp, ctypes.c_char_p, ctypes.c_int64, i]),
            (avutil.av_get_pix_fmt_name, ctypes.c_char_p, [i])):
        function.restype, function.argtypes = result, arguments


def pixel_depth(name):
    """Bits per brightness sample from FFmpeg's format name: yuv420p10le, p010le and gray12le
    carry it at the end; everything else (yuv420p, nv12, gray) is 8 bits."""
    match = re.search(r'(?:p0|p|gray)(9|10|12|14|16)le$', name)
    return int(match.group(1)) if match else 8


def grey_frame(read_row, width, height, depth, out_w, out_h, full=False):
    """A small BGR frame of the brightness plane, out_w x out_h.

    read_row(y) returns the raw bytes of source row y. Without full, only the rows near the
    top and bottom edges are read (where bars can be); the middle is filled with one row, as
    the bar detection never looks there. depth is 8 to 16 bits.
    """
    wide = 2 if depth > 8 else 1
    shift = depth - 8
    step = max(1, width // out_w)
    edge = int(out_h * EDGE_SHARE) + 1

    def row(y):
        data = memoryview(read_row(y * height // out_h))
        values = (data.cast('H') if wide == 2 else data)[::step][:out_w]
        grey = bytes(v >> shift for v in values) if wide == 2 else bytes(values)
        grey = grey.ljust(out_w, grey[-1:] or b'\0')
        return bytes(b for v in grey for b in (v, v, v))

    if full:
        return b''.join(row(y) for y in range(out_h))
    middle = row(out_h // 2)
    rows = [row(y) if y < edge or y >= out_h - edge else middle for y in range(out_h)]
    return b''.join(rows)


class KodiReader:
    """Kodi's file access, for FFmpeg's custom I/O. Errors read as end of file."""

    def __init__(self, address):
        import xbmcvfs
        self.file = xbmcvfs.File(address)
        try:
            self.length = int(self.file.size())
        except Exception:  # Kodi could not say
            self.length = -1
        if self.length == 0:
            self.file.close()
            raise Unavailable('Kodi can not read the source')

    def read(self, size):
        try:
            return bytes(self.file.readBytes(size))
        except Exception:  # an unreachable share reads as the end of the file
            return b''

    def seek(self, offset, whence):
        if whence & AVSEEK_SIZE:
            return self.length
        try:
            return int(self.file.seek(offset, whence & 3))
        except Exception:
            return -1

    def close(self):
        try:
            self.file.close()
        except Exception:
            pass


class Decoder:
    """One open file. sample(seconds) returns a small grey BGR frame of a keyframe there.

    target: a locate.Target (kind 'direct' opens target.address with FFmpeg, 'kodi' reads it
    through Kodi). Use as a context manager; everything allocated is freed on exit.
    """

    def __init__(self, target, memory_path, width=128, height=144, full=False):
        self.avformat, self.avcodec, self.avutil, self.description = libraries(memory_path)
        _declare(self.avformat, self.avcodec, self.avutil)
        self.target, self.out_w, self.out_h, self.full = target, width, height, full
        self.fmt, self.ctx = ctypes.c_void_p(), ctypes.c_void_p()
        self.pkt, self.frame, self.avio = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
        self.reader, self.callbacks, self.index = None, None, -1

    def __enter__(self):
        if sys.platform.startswith('linux'):   # only Linux takes a thread id here; elsewhere it names a process
            try:
                os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)
            except (AttributeError, OSError):
                pass
        try:
            self._open()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def _custom_io(self):
        self.reader = KodiReader(self.target.address)
        reader = self.reader

        def read_packet(_opaque, buffer, size):
            data = reader.read(size)
            if not data:
                return AVERROR_EOF
            ctypes.memmove(buffer, data, len(data))
            return len(data)

        def seek(_opaque, offset, whence):
            return reader.seek(offset, whence)

        self.callbacks = (READ_PACKET(read_packet), SEEK(seek))   # kept alive while FFmpeg uses them
        buffer = self.avutil.av_malloc(IO_BUFFER)
        if not buffer:
            raise Unavailable('out of memory')
        read_packet, seek_callback = self.callbacks
        self.avio = ctypes.c_void_p(self.avformat.avio_alloc_context(buffer, IO_BUFFER, 0, None, read_packet, None,
                                                                     seek_callback))   # no write callback
        if not self.avio.value:
            self.avutil.av_free(buffer)
            raise Unavailable('out of memory')
        self.fmt = ctypes.c_void_p(self.avformat.avformat_alloc_context())
        if not self.fmt.value:
            raise Unavailable('out of memory')
        ctypes.c_void_p.from_address(self.fmt.value + 4 * P).value = self.avio.value   # AVFormatContext.pb

    def _open(self):
        options = ctypes.c_void_p()
        for key, value in PROBE_OPTIONS:
            self.avutil.av_dict_set(ctypes.byref(options), key, value, 0)
        try:
            if self.target.kind == 'kodi':
                self._custom_io()
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), b'', None, ctypes.byref(options))
            else:
                try:
                    address = self.target.address.encode('utf-8')
                except UnicodeEncodeError:
                    raise Unavailable('the file name can not be passed to FFmpeg')
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), address, None, ctypes.byref(options))
        finally:
            self.avutil.av_dict_free(ctypes.byref(options))
        if opened < 0:
            self.fmt = ctypes.c_void_p()      # FFmpeg frees the context when opening fails
            raise Unavailable('FFmpeg could not open the file')
        if self.avformat.avformat_find_stream_info(self.fmt, None) < 0:
            raise Unavailable('FFmpeg found no stream information')
        decoder = ctypes.c_void_p()
        self.index = self.avformat.av_find_best_stream(self.fmt, AVMEDIA_TYPE_VIDEO, -1, -1, ctypes.byref(decoder), 0)
        count = _integer(self.fmt.value, 5 * P + 4)
        if self.index < 0 or not decoder.value or not 0 <= self.index < count or count > 256:
            raise Unavailable('no video stream FFmpeg can decode')
        stream = _pointer(_pointer(self.fmt.value, 5 * P + 8), self.index * P)
        codecpar = _pointer(stream, P + 8)
        if not codecpar:
            raise Unavailable('no codec parameters')
        self.ctx = ctypes.c_void_p(self.avcodec.avcodec_alloc_context3(decoder))
        if not self.ctx.value or self.avcodec.avcodec_parameters_to_context(self.ctx, codecpar) < 0:
            raise Unavailable('decoder could not be set up')
        # Cheapest decoding that still gives a true picture: one thread, keyframes only,
        # no loop filter (its smoothing does not move the edges of black bars).
        for option, value in ((b'threads', 1), (b'skip_frame', AVDISCARD_NONKEY), (b'skip_loop_filter', AVDISCARD_ALL)):
            self.avutil.av_opt_set_int(self.ctx, option, value, 0)
        if self.avcodec.avcodec_open2(self.ctx, decoder, None) < 0:
            raise Unavailable('decoder would not open')
        self.pkt = ctypes.c_void_p(self.avcodec.av_packet_alloc())
        self.frame = ctypes.c_void_p(self.avutil.av_frame_alloc())
        if not (self.pkt.value and self.frame.value):
            raise Unavailable('out of memory')

    def sample(self, seconds):
        """(frame or None, detail)."""
        started = time.time()
        self.avformat.av_seek_frame(self.fmt, -1, int(seconds * 1000000), AVSEEK_FLAG_BACKWARD)
        self.avcodec.avcodec_flush_buffers(self.ctx)
        stream_index_at = STREAM_INDEX_AT
        got = False
        for _ in range(MAX_PACKETS_PER_SAMPLE):
            if self.avformat.av_read_frame(self.fmt, self.pkt) < 0:
                break
            try:
                if _integer(self.pkt.value, stream_index_at) == self.index:
                    self.avcodec.avcodec_send_packet(self.ctx, self.pkt)
                    got = self.avcodec.avcodec_receive_frame(self.ctx, self.frame) == 0
            finally:
                self.avcodec.av_packet_unref(self.pkt)
            if got:
                break
        if not got:
            return None, 'no keyframe decoded (%.1f s)' % (time.time() - started)
        return self._small(), '%.2f s' % (time.time() - started)

    def _small(self):
        base = self.frame.value
        data, line = _pointer(base, 0), _integer(base, 8 * P)
        width, height = _integer(base, 9 * P + 32), _integer(base, 9 * P + 36)
        name = (self.avutil.av_get_pix_fmt_name(_integer(base, 9 * P + 44)) or b'').decode('ascii', 'replace')
        if not name.startswith(PLANAR_YUV) or name.endswith('be'):
            raise Unavailable('picture format %s not read' % (name or 'unknown'))
        depth = pixel_depth(name)
        wide = 2 if depth > 8 else 1
        if not (data and 16 <= width <= 16384 and 16 <= height <= 16384 and line >= width * wide):
            raise Unavailable('unexpected frame layout (%dx%d, %s)' % (width, height, name))
        return grey_frame(lambda y: ctypes.string_at(data + y * line, width * wide),
                          width, height, depth, self.out_w, self.out_h, self.full)

    def close(self):
        if self.frame.value:
            self.avutil.av_frame_free(ctypes.byref(self.frame))
        if self.pkt.value:
            self.avcodec.av_packet_free(ctypes.byref(self.pkt))
        if self.ctx.value:
            self.avcodec.avcodec_free_context(ctypes.byref(self.ctx))
        if self.fmt.value:
            self.avformat.avformat_close_input(ctypes.byref(self.fmt))
        if self.avio.value:
            buffer = ctypes.c_void_p.from_address(self.avio.value + P).value   # AVIOContext.buffer, may be replaced
            if buffer:
                self.avutil.av_free(buffer)
            self.avformat.avio_context_free(ctypes.byref(self.avio))
        if self.reader:
            self.reader.close()
            self.reader = None
