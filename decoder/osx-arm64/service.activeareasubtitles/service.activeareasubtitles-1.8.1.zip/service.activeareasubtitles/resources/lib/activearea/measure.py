"""The two ways of finding the picture's shape, and when to trust what they see.

Each way is a generator of (ratio, how, final): a ratio may be offered early and confirmed
or corrected later, and the caller applies every one it gets. Unavailable means the way
does not work for this playback, so the next one may be tried.

- screen: tiny frame grabs of what Kodi renders (PCs and most Kodi systems).
- film: single keyframes decoded from the playing file through the film reader (filmreader.py; CoreELEC, where the
  video plane is out of Kodi's reach, and a PC with a decoder). Frames come from across the whole film, so an opening
  in another shape can not mislead it.
"""
from collections import Counter
import time

from . import detect
from .libav import Unavailable   # the decoder's own: nothing to translate

SIXTEEN_NINE = 16.0 / 9.0     # the screen's shape, which Kodi's grabs are taken in

SCREEN_WIDTH = 512           # 288 rows for 16:9: 2.35, 2.39 and 2.40 a row or more apart
SCREEN_INTERVAL = 0.3         # between grabs during the first minute
SCREEN_SLOW_INTERVAL = 2.0    # after that (long logos or a dark opening)
SCREEN_FAST_PERIOD = 60.0     # the first minute, grabbed every SCREEN_INTERVAL
SCREEN_GIVE_UP = 600.0        # seconds the screen route watches for a clear shape (reason not recorded)
SCREEN_EMPTY_LIMIT = 3        # grabs in a row without an image: the grab does not work here
SCREEN_BLACK_LIMIT = 40       # first grabs all black: nothing useful comes back
SCREEN_BLACK_AFTER = 10       # black grabs in a row that end the watch for a wider shape (credits, a long fade)
# Once settled, one grab this wide (at most the screen's own width: a larger one comes back half empty in Kodi 21)
# finds the edge to the row, as the file analysis does: 0.17 s against 0.15 for the small grab, and a
# 2.39 picture is no longer read as 2.40 (1.6 px high at 1080).
SCREEN_EXACT_WIDTH = 1920

# Where in the film keyframes are taken, as shares of its length, in this order. The first quarter first: over a
# corpus of real films the keyframe at 25 per cent is clear in more films than the one at 50 (a film's middle is
# dark more often) and alone equals the settled shape more often, so the first estimate is right a keyframe earlier
# in about 3 per cent of films. The same seven keyframes settle the same.
FILM_POSITIONS = (0.25, 0.35, 0.5, 0.65, 0.75, 0.15, 0.85)
# Read as well when the widest shape was seen only once: a cinemascope scene of an IMAX film that
# one keyframe landed on usually turns up again, a misread frame does not. 10 and 90 per cent since 1.3.0: a scope
# stretch near a film's end is confirmed there (on 96-keyframe grids of the hardest test films:
# 105 right against all 96, 104 with the six alone; at most 15 keyframes, 7.2 on average; reading every film
# denser, or only counting strongly lit sightings, gained nothing more).
FILM_MORE_POSITIONS = (0.45, 0.55, 0.3, 0.7, 0.2, 0.8, 0.1, 0.9)
# Read around a lone far-wider sighting first (shares of the film's length from it, in this order): a scene has a
# length, so a real wider picture seen once usually shows next to where it was seen, while a misread keyframe has
# ordinary neighbours. On the 96-keyframe grids of the real-film corpus, with the positions shifted by 1 to
# 3 per cent, three films lost their scope shape because one sighting among seven stayed single (the eight spread
# positions missed a short stretch, or the sighting was dim and never read on); their neighbours show it. Costs two
# to four keyframes on about one film in a hundred.
NEAR_SHARES = (-0.01, 0.01, -0.02, 0.02)
FILM_MIN_LENGTH = 120.0       # seconds; shorter videos are measured from the screen only (a PC)
# Where the file is the only way to measure (CoreELEC has no screen route), shorter videos are read too: at 120 s a
# trailer or a short film on the box was never placed (seen with 40 s test clips on a box).
FILM_MIN_LENGTH_ALONE = 30.0


class LeftToCoreELEC(Exception):
    """The film's Dolby Vision Level 5 has values, so CoreELEC places the subtitles itself."""


EXACT_SAME_PICTURE = 0.005   # the same picture when every shape was measured in the frame's own rows (exact edges)


def decide(ratios, last=False, share=None):
    """The shape to use from the clear samples so far, and whether it is settled.

    The widest shape seen (largest bars) is what keeps subtitles inside the picture in every
    scene, IMAX ones included, so it is offered first and settled once seen twice (counting
    shapes that are the same picture, see detect.same_picture; share: its precision). If the samples
    run out first, the widest shape seen at least twice is used, so one misread frame can not decide
    on its own.
    """
    if not ratios:
        return None, False
    widest = max(ratios)
    if _seen(ratios, widest, share) >= 2:
        return widest, True
    if last:
        repeated = [ratio for ratio in ratios if _seen(ratios, ratio, share) >= 2]
        return (max(repeated) if repeated else widest), True
    return widest, False


def believed(readings, share=None):
    """The shapes a film may settle on, from (ratio, strong) readings: one wider than every strongly lit
    reading is left out unless a strongly lit reading shows the same picture. Dark scenes read wide with
    dimly lit edges (in a large corpus of real films dozens sat 2 to 6 px high from
    exactly that; a PC's widening could jump 64 px mid-film); a real wider picture, IMAX's scope scenes,
    is strongly lit. With no strong reading at all (a film dark throughout) every reading counts, as before."""
    if not any(strong for _ratio, strong in readings):
        return [ratio for ratio, _strong in readings]
    strongs = [ratio for ratio, strong in readings if strong]
    kept = [(ratio, strong) for ratio, strong in readings
            if strong or any(ratio <= other or detect.same_picture((ratio, other), share) for other in strongs)]
    # The bar the clearly lit keyframes agree on: the widest shape at least two of them read exactly. No single
    # keyframe, dimly or brightly lit, makes a picture's bar thicker than that (in a 2:1 HDR10 film
    # five lit keyframes at 120 rows, one dark at 123 settled it high); a wider picture (IMAX's scope scenes) seen
    # lit twice is its own agreed shape. A picture whose lit readings do not agree is capped at its widest lit
    # reading (in the corpus one strong keyframe and a dark one's gradient read as bar settled a film 3 px high;
    # and a dim scope scene confirmed by one lit neighbour settled on the dim reading's own row).
    counts = Counter(round(ratio, 4) for ratio in strongs)
    caps = sorted({ratio for ratio in strongs if counts[round(ratio, 4)] >= 2}, reverse=True)   # agreed, widest first
    for ratio in sorted(set(strongs), reverse=True):
        if not any(detect.same_picture((ratio, cap), share) for cap in caps):
            caps.append(ratio)                     # a picture no lit readings agree on: its widest lit reading
    capped = []
    for ratio, _strong in kept:
        for cap in caps:
            if detect.same_picture((ratio, cap), share):
                ratio = min(ratio, cap)
                break
        capped.append(ratio)
    return capped


def _seen(ratios, ratio, share=None):
    """How often ratio was seen: the shapes no wider than it that are the same picture."""
    return sum(1 for other in ratios if other <= ratio and detect.same_picture((other, ratio), share))


def unsure(ratios, share=None):
    """True when the widest shape among ratios was seen only once (or none was clear)."""
    return not ratios or _seen(ratios, max(ratios), share) < 2


AGREEING_SAMPLES = 4     # clear grabs in a row before the screen route believes a shape (reason not recorded)


class Runs:
    """The screen route's belief: clear grabs in a row showing the same picture (see detect.same_picture; another
    picture starts a new run, and the caller feeds only clear grabs), and the answer offered so far.

    A run's answer is its widest strongly lit member (a dim member reads wide too easily to decide a run on its
    own), or its widest member when none is lit. The first completed run gives the first answer; it is provisional
    when no member was lit, and the first lit run replaces it, narrower or not ('corrected'). After that only a
    lit run of another, wider picture moves it ('wider'): a dark scene reads wide with dimly lit edges and agrees
    with itself grab after grab (one real film read a consistent 2.39 in its dark scenes on a 16:9
    picture), and a jump up mid-film never comes back down."""

    def __init__(self, needed=AGREEING_SAMPLES):
        self.needed = needed
        self.settled = None          # the shape offered as final so far
        self.provisional = False     # it came from a run with no strongly lit member
        self.answer_sample = None    # the grab the latest answer came from
        self._start()

    def _start(self):
        self._ratio = self._narrowest = None
        self._count = self._strong = 0
        self._sample = self._strong_ratio = self._strong_sample = None

    def add(self, ratio, strong=True, sample=None):
        """One clear grab. None while the answer stays; 'first', 'corrected' or 'wider' when the run it completes
        changes it (settled and answer_sample are then the run's answer). A completed run starts over either way."""
        if self._ratio is not None and detect.same_picture((ratio, self._ratio, self._narrowest)):
            self._count += 1
            self._strong += bool(strong)
            if ratio >= self._ratio:
                self._sample = sample
            self._ratio, self._narrowest = max(ratio, self._ratio), min(ratio, self._narrowest)
            if strong and (self._strong_ratio is None or ratio >= self._strong_ratio):
                self._strong_ratio, self._strong_sample = ratio, sample
        else:
            self._ratio = self._narrowest = ratio
            self._count = 1
            self._strong = int(bool(strong))
            self._sample = sample
            self._strong_ratio, self._strong_sample = (ratio, sample) if strong else (None, None)
        if self._count < self.needed:
            return None
        lit = bool(self._strong)
        answer, answer_sample = (self._strong_ratio, self._strong_sample) if lit else (self._ratio, self._sample)
        self._start()
        if self.settled is None:
            change = 'first'
        elif self.provisional and lit:
            change = 'corrected'
        elif lit and answer > self.settled and not detect.same_picture((answer, self.settled)):
            change = 'wider'
        else:
            return None
        self.settled = answer if lit else detect.Picture(answer, provisional=True)
        self.provisional, self.answer_sample = not lit, answer_sample
        return change

    def refine(self, picture):
        """The answer measured again in one grab of the screen's width (see exact_on_screen)."""
        self.settled = picture

    def wider(self, ratio):
        """Whether a grab of ratio (None for an unclear one) still matters: nothing offered yet, or another, wider
        picture than the answer."""
        return self.settled is None or (ratio is not None and ratio > self.settled
                                        and not detect.same_picture((ratio, self.settled)))


def look(capture, video_ratio):
    """One small grab of the playing video, analysed as the screen route does: (frame, width, height, sample).
    capture: the frame grab (capture.KodiScreen in Kodi; a list of frames in the tests). What screen(), a PC's first
    look (capture.first_look) and the grab reader (grabreader.GrabReader) share."""
    width, height = SCREEN_WIDTH, max(16, int(round(SCREEN_WIDTH / video_ratio)))
    frame, _stopped = capture.grab(width, height)
    return frame, width, height, detect.analyse(frame, width, height)


def exact_picture(capture, video_ratio, sample):
    """The picture with its exact edge from one grab of the screen's width (exact_on_screen), kept only when that
    edge is strongly lit (a dim grab's edge row would read as bar); else None."""
    exact = exact_on_screen(capture, video_ratio, sample)
    if exact is None or not exact.strong:
        return None
    return detect.picture_of(exact, video_ratio)


def screen(video_ratio, current, wait, record, capture):
    """Frame grabs until enough clear ones in a row agree. After that the grabs go on at the slow pace,
    until SCREEN_GIVE_UP or a long run of black, and a wider shape agreed on the same way is offered
    as well: an IMAX film that opens in a tall scene ends on its widest shape, as on CoreELEC. It only
    ever widens, and only to another picture (see detect.same_picture), so a dark scene that reads a row
    more of bar moves nothing. Once settled only wider grabs go to the detailed log. capture: the frame grab
    (capture.KodiScreen in Kodi)."""
    runs = Runs()
    started = time.time()
    grabs = clear = empty_run = black_run = 0
    all_black = True
    while current():
        elapsed = time.time() - started
        if elapsed > SCREEN_GIVE_UP:
            return
        frame, width, height, sample = look(capture, video_ratio)
        grabs += 1
        ratio = detect.shape(sample, video_ratio) if sample.clear else None
        if runs.wider(ratio):
            record(grabs, frame, width, height, 4, sample)
        nothing = sample.reason.startswith('no image')
        empty_run = empty_run + 1 if nothing else 0
        black_run = black_run + 1 if sample.reason == 'black frame' else 0
        all_black = all_black and (nothing or sample.reason == 'black frame')
        if runs.settled is not None and (empty_run >= SCREEN_EMPTY_LIMIT or black_run >= SCREEN_BLACK_AFTER):
            return                        # settled already: the answer stands, only the widening ends
        if empty_run >= SCREEN_EMPTY_LIMIT:
            raise Unavailable('the frame grab returns no image here')
        if all_black and grabs >= SCREEN_BLACK_LIMIT:
            raise Unavailable('the frame grab returns only black here')
        if ratio is not None:
            clear += 1
            change = runs.add(ratio, sample.strong, sample)
            if change is not None:
                # A provisional answer (a film that opens dark) is placed, and playback does not write it to the
                # cache; the first lit run replaces it (see Runs).
                how = 'screen, %d grabs, %d clear, %.1f s%s' % (
                    grabs, clear, elapsed, {'first': '', 'corrected': ', corrected', 'wider': ', wider'}[change])
                if not runs.provisional:
                    # Refined within a row of the answer (exact_bars reads only between analysed rows),
                    # from the grab the answer came from (exact_picture keeps a strongly lit edge only).
                    picture = exact_picture(capture, video_ratio, runs.answer_sample)
                    if picture is not None:
                        runs.refine(picture)
                        how += ', exact bars %d/%d of %d' % (picture.top, picture.bottom, picture.height)
                yield runs.settled, how, True
        if wait(SCREEN_SLOW_INTERVAL if runs.settled is not None or elapsed >= SCREEN_FAST_PERIOD
                else SCREEN_INTERVAL):
            return


def exact_on_screen(capture, video_ratio, sample):
    """The settled grab's edges in one grab of the screen's width (SCREEN_EXACT_WIDTH at most), found row by row with
    detect.exact_bars as in a decoded frame, or None: Kodi could not say the screen's size, the grab came back
    empty, the playback ended meanwhile, or the grab shows another scene (its bars are not all bar). The caller
    keeps it only when strongly lit."""
    screen_width = capture.width()
    if screen_width is None:
        return None
    width = min(SCREEN_EXACT_WIDTH, screen_width)
    if width <= SCREEN_WIDTH:
        return None
    height = int(round(width / video_ratio))
    frame, stopped = capture.grab(width, height)
    if stopped or not frame or len(frame) < width * height * 4 or detect.empty_green(frame, width, height, 4):
        return None

    def read_values(y):
        start = y * width * 4 + 1
        return bytes(frame[start:start + width * 4:4])

    def darkest(y):                      # each pixel's darkest of blue, green and red
        start = y * width * 4
        return bytes(map(min, frame[start:start + width * 4:4], frame[start + 1:start + width * 4:4],
                         frame[start + 2:start + width * 4:4]))
    exact = detect.exact_bars(read_values, width, height, sample, darkest=darkest)
    return exact if exact is not None and detect.bars_hold(read_values, exact, darkest) else None


def _level5_text(dovi, keyframe):
    """What the keyframe said about Dolby Vision Level 5, for the detailed log. dovi: the decoder can read the
    metadata at all."""
    if not dovi:
        return 'Dolby Vision metadata not readable with this FFmpeg'
    level5 = keyframe.level5
    if level5 is None:
        return 'no Dolby Vision Level 5'
    return 'Level 5 top %d, bottom %d' % tuple(level5[:2])


class Readings:
    """The file route's clear readings and the precision they are judged at.

    The same picture within half a per cent (EXACT_SAME_PICTURE) while every clear keyframe's edges were found in
    its own rows; the analysed rows' 2 per cent let one or two dark keyframes (a dark edge reads as bar) lift a film
    by 9 px (in the test corpus many films came closer to the edge, none worse, none in the bar). One keyframe
    measured only on the analysed rows puts the film back on the 2 per cent. Each exact shape keeps its own rows,
    the taller bar on each side where readings of one shape split them differently: a capped reading takes the
    capping (agreed) reading's ratio, which is in here too, so the settled shape always finds its frame rows."""

    def __init__(self):
        self.readings = []          # (shape, strongly lit) per clear keyframe, in keyframe order
        self._shares = []           # where in the film each reading was taken (a share of its length, or None)
        self._bars = {}             # each exact shape's own rows: ratio -> (top, bottom, height)
        self._exact_only = True

    def __len__(self):
        return len(self.readings)

    def add(self, sample, exact, video_ratio, share=None):
        """One clear keyframe: its analysed sample and its exact edge (None when not found in its own rows), and
        where in the film it was taken."""
        measured = exact or sample
        found = detect.shape(measured, video_ratio)
        self.readings.append((found, measured.strong))
        self._shares.append(share)
        if exact is not None:
            # Readings of one shape can split their rows differently (59/60 and 60/59): each side keeps the taller
            # bar, as decide keeps the widest shape. Placement reads the bar on the subtitle's side, and the last
            # reading's side used to win (a corpus film placed bottom text a row into the bar two keyframes read).
            known = self._bars.get(found)
            if known is not None and known[2] == exact.height:
                self._bars[found] = (max(known[0], exact.top), max(known[1], exact.bottom), exact.height)
            else:
                self._bars[found] = (exact.top, exact.bottom, exact.height)
        self._exact_only = self._exact_only and exact is not None

    def share(self):
        return EXACT_SAME_PICTURE if self._exact_only else None

    def unsure(self):
        return unsure(believed(self.readings, self.share()), self.share())

    def decide(self, last=False):
        """The shape to offer (or, with last, to settle on), or None (see decide and believed)."""
        return decide(believed(self.readings, self.share()), last=last, share=self.share())[0]

    def picture(self, ratio):
        return detect.Picture(ratio, *self._bars.get(ratio, (0, 0, 0)))

    def lit_at(self, ratio):
        """How many strongly lit keyframes read exactly this shape: how firm a settled answer is, for the log (a
        capped or dim reading does not count)."""
        return sum(1 for found, strong in self.readings if strong and round(found, 4) == round(ratio, 4))

    def lone_far(self):
        """Where the widest reading was first taken when it is another picture than the rest (at this film's own
        precision, share()) and no strongly lit reading has confirmed it: seen once, or only dimly; else None. Its
        neighbours are read next (NEAR_SHARES): a dim reading never decides on its own (believed), and a dim neighbour
        is usually the same dark scene again, so only a lit one ends the look."""
        ratios = [ratio for ratio, _strong in self.readings]
        if len(ratios) < 2:
            return None
        widest = max(ratios)
        same = [at for at, ratio in enumerate(ratios) if detect.same_picture((ratio, widest), self.share())]
        if len(same) == len(ratios) or (len(same) > 1 and any(self.readings[at][1] for at in same)):
            return None
        return self._shares[same[0]]


def _exact_text(exact):
    """The exact edge for the detailed log."""
    return ', exact bars %d/%d of %d' % (exact.top, exact.bottom, exact.height) if exact else ''


def film(reader, length, video_ratio, current, record, level5_hands_over=False, keyframes=None,
         min_length=FILM_MIN_LENGTH, ready=None, shift=0.0):
    """Keyframes from across the film; the widest clear shape is offered at once, and settled once
    every keyframe is in (about 0.3 s each on a box), so an IMAX film whose first keyframes land in
    its tall scenes still ends on its widest shape. When that widest shape was seen only once, its
    neighbours are read (NEAR_SHARES), then FILM_MORE_POSITIONS while it stays unsure (see _positions).

    reader: a filmreader.FilmReader for the playing file (every decode inside the decode guard). A clear keyframe's
    edges are then found in the frame's own rows (1.2.0), so the shape is no longer limited to the analysed frame's
    288 rows (up to 7.5 source rows apart at 2160). Level 5 is still judged on the analysed rows.
    level5_hands_over: CoreELEC restricts subtitles once Level 5 has values, and it was zero at
    the start; True, or a function asked when a keyframe has values (the kind of subtitle shown may
    change while measuring). Each keyframe's Level 5 is read along with it (no extra decoding); values
    in any of them raise LeftToCoreELEC, before that keyframe's shape is offered.
    An exact shape is offered as soon as it changes, an analysed one only for another picture (until
    1.4.1 both at two per cent: an exact 2.39 after an offered 2.40 waited for the final answer).
    keyframes: a list that gets each decoded Keyframe, for level5_correction and the scene verdict, so a Level 5
    check after measuring needs no second decode. ready(first): asked before the file is opened (first True) and
    before every later keyframe; it waits until Kodi plays on smoothly and says False when the playback ended meanwhile
    (Playback.steady). None: read at once (the real-film corpus). shift: a share of the film added to every position (a
    film read again after no answer, measurement.AGAIN_SHIFTS).
    """
    if length < min_length:
        raise Unavailable('no film length to sample from')
    readings, offered, number, decoded = Readings(), None, 0, 0
    if ready is not None and not ready(True):
        return
    reader.open()
    try:
        length = reader.playable(length)
        if length < min_length:
            raise Unavailable('no film length to sample from')
        width, height = reader.size
        for share in _positions(readings, lambda: decoded, shift):
            number += 1
            if not current() or (ready is not None and number > 1 and not ready(False)):
                return
            keyframe = reader.keyframe(length * share, uneven=True, faint=False)
            if keyframe.frame is None:
                record(number, None, width, height, 3, None, keyframe.detail)
                continue
            decoded += 1
            level5 = keyframe.level5
            if level5 and any(level5[:2]) and _hands_over(level5_hands_over):   # top or bottom, as CoreELEC restricts
                raise LeftToCoreELEC('Level 5 at %d s: top %d, bottom %d' % (length * share, level5[0], level5[1]))
            sample, exact = keyframe.sample, keyframe.exact
            if keyframes is not None:
                keyframes.append(keyframe)
            record(number, keyframe.frame, width, height, 3, sample,
                   '%s, %s%s' % (keyframe.detail, _level5_text(reader.dovi, keyframe), _exact_text(exact)))
            if sample.clear:
                readings.add(sample, exact, video_ratio, share)
            ratio = readings.decide()
            how = 'file, %s, %s, %s' % (_counted(len(readings), decoded, number), reader.where, reader.description)
            if ratio is not None and (offered is None or (ratio != offered if readings.share()
                                                          else not detect.same_picture((ratio, offered)))):
                offered = ratio
                yield readings.picture(ratio), how, False
    finally:
        reader.close()
    ratio = readings.decide(last=True)
    if ratio is not None:
        picture = readings.picture(ratio)
        if decoded == 1:
            # One keyframe in the whole file (every other position landed on it again): one reading is no film's
            # shape to keep. A logo on white there would be cached as a full frame. Placed, never cached.
            picture = detect.Picture(picture, picture.top, picture.bottom, picture.height, provisional=True)
        yield (picture, 'file, %s, %d lit at that edge, %s, %s' % (
            _counted(len(readings), decoded, number), readings.lit_at(ratio), reader.where, reader.description), True)


def _counted(clear, decoded, number):
    """The clear keyframes of those decoded, and the positions asked, for the log: a position that lands on a keyframe
    read already decodes nothing."""
    return '%d clear of %d keyframe%s decoded (%d position%s)' % (
        clear, decoded, '' if decoded == 1 else 's', number, '' if number == 1 else 's')


def _positions(readings, decoded, shift=0.0):
    """The shares of the film to read, in order, decided as the readings come in: FILM_POSITIONS; then, when the
    widest reading is another picture seen once (Readings.lone_far), its neighbours (NEAR_SHARES, within the film,
    none twice) until it is seen again; then, while the widest believed shape was seen only once (Readings.unsure),
    FILM_MORE_POSITIONS, and the neighbours of a sighting made there. Nothing more when no keyframe decoded at all
    (decoded(): how many did). shift: added to each of the two lists' shares."""
    read, near = [], [0]
    for share in FILM_POSITIONS:
        share = round(share + shift, 4)
        read.append(share)
        yield share
    if not decoded():
        return
    yield from _near(readings, read, near)
    if readings.unsure():
        for share in FILM_MORE_POSITIONS:
            share = round(share + shift, 4)
            if share not in read:
                read.append(share)
                yield share
        yield from _near(readings, read, near)


NEAR_MOST = 8        # neighbour reads per measurement: a wider lone sighting among them brings neighbours of its own,
                     # so a dark stretch reading ever wider could walk on keyframe by keyframe


def _near(readings, read, near):
    """The neighbours of a lone far-wider sighting until a lit reading confirms it; a wider lone sighting among them
    takes its place, with neighbours of its own. near: [how many were read so far], NEAR_MOST at most."""
    lone, steps = readings.lone_far(), list(NEAR_SHARES)
    while lone is not None and steps and near[0] < NEAR_MOST:
        share = round(lone + steps.pop(0), 4)
        if share in read or not 0.01 <= share <= 0.99:
            continue
        read.append(share)
        near[0] += 1
        yield share
        now = readings.lone_far()
        if now != lone:
            lone, steps = now, list(NEAR_SHARES)


def _hands_over(level5_hands_over):
    return level5_hands_over() if callable(level5_hands_over) else bool(level5_hands_over)


LEVEL5_AGREEING = 3      # clear keyframes that must agree before a film's Level 5 is corrected


def level5_correction(reader, length, current, keyframes=None, min_length=FILM_MIN_LENGTH, ready=None):
    """Whether a Dolby Vision film's own Level 5 is wrong, and what it should be.

    Returns ((top, bottom) or None, reason for the log). (top, bottom) are the picture's bars
    in the frame's own pixels, for CoreELEC's Level 5 override, which also goes to the TV. A film
    is corrected when every clear keyframe (at least three) shows the same picture (within the
    measuring precision, see detect.same_picture; the widest reading is used) and the Level 5
    of at least one of them does not fit it: wrong, dropping to zero in some scenes, or missing in
    a Dolby Vision stream. Each keyframe's Level 5 is held against its own picture, so correct
    Level 5 that follows IMAX scenes is never touched; films whose picture changes are left as
    they are, as is Level 5 with side bars and a stream whose Dolby Vision metadata this FFmpeg
    can not read. keyframes: what measuring already decoded (see film); without them the
    keyframes are decoded here, through reader (ready as for film). Raises Unavailable.
    """
    if keyframes:
        return judge_level5(keyframes)
    if length < min_length:
        raise Unavailable('no film length to sample from')
    keyframes = []
    if ready is not None and not ready(True):
        return None, 'playback changed'
    reader.open()
    try:
        length = reader.playable(length)
        if length < min_length:
            raise Unavailable('no film length to sample from')
        for number, share in enumerate(FILM_POSITIONS):
            if not current() or (ready is not None and number and not ready(False)):
                return None, 'playback changed'
            keyframe = reader.keyframe(length * share)
            if keyframe.frame is None:
                continue
            keyframes.append(keyframe)
            if judge_level5(keyframes, complete=False) is not None:
                break                     # decided already: no need to decode the rest
    finally:
        reader.close()
    return judge_level5(keyframes)


def judge_level5(keyframes, complete=True):
    """level5_correction's verdict on what the keyframes said (keyframes.Keyframe). Not complete: the verdict only
    when more keyframes could not change it, else None."""
    seen = []
    for keyframe in keyframes:
        if keyframe.level5_pair is None:
            return None, 'no Dolby Vision metadata readable'
        if keyframe.side_bars:
            return None, 'Level 5 with side bars'
        if not keyframe.judgeable:
            continue                     # uneven: both bars taken as the taller one, not the film's own Level 5 shape
        seen.append(keyframe)
        if not detect.same_picture([entry.shape for entry in seen]):
            return None, 'the picture changes during the film'
    if not complete:
        return None
    if len(seen) < LEVEL5_AGREEING:
        return None, 'too few clear keyframes to judge'
    width, height = seen[0].size
    picture = max(entry.shape for entry in seen)
    # On the analysed rows by design: whether to correct is judged at the precision every keyframe has.
    if all(entry.fits(entry.level5_pair, exact=False)[0] for entry in seen):
        return None, 'Level 5 matches the picture (%.2f)' % picture
    given = ' and '.join(sorted({'%d/%d' % entry.level5_pair for entry in seen}))
    found = _level5_bars([entry.exact for entry in seen if entry.exact is not None and entry.exact.strong])
    if found:
        return found, 'Level 5 says %s, the picture is %.2f (exact bars)' % (given, width / (height - sum(found)))
    bars = max(0, height - round(width / picture))
    if bars < height * 0.005:    # rounding between a standard shape and the frame's own: no bars
        bars = 0
    return (bars // 2, bars - bars // 2), 'Level 5 says %s, the picture is %.2f' % (given, picture)


def _level5_bars(exacts):
    """(top, bottom) in the frame's own rows for the Level 5 override: the tallest exact bars that two strongly lit
    keyframes agree on (within detect.EXACT_SLACK rows at each edge), or None. The analysed frame's shape, snapped to
    a standard, was off by 3 to 22 rows in most films with a wrong Level 5 in the test corpus (a dark scene's edge read
    as bar made 276 rows 290), and the override also tells the TV where the picture is; from the exact edges all 140
    come within 2 rows, 135 to the row."""
    for candidate in sorted(exacts, key=lambda exact: exact.top + exact.bottom, reverse=True):
        if sum(1 for other in exacts if abs(other.top - candidate.top) <= detect.EXACT_SLACK
               and abs(other.bottom - candidate.bottom) <= detect.EXACT_SLACK) >= 2:
            return candidate.top, candidate.bottom
    return None
