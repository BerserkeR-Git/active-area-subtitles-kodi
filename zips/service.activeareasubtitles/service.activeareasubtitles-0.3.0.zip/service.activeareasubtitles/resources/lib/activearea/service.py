"""The background service: find the picture's shape once per playback, then step aside.

Per playback: wait a moment, check that there is anything to do, work out the picture's
shape (from the file's own shape when it is already cropped, otherwise by measuring), set
Kodi's subtitle margin so subtitles sit just inside the picture, and put the person's own
margin back when playback ends. It never sends a playback command, and once the shape is
known it does nothing more until the next playback.

Measuring: on CoreELEC from keyframes decoded from the file (Kodi can not see the video
plane there); elsewhere from tiny frame grabs, with the file as a fallback where the system
has FFmpeg. Everything runs on its own low-key thread; any failure leaves Kodi's normal
subtitle position.
"""
import contextlib
import os
import threading
import time

import xbmc
import xbmcgui

from . import coreelec, diagnostics, geometry, kodi, measure
from .keeper import Keeper

MARGIN_SETTING = 'subtitles.marginvertical'
START_DELAY = 1.0              # seconds after playback starts before anything is looked at
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 is taken as already cropped
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = xbmc.Monitor()
        self.keeper = Keeper(lambda: _number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'))
        self.lock = threading.Lock()
        self.generation = 0
        self.manual_notice_shown = False
        self.on_coreelec = coreelec.is_coreelec()

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        generation = self._next_generation()
        if self.isPlayingVideo():
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onPlayBackStopped(self):
        self._finish('playback stopped')

    def onPlayBackEnded(self):
        self._finish('playback ended')

    def onPlayBackError(self):
        self._finish('playback error')

    def run(self):
        with self.lock:
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
        self._check_last_decoding()
        kodi.log('started on %s' % ('CoreELEC: measuring from the file' if self.on_coreelec
                                    else 'this system: measuring from the screen'))
        while not self.monitor.waitForAbort(30):
            pass
        self._finish('Kodi closing')
        # A decode in progress finishes within about two seconds; let it, so Kodi does not
        # tear Python down in the middle of an FFmpeg call (and the marker is not left behind).
        for _ in range(40):
            if not os.path.exists(self._decode_marker()):
                break
            time.sleep(0.1)

    # Bookkeeping.

    def _next_generation(self):
        with self.lock:
            self.generation += 1
            return self.generation

    def _current(self, generation):
        return generation == self.generation and not self.monitor.abortRequested()

    def _finish(self, why):
        with self.lock:
            self.generation += 1
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    def _restore_if_current(self, generation, why):
        with self.lock:
            if self._current(generation) and self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    # Protection against the one thing that could take Kodi down: decoding through FFmpeg.
    # A marker is written before each keyframe and removed after. Finding it at start-up
    # means Kodi stopped in the middle of a decode, so file measuring stays off until the
    # add-on is updated.

    def _decode_marker(self):
        return kodi.data_path('decoding.marker')

    def _decode_block(self):
        return kodi.data_path('decoding.disabled')

    def _check_last_decoding(self):
        marker = self._decode_marker()
        if os.path.exists(marker):
            _remove(marker)
            try:
                with open(self._decode_block(), 'w', encoding='utf-8') as handle:
                    handle.write(kodi.addon().getAddonInfo('version'))
            except OSError:
                pass
            kodi.log('Kodi stopped during a decode last time; measuring from the file is off until the next update',
                     always=True)

    def _decoding_allowed(self):
        try:
            with open(self._decode_block(), encoding='utf-8') as handle:
                blocked_version = handle.read().strip()
        except OSError:
            return True
        if blocked_version != kodi.addon().getAddonInfo('version'):
            _remove(self._decode_block())
            return True
        return False

    @contextlib.contextmanager
    def _decode_guard(self):
        marker = self._decode_marker()
        folder = os.path.dirname(marker)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(marker, 'w', encoding='utf-8') as handle:
            handle.write(str(time.time()))
        try:
            yield
        finally:
            _remove(marker)

    # The work for one playback, on its own thread.

    def _fit(self, generation):
        try:
            self._fit_once(generation)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)

    def _fit_once(self, generation):
        if self.monitor.waitForAbort(START_DELAY) or not self._current(generation):
            return
        if not kodi.setting_bool('enabled'):
            self._finish('turned off in settings')
            return
        if not xbmc.getCondVisibility('VideoPlayer.HasSubtitles'):
            kodi.log('video has no subtitles, nothing to do')
            self._restore_if_current(generation, 'no subtitles')
            return
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self._restore_if_current(generation, '3D video')
            return
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self._restore_if_current(generation, 'position not handled')
            self._manual_notice()
            return
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self._restore_if_current(generation, 'view mode not normal')
            return
        if self.on_coreelec and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.monitor.waitForAbort,
                lambda: self._current(generation), kodi.log):
            self._restore_if_current(generation, 'CoreELEC places the subtitles')
            return

        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        video_ratio = xbmc.RenderCapture().getAspectRatio()
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            return
        layout = (area, screen_w, screen_h, video_ratio)
        if abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE:
            self._apply(generation, layout, video_ratio, 'file already cropped', time.time())
            return

        started = time.time()
        current = lambda: self._current(generation)  # noqa: E731
        saved = []

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and len(saved) < SAVED_PICTURES and kodi.setting_bool('diagnostics'):
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        for name, attempt in self._ways(video_ratio, current, record):
            try:
                for ratio, how, final in attempt():
                    self._apply(generation, layout, ratio, how, started, final)
                    if final:
                        return
                kodi.log('%s gave no clear answer' % name)
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
        kodi.log('no way of measuring worked for this playback; subtitles left where Kodi puts them')

    def _ways(self, video_ratio, current, record):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.monitor.waitForAbort, record)

        def film():
            if not self._decoding_allowed():
                raise measure.Unavailable('switched off after an interrupted decode')
            try:
                url, length = self.getPlayingFile(), self.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing file unknown')
            return measure.film(url, length, video_ratio, kodi.data_path('ffmpeg.json'), current,
                                record, self._decode_guard)

        if self.on_coreelec:
            return [('measuring from the file', film)]
        return [('measuring from the screen', screen), ('measuring from the file', film)]

    def _apply(self, generation, layout, picture_ratio, how, started, final=True):
        area, screen_w, screen_h, video_ratio = layout
        screen_ratio = screen_w / screen_h
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, not handled')
                return
            value = geometry.margin_value(own, area, screen_ratio, video_ratio, picture_ratio)
            changed = self.keeper.apply(value)
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; margin %.2f -> %.2f%s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, own, value, '' if changed else ' (unchanged)'))

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None

    def _manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32040), kodi.addon().getAddonInfo('icon'), 8000)


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass


def run():
    Service().run()
