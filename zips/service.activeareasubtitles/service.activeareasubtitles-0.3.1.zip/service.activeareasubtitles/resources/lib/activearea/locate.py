"""What is playing, turned into something FFmpeg can read, with an identity for the exact file version.

- A local path (also a kernel NFS or SMB mount that PM4K maps its libraries to): read directly.
- A Plex address for direct play: read directly. A token PM4K passes in Kodi's header form
  ("address|X-Plex-Token=...") is moved into the address, which FFmpeg understands.
- A Plex transcode address (audio only or full): the original file is looked up on the same
  server and read directly, so no extra transcode is started and the session is not touched.
- Kodi's own sources (smb://, nfs://, ...): read through Kodi's file access.
- Streams without a file (live TV, add-on streams): not measurable.

Identities never contain a token: they are built from paths, sizes and dates only. Plex file
keys carry the file's update time, so a replaced file gets a new identity.
"""
import os
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ElementTree

DIRECT, KODI = 'direct', 'kodi'
NOT_MEASURABLE = ('plugin', 'pvr', 'rtsp', 'rtmp', 'rtp', 'udp', 'mms', 'upnp', 'addons', 'videodb', 'musicdb')
PLEX_TIMEOUT_S = 4
PLEX_MAX_BYTES = 1024 * 1024
TOKEN = 'X-Plex-Token'


class Unavailable(Exception):
    """The playing item can not be read for measuring. The message is for the log."""


class Target:

    def __init__(self, kind, address, identity, description):
        self.kind = kind                # DIRECT: FFmpeg opens address; KODI: read through Kodi
        self.address = address          # may carry a token: never log it
        self.identity = identity        # safe to log and to use as a key
        self.description = description  # safe to log

    def __repr__(self):
        return 'Target(%s, %s)' % (self.kind, self.description)


def _kodi_options(options):
    found = {}
    for pair in options.split('&'):
        key, _, value = pair.partition('=')
        if key:
            found[urllib.parse.unquote(key)] = urllib.parse.unquote(value)
    return found


def _with_token(address, token):
    parts = urllib.parse.urlsplit(address)
    query = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    if token and not any(key == TOKEN for key, _ in query):
        query.append((TOKEN, token))
    return urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query)))


def _local_identity(path):
    try:
        info = os.stat(path)
        return '%s|%d|%d' % (path, info.st_size, int(info.st_mtime))
    except (OSError, ValueError):   # ValueError: a path with a null character
        raise Unavailable('the local file can not be read')


def _kodi_identity(address, stat):
    try:
        info = stat(address)
        return '%s|%d|%d' % (_without_credentials(address), info.st_size(), int(info.st_mtime()))
    except Exception:  # Kodi's stat raises on unreachable sources
        return _without_credentials(address)


def _without_credentials(address):
    parts = urllib.parse.urlsplit(address)
    host = parts.hostname or ''
    if parts.port:
        host += ':%d' % parts.port
    return urllib.parse.urlunsplit((parts.scheme, host, parts.path, '', ''))


def _plex_original(base, query, token, opener):
    """The direct address and file key of the original behind a Plex transcode."""
    item = query.get('path', [''])[0]
    if not item.startswith('/library/metadata/') or not token:
        raise Unavailable('transcode without a recognisable library item')
    media_index = _index(query.get('mediaIndex', ['0'])[0])
    part_index = _index(query.get('partIndex', ['0'])[0])
    request = urllib.request.Request(base + item + '?' + urllib.parse.urlencode({TOKEN: token}),
                                     headers={'Accept': 'application/xml'})
    try:
        with opener(request, timeout=PLEX_TIMEOUT_S) as response:
            data = response.read(PLEX_MAX_BYTES + 1)
    except (OSError, ValueError):
        raise Unavailable('the Plex server did not answer')
    if len(data) > PLEX_MAX_BYTES:
        raise Unavailable('unexpectedly large answer from the Plex server')
    try:
        root = ElementTree.fromstring(data)
    except ElementTree.ParseError:
        raise Unavailable('unreadable answer from the Plex server')
    media = root.findall('./*/Media')
    if not media:
        raise Unavailable('the Plex server lists no file for this item')
    parts = media[min(media_index, len(media) - 1)].findall('Part')
    if not parts:
        raise Unavailable('the Plex server lists no file for this item')
    key = parts[min(part_index, len(parts) - 1)].get('key', '')
    if not key.startswith('/library/parts/'):
        raise Unavailable('unexpected file key from the Plex server')
    return _with_token(base + key, token), key


def _index(text):
    try:
        return max(0, int(text))
    except ValueError:
        return 0


def resolve(playing, stat=None, opener=urllib.request.urlopen):
    """A Target for the playing item. Raises Unavailable."""
    if not playing:
        raise Unavailable('nothing is playing')
    address, _, options = playing.partition('|')
    scheme = urllib.parse.urlsplit(address).scheme.lower()
    if scheme in ('', 'file') or len(scheme) == 1:   # a one-letter scheme is a drive: C:\ on Windows
        path = urllib.parse.unquote(urllib.parse.urlsplit(address).path) if scheme == 'file' else address
        return Target(DIRECT, path, _local_identity(path), 'local file')
    if scheme in ('http', 'https'):
        parts = urllib.parse.urlsplit(address)
        query = urllib.parse.parse_qs(parts.query)
        token = query.get(TOKEN, [''])[0] or _kodi_options(options).get(TOKEN, '')
        base = '%s://%s' % (parts.scheme, parts.netloc)
        if '/transcode/' in parts.path:
            direct, key = _plex_original(base, query, token, opener)
            return Target(DIRECT, direct, 'plex|%s|%s' % (parts.hostname, key), 'Plex original behind a transcode')
        return Target(DIRECT, _with_token(address, token), 'web|%s|%s' % (parts.hostname, parts.path),
                      'Plex file' if '/library/parts/' in parts.path else 'web address')
    if scheme in NOT_MEASURABLE:
        raise Unavailable('%s streams have no file to measure' % scheme)
    return Target(KODI, playing, _kodi_identity(address, stat) if stat else _without_credentials(address),
                  '%s source through Kodi' % scheme)
