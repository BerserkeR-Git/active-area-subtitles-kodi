"""Protection against the one part that could take Kodi down: decoding through FFmpeg.

A marker file names the files being decoded while any decode runs, one per start of the
service, with the Kodi process it runs in. Finding one of another Kodi process when the
service starts means Kodi stopped in the middle of a decode without closing normally: a
crash in FFmpeg, or a crash of Kodi's own, a power cut, Kodi killed. Once says little: a
film is read for much of its playing time (a PC reads it ahead), so any death of Kodi
during a film lands in a decode of it. So:

- once, nothing is left out: that film is read again at its next playback;
- a file Kodi died in a decode of twice within STRIKE_FOR is left to Kodi from now on (one
  film, not the add-on), so a file that crashes FFmpeg can not crash Kodi again and again;
- two deaths in a row, each in the first decode since the start (none came back in between),
  of different films: FFmpeg itself is the problem, not one file, and decoding pauses for a
  day, then it is simply tried again;
- a marker naming no file (one a power cut left empty) counts for nothing;
- an update of the add-on starts with a clean slate, since it may bring the fix.

A normal close removes the marker, even when a decode is still running then (a slow network
read), so that is never taken for a crash. A marker of this Kodi process is another start of
the add-on still decoding (an update, or a start whose stop Kodi lost), never a crash: it is
left alone, and goes when that start's decode ends or at the newest start's close.
"""
import collections
import contextlib
import json
import os
import threading
import time
import uuid

PAUSE_S = 24 * 60 * 60     # after two interrupted decodes in a row, of different films
SKIPPED_LIMIT = 50         # files left to Kodi, newest kept
STRIKES_TO_SKIP = 2        # deaths inside a decode of one file that leave it to Kodi
STRIKE_FOR = 30 * 24 * 60 * 60   # how long a death counts against its file
STRUCK_LIMIT = 200         # files with a death on record, the latest kept
ROW_LIMIT = 5              # deaths in a row kept
MARKER = 'decoding-%s.marker'        # one per start, named by its claim


def process():
    """This Kodi process as a marker names it: its id, and where the system says the boot it runs in (a box switched
    off and on can give Kodi the same id again). Every start of the add-on in one Kodi runs in its process."""
    try:
        with open('/proc/sys/kernel/random/boot_id', encoding='ascii') as handle:
            boot = handle.read().strip()
    except OSError:
        boot = ''
    return '%d %s' % (os.getpid(), boot)


# What check_last_run found: outcome 'noted' (a death counted, nothing left out), 'skipped' (a file left to Kodi now)
# or 'paused'; files: the films the markers named; left: those left to Kodi from now on.
Interruption = collections.namedtuple('Interruption', 'outcome files left')


class DecodeGuard:

    def __init__(self, folder, version, clock=time.time, start=None, kodi_process=None):
        """start: its start's claim (kodi_session.claim_service), which names its marker and orders it among this
        Kodi's starts; None: a name of its own. kodi_process: Kodi's own id for this Kodi (kodi_session.process_id),
        which a Kodi started again never shares, where the system's can (a container, Windows' ids coming round); None:
        process()."""
        self.start = start
        self.marker = os.path.join(folder, MARKER % (start if start is not None else uuid.uuid4().hex))
        self.record = os.path.join(folder, 'decoding.json')
        self.folder, self.version, self.clock = folder, version, clock
        self.process = kodi_process or process()
        self.lock = threading.Lock()
        self.running = []   # identities being decoded: an older playback's may still be finishing
        self.closing = False  # Kodi is closing normally: no decode may write the marker again

    def check_last_run(self):
        """At start: what an interrupted decode last time led to (an Interruption), for the log, or None when Kodi
        did not stop inside a decode or the markers it left name no file. Every marker of another Kodi is one death,
        however many there are (starts of one Kodi, each decoding)."""
        files = []
        for path, marked in self._markers():
            if marked.get('process') == self.process:
                continue            # another start in this Kodi, decoding now
            named = marked.get('files') if isinstance(marked.get('files'), list) else []
            files += [name for name in named if isinstance(name, str) and name not in files]
            _remove(path)
        if not files:
            return None
        state, now = self._load(), self.clock()
        left = []
        for name in files:
            state['strikes'][name] = state['strikes'].pop(name, []) + [now]
            if len(state['strikes'][name]) >= STRIKES_TO_SKIP:
                left.append(name)
        state['strikes'] = dict(sorted(state['strikes'].items(), key=lambda item: max(item[1]))[-STRUCK_LIMIT:])
        skipped = [name for name in state['skipped'] if name not in left] + left
        state['skipped'] = skipped[-SKIPPED_LIMIT:]
        # The pause needs another death in the row naming no film in common with this one: one bad film twice is that
        # film's problem, not FFmpeg's.
        paused = any(not set(files) & set(before) for before in state['row'])
        state['row'] = (state['row'] + [files])[-ROW_LIMIT:]
        if paused:
            state['paused_until'] = now + PAUSE_S
        self._save(state)
        return Interruption('paused' if paused else 'skipped' if left else 'noted', tuple(files), tuple(left))

    def paused(self):
        """True while decoding pauses after two interrupted decodes in a row, of different films."""
        return self.clock() < self._load()['paused_until']

    def allowed(self, identity=None):
        """False while paused, and for a file Kodi stopped in a decode of twice."""
        state = self._load()
        return self.clock() >= state['paused_until'] and identity not in state['skipped']

    @contextlib.contextmanager
    def decoding(self, identity=None):
        with self.lock:
            self.running.append(identity)
            self._mark()
        try:
            yield
        finally:
            with self.lock:
                self.running.remove(identity)
                self._mark()
            # FFmpeg came back (with a picture or with an error): the row of interruptions starts again. A file's own
            # strikes stay (a file can decode four keyframes and crash on the fifth).
            state = self._load()
            if state['row']:
                state['row'] = []
                self._save(state)

    def wait_until_idle(self, seconds=4.0):
        """At a normal close: let a running decode finish (about two seconds at most), then
        remove the marker in any case, since Kodi did not stop in the middle of one."""
        deadline = time.time() + seconds
        while self.running and time.time() < deadline:
            time.sleep(0.1)
        with self.lock:
            self.closing = True       # a read that ends (or starts) later must not name the others again
            _remove(self.marker)
            # An older start in this Kodi whose stop Kodi lost leaves through its run() without this wait.
            for path, marked in self._markers():
                if marked.get('process') == self.process and self.start is not None \
                        and isinstance(marked.get('start'), int) and marked['start'] < self.start:
                    _remove(path)

    def _mark(self):
        """The marker names what is being decoded; it is gone while nothing is, and once Kodi closes normally. Written
        whole or not at all: another start reads it at its own start."""
        if not self.running or self.closing:
            _remove(self.marker)
            return
        try:
            self._ensure_folder()
            with open(self.marker + '.part', 'w', encoding='utf-8') as handle:
                json.dump({'files': [f for f in self.running if f], 'process': self.process, 'start': self.start},
                          handle)
            os.replace(self.marker + '.part', self.marker)
        except OSError:
            pass

    def _markers(self):
        """Every marker in the folder, this start's included: [(path, its content)], the content {} where it can not
        be read (counted as another process's)."""
        try:
            names = [name for name in os.listdir(self.folder)
                     if name.startswith('decoding-') and name.endswith('.marker')]
        except OSError:
            return []
        found = []
        for name in sorted(names):
            path = os.path.join(self.folder, name)
            try:
                with open(path, encoding='utf-8') as handle:
                    marked = json.load(handle)
            except (OSError, ValueError):
                marked = {}
            found.append((path, marked if isinstance(marked, dict) else {}))
        return found

    def _load(self):
        """The record: {'version', 'skipped': [files], 'strikes': {file: [the clock at each death]}, 'row': [[files of
        each death in a row]], 'paused_until'}, strikes older than STRIKE_FOR dropped. Anything else in it (an older
        version's single count, a damaged file) reads as none."""
        fresh = {'version': self.version, 'skipped': [], 'strikes': {}, 'row': [], 'paused_until': 0.0}
        try:
            with open(self.record, encoding='utf-8') as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            return fresh
        if not isinstance(state, dict) or state.get('version') != self.version:
            return fresh          # an update: a clean slate
        try:
            skipped, paused_until = state.get('skipped', []), float(state.get('paused_until', 0.0))
        except (TypeError, ValueError):
            return fresh
        now = self.clock()
        strikes = {}
        for name, stamps in (state.get('strikes') if isinstance(state.get('strikes'), dict) else {}).items():
            kept = [stamp for stamp in stamps if _number(stamp) and now - stamp < STRIKE_FOR] \
                if isinstance(stamps, list) else []
            if kept:
                strikes[name] = kept
        row = [[name for name in death if isinstance(name, str)]
               for death in (state.get('row') if isinstance(state.get('row'), list) else []) if isinstance(death, list)]
        return {'version': self.version, 'skipped': [f for f in skipped if isinstance(f, str)]
                if isinstance(skipped, list) else [], 'strikes': strikes, 'row': [death for death in row if death],
                'paused_until': paused_until}

    def _save(self, state):
        try:
            self._ensure_folder()
            with open(self.record, 'w', encoding='utf-8') as handle:
                json.dump(state, handle)
        except OSError:
            pass

    def _ensure_folder(self):
        if self.folder and not os.path.isdir(self.folder):
            os.makedirs(self.folder)


def _number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass
