"""Opening the add-on (its menu) and the buttons: checking for updates and the HDR brightness steps."""
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import hdr, kodi, menu, question, shapes, updates

# How long Kodi gets to look at its repositories before its list of updates is opened.
UPDATE_WAIT_S = 6
PROBLEM_TEXT = {updates.NO_CONNECTION: 32061, updates.NOT_NOW: 32062, updates.NO_SOURCE: 32063}


def _tell(message):
    question.tell(message)


def _repository_xml():
    try:
        path = xbmcaddon.Addon(updates.REPOSITORY_ID).getAddonInfo('path')
        with open(os.path.join(xbmcvfs.translatePath(path), 'addon.xml'), encoding='utf-8') as handle:
            return handle.read()
    except (RuntimeError, OSError):
        return None


def _auto_update_mode():
    """Kodi's own setting: 0 installs updates by itself, 1 only tells, 2 never looks; None when Kodi does not say."""
    try:
        return int(kodi.get_setting('general.addonupdates', quiet=True))
    except (ValueError, TypeError):
        return None


def check_updates():
    installed = kodi.addon().getAddonInfo('version')
    repository = _repository_xml()
    if repository is None:
        _tell(kodi.text(32053))
        return
    try:
        available = updates.latest(repository)
    except updates.UpdateProblem as problem:
        _tell(kodi.text(PROBLEM_TEXT.get(problem.args[0], 32062)))
        return
    if not updates.newer(available, installed):
        _tell(kodi.text(32054).format(installed))
        return
    if not question.ask(kodi.text(32055).format(available, installed), kodi.text(32057), kodi.text(32056),
                        careful=True):
        return
    if _auto_update_mode() == 0:
        # Kodi installs it and restarts the add-on by itself, but only once this script has
        # ended, so nothing here may wait for an answer. Short and brief, so Kodi's own
        # "updated" notice that follows is shown in full. The service checks later that it
        # did (updates.outcome): Kodi skips an add-on installed from a zip without a word.
        try:
            updates.asked(kodi.data_path(updates.ASKED_FILE), available)
        except OSError:
            pass
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32058).format(available),
                                      kodi.addon().getAddonInfo('icon'), 3000, False)
        xbmc.executebuiltin('UpdateAddonRepos')
        return
    # Kodi looks at repositories only once a day; this makes it look now.
    xbmc.executebuiltin('UpdateAddonRepos')
    progress = question.waiting(kodi.text(32059))
    monitor = xbmc.Monitor()
    try:
        for step in range(UPDATE_WAIT_S):
            progress.update(int(100 * (step + 1) / UPDATE_WAIT_S))
            if progress.cancelled or monitor.waitForAbort(1):
                return          # Back cancels, as everywhere in Kodi; or Kodi is closing
    finally:
        progress.close()
    _tell(kodi.text(32060))
    xbmc.executebuiltin(updates.REPOSITORY_PAGE)


def forget_shapes():
    """The Clear cache button: asked first (Cancel focused, as for an update), then the file removed, the count
    logged and "Cache cleared" told once. An empty cache is only told so."""
    cache = shapes.Shapes(kodi.data_path(shapes.FILE_NAME), lambda: True, kodi.log)
    if not any(os.path.exists(path) for path in (cache.path, cache.path + '.new')):   # even a damaged one goes
        _tell(kodi.text(32162))
        return
    if not question.ask(kodi.text(32160), kodi.text(32161), kodi.text(32130), careful=True):
        return
    count = cache.forget()
    kodi.log('cache: cleared, %d %s removed' % (count, 'file' if count == 1 else 'files'), always=True)
    try:
        kodi.addon().setSetting('status_shapes', '0')
    except Exception:  # the status display is a courtesy
        pass
    _tell(kodi.text(32155))


def main(argv):
    action = argv[1] if len(argv) > 1 else ''
    if action == 'check_updates':
        check_updates()
    elif action == 'forget_shapes':
        forget_shapes()
    elif action == 'hdr_apply':
        hdr.apply()
    elif action == 'hdr_restore':
        hdr.restore()
    elif action == 'hdr_steps':
        hdr.steps()
    elif action == 'settings':
        kodi.addon().openSettings()
    else:
        after = menu.show()
        if after == 'check_updates':
            check_updates()
        elif after == 'forget_shapes':
            forget_shapes()
