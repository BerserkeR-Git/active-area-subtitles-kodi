"""The background service: find the picture's shape once per playback, then step aside.

Per playback: check that there is anything to do, work out the picture's shape (from the
file's own shape when it is already cropped, otherwise by measuring), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command, and once the shape is known it does
nothing more until the next playback.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there), elsewhere from tiny screen captures with the video file as a fallback where the
system has FFmpeg. Everything runs on its own thread; any failure leaves Kodi's normal
subtitle position.
"""
import contextlib
import os
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

from . import coreelec, diagnostics, geometry, kodi, locate, measure, status
from .guard import DecodeGuard
from .keeper import Keeper
from .memo import Memo

MARGIN_SETTING = 'subtitles.marginvertical'
SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 is taken as already cropped
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = xbmc.Monitor()
        self.keeper = Keeper(lambda: _number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'))
        self.lock = threading.Lock()
        self.generation = 0
        self.manual_notice_shown = False
        self.on_coreelec = coreelec.is_coreelec()
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), kodi.addon().getAddonInfo('version'))
        self.memo = Memo()
        self.waiting_for_subtitles = None   # playback that had no subtitles yet; measured once some appear

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        generation = self._next_generation()
        if self.isPlayingVideo():
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onAVChange(self):
        # Streams changed: subtitles switched on later in a playback that had none at the start.
        generation = self.waiting_for_subtitles
        if generation is not None and generation == self.generation and \
                xbmc.getCondVisibility('VideoPlayer.HasSubtitles'):
            self.waiting_for_subtitles = None
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onPlayBackStopped(self):
        self._finish('playback stopped')

    def onPlayBackEnded(self):
        self._finish('playback ended')

    def onPlayBackError(self):
        self._finish('playback error')

    def run(self):
        with self.lock:
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
        if self.guard.check_last_run():
            kodi.log('Kodi stopped during a decode last time; video file analysis is paused until the next update',
                     always=True)
        self._show_status()
        while not self.monitor.waitForAbort(30):
            pass
        self._finish('Kodi closing')
        self.guard.wait_until_idle()

    def _show_status(self):
        p3i = self.on_coreelec and coreelec.is_p3i(kodi.get_setting, xbmc.getInfoLabel('System.BuildVersion'))
        system, method = status.describe(self.on_coreelec, p3i, self.guard.allowed(), xbmc.getCondVisibility)
        for setting_id, string_id in (('status_system', system), ('status_method', method)):
            try:
                kodi.addon().setSetting(setting_id, kodi.text(string_id))
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        kodi.log('started: %s, %s' % (kodi.text(system), kodi.text(method).lower()))

    # Bookkeeping.

    def _next_generation(self):
        with self.lock:
            self.generation += 1
            return self.generation

    def _current(self, generation):
        return generation == self.generation and not self.monitor.abortRequested()

    def _finish(self, why):
        with self.lock:
            self.generation += 1
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    def _restore_if_current(self, generation, why):
        with self.lock:
            if self._current(generation) and self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    # The work for one playback, on its own thread.

    def _fit(self, generation):
        try:
            self._fit_once(generation)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)

    def _fit_once(self, generation):
        if not self.on_coreelec and self.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self._current(generation):
            return
        layout = self._layout(generation)
        if layout is None:
            return
        area, screen_w, screen_h, video_ratio = layout
        if abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE:
            self._apply(generation, layout, video_ratio, 'file already cropped', time.time())
            return

        started = time.time()
        current = lambda: self._current(generation)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        identity = self._identity()
        known = self.memo.get(identity) if identity else None
        if known is not None:
            self._apply(generation, layout, known, 'remembered from earlier this session', started)
            return
        remember = [identity]
        for name, attempt in self._ways(video_ratio, current, record, remember, full_pictures):
            try:
                # Closed explicitly, so a decoder is freed the moment the answer is in.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        self._apply(generation, layout, ratio, how, started, final)
                        if final:
                            if remember[0]:
                                self.memo.put(remember[0], ratio)
                            return
                kodi.log('%s gave no clear answer' % name)
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
        kodi.log('no way of measuring worked for this playback; subtitles left where Kodi puts them')

    def _layout(self, generation):
        """(area, screen width, screen height, video ratio), or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self._finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, generation):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self._restore_if_current(generation, 'no subtitles')
            self.waiting_for_subtitles = generation
            return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self._restore_if_current(generation, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self._restore_if_current(generation, 'position not handled')
            self._manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self._restore_if_current(generation, 'view mode not normal')
            return None
        if self.on_coreelec and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.monitor.waitForAbort,
                lambda: self._current(generation), kodi.log):
            self._restore_if_current(generation, 'CoreELEC places the subtitles')
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, generation)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            return None
        return area, screen_w, screen_h, video_ratio

    def _wait_for(self, condition, seconds, generation, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self._current(generation):
            if condition():
                return True
            if waited >= seconds or self.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def _identity(self):
        """The playing file's identity for the session memory, or None."""
        try:
            return locate.resolve(self.getPlayingFile(), stat=xbmcvfs.Stat).identity
        except Exception:  # unknown or unreadable: just measure
            return None

    def _ways(self, video_ratio, current, record, remember, full_pictures):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.monitor.waitForAbort, record)

        def from_file():
            if not self.guard.allowed():
                raise measure.Unavailable('paused after an interrupted decode')
            try:
                playing, length = self.getPlayingFile(), self.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            try:
                target = locate.resolve(playing, stat=xbmcvfs.Stat)
            except locate.Unavailable as reason:
                raise measure.Unavailable(str(reason))
            remember[0] = target.identity
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                self.guard.decoding, full=full_pictures)

        if self.on_coreelec:
            return [('video file analysis', from_file)]
        return [('screen capture', screen), ('video file analysis', from_file)]

    def _apply(self, generation, layout, picture_ratio, how, started, final=True):
        area, screen_w, screen_h, video_ratio = layout
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, not handled')
                return
            value = geometry.margin_value(own, area, screen_w / screen_h, video_ratio, picture_ratio)
            changed = self.keeper.apply(value)
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; margin %.2f -> %.2f%s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, own, value, '' if changed else ' (unchanged)'))

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None

    def _manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32040), kodi.addon().getAddonInfo('icon'), 8000)


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def run():
    Service().run()
