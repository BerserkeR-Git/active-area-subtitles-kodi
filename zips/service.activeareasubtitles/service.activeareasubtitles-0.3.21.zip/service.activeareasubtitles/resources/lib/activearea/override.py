"""CoreELEC's Level 5 override, set for one playback and always cleared again.

The P3i build reads coreelec.amlogic.dolbyvision.level5.override ("top,bottom,left,right" in
the frame's pixels, empty for none) during playback, for the subtitle restriction and the
Level 5 sent to the TV. The add-on only sets it when it is empty, so a value someone else put
there (P3i's helpers, the person) is never replaced, and only clears it when it still holds
the add-on's own value. A small file records what was set, so it is cleared after a crash too.
"""
import json
import os
import posixpath

from . import keeper

SETTING = 'coreelec.amlogic.dolbyvision.level5.override'
INI = 'override.ini'      # P3i's per-folder setting override add-on (service.p3i.override)
# Addresses that add-on never looks next to; asking a Plex server for override.ini is pointless.
REMOTE_SCHEMES = ('http://', 'https://', 'plugin://', 'pvr://', 'plex://', 'upnp://')


def set_by_override_ini(playing, read_text):
    """True when an override.ini next to the playing file, or one folder up (where P3i's
    per-folder override add-on looks), sets the Level 5 override: the person supplies their
    own Level 5 there, so it is trusted and nothing is checked or changed. read_text(path)
    returns the file's text, or None when there is none."""
    address = playing.partition('|')[0]
    if address.lower().startswith(REMOTE_SCHEMES):
        return False
    folder = posixpath.dirname(address)
    for place in (folder, posixpath.dirname(folder.rstrip('/'))):
        if not place:
            continue
        text = read_text(posixpath.join(place, INI)) or ''
        for line in text.splitlines():
            key = line.split('=', 1)[0].strip()
            if '=' in line and key == SETTING:
                return True
    return False


def value_for(top, bottom):
    return '%d,%d,0,0' % (top, bottom)


class Override:

    def __init__(self, read, write, path):
        self._read = read      # () -> the setting's text, or None when it can not be read
        self._write = write    # (text) -> True when CoreELEC took it
        self._path = path

    def _current(self):
        value = self._read()
        return value if isinstance(value, str) else None

    def _load(self):
        try:
            with open(self._path, encoding='utf-8') as handle:
                applied = json.load(handle)['applied']
            return applied if isinstance(applied, str) and applied else None
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def apply(self, value):
        """Set value for this playback. False when the setting holds someone else's value."""
        now, mine = self._current(), self._load()
        if now and now != mine:
            return False
        if not self._save(value):
            return False      # without a record it could not be cleared after a crash
        if self._write(value):
            return True
        # Refused: whatever of ours was in place before still is, and must stay on record.
        if mine:
            self._save(mine)
        else:
            self._forget()
        return False

    def _save(self, value):
        try:
            keeper.write_record(self._path, {'applied': value})
            return True
        except OSError:
            return False

    def restore(self):
        """Clear the add-on's own value. True when something was cleared."""
        applied = self._load()
        if applied is None:
            return False
        now = self._current()
        if now is None or now == applied:      # unreadable, or still ours
            if not self._write(''):
                return False                   # still in place: kept on record, cleared next time
            self._forget()
            return True
        # Someone else's value now: theirs to keep. Ours stays on record, because the other party
        # may put it back later (P3i's override add-on restores what it found when it applied an
        # override.ini, and a playlist skip gives no stop in between): then it is cleared.
        return False

    def _forget(self):
        try:
            os.remove(self._path)
        except OSError:
            pass
