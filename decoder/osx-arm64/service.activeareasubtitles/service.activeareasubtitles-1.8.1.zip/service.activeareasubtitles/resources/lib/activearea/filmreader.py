"""The film reader (FilmReader): what the add-on decodes the playing file through, one question about one file at a
time (a measurement, a scene check, the start-up search, a Level 5 check, the subtitle streams, the scenes ahead).

It is built from its target, the FFmpeg memory path, the currency check, the decode guard and the priority rule.
keyframe(seconds) gives one keyframes.Keyframe, analysed (Keyframe.analyse) and with its exact edge where it is clear;
keyframes(positions) gives them one by one, opening the file at the first and closing it at the end; sequence(...) a
stretch's frames; keyframe_times() the file's own keyframe index; streams() the file's own subtitle streams. Everything
decoded runs inside the guard. The decoder (ffmpeg.Decoder) is the reader's own seam: the tests and the real-film corpus
put theirs there. ffmpeg.py is imported only when a reader makes its first decoder.

Plumbing only, outside the detector's modules (shapes.DETECTOR_MODULES): how a keyframe is analysed and judged is
keyframes.py's, how it is decoded ffmpeg.py's, so a change here measures no cached shape again.
"""
from . import libav

READ_WAIT = 0.1          # seconds between looks while another reader of the playback reads


class FilmReader:

    def __init__(self, target, memory_path, current, guard, background=True, full=False, decoder=None, lock=None,
                 wait=None, check=None):
        """guard(): a context for every decode (guard.DecodeGuard.decoding for the file); background: decoding lowers
        the thread's priority for good; full: whole frames for the diagnostic pictures; decoder: the decoder class
        (ffmpeg.Decoder). lock: the playback's one reader at a time (Service.reads), held from open to close; wait
        (seconds) -> True when Kodi is closing: how a reader waits for another to finish (Kodi's monitor, so a test's
        scheduler sees the wait). check(size): asked with each keyframe that came out, before it is analysed, raises
        libav.Unavailable when the decoder is not to be trusted (the box's self-check, checks.Checks.decoder_check)."""
        self._target, self._memory_path, self._current, self._guard = target, memory_path, current, guard
        self._background, self._full = background, full
        self._make = decoder
        self._check = check
        self._decoder = None
        self._lock, self._wait, self._locked = lock, wait, False
        self.opened = False          # the file was opened (streams: told apart from a file that could not be)

    def _new(self):
        make = self._make
        if make is None:
            from . import ffmpeg
            make = ffmpeg.Decoder
        self._decoder = make(self._target, self._memory_path, full=self._full, background=self._background,
                             current=self._current)

    def _take(self):
        """The playback's one reader at a time: waits while another reads the film (the measurement, a scene check, the
        search, the Level 5 check, the streams), so a slow source never gets two readers at once. Raises
        libav.Unavailable when the work ended or Kodi closes meanwhile."""
        if self._lock is None:
            return
        while not self._lock.acquire(blocking=False):
            if (self._current is not None and not self._current()) or self._wait(READ_WAIT):
                raise libav.Unavailable('the playback moved on while another read ran')
        self._locked = True

    def _give(self):
        if self._locked:
            self._locked = False
            self._lock.release()

    def open(self):
        """The decoder made and the file opened, inside the guard, once no other reader of the playback reads.
        Raises libav.Unavailable."""
        self._take()
        try:
            self._new()
            with self._guard():
                self._decoder.__enter__()
        except BaseException:
            self._give()
            raise
        self.opened = True

    def close(self):
        try:
            if self._decoder is not None:
                self._decoder.close()
        finally:
            self._give()

    @property
    def size(self):
        """(width, height) of the analysed frames."""
        return self._decoder.out_w, self._decoder.out_h

    @property
    def description(self):
        """The decoder's own description (which FFmpeg), for the log."""
        return self._decoder.description

    @property
    def where(self):
        """The file's description for the log (locate.Target.description), '' without a target."""
        return self._target.description if self._target is not None else ''

    def playable(self, length):
        """The part of Kodi's length (seconds) the film plays in, once open (ffmpeg.Decoder.playable); the length as it
        is where the decoder can not say (the real-film corpus's stored frames)."""
        playable = getattr(self._decoder, 'playable', None)
        return playable(length) if playable is not None else length

    @property
    def dovi(self):
        """The decoder can read Dolby Vision metadata at all."""
        return getattr(self._decoder, 'dovi', None)

    def keyframe(self, seconds, uneven=False, faint=True):
        """The Keyframe at or before seconds, analysed (Keyframe.analyse with uneven and faint) and, when clear, with its
        exact edge. Its frame is None when no keyframe came out there. Raises libav.Unavailable."""
        decoder = self._decoder
        with self._guard():
            keyframe = decoder.sample(seconds)
        if keyframe.frame is None:
            return keyframe
        if self._check is not None:
            self._check(keyframe.size)
        if keyframe.analyse(decoder.out_w, decoder.out_h, uneven, faint):
            with self._guard():
                keyframe.exact = decoder.exact(keyframe.sample)
        return keyframe

    def sequence(self, seconds, until, faint=True, go=None):
        """Every frame from the keyframe at or before seconds to the first past until (ffmpeg.Decoder.sequence),
        analysed (no exact edge: the shape is what tells a cut), decoded inside the guard; fewer once go() says no.
        Raises libav.Unavailable."""
        decoder = self._decoder
        with self._guard():
            frames = list(decoder.sequence(seconds, until, go=go))
        for frame in frames:
            if frame.frame is not None:
                frame.analyse(decoder.out_w, decoder.out_h, uneven=True, faint=faint)
        return frames

    def keyframe_times(self):
        """The film times of the file's keyframes from its own index, once open (ffmpeg.Decoder.keyframe_times), read
        inside the guard (FFmpeg's index is read through ctypes); None where it has none, or the decoder can not say (the
        real-film corpus's stored frames)."""
        read = getattr(self._decoder, 'keyframe_times', None)
        if read is None:
            return None
        with self._guard():
            return read()

    def keyframes(self, positions, uneven=False, faint=True):
        """The keyframe at or before each of positions (seconds), or None where none came out; nothing is opened or
        decoded until the first, and a caller that stops early closes the generator, which closes the file."""
        self.open()
        try:
            for seconds in positions:
                keyframe = self.keyframe(seconds, uneven, faint)
                yield keyframe if keyframe.frame is not None else None
        finally:
            self.close()

    def streams(self):
        """The file's own subtitle streams in file order (ffmpeg.Decoder.subtitle_streams), read inside the guard: the
        stream structures are read through ctypes as well. Raises libav.Unavailable."""
        self._take()
        try:
            self._new()
            with self._guard():
                try:
                    self._decoder.__enter__()
                    self.opened = True
                    return self._decoder.subtitle_streams()
                finally:
                    self._decoder.close()
        finally:
            self._give()
