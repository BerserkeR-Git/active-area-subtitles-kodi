import sys

from resources.lib.activearea import actions

actions.main(sys.argv)
