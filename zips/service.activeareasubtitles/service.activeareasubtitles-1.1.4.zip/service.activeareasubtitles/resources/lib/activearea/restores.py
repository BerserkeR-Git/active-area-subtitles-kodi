"""Every setting the add-on changes in Kodi and CoreELEC, each kept with a record so it goes back: what
goes back, in which order, and when (a stop, a crash, the add-on switched off, the next video).

Two kinds of method. Those that take the lock themselves are right whether or not a playback is running
(putting things back). Those marked "with the lock held" belong to a playback: the caller holds the lock
and has checked that its playback is still the current one, so nothing is written for a playback that
ended in between. This module knows nothing about playbacks.
"""
import threading

from . import coreelec, geometry, kodi, override
from .keeper import Keeper, Switch

MARGIN_SETTING = 'subtitles.marginvertical'


class Restores:

    def __init__(self):
        self.lock = threading.Lock()
        # Each change keeps a record until Kodi's memory and its settings file are free of it.
        self.override = override.Override(lambda: kodi.get_setting(override.SETTING),
                                           lambda value: kodi.set_setting(override.SETTING, value),
                                           kodi.data_path('level5.json'),
                                           lambda: kodi.saved_setting(override.SETTING))
        self.keeper = Keeper(lambda: number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'),
                             lambda: number(kodi.saved_setting(MARGIN_SETTING)))
        # CoreELEC's "Apply configured subtitle margin": never switched on since 1.1.3; one an older version left on
        # (it handed CoreELEC a distance) is switched off at the next video, at stop and at start.
        self.margin_switch = Switch(lambda: kodi.get_setting(coreelec.MARGIN_SETTING),
                                    lambda value: kodi.set_setting(coreelec.MARGIN_SETTING, value),
                                    kodi.data_path('margin_switch.json'),
                                    lambda: switch_value(kodi.saved_setting(coreelec.MARGIN_SETTING)),
                                    kodi.saved_settings_stamp)
        # P3i's own scan for SDR and HDR, held off by 0.3.31 to 1.0.6 while P3i placed text subtitles too:
        # only put back now (P3i needs it to keep image subtitles out of the bars in SDR and HDR).
        self.scan_switch = Switch(lambda: kodi.get_setting(coreelec.SDR_SCAN_SETTING, quiet=True),
                                  lambda value: kodi.set_setting(coreelec.SDR_SCAN_SETTING, value),
                                  kodi.data_path('scan_switch.json'),
                                  lambda: switch_value(kodi.saved_setting(coreelec.SDR_SCAN_SETTING)),
                                  kodi.saved_settings_stamp, value=False)
        # P3i's "Restrict subtitles to active picture", held off while the add-on is enabled, so the add-on
        # places every text subtitle itself; the person's own value while an image subtitle is shown.
        self.restrict_switch = Switch(lambda: kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True),
                                      lambda value: kodi.set_setting(coreelec.RESTRICT_SETTING, value),
                                      kodi.data_path('restrict_switch.json'),
                                      lambda: switch_value(kodi.saved_setting(coreelec.RESTRICT_SETTING)),
                                      kodi.saved_settings_stamp, value=False)
        # Image subtitles on P3i builds (1.1.4): P3i's "Bitmap subtitle margin" for the distance chosen, and its
        # restriction switched on while one shows when the person keeps it off (the person's own "on" is simply
        # no longer held off then). Both go back when a text subtitle shows, when playback ends, and after a crash.
        self.bitmap = Keeper(lambda: number(kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True)),
                             lambda value: kodi.set_setting(coreelec.BITMAP_MARGIN_SETTING, value),
                             kodi.data_path('bitmap_margin.json'),
                             lambda: number(kodi.saved_setting(coreelec.BITMAP_MARGIN_SETTING)))
        self.restrict_on = Switch(lambda: kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True),
                                  lambda value: kodi.set_setting(coreelec.RESTRICT_SETTING, value),
                                  kodi.data_path('restrict_on.json'),
                                  lambda: switch_value(kodi.saved_setting(coreelec.RESTRICT_SETTING)),
                                  kodi.saved_settings_stamp)

    # Taking the lock: right whether or not a playback runs.

    def repair(self):
        """What an unfinished playback left (Kodi crashed or was cut off) is put back."""
        with self.lock:
            if self.margin_switch.restore():
                kodi.log('CoreELEC\'s subtitle margin option switched off after an unfinished playback', always=True)
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
            if self.override.restore():
                kodi.log('Level 5 correction cleared after an unfinished playback', always=True)
            if self.bitmap.restore():
                kodi.log('CoreELEC\'s bitmap subtitle margin put back after an unfinished playback', always=True)
            if self.restrict_on.restore():
                kodi.log('CoreELEC\'s subtitle restriction switched off again after an unfinished playback', always=True)

    def finish(self, why, ended, always=False):
        """A playback's changes back, at its end. ended(): run first under the same lock (the playback marked
        as ended, so nothing of it is written after these)."""
        with self.lock:
            ended()
            if self.margin_switch.restore():      # before the margin, so nothing moves in between
                kodi.log('%s: CoreELEC\'s subtitle margin option switched off' % why, always)
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why, always)
            if self.override.restore():
                kodi.log('%s: Level 5 correction cleared' % why, always)
            if self.bitmap.restore():
                kodi.log('%s: CoreELEC\'s bitmap subtitle margin put back' % why, always)
            # The restriction switched on for an image subtitle goes off with the hold that follows a stop
            # (hold), or with the release when the add-on is switched off.

    def hold(self):
        """P3i's restriction held off (see held_off). True when the person's own "on" was switched off just now."""
        with self.lock:
            return self.held_off()

    def release_restriction(self, why, always=False):
        """The person's own value back for good (the add-on switched off or removed)."""
        with self.lock:
            self.restrict_on.restore()
            if self.restrict_switch.restore():
                kodi.log('%s: CoreELEC\'s subtitle restriction back as it was' % why, always)

    def release_bitmap(self, why, always=False):
        with self.lock:
            if self.bitmap.restore():
                kodi.log('%s: CoreELEC\'s bitmap subtitle margin put back' % why, always)

    def release_scan(self, why, always=False):
        with self.lock:
            if self.scan_switch.restore():
                kodi.log('%s: CoreELEC\'s own picture detection for SDR and HDR switched on again' % why, always)

    def distances_none(self):
        """Both distances set to none: CoreELEC goes back to the picture's edge at once."""
        with self.lock:
            if self.margin_switch.restore():
                kodi.log('distances set to none: CoreELEC\'s subtitle margin option switched off')

    def fix_off(self):
        """Level 5 correction turned off: does nothing unless a correction is in place."""
        with self.lock:
            if self.override.restore():
                kodi.log('Level 5 correction turned off: cleared')

    # With the lock held, by a playback that is still the current one.

    def next_video(self):
        """A playlist's next video: the previous one's Level 5 correction goes. CoreELEC's margin option is never
        switched on since 1.1.3; one an older version left on (it handed CoreELEC a distance) goes off here, at
        every new video, and at stop and start."""
        if self.override.restore():
            kodi.log('next video: Level 5 correction cleared')
        if self.margin_switch.restore():
            kodi.log('next video: CoreELEC\'s subtitle margin option switched off')

    def held_off(self):
        """The restriction off. Ours (switched on for an image subtitle) goes off again, the person's own "on"
        is held off. True when the person's own was switched off just now. Switched off in its settings: nothing
        (the release gives the person's value back)."""
        if not kodi.setting_bool('enabled'):
            return False
        self.restrict_on.restore()
        return kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is True and self.restrict_switch.on()

    def image_restriction(self):
        """The restriction on for an image subtitle: the person's own "on" back, or ours when they keep it off.
        Not offered (an older build, or hidden): nothing to switch. Switched off: nothing."""
        if not kodi.setting_bool('enabled'):
            return
        self.restrict_switch.restore()
        if kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is False and self.restrict_on.on():
            kodi.log('CoreELEC\'s subtitle restriction switched on for an image subtitle')

    def text_bitmap_back(self):
        """A text subtitle: CoreELEC's bitmap margin is the person's again."""
        if self.bitmap.restore():
            kodi.log('text subtitle: CoreELEC\'s bitmap subtitle margin put back')

    def disc(self):
        """An image subtitle left as on the disc: the restriction off and the bitmap margin the person's."""
        self.held_off()
        self.bitmap.restore()

    def image(self, distance):
        """An image subtitle at distance from the picture's edge: the restriction on and P3i's bitmap margin for
        it. The bitmap margin set, or None on a CoreELEC without one (kept inside the picture all the same)."""
        self.image_restriction()
        if kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True) is None:
            return None
        margin = geometry.bitmap_margin(distance)
        self.bitmap.apply(margin)
        return margin

    def own_margin(self):
        """The person's own subtitle margin, None when Kodi does not say."""
        return self.keeper.own()

    def apply_margin(self, value):
        """The add-on's subtitle margin; True when it changed."""
        return self.keeper.apply(value)

    def margin_back(self):
        """The person's own subtitle margin back; True when it moved."""
        return self.keeper.restore()


def number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def switch_value(text):
    """A switch setting's value as Kodi's settings file writes it: True, False or None."""
    return {'true': True, 'false': False}.get(text)
