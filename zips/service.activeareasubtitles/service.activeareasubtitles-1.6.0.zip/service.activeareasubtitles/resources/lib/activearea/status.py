"""The settings' status section: which system was detected and how the picture is measured."""
SCREEN, SCREEN_AND_FILE = 32097, 32099   # without the file fallback while it is paused
SYSTEMS = (('System.Platform.Windows', 32090, SCREEN), ('System.Platform.OSX', 32091, SCREEN),
           ('System.Platform.Android', 32093, SCREEN), ('System.Platform.Linux', 32092, SCREEN_AND_FILE))
GENERIC = (32096, SCREEN)
COREELEC = 32094   # one name for every CoreELEC: the measurement row says who places image subtitles
FILE_ANALYSIS, FILE_ANALYSIS_P3I, PAUSED = 32098, 32101, 32100
FILE_AND_SCREEN = 32165                  # a PC with the decoder shipped in the add-on


def describe(on_coreelec, p3i, decoding_allowed, condition, file_first=False):
    """(system string id, measurement string id). file_first: a PC whose shipped decoder loaded at start."""
    if on_coreelec:
        system = COREELEC
        if not decoding_allowed:
            return system, PAUSED
        return system, FILE_ANALYSIS_P3I if p3i else FILE_ANALYSIS
    for name, system, method in SYSTEMS:
        if condition(name):
            if not decoding_allowed:
                return system, SCREEN
            return system, FILE_AND_SCREEN if file_first else method
    return GENERIC
