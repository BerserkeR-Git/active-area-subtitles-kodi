from resources.lib.activearea import service

service.run()
