"""Small helpers around Kodi's Python and JSON-RPC interfaces."""
import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

from . import coreelec

ADDON_ID = 'service.activeareasubtitles'
PREFIX = '[Active Area Subtitles] '


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def setting_bool(name, default=True):
    try:
        return addon().getSettingBool(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    return folder + name


def picture_folder():
    """Where diagnostic pictures go: somewhere easy to reach from another computer.

    CoreELEC's Screenshots share (/storage/screenshots), else Kodi's own screenshot
    folder when one is set, else the add-on's data folder.
    """
    if coreelec.is_coreelec() and os.path.isdir('/storage/screenshots'):
        return '/storage/screenshots/'
    chosen = get_setting('debug.screenshotpath')
    if chosen:
        folder = xbmcvfs.translatePath(chosen)
        if os.path.isdir(folder):
            return os.path.join(folder, '')
    return data_path('')


def log(message, always=False):
    if always or setting_bool('diagnostics'):
        xbmc.log(PREFIX + message, xbmc.LOGINFO)


def rpc(method, params=None):
    """Call Kodi's JSON-RPC. Returns the result, or None on an error."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as error:  # a malformed answer, or Kodi raising (closing, say): as refused
        log('%s failed: %r' % (method, error))
        return None
    if not isinstance(reply, dict):
        return None
    if 'error' in reply:
        log('%s refused: %s' % (method, reply['error'].get('message')))
        return None
    return reply.get('result')


def get_setting(setting_id):
    result = rpc('Settings.GetSettingValue', {'setting': setting_id})
    return result.get('value') if isinstance(result, dict) else None


def set_setting(setting_id, value):
    return rpc('Settings.SetSettingValue', {'setting': setting_id, 'value': value}) is True
