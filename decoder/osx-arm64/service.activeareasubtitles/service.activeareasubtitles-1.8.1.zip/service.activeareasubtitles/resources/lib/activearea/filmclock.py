"""The film's time for a PC follower's looks (_FilmClock), counted on the service's clock between Kodi's answers, at
Kodi's tempo. The scene follower's reader on a PC (screenreader.ScreenReader) places its map's moves by it. Kept outside
the detector's modules (shapes.DETECTOR_MODULES). Loads without Kodi: Kodi's answer and tempo are handed in.
"""

ANCHOR_EVERY = 2.0            # seconds between two questions for the film's time while a PC follows (counted between
                              # them; at 30 s fast forward, a seek no look saw would leave every planned move off that
                              # long); at every look for FRESH seconds after a start, a hold or another tempo
FRESH = 1.5                   # seconds of a question at every look after a start, a hold or another tempo. Reason not
                              # recorded
FRESH_STEP = 0.0              # meanwhile at every look
FRESHEST = 20.0               # seconds of answers the count is taken from: the freshest of them (Kodi's answer is the
                              # time at its last update, every 0.2 s: 0 to 0.2 s old, more under load; re-taken at
                              # random ones, the count would hop 0.2 s and planned moves with it)
ANSWER_JUMP = 0.5             # seconds an answer can be off the count before it says the film jumped, went slower or
                              # back
LAG_MOST = 0.25               # seconds an answer lags the count at most while the film plays on (Kodi's update step, 0.2
                              # s, and a little; that many of the service's clock, more film at a faster tempo): two in
                              # a row further behind and the film stood still a moment
TEMPO_LEAST = 0.75            # Kodi's tempos (Player.PlaySpeed while the speed is 1; ProcessInfo.cpp): the film's time
TEMPO_MOST = 1.55             # counts at the one Kodi says. Outside them it says a speed (0 paused, 2 and up fast
                              # forward), where the follower holds: the count keeps its tempo
STALL_BACK = 3 * ANCHOR_EVERY + ANSWER_JUMP   # seconds before the count starts over behind itself within which the
                              # screen's lead may have been measured against a count running on through a stall: the
                              # second answer behind comes at most three questions after the stall began, and the
                              # stall lasted ANSWER_JUMP at most (a longer one starts the count over at one answer)


class _FilmClock:
    """The film's time for the scene map without asking Kodi at every look: Kodi logs an error for a position asked
    as playback ends (between "is it playing" and the question, seen in the test rig).
    Counted on the service's clock from the freshest answer of the last FRESHEST seconds: Kodi's answer is never ahead
    of the film, only late by up to its update step, so the answer that puts the film furthest on is the nearest.
    Asked at every look for FRESH seconds after a start or a hold (answers at many phases of Kodi's step), then every
    ANCHOR_EVERY; an answer more than ANSWER_JUMP behind the count, or a jump ahead, starts over (a seek no look saw, a
    slower film), as do two answers in a row more than LAG_MOST behind it (a stall Kodi does not report as holding:
    the answers before it would put the film on by the stall for FRESHEST seconds, every planned move that much
    early). answer(): Kodi's own answer, asked now (a move into a narrower picture waits for it,
    ScreenReader._confirmed: the count runs on through a stall's first answers). hop(): how far the count moved since
    the last call (the screen's lead was measured against it).
    Counted at Kodi's tempo (tempo(): Player.PlaySpeed as a number, or None where Kodi can not say), read whenever the
    count is asked for or Kodi is asked. Another tempo goes on from the count as far as the film can have gone since
    the tempo was last read (at the faster of the two: Kodi says a tempo as it asks its player for it), until FRESH
    answers at the new tempo took over: meanwhile a move into a wider picture comes early rather than late, and one
    into a narrower picture waits for Kodi's answer as always (ScreenReader._confirmed)."""

    def __init__(self, ask, clock, tempo=None):
        self._ask, self._clock = ask, clock
        self._tempo = tempo or (lambda: 1.0)
        self.rate = 1.0                 # film seconds a second of the service's clock: Kodi's tempo
        self._rated = None              # the service's clock when the tempo was last read
        self._answers = []              # (the service's clock, the answer less rate times it), the latest FRESHEST
                                        # seconds
        self._asked = self._fresh_until = None
        self._answer = None             # Kodi's latest answer
        self._known = None              # the freshest of the answers kept (as _answers has them), or None
        self._gone_on = None            # the count gone on at another tempo (the same way), until FRESH after it
        self._best = None               # what the count runs from: the freshest answer, or where it went on to
        self._hop = 0.0
        self._behind = False            # the last answer lagged the count by more than LAG_MOST
        self._went_back = None          # the service's clock when the count last started over behind itself
        self.changed = None             # the service's clock when the count last went on at another tempo

    def hold(self):
        self._answers, self._best, self._known, self._gone_on = [], None, None, None

    def now(self):
        counted = self._clock()
        self._follow_tempo(counted)
        every = FRESH_STEP if self._fresh_until is not None and counted < self._fresh_until - 1e-6 else ANCHOR_EVERY
        if self._best is None or self._asked is None or counted - self._asked >= every - 1e-6:
            if self._take(counted) is None:
                return None
        return self.rate * counted + self._settled(counted)

    def answer(self):
        """Kodi's own answer asked now (or None where it can not say), taken into the count as now() takes one; one
        question at a moment of the service's clock."""
        counted = self._clock()
        self._follow_tempo(counted)
        if self._asked is None or counted > self._asked:
            self._take(counted)
        return self._answer

    def _follow_tempo(self, counted):
        """Kodi's tempo read at clock time counted (once a moment); another one goes on from the count as far as the
        film can have gone, and asks Kodi at every look again."""
        if counted == self._rated:
            return
        told = self._tempo()
        rate = told if told is not None and TEMPO_LEAST <= told <= TEMPO_MOST else self.rate
        if abs(rate - self.rate) > 0.005:
            if self._best is not None:
                since = counted if self._rated is None else self._rated
                at = self.rate * since + self._best + max(self.rate, rate) * (counted - since)
                self._best = self._gone_on = at - rate * counted
                self._answers, self._known = [], None
                self._fresh_until, self._behind, self._asked, self.changed = counted + FRESH, False, None, counted
            self.rate = rate
        self._rated = counted

    def _settled(self, counted):
        """The count's offset at clock time counted: where it went on to at another tempo only for FRESH after it."""
        if self._gone_on is not None and counted >= self._fresh_until - 1e-6 and self._known is not None:
            self._gone_on, self._best = None, self._known
        return self._best

    def _take(self, counted):
        """Kodi asked at clock time counted; its answer, or None (the count gone: hold)."""
        at = self._answer = self._ask()
        self._asked = counted
        if at is None:
            self.hold()
            return None
        offset, known = at - self.rate * counted, self._known
        behind = known is not None and offset < known - LAG_MOST * self.rate
        stalled, self._behind = behind and self._behind, behind
        if known is None or offset < known - ANSWER_JUMP or offset > known + ANSWER_JUMP or stalled:
            # The start, a hold, another tempo, a jump, another speed, a stall.
            if known is not None:
                self._gone_on = None
                if stalled or offset < known - ANSWER_JUMP:
                    self._went_back = counted
            self._answers, self._fresh_until, self._behind = [], counted + FRESH, False
        self._answers = [answer for answer in self._answers if counted - answer[0] <= FRESHEST]
        self._answers.append((counted, offset))
        self._known = max(answer[1] for answer in self._answers)
        # A hop only once settled: while FRESH answers bring a count begun stale up to the freshest, what was
        # measured against the freshest count before the hold holds for it again.
        if known is not None and abs(self._known - known) < ANSWER_JUMP and counted >= self._fresh_until:
            self._hop += self._known - known
        self._best = self._known if self._gone_on is None else max(self._known, self._gone_on)
        self._settled(counted)
        return at

    def hop(self):
        hop, self._hop = self._hop, 0.0
        return hop

    def ask(self):
        """Kodi's own answer asked now, not taken into the count (one at a seek's target while the landing does not
        show yet is ahead of the film), or None where it can not say."""
        return self._ask()

    def went_back(self):
        """The service's clock when the count last started over behind itself (Kodi's time stood still a moment while
        it ran on: a stall it does not report, or the film went slower or back unseen), once; else None."""
        went, self._went_back = self._went_back, None
        return went

    def peek(self):
        """The counted film time without asking Kodi (for the log, also while it holds), or None."""
        if self._best is None:
            return None
        counted = self._clock()
        return self.rate * counted + self._settled(counted)
