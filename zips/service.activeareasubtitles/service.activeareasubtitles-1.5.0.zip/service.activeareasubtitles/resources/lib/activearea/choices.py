"""The four distance rows of the menu: which add-on setting holds each row's choice and its Custom number, their
defaults (as in settings.xml), and the distance a choice gives. The menu shows these distances and the placement
uses them, so both read them here."""
from . import geometry, kodi


class Row:

    def __init__(self, key, distance, default, custom_default, custom_max):
        self.key = key
        self.custom_key = key + '_custom'
        self.distance = distance              # (choice, typed Custom number) -> distance, or geometry.DISC
        self.default = default                # the choice before anything was chosen
        self.custom_default = custom_default  # the Custom number before anything was typed
        self.custom_max = custom_max


ROWS = {row.key: row for row in (
    Row('gap_bars', geometry.bar_distance, 0, geometry.EDGE_GAP, geometry.CUSTOM_RANGE[1]),
    Row('gap_full', geometry.full_distance, geometry.FULL_DEFAULT, geometry.FULL_DISTANCES[geometry.FULL_DEFAULT],
        geometry.CUSTOM_RANGE[1]),
    Row('image_bars', lambda choice, custom: geometry.image_distance(choice, geometry.IMAGE_BAR_DISTANCES, custom),
        geometry.IMAGE_DEFAULT, geometry.EDGE_GAP, geometry.IMAGE_CUSTOM_MAX),
    Row('image_full', lambda choice, custom: geometry.image_distance(choice, geometry.IMAGE_FULL_DISTANCES, custom),
        geometry.IMAGE_DEFAULT, geometry.EDGE_GAP, geometry.IMAGE_CUSTOM_MAX))}


def chosen(key):
    """The distance chosen on a row, from the add-on's settings."""
    row = ROWS[key]
    return row.distance(kodi.setting_int(key, row.default), kodi.setting_number(row.custom_key, row.custom_default))


def distances():
    """(content with black bars, full-screen content) for text subtitles."""
    return chosen('gap_bars'), chosen('gap_full')


def image_distances():
    """(content with black bars, full-screen content) for image subtitles on P3i builds: a distance, or
    geometry.DISC for "As on the disc"."""
    return chosen('image_bars'), chosen('image_full')
