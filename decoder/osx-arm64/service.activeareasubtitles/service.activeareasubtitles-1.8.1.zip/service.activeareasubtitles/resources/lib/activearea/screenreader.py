"""The scene follower's readings on a PC (ScreenReader): the grab reader's picture (grabreader.GrabReader) placed on
time by the film's scene map (scenemap.py), the film's time counted between Kodi's answers (filmclock._FilmClock) and
the screen's lead measured at the map's cuts (screenlead.ScreenLead). Read by the follow loop as it reads the live
labels reader (labels.Reader), and told the rest by screenfollow.ScreenFollowing. Kept outside the detector's modules
(shapes.DETECTOR_MODULES). Loads without Kodi: the grab, the film's time, the tempo and the log are handed in.
"""
import time

from . import pictures, scenemap
from .filmclock import FRESH, LAG_MOST, STALL_BACK, _FilmClock
from .grabreader import DIM_NARROWER_GRABS, GrabReader
from .screenlead import ScreenLead

FAST_STEP = 0.1               # seconds between a look and the next on a PC (with the grab, a look about every 0.15 s)
SLOW_STEP = 0.85              # the same where no cut is to be expected (a look about every second): until a film shows a
                              # second shape where a move waits for the next line anyway, and with a scene map away from
                              # its cuts (ScreenReader.pace)
EMPTY_FOR = 10.0              # seconds of grabs with no image, none with one before in the playback, after which Kodi's
                              # grab gives nothing here (a renderer without a capture: DRM PRIME, Android's MediaCodec
                              # surface); a seek empties them for a moment only
EMPTY_STEP = 10.0             # seconds between looks then (each costs Kodi an error line in its log): the first grab with
                              # an image brings the pace back
PROBE_LATE = 0.03             # seconds a probe's grab may hold a move into a narrower picture up, at most (about a frame)
SLOW_GRAB_KEPT = 3.0          # seconds a slow grab keeps the probes off (about 20 looks): a probe's grab as slow would hold
                              # the move into a narrower picture up by as much
DUE_SLACK = 0.02              # seconds a wake for a planned move may come before it and still count as at it
HOLD_JUMP = 2.0               # seconds the film's time moved across a hold beyond which it was a seek: what the grabs
                              # showed before it says nothing of where playback went
SEEK_ANSWER_WAIT = 3.0        # seconds after a seek reaches the follower (ScreenReader.landing) within which a move into a
                              # narrower picture waits for Kodi's time to leave the place before the seek: until then the
                              # screen still shows the frame from before it (in the test rig under load the time moved
                              # 1.1 to 1.4 s after the seek began, the new picture 0 to 0.25 s after it). A time that
                              # never moves holds nothing down for longer
PLANNED_NEAR = 1.0            # seconds before a planned move into a narrower picture from which the follower waits for
                              # it, grabbing nothing but its probe (ScreenReader._next_look): a look with its grab takes
                              # 0.3 to 0.4 s in the test rig, and one ending past the cut sees it first, the move then
                              # late by the rest of that look


class ScreenReader:
    """The scene follower's readings on a PC. The follow loop reads it as it reads the live labels reader (labels.Reader):
    read(), note(shown), pace(), film_time(), verifiable, and landing(target) at a seek; the PC's following
    (screenfollow.ScreenFollowing) tells it the rest: settled(picture), only_wider, hold(), placed(picture),
    widened(picture), resume(moves_shown), on_screen(moves_shown), shapes(), keep(memory, stopping). Behind it the grab
    reader (GrabReader) and the film's scene map (scenemap.py): the one a playback before recorded, which places the
    text on time, and the one this playback records from the screen, kept with the file when following ends. Built on
    the follower's own thread: the CPU its looks cost, for the log, is this thread's."""

    verifiable = False               # a reading is no Level 5: nothing a keyframe could be held against

    def __init__(self, screen, video_ratio, placed, film_time, clock, log, known=None, decoded=(),
                 moves_shown=False, seen=(), live=None, tempo=None):
        """screen: the grab (KodiScreen); placed: the picture placed now (the measured shape, with its bars);
        film_time() -> the playing position in seconds or None (asked through _FilmClock on clock()); tempo() -> Kodi's
        Player.PlaySpeed as a number or None (kodi.tempo), the rate the film's time counts at (1 without it); log(line,
        always): the add-on's log; known: the scene map from the cache, or None; decoded: the pictures the file
        analysis read with an exact edge (the grabs tell which shows, the decoder gave its edges), or a function giving
        them as they are read (a follower started before the measurement settled); moves_shown: a new margin moves the
        line on screen (Kodi's Manual position), so the map moves the text just before a cut; seen: the shapes a
        follower of this film saw before (an earlier epoch's: a window changed, another track); live(): the scene map
        read from the file ahead of playback (lookahead.Lookahead.map), or None: before the cache's map where it says
        anything, and its cuts at their frames."""
        self._grabs = GrabReader(screen, video_ratio, placed)
        self._decoded = decoded if callable(decoded) else (lambda: decoded)
        self._grabs.from_file(self._decoded())
        self.known = known
        self._live = live or (lambda: None)
        self._due_at = None                      # the film time of the planned move woken for: placed before any grab
        self._returned = None                    # the picture read() gave last
        self._placed = None                      # the picture the follower placed last (placed)
        self._lead = ScreenLead()                # the picture on screen ahead of Kodi's film time (measured, _measure)
        self._probing = False                    # the next look is a probe's (pace): its sighting bounds the lead
                                                 # either way
        self._slowest_grab = 0.0                 # seconds the slowest grab of this playback took: how long a look may
                                                 # take before a move into a wider picture (a rare slow grab comes back)
        self._slow_grab = (0.0, None)            # (seconds, the service's clock): the slowest grab of the last
                                                 # SLOW_GRAB_KEPT, how long a probe's may take (judged by the slowest of
                                                 # the playback, one slow grab would end the probes for good)
        self._shown = ('picture', round(float(self._grabs.picture), 2))
        self._moves_shown = moves_shown
        self.recording = scenemap.SceneMap()
        # The latest picture a strongly lit grab showed, its film time, and the grab reader's count of such grabs then:
        # the evidence against the maps (a dim grab can read a dark IMAX scene as wide as scope). The picture placed
        # when the reader was built is no sighting (the measured shape written again after Kodi's window changed, or a
        # cached one at a resume, counted as a lit grab at the first look's film time, would keep a dark IMAX scene at
        # the scope height).
        self._lit, self._lit_at, self._lit_sightings = None, None, self._grabs.lit_sightings
        self._at = None                          # the film's time at the last look
        self._held_at = None                     # the film's time when Kodi last held, until the next look
        self._grab_change_at = None              # the film's time the grab reader's picture last changed
        self._since = None                       # the film's time playback has run on from (this reader's first look, a
                                                 # seek's landing): what a map read before it ended on says nothing now
        self._clock = _FilmClock(film_time, clock, tempo)
        self._rate_told = 1.0                    # the tempo the log was last told of
        self._now = clock
        self._times = []                         # the service's clock at the latest looks whose grab showed a picture
                                                 # (how long a change took, and the look before it)
        self._change = None                      # (grabs, seconds from the first to now, seconds from the look before)
        self._log = log
        self._widest = placed                    # a wider shape seen while following is the one the cache keeps
        self.source = 'grabs'                    # what placed the latest picture read: grabs, read ahead, cached map
        self.only_wider = False                  # only a picture wider than the measured one moves the text: slow pace
        self.looks = 0
        self._cpu = time.thread_time()
        self._imaged = False                     # a grab of this playback came back with an image
        self._empty_since = None                 # the service's clock at the first of the empty grabs in a row
        self._empty_told = False
        self._seek_from = None                   # (Kodi's answer when a seek reached the follower, the service's clock
                                                 # then) until that answer moves (_seek_stands)
        if known:
            self._grabs.learn(known.shapes)      # one shape, one margin: the map's exact edges for what the grabs see
        self._grabs.learn(seen)

    def read(self):
        """(the picture to place for, ('picture', the grab reader's shape) for the log): the map's plan for the film
        time now (scenemap.SceneMap.plan, with the latest lit grab's picture as evidence; a move into a narrower picture
        once Kodi's own answer reaches it, _confirmed), else the grab reader's picture (outside the map, or without a
        film time: Kodi could not say). After a seek nothing narrower than the picture placed while Kodi's time still
        stands at the place before it (_seek_stands): the grab shows the frame from before the seek, the plan that
        place."""
        stands = self._seek_stands()
        picture, shown = self._read()
        placed = self._placed
        if stands and placed is not None and picture is not None and pictures.narrower(picture, placed):
            self._returned = picture = placed
        return picture, shown

    def _seek_stands(self):
        """Whether Kodi's time still stands where it was when the latest seek reached the follower (landing), for
        SEEK_ANSWER_WAIT at most; asked at each look until it moves. The grabs go on meanwhile: one held back until the
        time moves would come just before the new picture, which shows up to a quarter of a second after it in the
        test rig, and the next grab a whole look later."""
        if self._seek_from is None:
            return False
        before, since = self._seek_from
        answer = self._clock.ask()
        if answer is None or abs(answer - before) > 0.001 or self._now() - since >= SEEK_ANSWER_WAIT:
            self._seek_from = None
            return False
        return True

    def _read(self):
        self._grabs.from_file(self._decoded())   # the file analysis may have read more meanwhile
        live = self._live()
        if live:
            self._grabs.from_file(live.shapes)   # the shapes read ahead: known, with the file's edges
        self._change = None
        if self._due_at is not None:
            # Woken for a move a map planned: placed now, the grab at the next look (its wait would make it late). At
            # the planned moment itself at least (the count can land a hair before it).
            due, self._due_at = self._due_at, None
            now = self._clock.now()
            if now is not None:
                # Woken early (Kodi asked again, the count moved), never planned ahead of the time it is.
                planned = self._plan(due if 0 <= due - now <= DUE_SLACK else now, grabbed=False)
                if planned is not self._returned:
                    self._returned = planned
                    return planned, self._shown
        before = self._grabs.picture
        probing, self._probing = self._probing, False
        grabbed_at = self._now()                 # the grab shows the screen as it is when it begins
        # Inside a silent span of a map, the narrower picture it leads into: one dim grab of that picture is enough.
        counted = self._clock.peek()
        _picture, shown = self._grabs.read(None if counted is None else self._plans().silent_into(counted))
        took = self._now() - grabbed_at
        self._slowest_grab = max(self._slowest_grab, took)
        slow, slow_at = self._slow_grab
        if slow_at is None or took >= slow or grabbed_at - slow_at > SLOW_GRAB_KEPT:
            self._slow_grab = (took, grabbed_at)    # a slower one, or the old one aged out: the latest stands
        self._shown = shown
        self.looks += 1
        if not self._grabs.empty:
            self._imaged, self._empty_since = True, None
        elif self._empty_since is None:
            self._empty_since = grabbed_at
        if self._grabs.clear:
            # A black grab is no sighting of the picture before a cut: one just after a cut into a scene that opens on
            # black frames, counted as the look before, bounded the screen's lead too low for the rest of the playback.
            self._times = (self._times + [grabbed_at])[-(DIM_NARROWER_GRABS + 1):]
        at = self._clock.now()
        if abs(self._clock.rate - self._rate_told) > 0.005:
            self._rate_told = self._clock.rate
            self._log('scenes: Kodi plays at a tempo of %.2f' % self._rate_told)
        self._lead.shift(self._clock.hop())
        went_back = self._clock.went_back()
        if went_back is not None and self._lead.undo(went_back - STALL_BACK):
            # The film stood still a moment while the count ran on: a lead measured meanwhile was measured against it.
            self._log('scenes: the picture on screen %.2f s ahead of Kodi\'s time again, after a stall'
                      % self._lead.value)
        if self._grabs.picture is not before:
            self._grab_change_at = at
            grabs = self._grabs.run_back + 1
            first = self._times[-grabs] if grabs <= len(self._times) else None
            gap = self._times[-grabs - 1] if grabs < len(self._times) else None
            self._change = (grabs, None if first is None else self._now() - first,
                            None if first is None or gap is None else first - gap)
            changed = self._clock.changed
            if at is not None and self._change[1] is not None and (
                    changed is None or changed < self._now() - self._change[1] - (self._change[2] or 0.0) - FRESH):
                # The film time of the change's first grab and of the look before it, counted back on the service's
                # clock at Kodi's tempo. Not from looks within FRESH of another tempo: the count, gone on from where
                # it stood, is still behind by the change, and a look before it was at the old tempo.
                rate = self._clock.rate
                first_at = at - self._change[1] * rate
                self._measure(first_at, None if self._change[2] is None else first_at - self._change[2] * rate,
                              probing and grabs == 1)
        self._returned = self._plan(at)
        return self._returned, shown

    @property
    def shown_ahead(self):
        """Seconds the picture on screen is ahead of Kodi's film time (ScreenLead), as believed now."""
        return self._lead.value

    @shown_ahead.setter
    def shown_ahead(self, seconds):
        """A lead given instead of measured: the tests set one to see what the plans and the probes do with it (a
        measured one needs a map known to the frame and grabs around its cut)."""
        self._lead.value = seconds

    def _measure(self, seen_at, before_at, probe=False):
        """The screen's lead measured at a cut a map read from the file knows to the frame (ScreenLead.measure): the
        grab at film time seen_at showed the grab reader's new picture, the look at before_at the old one; the cut is
        the one into that picture nearest the sighting."""
        live = self._live()
        if not live or not live.exact:
            return
        picture = self._grabs.picture
        # Only cuts at their frames: a stretch's first entry is where reading began (in the film simulator a stretch
        # begun after a fall behind measured the lead at 0.23 s, and planned moves came early, one into the bar), and a
        # coarse cut lies up to a keyframe gap before its frame.
        cuts = [when for when, index in live.at_frames() if abs(when - seen_at) < 1.0
                and pictures.same(live.shapes[index], picture)]
        if not cuts:
            return
        cut = min(cuts, key=lambda when: abs(when - seen_at))
        if self._lead.measure(cut, seen_at, before_at, probe, when=self._now()):
            self._log('scenes: the picture on screen %.2f s ahead of Kodi\'s time' % self._lead.value)

    def _plans(self):
        return scenemap.Plans(self._live(), self.known, self._moves_shown, self.shown_ahead)

    def _plan(self, at, grabbed=True):
        grabs = self._grabs
        if at is not None and self._held_at is not None:
            if abs(at - self._held_at) > HOLD_JUMP:
                # A seek: what the grabs showed before it says nothing of where playback went (in the film simulator a
                # lit scope grab from before a rewind held the text at the scope height for 6 s over the map's dark tall
                # scene it landed in).
                self._lit = self._lit_at = None
                self._since = at
            self._held_at = None
        self._at = at
        if at is None:
            self.source = 'grabs'
            return grabs.picture
        if self._since is None:
            self._since = at
        sighted = None                          # the picture a lit grab at this look showed
        if grabbed:
            # A grab that showed it, not a shape's edges replaced (a stale sighting would win).
            if grabs.lit_sightings != self._lit_sightings:
                self._lit_sightings, self._lit, self._lit_at = grabs.lit_sightings, grabs.lit, at
                sighted = grabs.lit
            if grabs.provisional:
                self.recording.hold()           # what dim grabs showed is no shape for the map
            else:
                self.recording.observe(at, grabs.picture, back=grabs.run_back)
        plans = self._plans()
        planned = self._confirmed(plans, plans.picture(at, (self._lit, self._lit_at)), self._returned, sighted)
        if planned is None:
            # A map whose stretch ends within its lead, or behind playback, says nothing, but knows the picture now or
            # where it stopped: never a grab's narrower than it that is older (with the
            # read-ahead behind and grabs empty under load, a stale tall grab would go back over the map's scope, 1.1 s
            # in the bar); a grab that changed since is newer (a dark opening's dim grabs, the map silent over it).
            known = plans.last_known(at, self._since)
            if (known is not None and pictures.wider(known[0], grabs.picture)
                    and (self._grab_change_at is None or self._grab_change_at <= known[1])):
                planned = known[0]
        self.source = 'grabs' if planned is None else 'read ahead' if plans.read_ahead() else 'cached map'
        return grabs.picture if planned is None else grabs.version(planned)

    def _confirmed(self, plans, planned, placed, sighted=None):
        """planned, the maps' plan at the counted film time; a move into a narrower picture than placed only once
        Kodi's own answer, asked now, is not behind the count, or a lit grab at this look showed that picture
        (sighted) while the answer lags the count by Kodi's step at most (LAG_MOST), else the plan at that answer. The
        count runs on through a stall Kodi does not report: the text would go down into the frozen wider picture's
        bar, the next lit grab take it back up, the plan down again; and a frozen frame of the narrower picture
        before a short wider shot is no sighting of the one after it. Never urgent: late by Kodi's answer step at
        most (0.2 s)."""
        if planned is None or placed is None or not pictures.narrower(planned, placed):
            return planned
        counted = self._clock.peek()
        answer = self._clock.answer()           # asked whatever the grab showed: the count stays fresh
        if answer is None:
            return None                         # Kodi can not say (the playback ending): the grabs decide
        if answer >= counted - scenemap.EPS:
            return planned
        if sighted is not None and pictures.same(sighted, planned) and counted - answer <= LAG_MOST * self._clock.rate:
            return planned                      # the film is there: on screen
        return plans.picture(answer, (self._lit, self._lit_at))

    def landing(self, target):
        """The picture for a seek to film time target (Kodi's; None: a chapter) before the landing shows: the maps'
        plan there, else the widest picture this film is known to show (the follower only moves up for it: the text
        never in the landing's bar, a moment high at most). What the grabs showed before the seek says nothing there,
        nor do they until Kodi's time leaves the place before it (read)."""
        answer = self._clock.ask()
        self._seek_from = None if answer is None else (answer, self._now())
        if target is not None:
            plans = self._plans()
            planned = plans.picture(target)
            if planned is not None:
                self.source = 'read ahead' if plans.read_ahead() else 'cached map'
                return self._grabs.version(planned)
        self.source = 'widest known picture'
        return self._grabs.known.widest()

    def resume(self, moves_shown):
        """A newer epoch's follower carries on with this reader (Kodi's window, a distance, the position changed): its
        grabs, the shapes seen, the evidence, the screen's lead and the recording go on; the layout may move lines on
        screen or not now; Kodi's time is asked again at the next look (its window switch can hold the picture); the
        looks and the CPU count from here for this thread's log line."""
        self._moves_shown = moves_shown
        self._due_at = None
        self._clock.hold()
        # Another layout (a window): its picture may run ahead by another lead; the one believed is where it starts.
        self._lead.forget()
        self._probing = False
        self.looks, self._cpu = 0, time.thread_time()

    def placed(self, picture):
        """The follower wrote the margin for picture (before the scene rule) and Kodi took it. A bare ratio (its first
        write, where the file's own shape was placed) is kept as the known shape of that picture, else as one without
        rows: a seek hands it back as the reading (read), and the follower reads its rows."""
        if pictures.bare(picture):
            picture = pictures.as_picture(self._grabs.version(picture))
        self._placed = picture

    def on_screen(self, moves_shown):
        """The picture to place now without a grab, for a layout that moves lines on screen or not: the maps' plan at
        the counted film time (a move into a narrower picture once Kodi's own answer reaches it, _confirmed), else the
        picture the follower placed last (placed); None before it placed one."""
        placed = self._placed
        if placed is None:
            return None
        at = self._clock.peek()
        if at is None:
            return placed
        plans = scenemap.Plans(self._live(), self.known, moves_shown, self.shown_ahead)
        planned = self._confirmed(plans, plans.picture(at, (self._lit, self._lit_at)), placed)
        return placed if planned is None else self._grabs.version(planned)

    def note(self, shown):
        """The log's words for a reading; a change of picture says how many grabs it took and how long, and the
        time since the look before them (the cut came in between)."""
        change, self._change = self._change, None
        if change is None or change[1] is None:
            return GrabReader.note(shown) + self._overruled(shown)
        return '%s (%d %s over %.2f s%s%s)%s' % (
            GrabReader.note(shown), change[0], 'grab' if change[0] == 1 else 'grabs', change[1],
            '' if change[2] is None else ', the look before %.2f s earlier' % change[2],
            ', lit at the frame\'s edge only' if self._grabs.at_edge else '', self._overruled(shown))

    def _overruled(self, shown):
        """', the read ahead says 2.20' where a map placed another picture than the grabs show (a shot it missed shows
        in the log as grabs nothing placed), else ''."""
        planned = self._returned
        if (self.source == 'grabs' or planned is None or shown[0] != 'picture'
                or pictures.same(planned, shown[1])):
            return ''
        return ', the %s says %.2f' % (self.source, float(planned))

    def pace(self):
        """Seconds to the next look (_next_look), the wake it plans kept for the next read: a planned move placed at
        once, or a probe's grab."""
        seconds, due, probing = self._next_look()
        if probing:
            self._probing = True
        if due is not None:
            self._due_at = due
        return seconds

    def _next_look(self):
        """(seconds to the next look, the film time of a planned move woken for or None, whether that look is a
        probe's). Seconds to the next look: the fast pace once the film has shown a second shape (grabs, the decoder's
        keyframes, a map), except where a map knows no cut is coming; the slow one otherwise. A steady film, most of
        them, is looked at once a second; an IMAX film about three times a second around its cuts; with no map, every
        EMPTY_STEP where Kodi's grab gives nothing (_grab_gives_nothing). Where a margin moves the line on screen
        (Kodi's Manual position) the fast pace throughout: the first cut is up to a second late at the slow one, and a
        look costs about 1.5 ms. A move a map plans before the next look would end wakes
        the follower for it, to the moment (the film's time counted, not asked again: Kodi's answers come in coarser
        steps than the count); one into a narrower picture from PLANNED_NEAR before it, with one probe's look."""
        plans = self._plans()
        if not plans and self._grab_gives_nothing():
            pace = EMPTY_STEP
        elif self.only_wider and not self._wider_known():
            # Same as black bars with the widest picture measured: nothing to follow but a wider one, once a second
            # (grabbing six times a second for a whole film would move nothing); at the fast pace
            # again once the film is known to show a wider one (the file's keyframes, a map).
            pace = SLOW_STEP
        elif self._moves_shown:
            pace = FAST_STEP                     # a scene the maps miss (shorter than lookahead.SPARSE) moves too
        elif len(self._grabs.known) < 2 and not plans:
            pace = SLOW_STEP
        elif self._at is not None and plans.calm(self._at):
            pace = SLOW_STEP
        else:
            pace = FAST_STEP
        now = self._clock.peek() if self._at is not None else None
        ahead = plans.next_move(now) if now is not None else None
        if ahead is None:
            return pace, None, False
        rate = self._clock.rate
        soon = ahead / rate                     # film seconds to the move at Kodi's tempo: the wait
        # Waited for, grabbing nothing: a move into a narrower picture from PLANNED_NEAR before it (its probe below),
        # any other only where the next look would end past it (a look ending past the cut sees it first, the move then
        # late by the rest of that look; one ending before it sees a short scope shot the map does not know, which
        # PLANNED_NEAR's blind second left in its bar). A look is judged by the slowest grab of the playback: judged by
        # the latest 20, a look taken once a rare slow one had passed out of them was as slow and ran past the move. The
        # blind wait is PLANNED_NEAR at most, however slow the grabs.
        look = min(pace + self._slowest_grab + DUE_SLACK, PLANNED_NEAR)
        narrower = exact = False
        if soon < max(pace, PLANNED_NEAR):                       # near enough for its direction to matter
            narrower, exact = self._planned_move(plans, now, ahead)
        if soon >= max(pace, PLANNED_NEAR if narrower else look):
            return pace, None, False
        # A look before a move into a narrower picture whose grab tests a lead halfway between the least and the most
        # still possible: the cut on screen then or not (_measure), a halving search over the film's cuts (without it
        # nothing near a planned cut is grabbed and the lead stays a guess). A move up is never put off for it: its text
        # would sit in the bar.
        before = (scenemap.EXACT_AFTER - self._lead.value + self._lead.probe_target()) / rate
        # Not where grabs come back so slow that its grab would hold the move up by more than PROBE_LATE (a 0.55 s grab
        # would make the move down 0.5 s late).
        if exact and before > 0.005 and soon > before + 0.005 and self._slow_grab[0] < before + PROBE_LATE:
            return soon - before, None, True
        return max(0.005, soon), now + ahead, False

    def _wider_known(self):
        return pictures.wider_than(self._widest, self._grabs.known)

    def _grab_gives_nothing(self):
        """Whether Kodi's grab gives nothing here: no grab of this playback came back with an image, and they have come
        back empty for EMPTY_FOR (a seek empties them for a moment, and never for good: the first image brings the pace
        back). Told once in the log."""
        if self._imaged or self._empty_since is None or self._now() - self._empty_since < EMPTY_FOR - 1e-6:
            return False
        if not self._empty_told:
            self._empty_told = True
            self._log('scenes: Kodi\'s screen grab gives no image here, looking every %d s' % EMPTY_STEP, always=True)
        return True

    @staticmethod
    def _planned_move(plans, now, soon):
        """(whether the move planned soon seconds from film time now is into a narrower picture, whether that is from
        the map read from the file: the cut at its frame, the screen's lead measured against it)."""
        before = plans.picture(now)
        after = plans.picture(now + soon + 0.002)
        narrower = before is not None and after is not None and pictures.narrower(after, before)
        return narrower, narrower and plans.answered is not None and plans.answered.exact

    def hold(self):
        """Kodi holds the picture still (a pause, a seek): the stretch watched so far ends, the film's time is asked
        again after, and no planned move is waited for meanwhile (it would spin at the wake for the whole pause)."""
        self.recording.hold()
        self._clock.hold()
        if self._at is not None:
            self._held_at = self._at
        self._at = self._due_at = None
        self._probing = False
        # The looks before it are no look before a change after it (in the film simulator a landing just after a cut
        # counted the last grab before the seek back from the landing, the lead measured 0.2 s low).
        self._times = []

    def film_time(self):
        """The film time for the log: counted, never asked of Kodi (asked during a seek, it anchored the count to a
        position mid-seek)."""
        return self._clock.peek()

    def widened(self, picture):
        """True once for a picture wider than any this film was known to show: the cache keeps it."""
        # Another picture, not a version of the same one (a grab's shape without rows, edges a row apart): the cache
        # would keep a row-less 2.40 over the measured 2.39.
        if pictures.wider(picture, self._widest):
            self._widest = picture
            return True
        return False

    def settled(self, picture):
        """The measurement settled on picture after following started (at the first estimate): the file's exact edges
        replace what the grabs read of the same picture, so the next look places them; and the cache keeps a wider scene
        only than that (the estimate may have been an IMAX opening: a 1.90 scene would then replace the settled 2.39 in
        the cache). None: not settled yet."""
        if picture is None:
            return
        if pictures.has_rows(picture):
            self._grabs.prefer(picture)
        if float(picture) > float(self._widest):
            self._widest = picture

    def shapes(self):
        """The shapes this film showed so far, for the next epoch's reader."""
        return list(self._grabs.known)

    def keep(self, memory, stopping):
        """Following ended: the looks and their CPU in the log (without asking for the detailed log setting), then
        this reader's recording handed to the playback's cache memory (shapes.Memory.keep_scenes: merged and kept for
        the next playback). Not while Kodi stops the add-on (stopping(): switched off, removed, updated): Kodi refuses
        an add-on's settings then, with an error of its own in its log. A map that can not be
        kept is logged, never raised."""
        used = time.thread_time() - self._cpu
        self._log('scenes: %d looks at the screen, %.1f s of CPU on this thread (%.1f ms a look)' % (
            self.looks, used, 1000 * used / max(self.looks, 1)), always=True)
        try:
            if stopping() or memory is None:
                return
            memory.keep_scenes(self.recording)
            live = self._live()
            if live:
                memory.keep_scenes(live)         # the file's cuts over the grabs' where both watched
        except Exception as error:  # the map is a nicety: never a reason to complain at a stop
            self._log('scene map not kept: %r' % error)
