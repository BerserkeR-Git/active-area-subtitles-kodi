"""One measurement of a playback's picture, from the cache to the settled shape (take): the cached shape and the first
estimate placed, each way of measuring in turn until one settles, what becomes of each answer on the way, and what is
left when none settles (the file's own shape, the person's margin back, the watch after a black opening). A file
cropped to its picture keeps its own shape; a remembered shape (the cache) is only ever widened (or read again more
exactly where a smaller window's grab read its rows), and an answer from dim grabs alone never moves it; a settled
answer is written to the cache unless every grab that agreed on it was dim, or the file has one keyframe.

take and its Outcome are the interface: the playback gives it the epoch's Placing, its Following and Steady, and
callables for what stays the playback's (its memory, the kind shown, its mark, its settled shape, its restore), and acts
on one outcome only, COREELEC. Nothing here takes a lock or holds a Playback, and nothing is written but through
placing.place and restore (test_service_names pins what it reads of the service). The order holds: the estimates
before the mark (started), the mark before the first read, an early follower stopped (following.unsettled) before the
margin goes back and before an unexpected error goes on, the margin back before a black screen is watched.
Measurement, the ways in order and the rule for each answer, is its internal seam, tested on its own."""
import collections
import contextlib
import os

from . import capture, coreelec, diagnostics, estimate, kodi, libav, measure, pictures, subtitles

CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 has a shape of its own (cropped, or 4:3 and the like)
SAME_SHAPE = 0.005             # a cached shape stands against a measurement this much wider: two routes differ by a
                               # few thousandths on one picture, under a pixel of margin
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on

SETTLED, STOPPED, NO_ANSWER, COREELEC, NONE_WORKED = 'settled', 'stopped', 'no answer', 'coreelec', 'none worked'
CACHED = 'cached'              # take's only: a cached shape placed and nothing left to run
# Shares of the film added to every position the file route reads when a film that gave no answer is read again
# (Playback.try_later), one per try: halfway between the positions read before (5 per cent apart), then a quarter
# of the way, then three quarters: every try reads keyframes no earlier one read.
AGAIN_SHIFTS = (0.025, 0.0125, 0.0375)

FILE_ANALYSIS = 'video file analysis'
SCREEN_CAPTURE = 'screen capture'
# measure.screen's reasons for a screen that showed nothing but black from the start, and for a grab that gives no image
# at all (their texts are pinned by test_measure).
ONLY_BLACK = 'the frame grab returns only black here'
NO_IMAGE = 'the frame grab returns no image here'
BLACK_WATCH = measure.SCREEN_GIVE_UP   # seconds of black the screen is watched for after that, one grab at a time

# What take ended in (one of the kinds above), the shape it settled on ((ratio, how), or None), the ways that could not
# run ({name: why}) and CoreELEC's hand-over (its reason, for COREELEC).
Outcome = collections.namedtuple('Outcome', 'kind settled unavailable reason')


def take(service, placing, following, steady, memory, target, kind, started, settled, measured, restore, tries=0):
    """One measurement of the epoch's picture, from the cache to the settled shape, on the epoch's placing thread
    after its layout and its memory are set. service: what it reads of the service (test_service_names pins the names).
    placing: the epoch's Placing, the one write of an answer. following: the playback's Following, asked places(epoch)
    and told unsettled(epoch). steady: the playback's Steady. memory(): the playback's shapes.Memory. target:
    Playback.target()'s answer. kind(): the kind of subtitle shown now. started(): the playback's mark set while the
    epoch is current, False when it is not; settled(ratio, how): a shape it settled on; measured(): the shape the
    playback settled on so far (Playback.measured); restore(why): the person's margin back for this epoch. tries: how
    often the film was read again after no answer (the file route's positions shifted by AGAIN_SHIFTS).

    The estimates (the cached shape, the first estimate) are placed before started(), whose False ends it with
    STOPPED before any read; every read comes after it. An early follower stops (following.unsettled) before any
    margin goes back and before an unexpected error goes on to the caller. With no answer the margin goes back before
    the screen is watched after a black opening. It takes no lock and writes only through placing, settled and
    restore. COREELEC is the caller's to act on."""
    epoch, video_ratio = placing.epoch, placing.layout.video_ratio
    current = placing.is_current
    own = own_shape(video_ratio)
    full = kodi.setting_bool('diagnostics', default=False)
    target, unreadable = target
    last = [None]                   # the shape settled on here

    def settle(ratio, how):
        last[0] = (ratio, how)
        settled(ratio, how)

    # Remembered from an earlier playback of this file (shapes.py): placed at once as the settled answer. On
    # CoreELEC that is the whole measurement (the keyframe decoding is what the memory saves); on a PC the
    # screen capture still runs, cheap, and may only widen what is remembered (a film stopped during a 16:9
    # opening would otherwise stay remembered as full-screen), or read it more exactly where a smaller window's
    # grab read its rows.
    remembered = memory()
    floor = None
    if remembered.entry is None:
        kodi.log('cache: %s, measuring' % remembered.note)
    else:
        floor = remembered.entry.ratio
        # Rows a smaller window's grab read (the file route could not read the file then): measured again, the
        # same picture read more exactly replaces them (Measurement).
        coarse = not service.on_coreelec and service.checks.file_first and capture.finer_rows(
            capture.KodiScreen(service.monitor.waitForAbort), video_ratio, floor) > 0
        from_file_only = (service.on_coreelec or service.checks.file_first) and not coarse
        kodi.log('cache: found (measured %s), %s' % (
            remembered.entry.date, 'nothing decoded' if from_file_only
            else 'measured again, its rows read in a smaller window' if coarse
            else 'the screen capture only watches for a wider picture'))
        how = 'cached (measured %s)' % remembered.entry.date
        placing.place(floor, how)
        settle(floor, how)
        if from_file_only:
            return Outcome(CACHED, last[0], {}, None)
    first = early_estimate(service, placing, video_ratio, kind) if floor is None and not own else None
    keyframes = []      # what the file analysis decoded, for a Level 5 check without decoding again

    def place(ratio, how, final):
        placing.place(ratio, how, final, keyframes)
        if final:
            settle(ratio, how)

    def ending(why):
        if floor is not None:
            kodi.log('cache: kept (screen capture: %s)' % why)   # the remembered shape stays in place
        elif own:
            placing.place(video_ratio, 'the file\'s own shape (%s)' % why)
        else:
            restore(why)

    in_order = ways(service, video_ratio, target, unreadable, kind, steady, current, recorder(full), full, keyframes,
                    watching=lambda: current() and not (measured() is not None and following.places(epoch)),
                    meanwhile=first.step if first is not None else None,
                    shift=AGAIN_SHIFTS[tries - 1] if tries else 0.0)
    run = Measurement(in_order, video_ratio, own, floor, memory, current)
    if not started():
        return Outcome(STOPPED, last[0], {}, None)
    try:
        outcome = run.run(place)
        if outcome in (SETTLED, NONE_WORKED) and not service.on_coreelec:
            service.checks.screen_measured(run.unavailable.get(SCREEN_CAPTURE) == NO_IMAGE and outcome == NONE_WORKED)
        if outcome != SETTLED and measured() is None:
            following.unsettled(epoch)        # a follower of a cached shape goes on (it settled)
        if outcome == NO_ANSWER:
            ending('no clear answer')
        elif outcome == NONE_WORKED:
            # The previous item of a playlist may have changed the margin: this one gets the person's own,
            # or the margin for the file's own shape.
            ending('not measured')
            # A file's own shape is placed as settled, and its follower watches the screen from then on.
            if floor is None and not own and run.unavailable.get(SCREEN_CAPTURE) == ONLY_BLACK:
                watch_after_black(in_order, video_ratio, current, place, service.monitor.waitForAbort, memory)
    except BaseException:
        # An unexpected error: the caller puts the person's margin back, and a follower of this epoch stops, or it
        # would write its own again at the next change (an early one, before any settled shape).
        following.unsettled(epoch)
        raise
    return Outcome(outcome, last[0], run.unavailable, run.reason)


def early_estimate(service, placing, video_ratio, kind):
    """A first estimate before the file is read, where one is to be had without reading it (the first keyframe waits
    steady.START_STEADY of smooth playback): on the box a Dolby Vision film's Level 5 as P3i reports it, live from
    the first frame (estimate.FirstEstimate, tried now and at every step of the first read's wait; returned for
    that); on a PC that reads the file first, one screen grab, placed now (None returned). The measurement confirms
    or corrects it as any estimate. Nothing on the box for image subtitles (P3i places those), without the video's
    height (the offsets count in its rows), with has.l5 0 or with Level 5 0/0 (each says the full frame, a guess: a
    scope film can carry either). Where CoreELEC places the text with Level 5, the playback's layout has handed it over
    before this."""
    if service.on_coreelec:
        if kind() == subtitles.IMAGE:
            return None
        reader = service.labels.reader(service.labels.video_height(), video_ratio)
        first = estimate.FirstEstimate(placing, reader, service.held, service.labels.report)
        first.step()
        return first
    if service.checks.file_first:
        picture = capture.first_look(capture.KodiScreen(service.monitor.waitForAbort), video_ratio)
        if picture is not None:
            placing.place(picture, 'one screen grab, measuring', final=False)
    return None


def _why_provisional(how, screen):
    """Why an answer is provisional, for the log: the file route's rests on the one keyframe the file has (measure.film),
    the screen route's (screen) on dim grabs."""
    return 'the file gave one keyframe' if how.startswith('file') else screen


def own_shape(video_ratio):
    """True for a video in a shape of its own, usually cropped to its picture."""
    return abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE


def min_length(on_coreelec):
    """The shortest video the file analysis reads: shorter on CoreELEC, where it is the only way to measure."""
    return measure.FILM_MIN_LENGTH_ALONE if on_coreelec else measure.FILM_MIN_LENGTH


def recorder(full):
    """record(number, frame, width, height, channels, sample, detail) for the ways: each sample logged, and with full
    (the detailed log) the first SAVED_PICTURES frames saved as pictures."""
    saved = []

    def record(number, frame, width, height, channels, sample, detail=''):
        kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
        if frame and full and len(saved) < SAVED_PICTURES:
            saved.append(_save_picture(frame, width, height, channels, len(saved) + 1))
    return record


def _save_picture(frame, width, height, channels, number):
    try:
        path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
        with open(path, 'wb') as handle:
            handle.write(diagnostics.png(frame, width, height, channels))
        return path
    except Exception as error:  # a diagnostic must never get in the way
        kodi.log('could not save a picture: %r' % error)
        return None


def ways(service, video_ratio, target, unreadable, kind, steady, current, record, full, keyframes=None, watching=None,
         meanwhile=None, shift=0.0):
    """The ways of measuring for this system, in order of preference. target, unreadable: Playback.target()'s answer.
    kind(): the kind of subtitle shown now. steady: the playback's steady.Steady. full: the detailed log's pictures.
    watching(): whether the screen route still watches for a wider picture once settled: not once the scene follower
    places the text (it reads the screen itself, and a distance changed meanwhile then places again at once rather than
    as an estimate); a follower started at an estimate leaves the measurement running until it settles. meanwhile:
    steady's, for the file route's first read (the first estimate). shift: added to every position the file route reads
    (measure.film)."""
    def screen():
        # Every row it reads is a screen grab's (pictures.Grabbed): read again where a larger grab can be had.
        wait = service.monitor.waitForAbort
        with contextlib.closing(measure.screen(video_ratio, watching or current, wait, record,
                                               capture.KodiScreen(wait))) as answers:
            for ratio, how, final in answers:
                yield pictures.grabbed(ratio), how, final

    def from_file():
        if target is None:
            raise libav.Unavailable(unreadable)
        if not service.guard.allowed(target.identity):
            raise libav.Unavailable('left to Kodi after an interrupted decode')
        length = service.length()
        if length is None:                  # not playing any more, or Kodi could not say
            raise libav.Unavailable('playing item unknown')
        def hands_over():
            # Asked when a keyframe carries Level 5 values, with the kind shown then (a switch to an image subtitle
            # while measuring must not hand over as for a text one).
            return (service.on_coreelec and kind() != subtitles.IMAGE
                    and coreelec.restricts_with_level5(kodi.get_setting, service.labels))
        return measure.film(service.film(target, current, full=full), length, video_ratio, current,
                            record, level5_hands_over=hands_over, keyframes=keyframes,
                            min_length=min_length(service.on_coreelec),
                            ready=lambda _first: steady.wait(current, meanwhile), shift=shift)

    if service.on_coreelec:
        return [(FILE_ANALYSIS, from_file)]
    if service.checks.file_first:      # a PC with a decoder: as the box, the screen capture as the fallback
        return [(FILE_ANALYSIS, from_file), (SCREEN_CAPTURE, screen)]
    return [(SCREEN_CAPTURE, screen), (FILE_ANALYSIS, from_file)]


class Measurement:

    def __init__(self, ways, video_ratio, own_shape, floor=None, memory=lambda: None, current=lambda: True):
        """ways: (name, attempt) in order of preference, attempt() giving (ratio, how, final) answers. floor: a
        remembered shape the measurement may only widen, or read more exactly (pictures.finer). memory(): the
        playback's shapes.Memory or None, asked at each settled answer. current(): whether the playback still wants the
        answers."""
        self._ways = ways
        self._video_ratio = video_ratio
        self._own_shape = own_shape
        self._floor = floor
        self._memory = memory
        self._current = current
        self.reason = None                  # what CoreELEC's hand-over said, for COREELEC
        self.unavailable = {}               # {way's name: why it could not run}

    def run(self, place):
        """SETTLED, STOPPED (the playback ended or was placed again), NO_ANSWER (a way ran out without one),
        COREELEC (CoreELEC places the subtitles, see reason) or NONE_WORKED (no way could run)."""
        for name, attempt in self._ways:
            try:
                settled = False
                # Closed explicitly, so a decoder is freed the moment the answer is in. A way may settle
                # more than once (screen capture widening for IMAX scenes): each settled shape counts.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        if self._answer(ratio, how, final, place):
                            settled = True
                if settled:
                    return SETTLED
                if not self._current():   # stopped, or a newer placing of this film took over: not the file's fault
                    kodi.log('%s ended: the playback stopped or was placed again' % name)
                    return STOPPED
                kodi.log('%s gave no clear answer' % name)
                return NO_ANSWER
            except libav.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
                self.unavailable[name] = str(reason)
                if settled:               # what was settled stands
                    return SETTLED
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self.reason = str(reason)
                return COREELEC
        kodi.log('no way of measuring worked for this playback')
        return NONE_WORKED

    def _answer(self, ratio, how, final, place):
        """One answer: placed, kept back, or written to the cache. True when it settles the measurement."""
        floor = self._floor
        provisional = getattr(ratio, 'provisional', False)     # read before the clamp below turns it into a number
        if self._own_shape and ratio <= self._video_ratio * (1 + CROPPED_TOLERANCE):
            ratio = self._video_ratio     # no bars in the file: its own shape, not moved again
        if floor is not None and provisional:
            # A measured, cached shape outweighs an answer from dim grabs alone, or from a file's one keyframe.
            kodi.log('cache: kept, %s (%.2f)' % (_why_provisional(how, 'the screen capture agreed only in dim scenes'),
                                                 ratio))
            return True
        if floor is not None and ratio <= floor * (1 + SAME_SHAPE) and not (final and pictures.finer(ratio, floor)):
            # The cached shape is on already: nothing to place again (no writes, no settings read
            # while Kodi may be switching the add-on off), only a wider picture moves it, or the same picture read
            # more exactly than a smaller window's grab read it (its edge row was coarser).
            if final:
                kodi.log('cache: kept, the measurement found %.2f' % ratio)
            return final
        place(ratio, how, final)
        if not final:
            return False
        memory = self._memory()
        if memory is None:
            pass
        elif provisional:
            kodi.log('cache: not saved, %s' % _why_provisional(how, 'every agreeing grab was dim'))
        else:
            memory.remember(ratio, how)   # logs "cache: saved ..." itself
        return True


def watch_after_black(ways, video_ratio, current, place, wait, memory):
    """Every way gave up and the screen showed nothing but black (a PC without the decoder, a film opening
    on more black than measure.SCREEN_BLACK_LIMIT grabs): one grab every SCREEN_SLOW_INTERVAL until one is clear,
    then the screen is measured again, for BLACK_WATCH seconds of black in all. A grab that gives no image ends it.
    Nothing moved meanwhile: the person's margin stays. ways: the measurement's, of which the screen capture runs
    again; wait(seconds): Kodi's monitor, True when Kodi closes."""
    screen = capture.KodiScreen(wait)
    screen_only = [way for way in ways if way[0] == SCREEN_CAPTURE]
    left = BLACK_WATCH
    while left > 0 and current():
        if wait(measure.SCREEN_SLOW_INTERVAL):
            return
        left -= measure.SCREEN_SLOW_INTERVAL
        sample = measure.look(screen, video_ratio)[3]
        if sample.reason.startswith('no image'):
            return
        if sample.clear:
            kodi.log('screen capture: a picture after the black, measuring again')
            again = Measurement(screen_only, video_ratio, False, None, memory, current)
            if again.run(place) != NONE_WORKED:
                return
