"""The P3i policy: which kind of subtitle Kodi shows, and CoreELEC's own settings for it.

The add-on places every text subtitle itself, with Kodi's margin; only CoreELEC can move an image subtitle
(PGS, DVD, DVB), with P3i's "Restrict subtitles to active picture" and its bitmap margin. So P3i's restriction
is held off while nothing plays and for text, switched on while an image subtitle shows, and left off for one
the person keeps "As on the disc". This module decides that and looks up the kind; the writes themselves
belong to the restores (restores.py), done through the playback they are for (Playback.write).
"""
import xbmc
import xbmcvfs

from . import coreelec, geometry, kodi, measure, subtitles
from .playback import HDR_TYPE, image_distances

TEXT, DISC, IMAGE = 'text', 'as on the disc', 'image'


def decide(kind, distances):
    """TEXT (the add-on places it), DISC (left as on the disc, nothing measured) or IMAGE (CoreELEC places it) for a
    subtitle of kind (None: not known to be an image), with distances the image distances for both shapes."""
    if kind != subtitles.IMAGE:
        return TEXT
    if all(distance is geometry.DISC for distance in distances):
        return DISC
    return IMAGE


class P3i:

    def __init__(self, service):
        self.service = service               # on CoreELEC or not, the restores, Kodi's player, the decode guard

    def offered(self):
        """True on a CoreELEC build that offers P3i's subtitle restriction (it is readable only there)."""
        return self.service.on_coreelec and kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is not None

    def hold(self):
        """P3i's restriction off while the add-on is on: the add-on places text subtitles itself; image subtitles
        have it on while they show (see Restores.image_restriction). Nothing is written elsewhere."""
        if not (self.service.on_coreelec and kodi.setting_bool('enabled')):
            return
        self._held(self.service.restores.hold())

    def _held(self, switched):
        """After a hold: told once when the person's own "on" was switched off just now."""
        if switched:
            kodi.log('CoreELEC\'s subtitle restriction switched off: the add-on places text subtitles itself',
                     always=True)
            self.service.checks.restrict_notice()

    def subtitle_track(self):
        """(index, shown) of Kodi's current subtitle track, None when Kodi does not say; only that
        track asked for, never the list (a remux can carry dozens)."""
        players = kodi.rpc('Player.GetActivePlayers', quiet=True)
        player = next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                       and entry.get('type') == 'video'), None)
        if player is None:
            return None
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None
        return (found.get('currentsubtitle') or {}).get('index'), bool(found.get('subtitleenabled'))

    def by_kind(self, playback, epoch, again=False):
        """CoreELEC's settings for the kind of subtitle shown in playback, and whether to measure and place.
        Text (or a kind not known to be an image): the restriction held off, the add-on places it. An image
        subtitle, which only CoreELEC can move: the person's own margin back, the restriction on at once when
        every shape gets a distance (with one shape "As on the disc", once the shape is known), then measured for
        the distance its shape gets (bitmap margin); with both image distances "As on the disc" the restriction
        stays off and nothing is measured (False)."""
        restores = self.service.restores
        watch = playback.watch
        track = self.subtitle_track() if watch is not None else None    # before the kind: a switch in between is seen
        kind, why = self.subtitle_kind(playback)
        if not playback.is_current(epoch):
            return False
        playback.subtitle_kind = kind or subtitles.TEXT
        if watch is not None and track is not None:
            watch.track = track             # the watch's first look then has nothing new to judge
        distances = image_distances()
        decided = decide(kind, distances)
        if decided == TEXT:
            kodi.log('%s subtitle (%s): the add-on places it' % ('text' if kind else 'unknown kind of', why))

            def text():
                restores.text_bitmap_back()
                return restores.held_off()
            # Through the playback's own write, not the idle hold: a playlist skip just before the hold let the
            # old film's thread switch the restriction off after the new film switched it on for an image
            # subtitle (deep review probe, 2026-10-13).
            self._held(playback.write(epoch, text))
            return True
        if decided == DISC:
            kodi.log('image subtitle (%s): left as on the disc' % why)
            playback.write(epoch, restores.disc)
            playback.restore_if_current(epoch, 'image subtitle')
            if xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision' and not (again and playback.level5_checked):
                playback._correct_late_level5(epoch)  # the picture signal to the TV still gets right Level 5
            return False
        kodi.log('image subtitle (%s): CoreELEC places it' % why)
        if not any(distance is geometry.DISC for distance in distances):
            # Every shape gets a distance: on at once. With one shape "As on the disc" the shape decides, in
            # Playback._place (until 1.1.4: on, then off again a second later for a film of that shape, and P3i
            # moves a showing line live).
            playback.write(epoch, restores.image_restriction)
        playback.restore_if_current(epoch, 'image subtitle')    # the text margin does not apply to it
        return True

    def subtitle_changed(self, playback, epoch):
        """Another subtitle track during playback: placed again (on a thread of its own) when it is now
        of the other kind, with the shape measured for this playback and its Level 5 as it is."""
        try:
            if playback.subtitle_kind is None or not self.offered():
                return
            kind = self.subtitle_kind(playback)[0] or subtitles.TEXT
            if not (playback.is_current(epoch) and playback.subtitle_kind is not None and kind != playback.subtitle_kind):
                return
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('subtitle track not looked at: %r' % error, always=True)
            return
        kodi.log('subtitle track changed to %s: placed again' % ('an image' if kind == subtitles.IMAGE else 'text'))
        playback.subtitle_kind = kind       # the next look compares with this, even before the placing starts
        playback.place_again(epoch)         # the epoch judged here, not one read again

    def subtitle_kind(self, playback):
        """(subtitles.IMAGE, TEXT or None, why) for the current subtitle, from Kodi's list and the file's own
        subtitle streams (read once per playback)."""
        players = kodi.rpc('Player.GetActivePlayers', quiet=True)
        player = next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                       and entry.get('type') == 'video'), None)
        if player is None:
            return None, 'no video player'
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['subtitles', 'currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None, 'Kodi did not say'
        if not found.get('subtitleenabled'):
            return subtitles.TEXT, 'subtitles off'
        listed = [entry for entry in found.get('subtitles') or [] if isinstance(entry, dict)]
        current = (found.get('currentsubtitle') or {}).get('index')
        target, _unreadable = playback._target()
        return subtitles.current_kind(listed, current, self.file_streams(playback, target), self.sidecars())

    def file_streams(self, playback, target):
        """The playing file's own subtitle streams, or None when they can not be read (read once per playback)."""
        if target is None:
            return None
        if playback.streams_of[0] == target.identity:
            return playback.streams_of[1]
        streams = None
        guard = self.service.guard
        if guard.allowed(target.identity):
            try:
                # Not lowered in priority: a header read, and it can run on the service's own thread (the watch).
                decoder = measure.ffmpeg.Decoder(target, kodi.data_path('ffmpeg.json'), background=False)
                # The stream structures are read through ctypes as well: guarded like a decode, so a layout this
                # add-on misjudges leaves the file to Kodi after one crash instead of crashing it at every play.
                with guard.decoding(target.identity):
                    try:
                        decoder.__enter__()
                        streams = decoder.subtitle_streams()
                    finally:
                        decoder.close()
            except Exception as error:  # unreadable here: the kind stays unknown
                kodi.log('subtitle streams not read: %s' % error)
        playback.streams_of = (target.identity, streams)
        return streams

    def sidecars(self):
        """subtitles.IMAGE or TEXT for the subtitle files next to the playing video, None when mixed or unknown."""
        try:
            playing = self.service.getPlayingFile().partition('|')[0]
            if '://' in playing and playing.split('://')[0] not in ('smb', 'nfs', 'file'):
                return None             # a web address (a Plex server): no folder to look in
            folder, name = playing.replace('\\', '/').rsplit('/', 1)
            return subtitles.sidecar_kind(xbmcvfs.listdir(folder + '/')[1], name)
        except Exception:  # not playing any more, or the folder can not be listed
            return None
