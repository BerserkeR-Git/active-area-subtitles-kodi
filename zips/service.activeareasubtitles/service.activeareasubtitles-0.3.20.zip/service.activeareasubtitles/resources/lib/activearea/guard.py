"""Protection against the one part that could take Kodi down: decoding through FFmpeg.

A marker file names the files being decoded while any decode runs. Finding it when the
service starts means Kodi stopped in the middle of a decode without closing normally: a
crash in FFmpeg, or just a power cut. Either way it heals itself:

- the file being decoded then is left to Kodi from now on (one film, not the add-on), so a
  file that crashes FFmpeg can not crash Kodi again and again;
- only when it happens twice in a row (no decode finished in between, so FFmpeg itself is the
  problem, not one file) does decoding pause, for a day, and then it is simply tried again;
- an update of the add-on starts with a clean slate, since it may bring the fix.

A normal close removes the marker, even when a decode is still running then (a slow network
read), so that is never taken for a crash.
"""
import contextlib
import json
import os
import threading
import time

PAUSE_S = 24 * 60 * 60     # after two interrupted decodes in a row
SKIPPED_LIMIT = 50         # files left to Kodi, newest kept


class DecodeGuard:

    def __init__(self, folder, version, clock=time.time):
        self.marker = os.path.join(folder, 'decoding.marker')
        self.record = os.path.join(folder, 'decoding.json')
        self.folder, self.version, self.clock = folder, version, clock
        self.lock = threading.Lock()
        self.running = []   # identities being decoded: an older playback's may still be finishing

    def check_last_run(self):
        """At start: what an interrupted decode last time led to, for the log, or None.

        'skipped' when the file being decoded is left to Kodi from now on, 'paused' when it was
        the second time in a row and decoding pauses for a day."""
        _remove(os.path.join(self.folder, 'decoding.disabled'))   # versions before 0.3.20
        if not os.path.exists(self.marker):
            return None
        try:
            with open(self.marker, encoding='utf-8') as handle:
                files = json.load(handle).get('files', [])
        except (OSError, ValueError, AttributeError):
            files = []
        _remove(self.marker)
        state = self._load()
        skipped = [f for f in state['skipped'] if f not in files] + [f for f in files if isinstance(f, str)]
        state['skipped'] = skipped[-SKIPPED_LIMIT:]
        state['strikes'] += 1
        paused = state['strikes'] >= 2
        if paused:
            state['paused_until'] = self.clock() + PAUSE_S
        self._save(state)
        return 'paused' if paused else 'skipped'

    def paused(self):
        """True while decoding pauses after two interrupted decodes in a row."""
        return self.clock() < self._load()['paused_until']

    def allowed(self, identity=None):
        """False while paused, and for a file that was being decoded when Kodi stopped."""
        state = self._load()
        return self.clock() >= state['paused_until'] and identity not in state['skipped']

    @contextlib.contextmanager
    def decoding(self, identity=None):
        with self.lock:
            self.running.append(identity)
            self._mark()
        try:
            yield
        finally:
            with self.lock:
                self.running.remove(identity)
                self._mark()
            # FFmpeg came back (with a picture or with an error): the count of interruptions
            # in a row starts again.
            if self._load()['strikes']:
                state = self._load()
                state['strikes'] = 0
                self._save(state)

    def wait_until_idle(self, seconds=4.0):
        """At a normal close: let a running decode finish (about two seconds at most), then
        remove the marker in any case, since Kodi did not stop in the middle of one."""
        deadline = time.time() + seconds
        while self.running and time.time() < deadline:
            time.sleep(0.1)
        _remove(self.marker)

    def _mark(self):
        """The marker names what is being decoded; it is gone while nothing is."""
        if not self.running:
            _remove(self.marker)
            return
        try:
            self._ensure_folder()
            with open(self.marker, 'w', encoding='utf-8') as handle:
                json.dump({'files': [f for f in self.running if f]}, handle)
        except OSError:
            pass

    def _load(self):
        fresh = {'version': self.version, 'skipped': [], 'strikes': 0, 'paused_until': 0.0}
        try:
            with open(self.record, encoding='utf-8') as handle:
                state = json.load(handle)
        except (OSError, ValueError):
            return fresh
        if not isinstance(state, dict) or state.get('version') != self.version:
            return fresh          # an update: a clean slate
        try:
            return {'version': self.version, 'skipped': [f for f in state.get('skipped', []) if isinstance(f, str)],
                    'strikes': int(state.get('strikes', 0)), 'paused_until': float(state.get('paused_until', 0.0))}
        except (TypeError, ValueError):
            return fresh

    def _save(self, state):
        try:
            self._ensure_folder()
            with open(self.record, 'w', encoding='utf-8') as handle:
                json.dump(state, handle)
        except OSError:
            pass

    def _ensure_folder(self):
        if self.folder and not os.path.isdir(self.folder):
            os.makedirs(self.folder)


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass
