"""Small helpers around Kodi's Python and JSON-RPC interfaces."""
import json
import os
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcaddon
import xbmcvfs

from . import coreelec

ADDON_ID = 'service.activeareasubtitles'
PREFIX = '[Active Area Subtitles] '


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def setting_bool(name, default=True):
    try:
        return addon().getSettingBool(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_int(name, default=0):
    try:
        return addon().getSettingInt(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_number(name, default=0.0):
    try:
        return addon().getSettingNumber(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    return folder + name


def picture_folder():
    """Where diagnostic pictures go: somewhere easy to reach from another computer.

    CoreELEC's Screenshots share (/storage/screenshots), else Kodi's own screenshot
    folder when one is set, else the add-on's data folder.
    """
    if coreelec.is_coreelec() and os.path.isdir('/storage/screenshots'):
        return '/storage/screenshots/'
    chosen = get_setting('debug.screenshotpath')
    if chosen:
        folder = xbmcvfs.translatePath(chosen)
        if os.path.isdir(folder):
            return os.path.join(folder, '')
    return data_path('')


def log(message, always=False):
    if always or setting_bool('diagnostics'):
        xbmc.log(PREFIX + message, xbmc.LOGINFO)


def rpc(method, params=None, quiet=False):
    """Call Kodi's JSON-RPC. Returns the result, or None on an error. quiet: an error is an
    expected answer, not logged (logging asks for a setting, which Kodi refuses with an error
    of its own while the add-on is being updated or removed)."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as error:  # a malformed answer, or Kodi raising (closing, say): as refused
        if not quiet:
            log('%s failed: %r' % (method, error))
        return None
    if not isinstance(reply, dict):
        return None
    if 'error' in reply:
        if not quiet:
            log('%s refused: %s' % (method, reply['error'].get('message')))
        return None
    return reply.get('result')


SAVED_SETTINGS = 'special://profile/guisettings.xml'


def saved_setting(setting_id):
    """What Kodi's settings file holds for setting_id (its text), or None when that is not known.

    Kodi keeps settings changed through JSON-RPC in memory only and writes them to this file at a
    clean close and from its settings window (seen in Kodi 21), with every setting in it, defaults
    included. So the file, not the value in memory, says what Kodi starts with next time."""
    try:
        root = ElementTree.parse(xbmcvfs.translatePath(SAVED_SETTINGS)).getroot()
    except Exception:  # missing, half written, or Kodi could not say: unknown
        return None
    for node in root.iter('setting'):
        if node.get('id') == setting_id:
            return node.text or ''
    return None


def saved_settings_stamp():
    """When Kodi last wrote its settings file, or None when that is not known."""
    try:
        return os.path.getmtime(xbmcvfs.translatePath(SAVED_SETTINGS))
    except Exception:  # missing, or Kodi could not say
        return None


def get_setting(setting_id):
    result = rpc('Settings.GetSettingValue', {'setting': setting_id})
    return result.get('value') if isinstance(result, dict) else None


def set_setting(setting_id, value):
    return rpc('Settings.SetSettingValue', {'setting': setting_id, 'value': value}) is True
