"""One playback, from Kodi's start of it to its end: what is known about it, and the work of placing its
subtitles, on threads of its own (the service's threads); following its scenes is labelfollow.py's on the box and
screenfollow.py's on a PC.

The service makes a Playback when Kodi starts one and drops it when it ends (Service.current). Every
thread works for one Playback and one of its epochs: placing the same playback again (another subtitle
track, another distance) starts a new epoch. Work for a playback that is no longer the current one, or for
an epoch that is no longer its newest, changes nothing (is_current). Nothing about one playback can be read
by the next: each starts with a fresh object.
"""
import contextlib
import os
import time
import types

import xbmc
import xbmcvfs

from . import (capture, choices, coreelec, detect, diagnostics, estimate, geometry, kodi, labelfollow, layouts, level5,
               libav, locate, measure, measurement, p3i, pictures, placement, screenfollow, steady, subtitles)

SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CANVAS_HOLD = 0.3              # seconds Kodi's window must stay as it changed to before the text is placed again for it
                               # (a window dragged larger; the watch and the follower both look: counting their looks
                               # could be two looks milliseconds apart)
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
FILE_ANALYSIS = 'video file analysis'
SCREEN_CAPTURE = 'screen capture'
# measure.screen's reason for a screen that showed nothing but black from the start (its text is pinned by test_measure).
ONLY_BLACK = 'the frame grab returns only black here'
BLACK_WATCH = measure.SCREEN_GIVE_UP   # seconds of black the screen is watched for after that, one grab at a time
# The watch (see Service._watch_step) looks at the subtitle track only after a button press, early in a playback,
# and once in a while; asking costs about 0.1 ms, normal watching asks nothing at all.
WATCH_EARLY = 30.0             # seconds after the start during which it is looked at regardless
WATCH_EARLY_STEP = 2.0         # how often then
WATCH_SLOW = 30.0              # how often otherwise

def watch_due(now, watch, pressed_lately):
    """Whether the watch looks at the subtitle track now: after a button press, early in the playback (a player
    add-on adds subtitles then, without a press), or once in a while (a phone remote switches without one)."""
    since = now - watch.looked
    return pressed_lately or since >= WATCH_SLOW or (now - watch.started < WATCH_EARLY and since >= WATCH_EARLY_STEP)


class Playback:

    def __init__(self, service, carried_over=False, same_film=False):
        self.service = service               # Kodi's player, the lock, the restores, the P3i policy
        self.epoch = 0                       # placed again: a new epoch of the same playback
        self.fitted = False                  # fit ran in this playback: only its first is a playlist's next video
        # Carried over from the previous service (an update during the film): its first epoch keeps what that
        # service put in place; placed again, it gets the add-on's own placement.
        self.carried_epoch = 0 if carried_over else None
        # On the monotonic clock: a system clock set back during a film would stop the timed looks.
        watched = time.monotonic()
        self.watch = types.SimpleNamespace(started=watched, looked=watched, failed=False, position_failed=False)
        self.shown = p3i.Shown()             # the kind of subtitle shown and the file's streams (P3i writes it)
        self.measured = None                 # (picture ratio, how) once its shape settled
        self.measuring = None                # the mark of the measurement running, if one is
        self.picture = None                  # (layout, picture ratio): the latest shape found
        self.level5 = level5.Correction(self)   # this playback's Level 5 correction (level5.py)
        self.memory = None                   # shapes.Memory: what is remembered for this file, once looked up
        self.waiting = None                  # the epoch that had no subtitles yet; measured once some appear
        self.finer_tried = set()             # (shape's rows, full-size grab's rows) read again once each (_read_finer)
        self._target = None                  # the playing file once worked out (target)
        # Following its scenes (followloop.Following): P3i's labels on the box, Kodi's screen on a PC.
        self.following = (labelfollow.LabelFollowing if service.on_coreelec else screenfollow.ScreenFollowing)(self)
        self.margin_placed = None            # the text margin of the add-on's last placement
        self.playing = self._playing_file()
        # What its layouts are made from and Kodi's refusal of Manual (layouts.py); made under the lock (Service.begin).
        # same_film: the add-on switched off and on in its own settings during it, so a position the person set is
        # still theirs.
        self.layouts = layouts.Layouts(self.playing, carried_over or same_film, service.restores.margin.own_position)
        # The one wait before every read of its file (steady.py), on the service's clock from Kodi's start of it.
        self.steady = steady.Steady(lambda: service.clock(), lambda: service.held(), lambda: service.last_seek,
                                    lambda: service.labels.cache_level(),
                                    lambda seconds: service.monitor.waitForAbort(seconds), kodi.log)

    def still_playing(self):
        """This is the playback now and Kodi is not closing, whichever epoch is newest: what a header read waits on,
        so another subtitle track does not cut it short."""
        return self.service.current is self and not self.service.monitor.abortRequested()

    def is_current(self, epoch):
        """Whether work for epoch may still change anything: this is the playback now, epoch its newest."""
        return epoch == self.epoch and self.still_playing()

    def write(self, epoch, change):
        """The one way this playback writes to Kodi: change() under the lock, only while epoch is current and its
        service in charge, so a stop, a newer placing or a newer start of the add-on in between keeps it from writing
        (the older start's loop sees a newer claim only at its next step). change()'s answer, or None when not current
        (a check by hand at each write, forgotten once or done outside the lock, would race with a stop)."""
        with self.service.lock:
            if not self.is_current(epoch) or not self.service.in_charge():
                return None
            return change()

    def claim_waiting(self, epoch):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.service.lock:
            if self.waiting == epoch == self.epoch and self.service.current is self:
                self.waiting = None
                return True
            return False


    def restore_if_current(self, epoch, why):
        def back():
            if epoch == self.carried_epoch:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                kodi.log('%s: what the previous service set for this video stays' % why)
            elif self.service.restores.margin.restore():
                kodi.log('%s: own subtitle margin put back' % why)
        self.write(epoch, back)

    def position_check(self):
        """The person set Kodi's subtitle position during the film, or changed its subtitle style (the watch looks, see
        Service._watch_step; a style change is placed for, the position stays as it is). The position: taken
        from Manual the add-on held, or simply not the one the layout was made with: theirs from now on, and the
        playback placed again with it, in a new epoch even while the
        first measurement runs (the layout itself changed: carrying on with the old one would hold Manual over their
        choice). Taken and the epoch moved on in one lock section, so no write of the old epoch
        lands between them."""
        style = placement.style()           # six questions to Kodi, outside the lock: only compared
        with self.service.lock:
            if not self.still_playing():
                return
            moved, restyled = self.layouts.changed(style, self.service.restores.margin)
            if not (moved or restyled):
                return
            self.epoch += 1
            epoch = self.epoch
        # A style changed in Kodi's subtitle settings moves the text's outline (a larger border at On the edge would
        # stay partly in the bar until the next placing).
        kodi.log('subtitle position set during the film: placed again with it' if moved
                 else 'subtitle style changed during the film: placed again for it')
        self.service.threads.start('placing', self.fit, epoch, True)

    def canvas_check(self):
        """Kodi's window changed size, or went to or from full screen, since the layout was made (a film started, then
        the person went to the desktop while its opening plays, and back: the text would sit in the bar once full
        screen): placed again for the window as it is now, in a new epoch, with the shape measured. Once
        the change has held for CANVAS_HOLD (a window dragged larger changes at every look), and not while the first
        measurement runs (placing again would read the file again): until it settles the text stays placed for the
        window it started in, and the first look after places it for this one. A look of a PC's watch, and of its
        scene follower at each look (placed again within a few tenths of a second): five questions to Kodi, about
        0.1 ms each."""
        now = placement.canvas()
        with self.service.lock:
            if not self.layouts.window_changed(now, self.service.clock(), self.still_playing(), CANVAS_HOLD,
                                               self.measuring is None and self.measured is not None):
                return
            self.epoch += 1
            epoch = self.epoch
        # Not whether windowed: Kodi says that a moment after the size; the layout's line does.
        kodi.log('Kodi\'s window changed (%sx%s, canvas %dx%d): placed again' % now[:4])
        self.service.threads.start('placing', self.fit, epoch, True)

    def _playing_file(self):
        try:
            return self.service.getPlayingFile()
        except Exception:  # not playing (any more), or Kodi could not say
            return None

    # The work for one playback, on its own thread.

    def fit(self, epoch, again=False):
        """again: the same playback placed again for another subtitle track. Subtitles switched on later come here
        without it, in the first epoch or a later one: only the playback's first fit is a playlist's next video."""
        try:
            carried_over = epoch == self.carried_epoch
            with self.service.lock:
                first, self.fitted = not self.fitted, True
            if first and not carried_over:      # a playlist's next video: the previous one's changes go
                self.write(epoch, lambda: self.service.restores.next_video(margin=self.service.on_coreelec))
            # A playback carried over from the previous service keeps CoreELEC's restriction as it was:
            # nothing moves during an update; the next video gets the add-on's own placement. Switched off in its
            # own settings: no P3i policy either, fit_once's layout check puts the margin back.
            if (not carried_over and self.service.enabled() and self.service.p3i.offered()
                    and not self.service.p3i.by_kind(self, epoch, again)):
                return                    # an image subtitle left as on the disc: nothing to measure
            self.fit_once(epoch)
            if carried_over and self.service.enabled() and self.service.p3i.offered():
                # Placed as the previous service left it; the kind learnt afterwards, for the watch's looks only, so a
                # switch to the other kind places again.
                self.service.p3i.learn_kind(self, epoch)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self.restore_if_current(epoch, 'unexpected error')
            except Exception:
                pass

    def while_measuring(self, epoch):
        """Another track or distance while the first measurement runs: CoreELEC's settings for the kind shown, and
        the shape found so far placed with what is chosen now."""
        try:
            # Only where P3i offers its restriction, as in fit (a distance changed while a PC measures must write
            # nothing of P3i's).
            if self.service.p3i.offered() and not self.service.p3i.by_kind(self, epoch, again=True):
                return
            picture, layout = self.picture, self.layouts.in_force(epoch)
            if picture is None or layout is None:
                return          # the epoch's own placing, started with it, lays out and places with what is chosen now
            placing = Placing(self, epoch, layout, time.time())
            if self.following.places(epoch):
                self.following.chosen_again(placing)       # the early follower places the text
            else:
                # Only while nothing newer was placed since the shape was read (the measurement settling).
                placing.place(picture[1], 'the shape found so far', final=False, when=lambda: self.picture is picture)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('subtitle track not placed: %r' % error, always=True)

    def place_again(self, epoch):
        """The same playback placed again (another subtitle track, another distance), on a thread of its own. While its
        first measurement runs, that measurement carries on (it reads the distances and the kind at every answer) and
        the shape found so far is placed now; once settled, with that shape and its Level 5 as it is, never a second
        measurement from the first keyframe. Before the measurement starts (the waits for subtitles, the shape and
        CoreELEC's scan in _layout) there is nothing to carry on: a new epoch starts the placing over, and the old one
        ends at its next check (harmless). epoch: the one this change was judged for; an older one changes nothing. Kodi
        failing here stays here (is_current asks Kodi, which can fail inside the watch's look)."""
        try:
            with self.service.lock:
                if not self.is_current(epoch):
                    return
                if self.measuring is None:
                    self.epoch += 1
                    target, args = self.fit, (self.epoch, True)
                else:
                    target, args = self.while_measuring, (epoch,)
            self.service.threads.start('placing', target, *args)
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('not placed again: %r' % error, always=True)


    def fit_once(self, epoch):
        # The picture on screen first, at a PC's start; placed again with the shape measured, nothing to wait for (a
        # window changed: 1 s of the 3 to 4 s it would take on a Windows PC).
        waits = not self.service.on_coreelec and self.measured is None
        if waits and self.service.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self.is_current(epoch):
            return
        layout = self._layout(epoch)
        if layout is None:
            return
        video_ratio = layout.video_ratio
        placing = Placing(self, epoch, layout, time.time())
        measured = self.measured
        if measured is not None:
            # A PC's followed film: the picture on screen now, the follower carrying on (Kodi's window, a distance).
            if self.following.carries_on(placing, measured[0]):
                return
            measured = self._read_finer(epoch, video_ratio, measured)
            # Placed again for another subtitle track: the shape this playback settled on, not decoded again.
            placing.place(measured[0], '%s, measured earlier in this playback' % measured[1],
                          level5=not self.level5.checked)
            return
        # A file in a shape of its own is usually cropped to its picture: that shape at once. It is
        # measured all the same, since a 4:3 or 1.85 file can hold a wider picture with black bars
        # of its own (letterboxed DVDs, older TV); without a clear answer its own shape stays.
        own_shape = measurement.own_shape(video_ratio)
        if own_shape:
            placing.place(video_ratio, 'the file\'s own shape, measuring', final=False)

        def give_up(why):
            if own_shape:
                placing.place(video_ratio, 'the file\'s own shape (%s)' % why)
            else:
                self.restore_if_current(epoch, why)

        current = lambda: self.is_current(epoch)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self.target()
        # Remembered from an earlier playback of this file (shapes.py): placed at once as the settled answer. On
        # CoreELEC that is the whole measurement (the keyframe decoding is what the memory saves); on a PC the
        # screen capture still runs, cheap, and may only widen what is remembered (a film stopped during a 16:9
        # opening would otherwise stay remembered as full-screen), or read it more exactly where a smaller window's
        # grab read its rows.
        memory = self.service.shapes.begin(target, self._length())
        with self.service.lock:             # an older epoch's thread never writes over a newer one's memory
            if not self.is_current(epoch):
                return                      # stopped or placed again while the file was read to identify it
            self.memory = memory
            # The layout in force for this epoch's placings from here on, where no write made it already: the
            # measurement whose mark lets while_measuring place again starts after it.
            self.layouts.made(epoch, layout)
        floor = None
        if self.memory.entry is None:
            kodi.log('cache: %s, measuring' % self.memory.note)
        else:
            floor = self.memory.entry.ratio
            # Rows a smaller window's grab read (the file route could not read the file then): measured again, the
            # same picture read more exactly replaces them (Measurement).
            coarse = not self.service.on_coreelec and self.service.checks.file_first and capture.finer_rows(
                capture.KodiScreen(self.service.monitor.waitForAbort), video_ratio, floor) > 0
            from_file_only = (self.service.on_coreelec or self.service.checks.file_first) and not coarse
            kodi.log('cache: found (measured %s), %s' % (
                self.memory.entry.date, 'nothing decoded' if from_file_only
                else 'measured again, its rows read in a smaller window' if coarse
                else 'the screen capture only watches for a wider picture'))
            how = 'cached (measured %s)' % self.memory.entry.date
            placing.place(floor, how)
            self.measured = (floor, how)
            if from_file_only:
                return
        first = self._early_estimate(placing, video_ratio) if floor is None and not own_shape else None
        ending = give_up if floor is None else self._keep_remembered
        keyframes = []      # what the file analysis decoded, for a Level 5 check without decoding again

        def place(ratio, how, final):
            placing.place(ratio, how, final, keyframes)
            if final:
                self.measured = (ratio, how)

        ways = self._ways(video_ratio, current, record, target, unreadable, full_pictures, keyframes,
                          watching=lambda: current() and not (self.measured is not None and self.following.places(epoch)),
                          meanwhile=first.step if first is not None else None)
        run = measurement.Measurement(ways, video_ratio, own_shape, floor, lambda: self.memory, current)
        mine = object()                     # this measurement's own mark: one per measurement, not per playback
        with self.service.lock:             # set and cleared only by the current epoch, under the lock
            if not self.is_current(epoch):
                return
            self.measuring = mine
        try:
            outcome = run.run(place)
            if outcome != measurement.SETTLED and self.measured is None:
                self.following.unsettled(epoch)        # a follower of a cached shape goes on (it settled)
            if outcome == measurement.NO_ANSWER:
                ending('no clear answer')
            elif outcome == measurement.NONE_WORKED:
                # The previous item of a playlist may have changed the margin: this one gets the person's own,
                # or the margin for the file's own shape.
                ending('not measured')
                # A file's own shape is placed as settled, and its follower watches the screen from then on.
                if floor is None and not own_shape and run.unavailable.get(SCREEN_CAPTURE) == ONLY_BLACK:
                    self._measured_once_lit(ways, video_ratio, current, place)
            elif outcome == measurement.COREELEC:
                self._coreelec_places(epoch)
        except BaseException:
            # An unexpected error: fit puts the person's margin back, and a follower of this epoch stops, or it would
            # write its own again at the next change (an early one, before any settled shape).
            self.following.unsettled(epoch)
            raise
        finally:
            with self.service.lock:
                if self.measuring is mine:  # a newer measurement keeps its own mark
                    self.measuring = None

    def _read_finer(self, epoch, video_ratio, measured):
        """measured, or its shape read again in one full-size grab where a smaller window's screen grab read its rows
        and Kodi's window allows a larger grab now (a window made full screen while nothing follows the scenes: placed
        from the window's grab, the text sat a row of 2160 under the distance). Once for each shape and size, at a
        strongly lit look; the playback's measured shape and the cache's from then on."""
        shape, how = measured
        screen = capture.KodiScreen(self.service.monitor.waitForAbort)
        rows = capture.finer_rows(screen, video_ratio, shape)
        if not rows:
            return measured
        tried = (shape.top, shape.bottom, shape.height, rows)
        if tried in self.finer_tried:
            return measured
        found = capture.read_finer(screen, video_ratio, shape)
        if found is None:
            return measured                 # no strongly lit look of it: the next placing looks again
        how = '%s, read again: bars %d/%d of %d' % (how, found.top, found.bottom, found.height)
        with self.service.lock:
            if not self.is_current(epoch):
                return measured             # a newer placing reads it again itself
            self.finer_tried.add(tried)
            if found is shape:
                return measured
            self.measured = (found, how)
        kodi.log('screen capture: picture %.2f read again in a full-size grab, bars %d/%d of %d' % (
            found, found.top, found.bottom, found.height))
        if self.memory is not None:
            self.memory.remember(found, how)
        return found, how

    def _measured_once_lit(self, ways, video_ratio, current, place):
        """Every way gave up and the screen showed nothing but black (a PC without the decoder, a film opening
        on more black than measure.SCREEN_BLACK_LIMIT grabs): one grab every SCREEN_SLOW_INTERVAL until one is clear,
        then the screen is measured again, for BLACK_WATCH seconds of black in all. A grab that gives no image ends it.
        Nothing moved meanwhile: the person's margin stays."""
        wait = self.service.monitor.waitForAbort
        screen = capture.KodiScreen(wait)
        screen_only = [way for way in ways if way[0] == SCREEN_CAPTURE]
        left = BLACK_WATCH
        while left > 0 and current():
            if wait(measure.SCREEN_SLOW_INTERVAL):
                return
            left -= measure.SCREEN_SLOW_INTERVAL
            sample = measure.look(screen, video_ratio)[3]
            if sample.reason.startswith('no image'):
                return
            if sample.clear:
                kodi.log('screen capture: a picture after the black, measuring again')
                again = measurement.Measurement(screen_only, video_ratio, False, None, lambda: self.memory, current)
                if again.run(place) != measurement.NONE_WORKED:
                    return

    def _early_estimate(self, placing, video_ratio):
        """A first estimate before the file is read, where one is to be had without reading it (the first keyframe waits
        steady.START_STEADY of smooth playback): on the box a Dolby Vision film's Level 5 as P3i reports it, live from
        the first frame (estimate.FirstEstimate, tried now and at every step of the first read's wait; returned for
        that); on a PC that reads the file first, one screen grab, placed now (None returned). The measurement confirms
        or corrects it as any estimate. Nothing on the box for image subtitles (P3i places those), without the video's
        height (the offsets count in its rows), with has.l5 0 or with Level 5 0/0 (each says the full frame, a guess: a
        scope film can carry either). Where CoreELEC places the text with Level 5, _layout has handed the playback over
        before this."""
        service = self.service
        if service.on_coreelec:
            if self.shown.kind == subtitles.IMAGE:
                return None
            reader = service.labels.reader(service.labels.video_height(), video_ratio)
            first = estimate.FirstEstimate(placing, reader, service.held, service.labels.report)
            first.step()
            return first
        if service.checks.file_first:
            picture = capture.first_look(capture.KodiScreen(service.monitor.waitForAbort), video_ratio)
            if picture is not None:
                placing.place(picture, 'one screen grab, measuring', final=False)
        return None

    def _layout(self, epoch):
        """The placement.Layout for this epoch, or None when there is nothing to do. Kodi answers no question of an
        add-on's until it finished switching to or from a window (4 s in its software renderer in the test rig):
        a window's correction waits that long here."""
        if not self.service.enabled():
            self.service.finish('turned off in settings', playback=self)
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, epoch):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self.restore_if_current(epoch, 'no subtitles')
            with self.service.lock:         # an older epoch never takes the wait over from a newer one
                if not self.is_current(epoch):
                    return None
                self.waiting = epoch
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self.claim_waiting(epoch)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self.restore_if_current(epoch, '3D video')
            return None
        if not self.service.on_coreelec:
            canvas = placement.canvas()
            with self.service.lock:
                if self.is_current(epoch):
                    self.layouts.laid_out(canvas)
        align = self.service.restores.text_position()      # the person's own, also while Manual is held
        chosen = self.layouts.choose(align, not self.service.on_coreelec)
        if chosen.area is None:
            if not (self.service.on_coreelec and self.shown.kind == subtitles.IMAGE):
                return self._position_not_handled(epoch, chosen.note, align)
            # P3i places image subtitles: Kodi's text position plays no part, their distance needs only the shape
            # (Manual would leave them at the person's bitmap margin, at no distance).
            chosen = chosen._replace(area='screen', note=None)
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self.restore_if_current(epoch, 'view mode not normal')
            return None
        if self.service.on_coreelec and self.shown.kind != subtitles.IMAGE and coreelec.places_subtitles(
                kodi.get_setting(coreelec.RESTRICT_SETTING) is True, self.service.labels,
                self.service.monitor.waitForAbort, lambda: self.is_current(epoch), kodi.log):
            self._coreelec_places(epoch)
            return None
        screen_w = kodi.number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = kodi.number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, epoch)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self.restore_if_current(epoch, 'size unknown')
            return None
        if chosen.note:
            kodi.log(chosen.note)
        return placement.Layout(chosen.area, screen_w, screen_h, video_ratio, chosen.top, chosen.manual)

    def _position_not_handled(self, epoch, what, align):
        kodi.log('subtitle position is %s, not handled' % what)
        self.restore_if_current(epoch, 'position not handled')
        if align == geometry.ALIGN_MANUAL:       # Manual only: where Kodi did not say, the position may be anything
            self.service.checks.manual_notice()
        return None

    def _wait_for(self, condition, seconds, epoch, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self.is_current(epoch):
            if condition():
                return True
            if waited >= seconds or self.service.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Worked out once per playback: its identity names the file for the decode guard, and it is what the file
        analysis reads: once, not at every placing, as each is a look at the file on a share or a question to the
        Plex server behind a transcode. An unreadable answer is not kept: asked again next time."""
        if self._target is not None:
            return self._target, None
        try:
            self._target = locate.resolve(self.service.getPlayingFile(), stat=xbmcvfs.Stat)
            return self._target, None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    @staticmethod
    def _keep_remembered(why):
        """A screen capture without an answer leaves the remembered shape in place."""
        kodi.log('cache: kept (screen capture: %s)' % why)

    def _length(self):
        """The film's length in seconds, or None when Kodi can not say."""
        try:
            return float(self.service.getTotalTime())
        except Exception:  # not playing any more, or Kodi could not say
            return None

    def min_length(self):
        """The shortest video the file analysis reads: shorter on CoreELEC, where it is the only way to measure."""
        return measure.FILM_MIN_LENGTH_ALONE if self.service.on_coreelec else measure.FILM_MIN_LENGTH

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures, keyframes=None, watching=None,
              meanwhile=None):
        """The ways of measuring for this system, in order of preference. watching(): whether the screen route still
        watches for a wider picture once settled: not once the scene follower places the text (it reads the screen
        itself, and a distance changed meanwhile then places again at once rather than as an estimate); a follower
        started at an estimate leaves the measurement running until it settles. meanwhile:
        steady's, for the file route's first read (the first estimate)."""
        def screen():
            # Every row it reads is a screen grab's (pictures.Grabbed): read again where a larger grab can be had.
            wait = self.service.monitor.waitForAbort
            with contextlib.closing(measure.screen(video_ratio, watching or current, wait, record,
                                                   capture.KodiScreen(wait))) as answers:
                for ratio, how, final in answers:
                    yield pictures.grabbed(ratio), how, final

        def from_file():
            if target is None:
                raise libav.Unavailable(unreadable)
            if not self.service.guard.allowed(target.identity):
                raise libav.Unavailable('left to Kodi after an interrupted decode')
            try:
                length = self.service.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise libav.Unavailable('playing item unknown')
            def hands_over():
                # Asked when a keyframe carries Level 5 values, with the kind shown then (a switch to an image subtitle
                # while measuring must not hand over as for a text one).
                return (self.service.on_coreelec and self.shown.kind != subtitles.IMAGE
                        and coreelec.restricts_with_level5(kodi.get_setting, self.service.labels))
            return measure.film(self.service.film(target, current, full=full_pictures), length, video_ratio, current,
                                record, level5_hands_over=hands_over, keyframes=keyframes,
                                min_length=self.min_length(),
                                ready=lambda _first: self.steady.wait(current, meanwhile))

        if self.service.on_coreelec:
            return [(FILE_ANALYSIS, from_file)]
        if self.service.checks.file_first:      # a PC with a decoder: as the box, the screen capture as the fallback
            return [(FILE_ANALYSIS, from_file), (SCREEN_CAPTURE, screen)]
        return [(SCREEN_CAPTURE, screen), (FILE_ANALYSIS, from_file)]

    def _coreelec_places(self, epoch):
        """CoreELEC's own restriction covers this playback: it was on when the playback started (a film
        carried over from an update, the hold refused, or the person switched it on during the film). CoreELEC
        places the subtitles on its own edge with the person's settings, so the add-on's margin goes back to the
        person's (a carried-over film keeps what the previous service set). Its Level 5 is corrected all the same
        (level5.Correction.after_coreelec_placed)."""
        kodi.log('CoreELEC places the subtitles with its own settings')
        self.restore_if_current(epoch, 'CoreELEC places the subtitles')
        self.level5.after_coreelec_placed(epoch)

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None


class Placing:
    """One epoch's placing: the layout _layout decided for it and when it started. place() puts a shape found on
    screen for the kind of subtitle shown and logs it (the measurement's answers, the cache, the file's own shape, the
    shape found so far); write() is the one write of a picture's settings, under the lock and only while the epoch is
    current. Once the scene follower places the text (Playback.following), estimates write nothing and the settled shape only
    confirms or stops it; the follower moves the text through write()."""

    def __init__(self, playback, epoch, layout, started):
        self.playback, self.epoch, self.layout, self.started = playback, epoch, layout, started
        self.level5_shown = None        # the picture a first estimate from Level 5 placed (estimate.FirstEstimate)

    def is_current(self):
        return self.playback.is_current(self.epoch)

    def place(self, picture_ratio, how, final=True, keyframes=None, level5=True, when=None):
        """The shape found, placed for the kind of subtitle shown (see write), then logged; a settled shape of Dolby
        Vision gets its Level 5 for the TV. keyframes: what the file analysis decoded so far (the scene verdict and the
        Level 5 check judge them instead of decoding again). when(): asked under the write's lock, False writes nothing.
        An estimate is written only while the follower does not place (asked again under the lock: one starting in
        between keeps its margin). False when nothing could be written (Kodi's margin unreadable, the epoch over, when()
        said no), so the first estimate tries again; True once placed, left to the follower or kept below Level 5."""
        playback, layout = self.playback, self.layout
        following = playback.following
        decoded = keyframes                 # for the Level 5 check: judged, never decoded again
        judged = False                      # the following's settled asked already: once per settled placing
        if following.places(self.epoch):
            if not final:
                following.measuring(self, keyframes)       # a PC's follower reads the file's keyframes as they come
                return True
            if following.settled(self, keyframes, picture_ratio):  # the verdict on every keyframe
                kodi.log('settled: picture %.2f in video %.2f on %dx%d, %s, %.1f s; placed by the scene follower' % (
                    picture_ratio, layout.video_ratio, layout.screen_w, layout.screen_h, how,
                    time.time() - self.started))
                if level5:
                    playback.level5.for_the_tv(self.epoch, keyframes)
                return True
            judged = True                                        # stopped: the settled shape is placed as before
        if not final:
            if self._below_level5(picture_ratio):
                kodi.log('estimate not placed: picture %.2f, %s; Level 5 shows %.2f on screen' % (
                    picture_ratio, how, self.level5_shown))
                following.measuring(self, keyframes)       # the early start is watched for all the same
                return True
            asked = when
            when = lambda: not following.places(self.epoch) and (asked is None or asked())  # noqa: E731
        placed = self.write(picture_ratio, when=when)
        if placed is None:
            return False
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; %s' % (
            'settled:' if final else 'first estimate:', picture_ratio, layout.video_ratio, layout.screen_w, layout.screen_h, how,
            time.time() - self.started, placed))
        if final and not judged:
            following.settled(self, keyframes, picture_ratio)
        elif not final:
            following.measuring(self, keyframes)
        if final and level5:
            playback.level5.for_the_tv(self.epoch, decoded)
        return True

    def _below_level5(self, picture_ratio):
        """Whether an estimate is a taller picture than the one Level 5 showed on screen when it placed the first
        estimate: the keyframes read so far are elsewhere in the film, and in an IMAX film the first one (a quarter in)
        can show a taller picture than the scene on screen (the corpus: 12 films, for one to three keyframes), which
        put the text into that scene's bar until a wider keyframe came. Only the settled shape, or the follower, lowers
        it then; a wider estimate lifts it at once."""
        shown = self.level5_shown
        return (shown is not None and float(picture_ratio) < float(shown)
                and not detect.same_picture((float(picture_ratio), float(shown))))

    def write(self, picture_ratio, keep=None, distances=None, when=None):
        """The settings for the kind of subtitle shown, decided under the same lock as the writes (decided before it, a
        switch in between would put the text margin under an image subtitle), only while the epoch is
        current. The end of the log line, or None when nothing could be placed or the epoch ended.

        A text subtitle: Kodi's margin for this shape. An image subtitle on a P3i build: CoreELEC places it with its
        restriction, at least the distance chosen for this shape from the picture's edge (its bitmap margin, from
        build 5212 on; older builds keep it inside the picture without a distance); "As on the disc": the
        restriction off. The text margin is the person's meanwhile. keep: the margins of a followed film's scenes, held
        on the record together (Keeper.apply); distances: the scenes' text distances (placement.scene_rule); when():
        asked under the lock as well, False writes nothing (the follower, once its epoch's following ended)."""
        return self.playback.write(self.epoch, lambda: self._settings(picture_ratio, keep, distances)
                                   if when is None or when() else None)

    @property
    def margin_placed(self):
        """The text margin of the playback's last placement (Playback.margin_placed), or None."""
        return self.playback.margin_placed

    def taken(self):
        """Whether Kodi holds the text margin this playback placed last (the scene follower's writes: a refused one is
        written again)."""
        return self.playback.service.restores.margin.holds(self.playback.margin_placed)

    def _settings(self, picture_ratio, keep, distances):
        playback, layout = self.playback, self.layout
        restores = playback.service.restores
        # The epoch's first write makes its layout in force (Layouts.made), so a refusal of Manual at it is the layout
        # in force from then on, whichever path the placing took (the file's own shape, the shape measured earlier).
        playback.layouts.made(self.epoch, layout)
        playback.picture = (layout, picture_ratio)
        if playback.shown.kind == subtitles.IMAGE:
            distances = choices.image_distances()
            full, distance = placement.image_distance(layout, picture_ratio, distances)
            chosen = p3i.plan(subtitles.IMAGE, distances, distance)
            restores.margin.restore()           # the text margin is the person's under an image subtitle (Plan.margin)
            margin = restores.for_subtitle(chosen.steps).get('bitmap')
            placed = ('as on the disc' if chosen.decided == p3i.DISC
                      else 'inside the picture (this CoreELEC has no bitmap subtitle margin)' if margin is None
                      else 'inside the picture (the bitmap subtitle margin not taken)' if margin is False
                      else '%.2f from the edge (bitmap subtitle margin %.1f %%)' % (distance, margin))
            return 'image subtitles of %s %s' % ('full-screen content' if full else 'content with black bars', placed)
        own = restores.margin.own()
        if own is None:
            kodi.log('could not read the subtitle margin, not handled')
            return None
        margin = placement.text_margin(layout, picture_ratio, distances or choices.distances(),
                                       playback.service.on_coreelec)
        manual = layout.manual is not None
        changed = restores.margin.apply(margin.value, tuple(keep or ()), manual)
        if manual and not restores.margin.manual_shown():
            # Kodi refused Manual, or the margin worked out for it (a Manual margin on the person's own position
            # puts the line far too high): their own position for the rest of the playback, placed for it now.
            kodi.log('Kodi refused its Manual position: text on the subtitle position %s for this playback'
                     % restores.margin.own_position(), always=True)
            self.layout = layout = playback.layouts.refused(layout)     # this placing's and its epoch's from now on
            manual = False
            margin = placement.text_margin(layout, picture_ratio, distances or choices.distances(),
                                           playback.service.on_coreelec)
            changed = restores.margin.apply(margin.value, tuple(keep or ()), False) or changed
        playback.margin_placed = margin.value
        if keep is not None:
            keep.add(margin.value)
        state = '' if changed else ' (unchanged)' if restores.margin.holds(margin.value) else ' (not taken by Kodi)'
        return 'margin %.2f -> %.2f%s%s (reach %.1f px, give %.1f px, %s)' % (
            own, margin.value, ' Manual' if manual else '', state, margin.reach,
            margin.give, margin.font.family if margin.font else 'font not read')
