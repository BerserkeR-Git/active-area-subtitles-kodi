"""Remembering the picture shape a file settled on, so the same file is not measured again.

What is remembered is the shape (the picture's ratio, with its bars when known and whether a screen grab read them)
and the judgements made about the file (KINDS: the Dolby Vision Level 5 judgement, the box's scene verdict, a PC's scene
map and its read-ahead's trust in Level 5); never a margin: the margin is computed from the shape and the settings at
every placement, so a changed distance, font or border, or a switch between text and image subtitles, needs nothing
forgotten.
The key is the file's content, not its address: a hash over its size and its first PROBE_BYTES, read the way the
measurement reads the file (a local open, Kodi's file access for anything it mounts, an HTTP range request for a
Plex part or a web file). The same file over NFS, SMB, a local disk or Plex gives the same key; two muxes of one
film never do. No path, host or date is stored. Every entry carries the detection code's version (a hash of its
source), so a change to the detection forgets everything on its own.

The file (picture-shapes.json in the add-on's data folder) is read at every use and written atomically
(keeper.write_record): a clear from the settings removes it, and a playback that looked it up before the clear
writes nothing more. Nothing is kept in memory between playbacks.
"""
import contextlib
import hashlib
import json
import os
import threading
import time
import urllib.parse
import urllib.request

from . import detect, follow, keeper, locate, pictures, scenemap

FILE_NAME = 'picture-shapes.json'
SCHEMA = 1
MOST_ENTRIES = 400          # files the cache holds, the oldest dropped first. Reason not recorded
# The picture ratios an entry may hold: older versions read nothing outside them, so a shape outside them (an upright
# phone video, 0.5625) is not written at all rather than written and dropped on reading.
NARROWEST, WIDEST = 1.0, 4.0
PROBE_BYTES = 64 * 1024     # the key's share of the file: another value gives every file a new key and the cache
                            # starts empty. Reason not recorded
HTTP_TIMEOUT = 10.0         # seconds a server gets to send those first bytes. Reason not recorded
DETECTOR_MODULES = ('detect.py', 'measure.py', 'ffmpeg.py', 'keyframes.py')
HERE = os.path.dirname(os.path.abspath(__file__))
LOCK_WAIT = 1.0             # seconds a writer waits for the lock file another interpreter holds
LOCK_STEP = 0.02            # seconds between two tries for the lock file. Reason not recorded
LOCK_STALE = 5.0            # a lock file older than this was left by a crash: taken over


@contextlib.contextmanager
def _locked(path):
    """The cache's lock file held while the file at path is read, changed and written, or cleared. The service's
    threads share Shapes._lock, but the Clear cache button runs in default.py's own interpreter with a Shapes of its
    own (a clear between the "cleared?" look and a write would bring the whole cache back). Made
    with O_EXCL, so one interpreter holds it at a time; one left by a crash is taken over after LOCK_STALE, and a writer
    that can not have it within LOCK_WAIT goes ahead all the same (as every write did before the lock)."""
    lock = path + '.lock'
    taken, waited = False, 0.0
    while not taken:
        try:
            folder = os.path.dirname(lock)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            os.close(os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            taken = True
        except FileExistsError:
            if waited >= LOCK_WAIT:
                try:
                    if time.time() - os.path.getmtime(lock) > LOCK_STALE:
                        os.remove(lock)
                        continue
                except OSError:
                    pass
                break
            time.sleep(LOCK_STEP)
            waited += LOCK_STEP
        except OSError:
            break               # no lock to be had here: written all the same
    try:
        yield
    finally:
        if taken:
            try:
                os.remove(lock)
            except OSError:
                pass


def detector_version(folder=HERE, modules=DETECTOR_MODULES):
    """A short hash of the detection code's source; 'unknown' when it can not be read, which is then remembered
    and trusted as a version of its own (never so while these modules ship with the add-on)."""
    digest = hashlib.sha256()
    try:
        for name in modules:
            with open(os.path.join(folder, name), 'rb') as handle:
                digest.update(name.encode() + b'\0' + handle.read() + b'\0')
    except OSError:
        return 'unknown'
    return digest.hexdigest()[:12]


def file_key(size, head):
    """The key of a file from its size and first bytes; None without either."""
    if not head or not size or size <= 0:
        return None
    return hashlib.sha256(b'%d\n' % size + head).hexdigest()[:32]


def _size_from_headers(headers, got):
    """The whole file's size from a range reply, or the length of a reply that ignored the range."""
    content_range = headers.get('Content-Range', '') if headers else ''
    if '/' in content_range:
        try:
            return int(content_range.rsplit('/', 1)[1])
        except ValueError:
            return None
    try:
        length = int(headers.get('Content-Length', '')) if headers else 0
    except ValueError:
        return None
    return length if length >= got else None


def head_of(target, opener=None, limit=PROBE_BYTES):
    """(size, first bytes) of a target as the measurement reads it, or None when it can not be read (then it can
    not be measured either). The address may carry a token: never logged."""
    if target is None:
        return None
    try:
        if target.kind == locate.DIRECT:
            scheme = urllib.parse.urlsplit(target.address).scheme.lower()
            if scheme in ('http', 'https'):
                request = urllib.request.Request(target.address, headers={'Range': 'bytes=0-%d' % (limit - 1)})
                with (opener or urllib.request.urlopen)(request, timeout=HTTP_TIMEOUT) as reply:
                    head = reply.read(limit)
                    size = _size_from_headers(reply.headers, len(head))
            else:
                with open(target.address, 'rb') as handle:
                    head = handle.read(limit)
                size = os.path.getsize(target.address)
        else:
            import xbmcvfs
            handle = xbmcvfs.File(target.address)
            try:
                size = int(handle.size())
                head = bytes(handle.readBytes(limit))
            finally:
                handle.close()
    except Exception:  # unreadable, unreachable, or Kodi could not say
        return None
    if not head or not size or size <= 0:
        return None
    return size, head


class Kind:
    """One kind of judgement the cache keeps with a file's shape.

    name: its key in the entry, and the attribute an Entry and a Memory hold it in. encode(value): what the file keeps;
    decode(data): the value back, or None when the data is not one (damaged, or written by another rule). carried: a
    new measurement of the file keeps an earlier playback's judgement of this kind (it does not depend on the shape
    measured: a scene map, the read-ahead's trust) instead of dropping it (it was judged with the shape it replaces).
    live: the value grows during the playback (a verdict the follower reads as its lists grow): the Memory keeps the
    value itself, encoded at each write; any other kind is kept as the next playback will read it. saved: the log
    line once it is written."""

    def __init__(self, name, encode, decode, carried, live, saved):
        self.name, self.encode, self.decode = name, encode, decode
        self.carried, self.live, self.saved = carried, live, saved

    def held(self, value):
        """What a Memory keeps of a value judged in its playback."""
        return value if self.live else self.decode(self.encode(value))


def _level5_data(value):
    bars, reason = value
    return {'bars': [int(bars[0]), int(bars[1])] if bars else None, 'reason': str(reason)}


def _level5_value(data):
    """((top, bottom) or None, reason) from the cache, or None when it is not one."""
    if not isinstance(data, dict) or not isinstance(data.get('reason'), str):
        return None
    bars = data.get('bars')
    if bars is None:
        return None, data['reason']
    if isinstance(bars, list) and len(bars) == 2 and all(isinstance(bar, int) for bar in bars):
        return (bars[0], bars[1]), data['reason']
    return None


def _ahead_data(value):
    return {'fits': [round(float(at), 2) for at in value['fits']], 'refused': bool(value['refused'])}


def _ahead_value(data):
    """A cached read-ahead trust ({'fits': film times, 'refused': bool}), or None when it is anything else."""
    if (not isinstance(data, dict) or not isinstance(data.get('refused'), bool)
            or not isinstance(data.get('fits'), list)
            or not all(isinstance(at, (int, float)) and not isinstance(at, bool) and at >= 0 for at in data['fits'])):
        return None
    return {'fits': [float(at) for at in data['fits']], 'refused': data['refused']}


def _scenes_value(data):
    return scenemap.SceneMap.from_data(data) if isinstance(data, dict) else None


# In the order an entry's keys are written.
KINDS = (
    Kind('level5', _level5_data, _level5_value, carried=False, live=False,
         saved='cache: Level 5 judgement saved with the shape'),
    Kind('follow', follow.Verdict.data, follow.Verdict.from_data, carried=False, live=True,
         saved='cache: checked shape saved for the next playback'),
    Kind('scenes', scenemap.SceneMap.data, _scenes_value, carried=True, live=True,
         saved='cache: scene map saved for the next playback'),
    Kind('ahead', _ahead_data, _ahead_value, carried=True, live=False,
         saved='cache: the read-ahead\'s trust in Level 5 saved for the next playback'),
)
KIND = {kind.name: kind for kind in KINDS}


class Entry:
    """What is remembered about one file."""

    def __init__(self, ratio, how, measured, level5=None, follow=None, scenes=None, ahead=None):
        self.ratio = ratio
        self.how = how
        self.measured = measured            # seconds since the epoch
        self.level5 = level5                # ((top, bottom) or None, reason), or None when never judged
        self.follow = follow                # follow.Verdict on following its scenes, or None when never judged
        self.scenes = scenes                # scenemap.SceneMap of a film that changes shape (a PC), or None
        self.ahead = ahead                  # a PC's read-ahead trust in Level 5 (lookahead.Trust.data), or None

    @property
    def date(self):
        return time.strftime('%Y-%m-%d', time.localtime(self.measured))


class Memory:
    """One playback's view of the memory: the entry found for its file (or None), and the writes it may make.
    Nothing is written for a playback that looked the file up before a clear, nor without a key."""

    def __init__(self, shapes, key, length, entry, existed):
        self.shapes, self.key, self.length, self.entry, self.existed = shapes, key, length, entry, existed
        # This playback's judgements (KINDS, Kind.held), written with every shape it remembers.
        self.level5 = None
        self.follow = None
        self.scenes = None
        self.ahead = None
        self.note = ''                      # why nothing was found, for the log ("not cached yet", "off" ...)
        self._scenes_lock = threading.Lock()   # two epochs' followers can end together (keep_scenes)

    def ahead_trust(self):
        """The read-ahead's trust in the file's Level 5 to start from (lookahead.Lookahead's trust): this playback's
        newest, else the cache's, else None (a cached playback decodes no keyframes of the measurement: without it Level
        5 would earn trust again from keyframes 30 s apart, and a dark IMAX opening would be left to the screen)."""
        if self.ahead is not None:
            return self.ahead
        return self.entry.ahead if self.entry is not None else None

    def scene_map(self):
        """The scene map a follower starts from: the newest this playback kept (an earlier epoch's, another subtitle
        track or distance), else the cache's from the playback's start, else None."""
        with self._scenes_lock:
            return self._newest_scenes()

    def keep_scenes(self, recording):
        """A follower's recording (scenemap.SceneMap) merged onto the newest map this playback kept, never the one
        that follower started from (an earlier epoch's follower may end after a later one began), and kept for the next
        playback of the file once the map shows two shapes. One at a time. True when it was written."""
        with self._scenes_lock:
            base = self._newest_scenes()
            merged = base.merged(recording) if base else recording
            if len(merged.shapes) < 2:
                return False
            return self.remember_judgement('scenes', merged)

    def _newest_scenes(self):
        if self.scenes is not None:
            return self.scenes
        return self.entry.scenes if self.entry is not None else None

    def remember(self, ratio, how):
        return self.shapes.remember(self, ratio, how)

    def remember_judgement(self, kind, value, with_shape=False):
        return self.shapes.remember_judgement(self, kind, value, with_shape)


def _kept(ratio):
    """Whether the cache keeps a shape of this ratio (NARROWEST to WIDEST), the one rule for reading and writing."""
    return NARROWEST <= float(ratio) <= WIDEST


class Shapes:

    def __init__(self, path, enabled, log, version=None, clock=time.time, opener=None, follows=False):
        self.path = path
        self.follows = follows              # scenes are followed here (CoreELEC): an entry needs a scene verdict
        self.opener = opener                # for HTTP range requests; None for urllib's own
        self.enabled = enabled              # read at every use: the setting, never cached
        self.log = log
        self.version = version or detector_version()
        self.clock = clock
        self.complained = set()             # each kind of failure is told once per service
        self._lock = threading.Lock()       # writes come from several threads (placing, checks, search, follower)

    # Reading.

    def _read(self):
        """The entries on disk, {key: entry dict}; an unreadable or malformed file counts as empty (told once)."""
        try:
            with open(self.path, encoding='utf-8') as handle:
                data = json.load(handle)
            entries = data.get('entries') if isinstance(data, dict) and data.get('schema') == SCHEMA else None
            if not isinstance(entries, dict):
                raise ValueError('not a shapes file')
            return {key: value for key, value in entries.items() if self._valid(value)}
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as why:
            self._complain('read', 'cache: not read (%s), starting afresh' % why)
            return {}

    @staticmethod
    def _valid(value):
        try:
            return (isinstance(value, dict) and _kept(value['ratio']) and isinstance(value['how'], str)
                    and float(value['measured']) > 0 and isinstance(value['version'], str))
        except (KeyError, TypeError, ValueError):
            return False

    @staticmethod
    def _entry(value):
        ratio = float(value['ratio'])
        bars = value.get('bars')
        if (isinstance(bars, list) and len(bars) == 3 and all(isinstance(bar, int) for bar in bars)
                and 0 <= bars[0] and 0 <= bars[1] and bars[0] + bars[1] < bars[2]):
            ratio = (pictures.Grabbed if value.get('grab') == bars else detect.Picture)(ratio, *bars)
        return Entry(ratio, value['how'], float(value['measured']),
                     **{kind.name: kind.decode(value.get(kind.name)) for kind in KINDS})

    def count(self):
        """The entries this version would use: another version's are refused until the cap pushes them out."""
        return sum(1 for value in self._read().values() if value['version'] == self.version)

    def begin(self, target, length):
        """A playback's Memory for its file: the key from the file's first bytes (read only while the setting is on) and
        the entry remembered for it, if its version is current, its length agrees and, where scenes are followed, it
        holds a scene verdict (one cached by a version before scene following is measured once more, so a film whose
        scenes can be followed is)."""
        if not self.enabled():
            return self._noted(Memory(self, None, length, None, False), 'off')
        found = head_of(target, self.opener) if target is not None else None
        key = file_key(*found) if found else None
        if key is None:
            return self._noted(Memory(self, None, length, None, False), 'the file could not be read to identify it')
        existed = os.path.exists(self.path)
        value = self._read().get(key) if existed else None
        memory = Memory(self, key, length, None, existed)
        if value is None:
            return self._noted(memory, 'not cached yet')
        if value.get('version') != self.version:
            return self._noted(memory, 'cached by a version that measured differently')
        if length is not None and value.get('length') is not None and abs(float(value['length']) - length) > 2.0:
            return self._noted(memory, 'the film\'s length changed')
        entry = self._entry(value)
        if self.follows and entry.follow is None:
            return self._noted(memory, 'cached before scene following')
        memory.entry = entry
        return memory

    @staticmethod
    def _noted(memory, note):
        memory.note = note
        return memory

    # Writing.

    def remember(self, memory, ratio, how):
        """The shape a playback settled on. False when nothing was written: the setting off, no key, a shape the cache
        does not keep (_kept), or the memory cleared since the playback looked it up."""
        if memory.key is None or not self.enabled():
            return False
        if not _kept(ratio):
            self.log('cache: not saved, the cache keeps pictures %.1f to %.1f wide, not %.2f' % (
                NARROWEST, WIDEST, float(ratio)))
            return False
        # One read-change-write at a time: several threads write the cache, and the Clear cache button clears it
        # from an interpreter of its own (_locked); cleared, nothing of this playback brings it back.
        with self._lock, _locked(self.path):
            if memory.existed and not os.path.exists(self.path):
                self.log('cache: not saved, the cache was cleared during this playback')
                return False
            entries = self._read()
            value = entries.get(memory.key) if entries.get(memory.key, {}).get('version') == self.version else {}
            # A shape without its bars never replaces the same picture kept with them.
            kept = not pictures.has_rows(ratio) and value.get('bars') and isinstance(value.get('ratio'), (int, float)) \
                and pictures.same(ratio, value['ratio'])
            value = dict(value, ratio=value['ratio'] if kept else round(float(ratio), 4), how=how,
                         measured=self.clock(), version=self.version, length=memory.length)
            # The picture's own bars, when the shape knows them (detect.Picture): placement uses the bar on the
            # subtitle's side, which the symmetric ratio alone cannot give back. grab: the same bars again where a
            # screen grab read them (pictures.Grabbed), so a later playback with a larger grab reads them again; a
            # version that knows no grab key keeps it as it rewrites the bars, and bars unlike it are not the grab's.
            if not kept:
                value.pop('bars', None)
                value.pop('grab', None)
            if pictures.has_rows(ratio):
                value['bars'] = [int(ratio.top), int(ratio.bottom), int(ratio.height)]
            if pictures.from_grab(ratio):
                value['grab'] = list(value['bars'])
            # A new measurement replaces the entry: a judgement made with the shape goes with it only when this
            # playback made one; a carried kind stays (value is {} for another detector version) unless this
            # playback made its own.
            for kind in KINDS:
                if not kind.carried:
                    value.pop(kind.name, None)
                made = getattr(memory, kind.name)
                if made is not None:
                    value[kind.name] = kind.encode(made)
            entries[memory.key] = value
            if not self._write(entries):
                return False
        memory.existed = True               # written: a clear from now on stops this playback's writes
        self.log('cache: saved for the next playback of this file (%d %s cached)' % (
            min(len(entries), MOST_ENTRIES), 'file' if len(entries) == 1 else 'files'))
        return True

    def remember_judgement(self, memory, name, value, with_shape=False):
        """A judgement of kind name (KINDS) onto the file's current entry: 'level5' ((top, bottom) or None, reason),
        'follow' (the scene verdict, again whenever a check or the search taught it something, so the next playback of
        the file moves there without checking), 'scenes' (a scene map), 'ahead' (the read-ahead's trust). Kept on the
        Memory either way, so a shape written later carries it; with_shape: only that (made as the shape settles,
        before it is written). False when nothing was written. A kind the cache does not know is refused (ValueError)."""
        kind = KIND.get(name)
        if kind is None:
            raise ValueError('the cache keeps no judgement of kind %r' % (name,))
        if memory.key is None or not self.enabled():
            return False
        if memory.existed and not os.path.exists(self.path):
            return False
        setattr(memory, kind.name, kind.held(value))
        if with_shape:
            return False
        with self._lock, _locked(self.path):
            entries = self._read()
            current = entries.get(memory.key)     # cleared meanwhile: no entry, nothing written (unlike remember)
            if current is None or current.get('version') != self.version:
                return False
            current[kind.name] = kind.encode(value)
            if not self._write(entries):
                return False
        self.log(kind.saved)
        return True

    def forget(self):
        """Removes every remembered shape and the file itself; the number forgotten. Waits for a write under way in
        the service (_locked: this runs in default.py's own interpreter)."""
        with self._lock, _locked(self.path):
            count = self.count()
            for path in (self.path, self.path + '.new'):
                try:
                    os.remove(path)
                except FileNotFoundError:
                    pass
                except OSError as why:
                    self._complain('remove', 'cache: not removed (%s)' % why)
        return count

    def _write(self, entries):
        if len(entries) > MOST_ENTRIES:
            newest = sorted(entries, key=lambda key: entries[key]['measured'], reverse=True)[:MOST_ENTRIES]
            entries = {key: entries[key] for key in newest}
        try:
            keeper.write_record(self.path, {'schema': SCHEMA, 'entries': entries})
            return True
        except OSError as why:
            self._complain('save', 'cache: not saved (%s)' % why)
            return False

    def _complain(self, kind, line):
        if kind not in self.complained:
            self.complained.add(kind)
            self.log(line, always=True)

