"""The HDR brightness buttons in the add-on's settings (Windows only).

Kodi draws subtitles and menus in HDR at a level set by
videoscreen.guipeakluminance, which maps to 80 * e^(0.025257 * value) nits
(WinSystemWin32.cpp, Kodi 21), unless "Use system HDR/SDR brightness
balance" hands the choice to Windows. 52 gives about 300 nits.
"""
import json
import os

import xbmcgui

from . import kodi

USE_SYSTEM = 'videoscreen.usesystemsdrpeakluminance'
PEAK = 'videoscreen.guipeakluminance'
RECOMMENDED_PEAK = 52


def _previous_path():
    return kodi.data_path('hdr_previous.json')


def apply():
    use_system, peak = kodi.get_setting(USE_SYSTEM), kodi.get_setting(PEAK)
    if use_system is None or peak is None:
        steps(kodi.text(32023))
        return
    path = _previous_path()
    # Keep the values from before the first press; a second press must not overwrite them.
    if not os.path.exists(path) and (use_system is not False or peak != RECOMMENDED_PEAK):
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump({'use_system': use_system, 'peak': peak}, handle)
    if kodi.set_setting(USE_SYSTEM, False) and kodi.set_setting(PEAK, RECOMMENDED_PEAK):
        _notify(32020)
    else:
        steps(kodi.text(32023))


def restore():
    path = _previous_path()
    try:
        with open(path, encoding='utf-8') as handle:
            previous = json.load(handle)
    except (OSError, ValueError):
        _notify(32022)
        return
    # The peak value only takes effect while the system balance is off, so set it first.
    done = kodi.set_setting(USE_SYSTEM, False)
    done = kodi.set_setting(PEAK, int(previous['peak'])) and done
    done = kodi.set_setting(USE_SYSTEM, bool(previous['use_system'])) and done
    if done:
        os.remove(path)
        _notify(32021)
    else:
        steps(kodi.text(32023))


def steps(lead=''):
    body = kodi.text(32031)
    xbmcgui.Dialog().textviewer(kodi.text(32030), (lead + '[CR][CR]' if lead else '') + body)


def _notify(string_id):
    xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(string_id), kodi.addon().getAddonInfo('icon'), 4000)
