"""Turning a picture shape into Kodi's subtitle margin setting.

Kodi's setting subtitles.marginvertical is a percentage, but for text
subtitles Kodi hands it to libass as MarginV = 10.8 * value * (1080 / 720)
on a 1080 line canvas (OverlayRenderer.cpp and DVDSubtitlesLibass.cpp,
Kodi 21). One unit of the setting therefore moves subtitles by 1.5 per cent
of the height they are laid out in: the whole screen for the "of screen"
positions, the video for the "of video" positions.
"""

MARGIN_SCALE = 1.5
MARGIN_MIN, MARGIN_MAX, MARGIN_STEP = 0.0, 50.0, 0.05

# subtitles.align values in Kodi 21.
ALIGN_MANUAL, ALIGN_BOTTOM_OF_VIDEO, ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_VIDEO, ALIGN_TOP_OF_SCREEN = range(5)


def layout_area(align):
    """'screen', 'video', or None when the position is Manual (not handled)."""
    if align in (ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_SCREEN):
        return 'screen'
    if align in (ALIGN_BOTTOM_OF_VIDEO, ALIGN_TOP_OF_VIDEO):
        return 'video'
    return None


def video_on_screen(screen_ratio, video_ratio):
    """Height of the video as a share of the screen (Kodi's normal view mode: fitted and centred)."""
    return 1.0 if video_ratio <= screen_ratio else screen_ratio / video_ratio


def bar_share(area, screen_ratio, video_ratio, picture_ratio):
    """Height of one black bar, as a share of the area subtitles are laid out in.

    Bars at the top and bottom are equal, so the same share applies to
    subtitles placed at the top.
    """
    picture_in_video = min(1.0, video_ratio / picture_ratio)
    if area == 'video':
        return (1.0 - picture_in_video) / 2
    return (1.0 - video_on_screen(screen_ratio, video_ratio) * picture_in_video) / 2


# Distances kept between the subtitles and the picture's edge, in setting units of the screen,
# as offered in the menu. Content with black bars: None or Small gap. 0.35 is about half a per
# cent of the screen height (7 to 8 px at 1440 lines); at 0 the descenders of g, j, p, q and y
# touch the edge (owner's test, 2026-10-07). Full-screen content: None, Small gap, Low, Medium,
# Standard (Kodi's own default margin), High, then Custom (any value in CUSTOM_RANGE).
EDGE_GAP = 0.35
BAR_DISTANCES = (0.0, EDGE_GAP)
FULL_DISTANCES = (0.0, EDGE_GAP, 1.5, 3.0, 4.95, 6.5)
FULL_DEFAULT, CUSTOM = 4, 6
CUSTOM_RANGE = (0.0, 10.0)
# Content counts as full-screen when each bar is at most this share of the screen's height:
# 16:9, 1.85 and 1.90 on a 16:9 screen (bars up to 3.2 %), not 2.00 (5.6 %) and wider.
FULL_SCREEN_BARS = 0.04


def bar_distance(choice):
    return BAR_DISTANCES[choice] if choice in range(len(BAR_DISTANCES)) else BAR_DISTANCES[0]


def custom_distance(value):
    """A typed distance in Kodi's steps, within CUSTOM_RANGE; None when it is not a number."""
    try:
        value = float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return None
    if value != value:      # NaN
        return None
    value = min(CUSTOM_RANGE[1], max(CUSTOM_RANGE[0], value))
    return round(round(value / MARGIN_STEP) * MARGIN_STEP, 2)


def full_distance(choice, custom):
    if choice == CUSTOM:
        typed = custom_distance(custom)
        return FULL_DISTANCES[FULL_DEFAULT] if typed is None else typed
    return FULL_DISTANCES[choice] if choice in range(len(FULL_DISTANCES)) else FULL_DISTANCES[FULL_DEFAULT]


def full_screen(screen_ratio, video_ratio, picture_ratio):
    return bar_share('screen', screen_ratio, video_ratio, picture_ratio) <= FULL_SCREEN_BARS


def margin_value(area, screen_ratio, video_ratio, picture_ratio, bars_gap, full_gap):
    """The margin setting that puts subtitles the chosen distance inside the picture.

    The distance is full_gap for full-screen content and bars_gap for content with black bars,
    measured from the picture's edge, whether the bars are in the file or added by Kodi, and
    whether the "of video" position has already lifted them above Kodi's own bars. Bars thinner
    than half a per cent (rounding between a measured and a standard shape) count as none.
    """
    gap = full_gap if full_screen(screen_ratio, video_ratio, picture_ratio) else bars_gap
    area_share = bar_share(area, screen_ratio, video_ratio, picture_ratio)
    if area_share < 0.005:
        area_share = 0.0
    # The same distance on screen: units of the "of video" positions are shares of the video's height.
    scale = video_on_screen(screen_ratio, video_ratio) if area == 'video' else 1.0
    value = (gap / scale + area_share * 100 / MARGIN_SCALE)
    value = round(value / MARGIN_STEP) * MARGIN_STEP
    return round(min(MARGIN_MAX, max(MARGIN_MIN, value)), 2)
