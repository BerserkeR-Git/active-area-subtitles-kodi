"""The settings' status section: which system was detected and how the picture is measured."""
SYSTEMS = (('System.Platform.Windows', 32090, 32097), ('System.Platform.OSX', 32091, 32097),
           ('System.Platform.Android', 32093, 32097), ('System.Platform.Linux', 32092, 32099))
GENERIC = (32096, 32097)
COREELEC, COREELEC_P3I = 32094, 32095
FILE_ANALYSIS, FILE_ANALYSIS_P3I, PAUSED = 32098, 32101, 32100
SCREEN, SCREEN_AND_FILE = 32097, 32099   # without the file fallback while it is paused


def describe(on_coreelec, p3i, decoding_allowed, condition):
    """(system string id, measurement string id)."""
    if on_coreelec:
        system = COREELEC_P3I if p3i else COREELEC
        if not decoding_allowed:
            return system, PAUSED
        return system, FILE_ANALYSIS_P3I if p3i else FILE_ANALYSIS
    for name, system, method in SYSTEMS:
        if condition(name):
            return system, SCREEN if method == SCREEN_AND_FILE and not decoding_allowed else method
    return GENERIC
