"""Small helpers around Kodi's Python and JSON-RPC interfaces."""
import contextlib
import ctypes
import json
import os
import sys
import time
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcaddon
import xbmcvfs

from . import coreelec
# Kodi's home window properties, here until the next release for the callers that still say kodi.
from .kodi_session import (HOME_WINDOW, PROCESS, SERVICE, SESSION, TAKEN, claim_held, claim_service,  # noqa: F401
                           end_session, mark_position_taken, position_taken_in, process_id, session, session_known)

ADDON_ID = 'service.activeareasubtitles'
PREFIX = '[Active Area Subtitles] '


def addon():
    return xbmcaddon.Addon(ADDON_ID)


def text(string_id):
    return addon().getLocalizedString(string_id)


def setting_bool(name, default=True):
    try:
        return addon().getSettingBool(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_int(name, default=0):
    try:
        return addon().getSettingInt(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def setting_number(name, default=0.0):
    try:
        return addon().getSettingNumber(name)
    except Exception:  # missing or malformed setting: fall back to the default
        return default


def data_path(name):
    folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    return folder + name


def picture_folder():
    """Where diagnostic pictures go: somewhere easy to reach from another computer.

    CoreELEC's Screenshots share (/storage/screenshots), else Kodi's own screenshot
    folder when one is set, else the add-on's data folder.
    """
    if coreelec.is_coreelec() and os.path.isdir('/storage/screenshots'):
        return '/storage/screenshots/'
    chosen = get_setting('debug.screenshotpath')
    if chosen:
        folder = xbmcvfs.translatePath(chosen)
        if os.path.isdir(folder):
            return os.path.join(folder, '')
    return data_path('')


stopping = lambda: False     # noqa: E731  Kodi stopping the add-on: the service puts its monitor's abortRequested here


def log(message, always=False):
    """A line in Kodi's log: always, or when Detailed logging is on. While Kodi stops the add-on (switched off,
    removed, updated) only the always lines: Kodi refuses the add-on's settings then, with an error in its own log
    (a thread logging while the add-on updates would leave one)."""
    if always or (not _stopping() and _detailed()):
        xbmc.log(PREFIX + message, xbmc.LOGINFO)


detailed = None     # Detailed logging's switch as Kodi last gave it; None: ask at the next line


def settings_changed():
    """The add-on's settings changed (or a service starts): the next detailed line reads the switch again."""
    global detailed
    detailed = None


def _detailed():
    """The switch, read from Kodi once a settings change: building the Addon and reading it for every line cost a call
    each. A read Kodi refuses is not kept: on, as the default says, and asked again at the next line."""
    global detailed
    if detailed is None:
        try:
            detailed = addon().getSettingBool('diagnostics')
        except Exception:  # missing or malformed setting, or Kodi refusing it: on, this line only
            return True
    return detailed


def _stopping():
    try:
        return stopping()
    except Exception:  # Kodi refusing its own monitor: it is going away, as stopping
        return True


def rpc(method, params=None, quiet=False):
    """Call Kodi's JSON-RPC. Returns the result, or None on an error. quiet: an error is an
    expected answer, not logged (logging asks for a setting, which Kodi refuses with an error
    of its own while the add-on is being updated or removed)."""
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception as error:  # a malformed answer, or Kodi raising (closing, say): as refused
        if not quiet:
            log('%s failed: %r' % (method, error))
        return None
    if not isinstance(reply, dict):
        return None
    if 'error' in reply:
        if not quiet:
            log('%s refused: %s' % (method, reply['error'].get('message')))
        return None
    return reply.get('result')


def addon_enabled():
    """Whether the add-on is switched on in Kodi's add-ons: True or False, or None when Kodi does not know it (while it
    installs an update or removes it) or does not say. Kodi answers this for an add-on switched off too."""
    details = rpc('Addons.GetAddonDetails', {'addonid': ADDON_ID, 'properties': ['enabled']}, quiet=True)
    addon = details.get('addon') if isinstance(details, dict) else None
    enabled = addon.get('enabled') if isinstance(addon, dict) else None
    return enabled if isinstance(enabled, bool) else None


SAVED_SETTINGS = 'special://profile/guisettings.xml'
_saved = [None]                 # while the put backs read the file once (read_once): {} until read, then its settings


def saved_setting(setting_id):
    """What Kodi's settings file holds for setting_id (its text), or None when that is not known.

    Kodi keeps settings changed through JSON-RPC in memory only and writes them to this file at a
    clean close and from its settings window (seen in Kodi 21), with every setting in it, defaults
    included. It also writes the file on its own, holding what it has in memory (in Kodi 21
    six seconds after a start, before add-on services start), so when the file was written says nothing of who chose
    what is in it. So the file, not the value in memory, says what Kodi starts with next time. Parsed once for all
    the records inside read_once."""
    once = _saved[0]
    if once is not None and 'values' in once:
        values = once['values']
    else:
        try:
            values = {}
            for node in ElementTree.parse(xbmcvfs.translatePath(SAVED_SETTINGS)).getroot().iter('setting'):
                values.setdefault(node.get('id'), node.text or '')     # the first, as Kodi reads it
        except Exception:  # missing, half written, or Kodi could not say: unknown
            values = None
        if once is not None:
            once['values'] = values
    return None if values is None else values.get(setting_id)


@contextlib.contextmanager
def read_once():
    """Kodi's settings file parsed at most once inside (saved_setting): the put backs and the look every 30 s ask it
    for every record, for weeks on a box after a close during a film. Under the
    restores' lock, the only place records are read."""
    _saved[0] = {}
    try:
        yield
    finally:
        _saved[0] = None


# Kodi has no call named for writing its settings file. Skin.Reset resets the skin setting it names and then saves
# Kodi's settings from memory (SkinBuiltins.cpp; seen in a Kodi 21.2 rig: the file followed memory, the skin's own
# settings unchanged); no skin has this one.
SAVE_SETTINGS = 'Skin.Reset(activearea.save)'
SAVE_ASKED = 'save_asked.json'     # what a save asked at a let go should change in the file, for the next start


def save_settings(settings=()):
    """Asks Kodi to write its settings file from memory. Queued, never waited for: Kodi's main thread may be waiting
    for the service to stop, and it runs the builtin once the service has stopped (the rig, Kodi 21.2). settings:
    setting ids whose values in Kodi's memory the file should hold then; those it holds otherwise now are kept in
    SAVE_ASKED, for the next start to look for (saved_as_asked)."""
    try:
        unsaved = {setting_id: [memory, saved] for setting_id, memory, saved in _unsaved(settings) if saved is not None}
        if unsaved:
            with open(data_path(SAVE_ASKED), 'w', encoding='utf-8') as handle:
                json.dump(unsaved, handle)
    except Exception:  # no record: nothing looked for at the next start
        pass
    try:
        xbmc.executebuiltin(SAVE_SETTINGS)
    except Exception:  # Kodi closing: it saves on its way out
        pass


def saved_as_asked():
    """The save the last let go asked for (save_settings), looked for once at the next start: one line in the log where
    Kodi's settings file still holds what it held before it instead of the value put back. Nothing names a save in
    Kodi, and a Kodi whose Skin.Reset no longer saves would otherwise go unnoticed. The file's stamp says nothing (Kodi
    writes it on its own)."""
    path = data_path(SAVE_ASKED)
    try:
        with open(path, encoding='utf-8') as handle:
            asked = json.load(handle)
        os.remove(path)
        still = ['%s: %s put back, %s in the file' % (setting_id, put, before)
                 for setting_id, (put, before) in sorted(asked.items()) if saved_setting(setting_id) == before]
    except Exception:  # none asked, or not readable: nothing to look for
        return
    if still:
        log('Kodi did not save its settings file when asked as the add-on let go (%s)' % ', '.join(still), always=True)


def _unsaved(settings):
    """[(setting id, its value in Kodi's memory as the file writes it, the file's text)] for each of settings the file
    holds otherwise."""
    found = []
    for setting_id in settings:
        memory, saved = get_setting(setting_id, quiet=True), saved_setting(setting_id)
        if memory is None:
            continue
        text = ('true' if memory else 'false') if isinstance(memory, bool) else str(memory)
        number_now, number_saved = number(memory), number(saved)
        same = saved == text or (not isinstance(memory, bool) and number_now is not None and number_saved is not None
                                 and abs(number_now - number_saved) < 0.005)
        if not same:
            found.append((setting_id, text, saved))
    return found


def saved_settings_text():
    """Kodi's settings file as text, or None when it can not be read (the screen calibrations, calibration.py)."""
    try:
        with open(xbmcvfs.translatePath(SAVED_SETTINGS), encoding='utf-8', errors='replace') as handle:
            return handle.read()
    except Exception:  # missing, or Kodi could not say
        return None


def running_for(seconds):
    """Whether Kodi's process has run seconds or more; None where that can not be read (_process_age)."""
    age = _process_age()
    return None if age is None else age >= seconds


def _process_age():
    """Seconds since Kodi's process started (the add-on runs inside it), or None where that can not be read. Linux
    and Android from the kernel's own clock since boot, Windows from the process's creation time; macOS: None."""
    try:
        with open('/proc/self/stat', encoding='ascii') as handle:
            ticks = int(handle.read().rsplit(')', 1)[1].split()[19])     # field 22, the start in clock ticks since boot
        with open('/proc/uptime', encoding='ascii') as handle:
            return float(handle.read().split()[0]) - ticks / os.sysconf('SC_CLK_TCK')
    except (OSError, ValueError, IndexError, AttributeError):
        pass
    if sys.platform != 'win32':
        return None
    try:
        created, ignored = ctypes.c_ulonglong(), [ctypes.c_ulonglong() for _ in range(3)]
        kernel = ctypes.windll.kernel32
        if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), ctypes.byref(created),
                                      *[ctypes.byref(value) for value in ignored]):
            return None
        return time.time() - (created.value / 1e7 - 11644473600)     # 100 ns steps since 1601
    except Exception:  # no ctypes for Windows here: unknown
        return None


def video_player(ask=None):
    """Kodi's video player's id (JSON-RPC's Player.GetActivePlayers, asked through ask, rpc unless given), or None when
    no video plays or Kodi does not say: the one lookup of it (the stream info, the subtitle watch)."""
    players = (ask or rpc)('Player.GetActivePlayers', quiet=True)
    return next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                 and entry.get('type') == 'video'), None)


def number(text):
    """A number Kodi gave as text or a value (a label, a setting), or None when it is not one."""
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def tempo():
    """Kodi's Player.PlaySpeed as a number: its tempo while the speed is 1 ("1.10"), else the speed (0 paused); None
    when Kodi can not say (nothing plays: an empty label)."""
    try:
        return number(xbmc.getInfoLabel('Player.PlaySpeed'))
    except Exception:  # Kodi could not say
        return None


def get_setting(setting_id, quiet=False):
    result = rpc('Settings.GetSettingValue', {'setting': setting_id}, quiet=quiet)
    return result.get('value') if isinstance(result, dict) else None


def set_setting(setting_id, value):
    return rpc('Settings.SetSettingValue', {'setting': setting_id, 'value': value}) is True


def holds(condition):
    """Whether a Kodi condition holds; False when Kodi could not say."""
    try:
        return xbmc.getCondVisibility(condition)
    except Exception:  # Kodi could not say
        return False
