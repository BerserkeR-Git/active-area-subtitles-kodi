"""The Keyframe record each decoded keyframe becomes, and how it is analysed and judged.

A Keyframe judges itself: analysed as the detector reads a keyframe (analyse), its Level 5 as a pair (no Level 5 in
Dolby Vision is the full frame, 0/0), whether it can judge at all (clear, sized, not uneven) and whether a Level 5 fits
its picture, at the exact edge or on the analysed rows. Its rules are part of the detector version
(shapes.DETECTOR_MODULES): the cached Level 5 judgements and scene verdicts were made with them. The film reader that
decodes keyframes (filmreader.FilmReader) is plumbing and lies outside it.
"""
from . import detect

ROWS_APART = 4           # rows of the analysed frame (288) Level 5 may be off by at the top or the bottom without an
                         # exact edge: finer is measuring precision (30 pixels at 2160)
EXACT_ROWS = 2           # rows per 1080 Level 5 may be off by from a strongly lit exact edge


class Keyframe:
    """One decoded keyframe. frame: the small grey frame (None when no keyframe came out; detail says why); detail:
    the decode's text for the log; level5: its Dolby Vision Level 5 offsets (top, bottom, left, right) or None;
    dovi: whether it carried Dolby Vision metadata at all; size: its own (width, height); at: its film time in seconds,
    None where the decoder could not say. Once analysed: sample (the analysed frame), analysed (the analysed frame's
    rows) and exact (the edge found in its own rows, or None)."""

    def __init__(self, frame, detail, level5=None, dovi=False, size=None, at=None):
        self.frame, self.detail, self.level5, self.dovi, self.size, self.at = frame, detail, level5, dovi, size, at
        self.sample = self.analysed = self.exact = None

    def analyse(self, width, height, uneven=False, faint=True):
        """Its small frame (width x height) analysed as the detector reads a keyframe (detect.analyse, uneven and faint
        as asked); True when clear (then its exact edge is worth finding)."""
        self.analysed = height
        self.sample = detect.analyse(self.frame, width, height, 3, uneven=uneven, faint=faint)
        return self.sample.clear

    @property
    def level5_pair(self):
        """Level 5 (top, bottom); Dolby Vision without Level 5 is the full frame, (0, 0). None without Dolby Vision
        metadata."""
        if self.level5 is None:
            return (0, 0) if self.dovi else None
        return tuple(self.level5[:2])

    @property
    def side_bars(self):
        return self.level5 is not None and any(self.level5[2:])

    @property
    def judgeable(self):
        """Clear, sized and with even bars: a keyframe whose picture can be held against its Level 5 (uneven bars are
        read as the taller one on both sides, not the film's own shape)."""
        return bool(self.sample is not None and self.sample.clear and self.size and self.sample.reason != 'uneven bars')

    @property
    def shape(self):
        """The analysed picture's shape in the frame's own proportions."""
        return detect.shape(self.sample, self.size[0] / self.size[1])

    @property
    def exact_picture(self):
        """The picture with its exact edge in the frame's own rows (a detect.Picture), when that edge is strongly lit;
        else None."""
        found = self.exact
        if found is None or not found.strong or not self.size:
            return None
        return detect.picture_of(found, self.size[0] / self.size[1])

    def fits(self, level5, exact=True):
        """(whether Level 5 (top, bottom) fits this keyframe's picture, the picture's bars for the log). exact: to
        EXACT_ROWS per 1080 against a strongly lit exact edge where there is one; else, and without exact, to
        ROWS_APART analysed rows (the Level 5 correction judges the analysed rows by design)."""
        height = self.size[1]
        found = self.exact
        if exact and found is not None and found.strong:
            return (max(abs(level5[0] - found.top), abs(level5[1] - found.bottom)) <= EXACT_ROWS * height / 1080,
                    '%d/%d of %d rows' % (found.top, found.bottom, height))
        sample, analysed = self.sample, self.analysed
        return (not any(abs(level5[side] * analysed / height - rows) > ROWS_APART
                        for side, rows in ((0, sample.top), (1, sample.bottom))),
                '%d/%d of %d analysed rows' % (sample.top, sample.bottom, analysed))
