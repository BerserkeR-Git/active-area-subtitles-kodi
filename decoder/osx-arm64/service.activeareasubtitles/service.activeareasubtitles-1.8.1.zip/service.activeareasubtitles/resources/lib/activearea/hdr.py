"""The HDR brightness buttons in the add-on's menu (Windows and Android).

Kodi draws subtitles and menus in HDR at the level of "GUI peak luminance in HDR PQ mode"
(videoscreen.guipeakluminance), which it has where it draws through DirectX or Android's MediaCodec. On Windows the
value maps to 80 * e^(0.025257 * value) nits (WinSystemWin32.cpp, Kodi 21), unless "Use system HDR/SDR brightness
balance" hands the choice to Windows. 25 gives about 150 nits there: just above SDR's white, so text is no longer the
brightest thing in a dark scene (52, about 300 nits, is glaring on a Windows 10 PC). Kodi's Android mapping from the
value to nits is not in the project or in the rig's Kodi, so it is not given here; 25 looked right on an Android phone
set by hand.

Kodi has the balance setting on every system but shows it only where the system has such a balance (Windows, and
there only with a build and driver that offer it), and JSON-RPC answers for a setting only while Kodi shows it (the
rig's Kodi 21 refuses to read or write the hidden one). Where Kodi does not show it (Android, a Windows without the
balance, where Kodi takes the peak alone) the buttons change and put back the peak alone, and the record holds no
balance (null). Kodi shows both only while the screen is in HDR.
"""
import json
import os


from . import kodi, question

USE_SYSTEM = 'videoscreen.usesystemsdrpeakluminance'
PEAK = 'videoscreen.guipeakluminance'
RECOMMENDED_PEAK = 25       # about 150 nits on Windows, just above SDR's white (see above)
# Where the buttons show (settings.xml and the add-on's menu): the systems whose Kodi has the peak setting.
WINDOWS, ANDROID = 'System.Platform.Windows', 'System.Platform.Android'
PLATFORMS = (WINDOWS, ANDROID)


def _previous_path():
    return kodi.data_path('hdr_previous.json')


def apply():
    peak = kodi.get_setting(PEAK)
    use_system = kodi.get_setting(USE_SYSTEM, quiet=True)      # None where Kodi does not show the balance
    if peak is None:
        steps(kodi.text(32023))
        return
    path = _previous_path()
    # Keep the values from before the first press; a second press must not overwrite them.
    if not os.path.exists(path) and (use_system not in (False, None) or peak != RECOMMENDED_PEAK):
        try:
            folder = os.path.dirname(path)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            with open(path, 'w', encoding='utf-8') as handle:
                json.dump({'use_system': use_system, 'peak': peak}, handle)
        except OSError:
            # Without a record the change could not be undone: change nothing.
            steps(kodi.text(32023))
            return
    if (use_system is None or kodi.set_setting(USE_SYSTEM, False)) and kodi.set_setting(PEAK, RECOMMENDED_PEAK):
        _notify(32020)
    else:
        steps(kodi.text(32023))


def restore():
    path = _previous_path()
    try:
        with open(path, encoding='utf-8') as handle:
            previous = json.load(handle)
        peak, use_system = int(previous['peak']), previous['use_system']
    except (OSError, ValueError, KeyError, TypeError):
        _notify(32022)
        return
    if use_system is None:                  # recorded where Kodi does not show the balance: the peak alone
        done = kodi.set_setting(PEAK, peak)
    else:
        # The peak value only takes effect while the system balance is off, so set it first.
        done = kodi.set_setting(USE_SYSTEM, False)
        done = kodi.set_setting(PEAK, peak) and done
        done = kodi.set_setting(USE_SYSTEM, bool(use_system)) and done
    if done:
        try:
            os.remove(path)
        except OSError:
            pass
        _notify(32021)
    else:
        steps(kodi.text(32023))


def steps(lead=''):
    """The manual steps: on Windows with the balance to turn off first, elsewhere the peak alone. A Windows Kodi
    that shows the peak without the balance has no balance to turn off; one that shows neither (the screen not in HDR
    now) can not tell."""
    balance = kodi.holds(WINDOWS) and (kodi.get_setting(USE_SYSTEM, quiet=True) is not None
                                       or kodi.get_setting(PEAK, quiet=True) is None)
    body = kodi.text(32031 if balance else 32032)
    question.tell((lead + '[CR][CR]' if lead else '') + body)


def _notify(string_id):
    """The outcome of a button pressed in the menu, in the add-on's own window with OK (as the steps above)."""
    question.tell(kodi.text(string_id))
