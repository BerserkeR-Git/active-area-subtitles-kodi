"""One playback, from Kodi's start of it to its end: what is known about it, and the work of placing its
subtitles, on threads of its own (the service's threads); following its scenes is labelfollow.py's on the box and
screenfollow.py's on a PC.

The service makes a Playback when Kodi starts one and drops it when it ends (Service.current). Every
thread works for one Playback and one of its epochs: placing the same playback again (another subtitle
track, another distance) starts a new epoch. Work for a playback that is no longer the current one, or for
an epoch that is no longer its newest, changes nothing (is_current). Nothing about one playback can be read
by the next: each starts with a fresh object.
"""
import time
import types

import xbmc
import xbmcvfs

from . import (calibration, capture, choices, coreelec, detect, geometry, kodi, labelfollow, layouts, level5, locate,
               measurement, p3i, placement, screenfollow, steady, subtitles)

SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CANVAS_HOLD = 0.3              # seconds Kodi's window must stay as it changed to before the text is placed again for it
                               # (a window dragged larger; the watch and the follower both look: counting their looks
                               # could be two looks milliseconds apart)
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
# The watch (see Service._watch_step) looks at the subtitle track only after a button press, early in a playback,
# and once in a while; asking costs about 0.1 ms, normal watching asks nothing at all.
WATCH_EARLY = 30.0             # seconds after the start during which it is looked at regardless
WATCH_EARLY_STEP = 2.0         # how often then
WATCH_SLOW = 30.0              # how often otherwise
# A settled shape's text margin Kodi did not read or did not take, in a film nothing follows, is written again on the
# placing's own thread before the box hands the film to CoreELEC (Placing.place).
WRITE_TRIES = 5                # tries after the first: with WRITE_STEP past a window switch (Kodi answers no add-on
                               # for up to 4 s), never long enough to keep the text in a bar for long
WRITE_STEP = 1.0               # seconds between them

# Handed to CoreELEC for its view mode alone (_not_placed): the film is the add-on's again once Normal (view_check).
VIEW_NOT_NORMAL = 'view mode not normal'
VIEW_HANDED = 'this film: %s' % VIEW_NOT_NORMAL

# A film whose measurement gave no answer, where nothing else keeps its text out of the bars (Playback.try_later), is
# read again this long after, at other positions (measurement.AGAIN_SHIFTS), the wait doubled after each try (60, 120,
# 240 s): as long as the read-ahead rests after a stall before it searches frames again, a pace the box's playback
# is known to take.
TRY_AGAIN = steady.FRAMES_QUIET


def normal_view(view):
    """Whether Kodi's view mode (Player.GetViewMode's answer) shows the video as Normal does: fitted and centred, no
    zoom, stretch, vertical shift or pixel ratio of its own. None when Kodi did not say."""
    if not (isinstance(view, dict) and view):
        return None
    return not (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001)


def watch_due(now, watch, pressed_lately):
    """Whether the watch looks at the subtitle track now: after a button press, early in the playback (a player
    add-on adds subtitles then, without a press), or once in a while (a phone remote switches without one)."""
    since = now - watch.looked
    return pressed_lately or since >= WATCH_SLOW or (now - watch.started < WATCH_EARLY and since >= WATCH_EARLY_STEP)


class Playback:

    def __init__(self, service, carried_over=False, same_film=False):
        self.service = service               # Kodi's player, the lock, the restores, the P3i policy
        self.epoch = 0                       # placed again: a new epoch of the same playback
        self.fitted = False                  # fit ran in this playback: only its first is a playlist's next video
        # Carried over from the previous service (an update during the film): its first epoch keeps what that
        # service put in place; placed again, it gets the add-on's own placement.
        self.carried_epoch = 0 if carried_over else None
        # On the monotonic clock: a system clock set back during a film would stop the timed looks.
        watched = time.monotonic()
        self.watch = types.SimpleNamespace(started=watched, looked=watched, failed=False, position_failed=False)
        self.shown = p3i.Shown()             # the kind of subtitle shown and the file's streams (P3i writes it)
        self.measured = None                 # (picture ratio, how) once its shape settled
        self.measuring = None                # the mark of the measurement running, if one is
        self.picture = None                  # (layout, picture ratio): the latest shape found
        self.level5 = level5.Correction(self)   # this playback's Level 5 correction (level5.py)
        self.memory = None                   # shapes.Memory: what is remembered for this file, once looked up
        self.waiting = None                  # the epoch that had no subtitles yet; measured once some appear
        self.tries = 0                       # reads again after no answer (try_later), at most one per AGAIN_SHIFTS
        self.again = None                    # (the service's clock when due, epoch) of the next of them
        self.finer_tried = set()             # (shape's rows, full-size grab's rows) read again once each (_read_finer)
        self._target = None                  # the playing file once worked out (target)
        # Following its scenes (followloop.Following): P3i's labels on the box, Kodi's screen on a PC.
        self.following = (labelfollow.LabelFollowing if service.on_coreelec else screenfollow.ScreenFollowing)(self)
        self.margin_placed = None            # the text margin of the add-on's last placement
        self.playing = service.playing_file()
        # What its layouts are made from and Kodi's refusal of Manual (layouts.py); made under the lock (Service.begin).
        # same_film: the add-on switched off and on in its own settings during it, so a position the person set is
        # still theirs.
        self.layouts = layouts.Layouts(self.playing, carried_over or same_film, service.restores.margin.own_position)
        # The one wait before every read of its file (steady.py), on the service's clock from Kodi's start of it.
        self.steady = steady.Steady(lambda: service.clock(), lambda: service.held(), lambda: service.last_seek,
                                    lambda: service.labels.cache_level(),
                                    lambda seconds: service.monitor.waitForAbort(seconds), kodi.log)

    def still_playing(self):
        """This is the playback now and Kodi is not closing, whichever epoch is newest: what a header read waits on,
        so another subtitle track does not cut it short."""
        return self.service.current is self and not self.service.monitor.abortRequested()

    def is_current(self, epoch):
        """Whether work for epoch may still change anything: this is the playback now, epoch its newest."""
        return epoch == self.epoch and self.still_playing()

    def write(self, epoch, change):
        """The one way this playback writes to Kodi: change() under the lock, only while epoch is current and its
        service in charge, so a stop, a newer placing or a newer start of the add-on in between keeps it from writing
        (the older start's loop sees a newer claim only at its next step). change()'s answer, or None when not current
        (a check by hand at each write, forgotten once or done outside the lock, would race with a stop)."""
        with self.service.lock:
            if not self.is_current(epoch) or not self.service.in_charge():
                return None
            return change()

    def claim_waiting(self, epoch):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.service.lock:
            if self.waiting == epoch == self.epoch and self.service.current is self:
                self.waiting = None
                return True
            return False


    def restore_if_current(self, epoch, why):
        def back():
            if epoch == self.carried_epoch:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                kodi.log('%s: what the previous service set for this video stays' % why)
            elif self.service.restores.margin.restore():
                kodi.log('%s: own subtitle margin put back' % why)
        self.write(epoch, back)

    def position_check(self):
        """The person set Kodi's subtitle position during the film, or changed its subtitle style (the watch looks, see
        Service._watch_step; a style change is placed for, the position stays as it is). The position: taken
        from Manual the add-on held, or simply not the one the layout was made with: theirs from now on, and the
        playback placed again with it, in a new epoch even while the
        first measurement runs (the layout itself changed: carrying on with the old one would hold Manual over their
        choice). Taken and the epoch moved on in one lock section, so no write of the old epoch
        lands between them."""
        style = placement.style()           # six questions to Kodi, outside the lock: only compared
        with self.service.lock:
            if not self.still_playing():
                return
            moved, restyled = self.layouts.changed(style, self.service.restores.margin)
            if not (moved or restyled):
                return
            self.epoch += 1
            epoch = self.epoch
        # A style changed in Kodi's subtitle settings moves the text's outline (a larger border at On the edge would
        # stay partly in the bar until the next placing).
        kodi.log('subtitle position set during the film: placed again with it' if moved
                 else 'subtitle style changed during the film: placed again for it')
        self.service.threads.start('placing', self.fit, epoch, True)

    def canvas_check(self):
        """Kodi's window changed size, or went to or from full screen, since the layout was made (a film started, then
        the person went to the desktop while its opening plays, and back: the text would sit in the bar once full
        screen): placed again for the window as it is now, in a new epoch, with the shape measured. Once
        the change has held for CANVAS_HOLD (a window dragged larger changes at every look), and not while the first
        measurement runs (placing again would read the file again): until it settles the text stays placed for the
        window it started in, and the first look after places it for this one. A look of a PC's watch, and of its
        scene follower at each look (placed again within a few tenths of a second): five questions to Kodi, about
        0.1 ms each."""
        now = placement.canvas()
        with self.service.lock:
            if not self.layouts.window_changed(now, self.service.clock(), self.still_playing(), CANVAS_HOLD,
                                               self.measuring is None and self.measured is not None):
                return
            self.epoch += 1
            epoch = self.epoch
        # Not whether windowed: Kodi says that a moment after the size; the layout's line does.
        kodi.log('Kodi\'s window changed (%sx%s, canvas %dx%d): placed again' % now[:4])
        self.service.threads.start('placing', self.fit, epoch, True)

    def view_check(self):
        """Kodi's view mode left Normal during the film (Zoom, Stretch, a custom zoom, a vertical shift or pixel ratio:
        the margin worked out for Normal can put the text in a bar or off the picture), or came back to it, since the
        layout was made: placed again in a new epoch, whose layout gives the margin back and hands the film over (as
        at its start, _layout) or places it for Normal. On the box a film handed over for its view mode alone is the
        add-on's again once Normal; one handed over for another reason stays with CoreELEC. A look of the watch (see
        Service._watch_step): one question to Kodi; one it does not answer is no change."""
        try:
            normal = normal_view(kodi.rpc('Player.GetViewMode', quiet=True))
            with self.service.lock:
                if not (self.still_playing() and self.layouts.view_changed(normal)):
                    return
                if normal:
                    self.shown.take_back(VIEW_HANDED)
                self.epoch += 1
                epoch = self.epoch
            kodi.log('view mode %s during the film: placed again' % ('back to Normal' if normal else 'changed'))
            self.service.threads.start('placing', self.fit, epoch, True)
        except Exception as error:  # never let a surprise disturb playback; looked at again at the next look
            kodi.log('view mode not looked at: %r' % error, always=True)

    # The work for one playback, on its own thread.

    def fit(self, epoch, again=False):
        """again: the same playback placed again for another subtitle track. Subtitles switched on later come here
        without it, in the first epoch or a later one: only the playback's first fit is a playlist's next video."""
        try:
            carried_over = epoch == self.carried_epoch
            with self.service.lock:
                first, self.fitted = not self.fitted, True
            if first and not carried_over:      # a playlist's next video: the previous one's changes go
                self.write(epoch, lambda: self.service.restores.next_video(margin=self.service.on_coreelec))
            # A playback carried over from the previous service keeps CoreELEC's restriction as it was:
            # nothing moves during an update; the next video gets the add-on's own placement. Switched off in its
            # own settings: no P3i policy either, fit_once's layout check puts the margin back.
            if (not carried_over and self.service.enabled() and self.service.p3i.offered()
                    and not self.service.p3i.by_kind(self, epoch, again)):
                return                    # an image subtitle left as on the disc: nothing to measure
            self.fit_once(epoch)
            if carried_over and self.service.enabled() and self.service.p3i.offered():
                # Placed as the previous service left it; the kind learnt afterwards, for the watch's looks only, so a
                # switch to the other kind places again.
                self.service.p3i.learn_kind(self, epoch)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self.restore_if_current(epoch, 'unexpected error')
            except Exception:
                pass
            self._surprised(epoch, 'an unexpected error')

    def while_measuring(self, epoch):
        """Another track or distance while the first measurement runs: CoreELEC's settings for the kind shown, and
        the shape found so far placed with what is chosen now."""
        try:
            # Only where P3i offers its restriction, as in fit (a distance changed while a PC measures must write
            # nothing of P3i's).
            if self.service.p3i.offered() and not self.service.p3i.by_kind(self, epoch, again=True):
                return
            picture, layout = self.picture, self.layouts.in_force(epoch)
            if picture is None or layout is None:
                return          # the epoch's own placing, started with it, lays out and places with what is chosen now
            placing = Placing(self, epoch, layout, time.time())
            if self.following.places(epoch):
                self.following.chosen_again(placing)       # the early follower places the text
            else:
                # Only while nothing newer was placed since the shape was read (the measurement settling).
                placing.place(picture[1], 'the shape found so far', final=False, when=lambda: self.picture is picture)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('subtitle track not placed: %r' % error, always=True)
            self._surprised(epoch, 'an unexpected error')

    def place_again(self, epoch):
        """The same playback placed again (another subtitle track, another distance), on a thread of its own. While its
        first measurement runs, that measurement carries on (it reads the distances and the kind at every answer) and
        the shape found so far is placed now; once settled, with that shape and its Level 5 as it is, never a second
        measurement from the first keyframe. Before the measurement starts (the waits for subtitles, the shape and
        CoreELEC's scan in _layout) there is nothing to carry on: a new epoch starts the placing over, and the old one
        ends at its next check (harmless). epoch: the one this change was judged for; an older one changes nothing. Kodi
        failing here stays here (is_current asks Kodi, which can fail inside the watch's look), and so does a placing
        that can not start: the kind shown now gets CoreELEC's settings at once (_surprised)."""
        try:
            with self.service.lock:
                if not self.is_current(epoch):
                    return
                if self.measuring is None:
                    self.epoch += 1
                    epoch = self.epoch
                    target, args = self.fit, (epoch, True)
                else:
                    target, args = self.while_measuring, (epoch,)
            self.service.threads.start('placing', target, *args)
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('not placed again: %r' % error, always=True)
            self._surprised(epoch, 'an unexpected error')

    def _surprised(self, epoch, why):
        """A placing of epoch that stopped on a surprise, on the box: CoreELEC's settings for the kind shown now at
        once, not the other kind's until the watch's next look (up to WATCH_SLOW). A subtitle only the add-on's placing
        keeps out of the bars goes to CoreELEC as for any film it can not place (_not_placed; after a switch from an
        image track the text sat at the person's margin, and that look switched the restriction off under it), unless
        it is text with the add-on's last margin still in Kodi (another distance: placed at the one before, inside the
        picture); an image one gets the restriction its plan holds (P3i.restriction_again; after a switch from text it
        stayed off)."""
        try:
            if self.shown.kind == subtitles.IMAGE or not self.service.restores.margin.holds(self.margin_placed):
                self._not_placed(epoch, why)
            # Switched off in its settings, the playback is no longer current: its write changes nothing.
            self.service.p3i.restriction_again(self, epoch, 'subtitle track not placed: CoreELEC\'s subtitle '
                                               'restriction switched %s for the subtitle shown')
        except Exception:  # Kodi failing still: the watch's next look tries again
            pass


    def fit_once(self, epoch):
        # The picture on screen first, at a PC's start; placed again with the shape measured, nothing to wait for (a
        # window changed: 1 s of the 3 to 4 s it would take on a Windows PC).
        waits = not self.service.on_coreelec and self.measured is None
        if waits and self.service.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self.is_current(epoch):
            return
        layout = self._layout(epoch)
        if layout is None:
            return
        video_ratio = layout.video_ratio
        placing = Placing(self, epoch, layout, time.time())
        measured = self.measured
        if measured is not None:
            # A PC's followed film: the picture on screen now, the follower carrying on (Kodi's window, a distance).
            if self.following.carries_on(placing, measured[0]):
                return
            measured = self._read_finer(epoch, video_ratio, measured)
            # Placed again for another subtitle track: the shape this playback settled on, not decoded again.
            placing.place(measured[0], '%s, measured earlier in this playback' % measured[1],
                          level5=not self.level5.checked)
            return
        # A file in a shape of its own is usually cropped to its picture: that shape at once. It is
        # measured all the same, since a 4:3 or 1.85 file can hold a wider picture with black bars
        # of its own (letterboxed DVDs, older TV); without a clear answer its own shape stays.
        if measurement.own_shape(video_ratio):
            placing.place(video_ratio, 'the file\'s own shape, measuring', final=False)
        target = self.target()
        memory = self.service.shapes.begin(target[0], self.service.length())
        with self.service.lock:             # an older epoch's thread never writes over a newer one's memory
            if not self.is_current(epoch):
                return                      # stopped or placed again while the file was read to identify it
            self.memory = memory
            # The layout in force for this epoch's placings from here on, where no write made it already: the
            # measurement whose mark lets while_measuring place again starts after it.
            self.layouts.made(epoch, layout)
        mine = object()                     # this measurement's own mark: one per measurement, not per playback
        marked = []

        def started():
            with self.service.lock:         # set and cleared only by the current epoch, under the lock
                if not self.is_current(epoch):
                    return False
                self.measuring = mine
                marked.append(mine)
                return True

        def settled(ratio, how):
            self.measured = (ratio, how)
        kept = []                           # why a Level 5 placement stays (_level5_stays)

        def without_answer(why):
            if self._level5_stays(placing, why):
                kept.append(why)
            else:
                self.restore_if_current(epoch, why)
        try:
            outcome = measurement.take(self.service, placing, self.following, self.steady, lambda: self.memory, target,
                                       lambda: self.shown.kind, started, settled, lambda: self.measured,
                                       without_answer, self.tries)
            if outcome.kind == measurement.COREELEC:
                self._coreelec_places(epoch)
            elif epoch != self.carried_epoch and not kept:
                # The decoder refused while measuring (checks.decoder_check), or this film gave no shape: on the box
                # CoreELEC places its subtitles as for any film that can not be measured, the restriction back as the
                # person set it (held off, the text would sit at their margin, in a scope film's bar). Where that adds
                # nothing (a PC, their own restriction off), a film without a clear answer is read again later. A film
                # carried over from the previous service keeps what it set, as at any update.
                refused = self.service.checks.decoder_refused is not None
                unanswered = None if refused else self._unanswered(outcome, video_ratio)
                if outcome.kind == measurement.NO_ANSWER and unanswered and self.service.p3i.adds_nothing():
                    self.try_later(epoch, unanswered)
                elif self.service.on_coreelec and (refused or unanswered) and self.service.p3i.offered():
                    self.service.p3i.by_kind(self, epoch, again=True, unanswered=unanswered)
        finally:
            if marked:
                with self.service.lock:
                    if self.measuring is mine:  # a newer measurement keeps its own mark
                        self.measuring = None

    def try_later(self, epoch, why):
        """A measurement of epoch without a clear answer, the text at the person's margin with nothing else to keep it out
        of a scope film's bars: the film read again TRY_AGAIN from now at other positions, the wait doubled after each
        try, at most once per measurement.AGAIN_SHIFTS (the watch starts it, try_again). Nothing is read meanwhile, and a
        newer placing measures for itself."""
        with self.service.lock:
            if self.tries >= len(measurement.AGAIN_SHIFTS) or not self.is_current(epoch):
                tried, wait = self.tries, None
            else:
                tried, wait = self.tries, TRY_AGAIN * 2 ** self.tries
                self.tries += 1
                self.again = (self.service.clock() + wait, epoch)
        if wait is None:
            kodi.log('%s: no answer after %d more reads, the person\'s margin stays for this film' % (why, tried))
        else:
            kodi.log('%s: read again at other places in the film in %d s' % (why, wait))

    def try_again(self):
        """The watch's step (Service._watch_step): the film read again once its try is due (try_later), on a thread of
        its own, as placed again for the same epoch. Only the watch clears it."""
        if self.again is None:              # every film that had an answer: nothing asked, nothing locked
            return
        with self.service.lock:
            due, epoch = self.again
            if self.service.clock() < due:
                return
            self.again = None
            if not self.is_current(epoch):
                return
        kodi.log('the film read again (try %d of %d)' % (self.tries, len(measurement.AGAIN_SHIFTS)))
        self.service.threads.start('placing', self.fit, epoch, True)

    def _level5_stays(self, placing, why):
        """A measurement that ended without an answer, where the first estimate placed the text from Level 5 (on the
        box, live from P3i) and a hand-over would leave it at the person's margin, in a scope film's bar (P3i.adds_nothing:
        their own restriction off, or none offered): True, the text stays there for this film, nothing more written. With
        their restriction on, P3i keeps the text to Level 5 itself, scene by scene: handed over (_unanswered)."""
        if placing.level5_shown is None or not self.service.p3i.adds_nothing():
            return False
        kodi.log('%s: the text stays placed from Level 5 (picture %.2f) for this film' % (why, placing.level5_shown))
        return True

    def _unanswered(self, outcome, video_ratio):
        """Why the box hands this film to CoreELEC after its measurement (measurement.Outcome), or None: it ended with
        no clear answer or no way that could read the file, and nothing placed stands for its shape (the cache's, the
        file's own shape: the text inside the picture already), with a subtitle only the add-on's placing keeps out of
        the bars (p3i.left_to_the_add_on: text, or an image one with one shape "As on the disc"). For the rest of the
        playback (P3i.unmeasurable): placed again, the film gives no answer a second time either, and the text would sit
        at the person's margin with the restriction off while it is read again. The next film is measured."""
        if outcome.kind not in (measurement.NO_ANSWER, measurement.NONE_WORKED):
            return None
        if (outcome.settled is not None or self.measured is not None or measurement.own_shape(video_ratio)
                or not p3i.left_to_the_add_on(self.shown.kind, choices.image_distances())):
            return None
        if outcome.kind == measurement.NO_ANSWER:
            return 'this film: no clear answer'
        return 'this film: %s' % ('; '.join(sorted(outcome.unavailable.values())) or 'no way of measuring worked')

    def _read_finer(self, epoch, video_ratio, measured):
        """measured, or its shape read again in one full-size grab where a smaller window's screen grab read its rows
        and Kodi's window allows a larger grab now (a window made full screen while nothing follows the scenes: placed
        from the window's grab, the text sat a row of 2160 under the distance). Once for each shape and size, at a
        strongly lit look; the playback's measured shape and the cache's from then on."""
        shape, how = measured
        screen = capture.KodiScreen(self.service.monitor.waitForAbort)
        rows = capture.finer_rows(screen, video_ratio, shape)
        if not rows:
            return measured
        tried = (shape.top, shape.bottom, shape.height, rows)
        if tried in self.finer_tried:
            return measured
        found = capture.read_finer(screen, video_ratio, shape)
        if found is None:
            return measured                 # no strongly lit look of it: the next placing looks again
        how = '%s, read again: bars %d/%d of %d' % (how, found.top, found.bottom, found.height)
        with self.service.lock:
            if not self.is_current(epoch):
                return measured             # a newer placing reads it again itself
            self.finer_tried.add(tried)
            if found is shape:
                return measured
            self.measured = (found, how)
        kodi.log('screen capture: picture %.2f read again in a full-size grab, bars %d/%d of %d' % (
            found, found.top, found.bottom, found.height))
        if self.memory is not None:
            self.memory.remember(found, how)
        return found, how

    def _layout(self, epoch):
        """The placement.Layout for this epoch, or None when there is nothing to do. Kodi answers no question of an
        add-on's until it finished switching to or from a window (4 s in its software renderer in the test rig):
        a window's correction waits that long here."""
        if not self.service.enabled():
            self.service.finish('turned off in settings', playback=self)
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, epoch):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self.restore_if_current(epoch, 'no subtitles')
            with self.service.lock:         # an older epoch never takes the wait over from a newer one
                if not self.is_current(epoch):
                    return None
                self.waiting = epoch
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self.claim_waiting(epoch)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self.restore_if_current(epoch, '3D video')
            self._not_placed(epoch, '3D video')
            return None
        if not self.service.on_coreelec:
            canvas = placement.canvas()
            with self.service.lock:
                if self.is_current(epoch):
                    self.layouts.laid_out(canvas)
        align = self.service.restores.text_position()      # the person's own, also while Manual is held
        chosen = self.layouts.choose(align, not self.service.on_coreelec)
        if chosen.area is None:
            if not (self.service.on_coreelec and self.shown.kind == subtitles.IMAGE):
                return self._position_not_handled(epoch, chosen.note, align)
            # P3i places image subtitles: Kodi's text position plays no part, their distance needs only the shape
            # (Manual would leave them at the person's bitmap margin, at no distance).
            chosen = chosen._replace(area='screen', note=None)
        view = kodi.rpc('Player.GetViewMode')
        normal = normal_view(view)
        with self.service.lock:             # what the watch's view_check compares with; unanswered: laid out as Normal
            if self.is_current(epoch):
                self.layouts.viewed(normal is not False)
        if normal is False:
            kodi.log('view mode is not normal (%s), not handled' % view)
            self.restore_if_current(epoch, VIEW_NOT_NORMAL)
            self._not_placed(epoch, VIEW_NOT_NORMAL)
            return None
        if self.service.on_coreelec and self.shown.kind != subtitles.IMAGE and coreelec.places_subtitles(
                kodi.get_setting(coreelec.RESTRICT_SETTING) is True, self.service.labels,
                self.service.monitor.waitForAbort, lambda: self.is_current(epoch), kodi.log):
            self._coreelec_places(epoch)
            return None
        screen_w = kodi.number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = kodi.number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, epoch)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self.restore_if_current(epoch, 'size unknown')
            self._not_placed(epoch, 'screen or video size unknown')
            return None
        if chosen.note:
            kodi.log(chosen.note)
        return placement.Layout(chosen.area, screen_w, screen_h, video_ratio, chosen.top, chosen.manual)

    def _not_placed(self, epoch, why):
        """On the box, a placing that stops before it places anything (_layout: 3D, a view mode other than Normal, sizes
        Kodi does not give; an unexpected error), or whose settled text margin Kodi did not read or take at any try
        (margin_missed), with a subtitle only the add-on's placing keeps out of the bars
        (p3i.left_to_the_add_on): CoreELEC places the film's subtitles as for one that can not be measured, the
        restriction back as the person set it (held off, the text would sit at their margin, in a scope film's bar).
        For the rest of the film, placed again for another reason (a track, a style) as well: the restriction would be
        held off while the layout is asked about again. The view mode alone is watched (view_check): Normal again, the
        film is the add-on's. A film carried over from the previous service keeps what it set, as at any update."""
        if not (self.service.on_coreelec and epoch != self.carried_epoch and self.service.enabled()
                and not self.shown.handed(epoch) and self.service.p3i.offered()):
            return
        if p3i.left_to_the_add_on(self.shown.kind, choices.image_distances()):
            self.service.p3i.hand_over(self, epoch, 'this film: %s' % why)

    def margin_missed(self, epoch, why):
        """Kodi did not read the text margin or did not take the add-on's at any of a settled placing's tries, and
        nothing follows the film to write it again (Placing.place): as any placing that places nothing (_not_placed)."""
        self._not_placed(epoch, why)

    def _position_not_handled(self, epoch, what, align):
        kodi.log('subtitle position is %s, not handled' % what)
        self.restore_if_current(epoch, 'position not handled')
        if align == geometry.ALIGN_MANUAL:       # Manual only: where Kodi did not say, the position may be anything
            self.service.checks.manual_notice(not self.service.on_coreelec and calibration.moves_subtitles(what))
        return None

    def _wait_for(self, condition, seconds, epoch, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self.is_current(epoch):
            if condition():
                return True
            if waited >= seconds or self.service.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Worked out once per playback: its identity names the file for the decode guard, and it is what the file
        analysis reads: once, not at every placing, as each is a look at the file on a share or a question to the
        Plex server behind a transcode. An unreadable answer is not kept: asked again next time."""
        if self._target is not None:
            return self._target, None
        playing = self.service.playing_file()
        if playing is None:                 # not playing any more, or Kodi could not say
            return None, 'playing item unknown'
        try:
            self._target = locate.resolve(playing, stat=xbmcvfs.Stat)
            return self._target, None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # an answer locate could not read
            return None, 'playing item unknown'

    def min_length(self):
        """The shortest video the file analysis reads: shorter on CoreELEC, where it is the only way to measure."""
        return measurement.min_length(self.service.on_coreelec)

    def _coreelec_places(self, epoch):
        """CoreELEC's own restriction covers this playback: it was on when the playback started (a film
        carried over from an update, the hold refused, or the person switched it on during the film). CoreELEC
        places the subtitles on its own edge with the person's settings, so the add-on's margin goes back to the
        person's (a carried-over film keeps what the previous service set). Its Level 5 is corrected all the same
        (level5.Correction.after_coreelec_placed)."""
        kodi.log('CoreELEC places the subtitles with its own settings')
        self.restore_if_current(epoch, 'CoreELEC places the subtitles')
        self.level5.after_coreelec_placed(epoch)


class Placing:
    """One epoch's placing: the layout _layout decided for it and when it started. place() puts a shape found on
    screen for the kind of subtitle shown and logs it (the measurement's answers, the cache, the file's own shape, the
    shape found so far); write() is the one write of a picture's settings, under the lock and only while the epoch is
    current. Once the scene follower places the text (Playback.following), estimates write nothing and the settled shape only
    confirms or stops it; the follower moves the text through write()."""

    def __init__(self, playback, epoch, layout, started):
        self.playback, self.epoch, self.layout, self.started = playback, epoch, layout, started
        self.level5_shown = None        # the picture a first estimate from Level 5 placed (estimate.FirstEstimate)

    def is_current(self):
        return self.playback.is_current(self.epoch)

    def place(self, picture_ratio, how, final=True, keyframes=None, level5=True, when=None):
        """The shape found, placed for the kind of subtitle shown (see write), then logged; a settled shape of Dolby
        Vision gets its Level 5 for the TV. keyframes: what the file analysis decoded so far (the scene verdict and the
        Level 5 check judge them instead of decoding again). when(): asked under the write's lock, False writes nothing.
        An estimate is written only while the follower does not place (asked again under the lock: one starting in
        between keeps its margin). False when nothing could be written (Kodi's margin unreadable, the epoch over, when()
        said no), so the first estimate tries again; True once placed, left to the follower or kept below Level 5."""
        playback, layout = self.playback, self.layout
        following = playback.following
        decoded = keyframes                 # for the Level 5 check: judged, never decoded again
        judged = False                      # the following's settled asked already: once per settled placing
        if following.places(self.epoch):
            if not final:
                following.measuring(self, keyframes)       # a PC's follower reads the file's keyframes as they come
                return True
            if following.settled(self, keyframes, picture_ratio):  # the verdict on every keyframe
                kodi.log('settled: picture %.2f in video %.2f on %dx%d, %s, %.1f s; placed by the scene follower' % (
                    picture_ratio, layout.video_ratio, layout.screen_w, layout.screen_h, how,
                    time.time() - self.started))
                if level5:
                    playback.level5.for_the_tv(self.epoch, keyframes)
                return True
            judged = True                                        # stopped: the settled shape is placed as before
        if not final:
            if self._below_level5(picture_ratio):
                kodi.log('estimate not placed: picture %.2f, %s; Level 5 shows %.2f on screen' % (
                    picture_ratio, how, self.level5_shown))
                following.measuring(self, keyframes)       # the early start is watched for all the same
                return True
            asked = when
            when = lambda: not following.places(self.epoch) and (asked is None or asked())  # noqa: E731
        # A settled text margin Kodi did not read or take is written again; an estimate's is not: the settled one comes.
        missed = [] if final else None
        placed = self.write(picture_ratio, when=when, missed=missed)
        if missed:
            placed = self._written_again(picture_ratio, when, missed)
        if placed is None:
            if missed:
                playback.margin_missed(self.epoch, 'the subtitle margin could not be read')
            return False
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; %s' % (
            'settled:' if final else 'first estimate:', picture_ratio, layout.video_ratio, layout.screen_w, layout.screen_h, how,
            time.time() - self.started, placed))
        if final and not judged:
            following.settled(self, keyframes, picture_ratio)
        elif not final:
            following.measuring(self, keyframes)
        if missed and not following.places(self.epoch):     # a follower writes it again at its next look
            playback.margin_missed(self.epoch, 'the subtitle margin not taken by Kodi')
        if final and level5:
            playback.level5.for_the_tv(self.epoch, decoded)
        return True

    def _written_again(self, picture_ratio, when, missed):
        """The settled shape written again while Kodi did not read or take its text margin (missed says so; emptied
        when a try got it in, or when the tries stopped with the playback), WRITE_TRIES times WRITE_STEP apart on this
        placing's own thread. The end of the last write's log line, or None."""
        placed = None
        for _ in range(WRITE_TRIES):
            del missed[:]
            if self.playback.service.monitor.waitForAbort(WRITE_STEP):
                return None
            placed = self.write(picture_ratio, when=when, missed=missed)
            if not missed:
                break
        return placed

    def _below_level5(self, picture_ratio):
        """Whether an estimate is a taller picture than the one Level 5 showed on screen when it placed the first
        estimate: the keyframes read so far are elsewhere in the film, and in an IMAX film the first one (a quarter in)
        can show a taller picture than the scene on screen (the corpus: 12 films, for one to three keyframes), which
        put the text into that scene's bar until a wider keyframe came. Only the settled shape, or the follower, lowers
        it then; a wider estimate lifts it at once."""
        shown = self.level5_shown
        return (shown is not None and float(picture_ratio) < float(shown)
                and not detect.same_picture((float(picture_ratio), float(shown))))

    def write(self, picture_ratio, keep=None, distances=None, when=None, missed=None):
        """The settings for the kind of subtitle shown, decided under the same lock as the writes (decided before it, a
        switch in between would put the text margin under an image subtitle), only while the epoch is
        current. The end of the log line, or None when nothing could be placed or the epoch ended.

        A text subtitle: Kodi's margin for this shape. An image subtitle on a P3i build: CoreELEC places it with its
        restriction, at least the distance chosen for this shape from the picture's edge (its bitmap margin, from
        build 5212 on; older builds keep it inside the picture without a distance); "As on the disc": the
        restriction off. The text margin is the person's meanwhile. keep: the margins of a followed film's scenes, held
        on the record together (Keeper.apply); distances: the scenes' text distances (placement.scene_rule); when():
        asked under the lock as well, False writes nothing (the follower, once its epoch's following ended). Nothing
        once the epoch is handed to CoreELEC (p3i.P3i.hand_over). missed: a list, given an entry when a text margin was
        to be written and Kodi did not read the margin or did not take the add-on's (Placing.place writes it again)."""
        return self.playback.write(self.epoch, lambda: self._settings(picture_ratio, keep, distances, missed)
                                   if (when is None or when()) and not self.playback.shown.handed(self.epoch) else None)

    @property
    def margin_placed(self):
        """The text margin of the playback's last placement (Playback.margin_placed), or None."""
        return self.playback.margin_placed

    def taken(self):
        """Whether Kodi holds the text margin this playback placed last (the scene follower's writes: a refused one is
        written again)."""
        return self.playback.service.restores.margin.holds(self.playback.margin_placed)

    def _settings(self, picture_ratio, keep, distances, missed=None):
        playback, layout = self.playback, self.layout
        restores = playback.service.restores
        # The epoch's first write makes its layout in force (Layouts.made), so a refusal of Manual at it is the layout
        # in force from then on, whichever path the placing took (the file's own shape, the shape measured earlier).
        playback.layouts.made(self.epoch, layout)
        playback.picture = (layout, picture_ratio)
        if playback.shown.kind == subtitles.IMAGE:
            distances = choices.image_distances()
            full, distance = placement.image_distance(layout, picture_ratio, distances)
            chosen = p3i.plan(subtitles.IMAGE, distances, distance)
            restores.margin.restore()           # the text margin is the person's under an image subtitle (Plan.margin)
            margin = restores.for_subtitle(chosen.steps).get('bitmap')
            placed = ('as on the disc' if chosen.decided == p3i.DISC
                      else 'inside the picture (this CoreELEC has no bitmap subtitle margin)' if margin is None
                      else 'inside the picture (the bitmap subtitle margin not taken)' if margin is False
                      else '%.2f from the edge (bitmap subtitle margin %.1f %%)' % (distance, margin))
            return 'image subtitles of %s %s' % ('full-screen content' if full else 'content with black bars', placed)
        own = restores.margin.own()
        if own is None:
            kodi.log('could not read the subtitle margin, not handled')
            if missed is not None:
                missed.append('unreadable')
            return None
        margin = placement.text_margin(layout, picture_ratio, distances or choices.distances(),
                                       playback.service.on_coreelec)
        manual = layout.manual is not None
        changed = restores.margin.apply(margin.value, tuple(keep or ()), manual)
        if manual and not restores.margin.manual_shown():
            # Kodi refused Manual, or the margin worked out for it (a Manual margin on the person's own position
            # puts the line far too high): their own position for the rest of the playback, placed for it now.
            kodi.log('Kodi refused its Manual position: text on the subtitle position %s for this playback'
                     % restores.margin.own_position(), always=True)
            self.layout = layout = playback.layouts.refused(layout)     # this placing's and its epoch's from now on
            manual = False
            margin = placement.text_margin(layout, picture_ratio, distances or choices.distances(),
                                           playback.service.on_coreelec)
            changed = restores.margin.apply(margin.value, tuple(keep or ()), False) or changed
        playback.margin_placed = margin.value
        if keep is not None:
            keep.add(margin.value)
        state = '' if changed else ' (unchanged)' if restores.margin.holds(margin.value) else ' (not taken by Kodi)'
        if missed is not None and not restores.margin.holds(margin.value):
            missed.append('not taken')
        return 'margin %.2f -> %.2f%s%s (reach %.1f px, give %.1f px, %s)' % (
            own, margin.value, ' Manual' if manual else '', state, margin.reach,
            margin.give, margin.font.family if margin.font else 'font not read')
