"""The Level 5 correction for one playback ("Correct faulty Dolby Vision Level 5", off by default, CoreELEC only):
whether it is wanted, the judge (measure.level5_correction, or the remembered verdict), override.ini, the wait past
the start, and the write of CoreELEC's override through the playback's own write.

Three ways in, one per reason the playback reaches it. Each asks the setting and whether CoreELEC's handling is on
(_handling_on) before anything is decoded; for the TV also the video's Dolby Vision label; for image subtitles left
as on the disc the label, and not twice in a playback. Clearing the correction is the restores' job (Restores.fix_off, finish, next_video).
"""

import xbmc
import xbmcvfs

from . import kodi, measure, override

HDR_TYPE = 'Player.Process(video.source.hdr.type)'
LEVEL5_EARLIEST = 3.0          # seconds after the start before a Level 5 correction is written


def enabled():
    """"Correct faulty Dolby Vision Level 5" switched on; the one place the setting is read."""
    return kodi.setting_bool('fix_level5', default=False)


class Correction:

    def __init__(self, playback):
        self.playback = playback             # its target, memory, start time, is_current and write; its service
        self.checked = False                 # judged for this playback: not decoded again when a track change places again
        self.applied = False                 # this playback's correction is CoreELEC's override (set under the write's lock)

    def after_coreelec_placed(self, epoch):
        """CoreELEC places the subtitles from the film's Level 5 (reported at the start, or values later in the
        film): a wrong or flickering one is corrected all the same."""
        if self.playback.is_current(epoch) and enabled() and _handling_on():
            self._correct(epoch)

    def for_the_tv(self, epoch, keyframes=None):
        """Dolby Vision the add-on places itself, with CoreELEC's Level 5 handling on (its override is only readable
        then): the TV gets the corrected Level 5 too. keyframes: what measuring decoded, judged instead of decoding
        again."""
        if not (self.playback.service.on_coreelec and enabled() and xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision'):
            return
        if _handling_on():
            self._correct(epoch, keyframes)

    def for_the_disc(self, epoch, again):
        """Image subtitles left as on the disc, nothing measured: a Dolby Vision film's picture signal to the TV
        still gets right Level 5. again: placed again for another track, judged already unless the first time
        found nothing to judge."""
        if xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision' and not (again and self.checked):
            self.after_coreelec_placed(epoch)

    def _correct(self, epoch, keyframes=None):
        """True when CoreELEC now has the picture's edges from an override: this one, or override.ini's."""
        applied = self._check(epoch, keyframes)
        if self.playback.is_current(epoch):
            self.checked = True
        return applied

    def _apply(self, service, known):
        """The correction written, with the lock held (Playback.write)."""
        self.applied = service.restores.override.apply(known) or self.applied
        return self.applied

    def _check(self, epoch, keyframes):
        playback = self.playback
        service = playback.service
        target, unreadable = playback.target()
        if target is None:
            kodi.log('Level 5 not checked: %s' % unreadable)
            return
        if override.set_by_override_ini(target.address, _read_text):
            kodi.log('Level 5 left alone: override.ini supplies it for this folder')
            return True
        if service.labels.scan_state() == '3':
            # CoreELEC only scans films without Level 5 of their own: nothing to correct.
            kodi.log('Level 5 left alone: CoreELEC measured this film itself')
            return
        memory = playback.memory
        remembered = memory.entry.level5 if memory is not None and memory.entry is not None else None
        if remembered is not None:
            correction, reason = remembered[0], '%s (cached)' % remembered[1]
        else:
            if not service.guard.allowed(target.identity):
                kodi.log('Level 5 not checked: left to Kodi after an interrupted decode')
                return
            try:
                current = lambda: playback.is_current(epoch)      # noqa: E731
                film, length = service.film(target, current), service.length()
                if length is None:
                    raise measure.Unavailable('playing item unknown')
                correction, reason = measure.level5_correction(
                    film, length, current, keyframes=keyframes, min_length=playback.min_length(),
                    ready=lambda _first: playback.steady.wait(current))
            except Exception as error:  # Unavailable (Kodi could not say, too), or a surprise: never a reason to stop
                kodi.log('Level 5 not checked: %s' % error)
                return
            if memory is not None and playback.is_current(epoch):
                memory.remember_judgement('level5', (correction, reason))
        if not playback.is_current(epoch):
            return
        kodi.log('Level 5 check: %s' % reason)
        known = override.value_for(*correction) if correction else ''
        if not known:
            return
        # P3i's per-folder override add-on writes the same setting from override.ini at the start
        # of playback, and saves what it found there to put back afterwards: never write before it. On the service's
        # clock from Kodi's start of the playback, as every other wait of a playback.
        wait = playback.steady.begun + LEVEL5_EARLIEST - service.clock()
        if wait > 0 and service.monitor.waitForAbort(wait):
            return
        # Asked again under the write's lock: switched off during the decode, the settings change found nothing to
        # clear yet (Restores.fix_off takes the same lock).
        applied = playback.write(epoch, lambda: self._apply(service, known) if enabled() else None)
        if applied is None:
            return
        if applied:
            kodi.log('Level 5 corrected for CoreELEC: %s' % known, always=True)
        else:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 override holds another value '
                     '(override.ini, or another add-on)', always=True)
        return applied


def _handling_on():
    """CoreELEC's Level 5 handling on: its override is readable only then, and nothing can be corrected without it.
    Asked before anything is decoded on every path (otherwise the disc's and CoreELEC's own placing would decode
    keyframes, then log that the override held another value)."""
    if kodi.get_setting(override.SETTING, quiet=True) is None:
        kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 handling is off')
        return False
    return True


def _read_text(path):
    """A small text file's contents, through Kodi's file access (local and network folders), or None."""
    try:
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:  # unreadable: as if there were none
        return None
