"""The P3i policy: which kind of subtitle Kodi shows, and CoreELEC's own settings for it.

The add-on places every text subtitle itself, with Kodi's margin; only CoreELEC can move an image subtitle
(PGS, DVD, DVB), with P3i's "Restrict subtitles to active picture" and its bitmap margin. So P3i's restriction
is held off while nothing plays and for text, switched on while an image subtitle shows, and left off for one
the person keeps "As on the disc". This module decides that and looks up the kind; the writes themselves
belong to the restores (restores.py), done through the playback they are for (Playback.write).
"""
import collections

import xbmcvfs

from . import coreelec, geometry, kodi, level5, subtitles
from .choices import image_distances

TEXT, DISC, IMAGE, COREELEC = 'text', 'as on the disc', 'image', 'coreelec'
BEFORE_SHAPE = 'before the shape'      # plan's distance while the film's shape is not known yet


class Shown:
    """What P3i knows about the subtitle one playback shows: its kind (subtitles.IMAGE, TEXT or None before the
    first look), the track the watch saw last, and the file's own subtitle streams (identity, streams, whether
    FFmpeg opened the file), read once per playback. A playback holds one; only this module writes it."""

    def __init__(self):
        self.kind = None
        self.track = None
        self.streams = (None, None, False)


def decide(kind, distances):
    """TEXT (the add-on places it), DISC (left as on the disc, nothing measured) or IMAGE (CoreELEC places it) for a
    subtitle of kind (None: not known to be an image), with distances the image distances for both shapes."""
    if kind != subtitles.IMAGE:
        return TEXT
    if all(distance is geometry.DISC for distance in distances):
        return DISC
    return IMAGE


# P3i's settings and Kodi's text margin for the subtitle shown. decided: TEXT, DISC, IMAGE or COREELEC (nothing can be
# measured: the person's own values, CoreELEC places every subtitle). steps: what is written, in this order, each
# (setting, value, the log line when it changed or None): 'restriction' 'off' or 'on' (held), 'own' (the person's);
# 'bitmap' 'own' or a distance from the picture's edge (P3i's bitmap margin for it). margin: 'ours' (the add-on
# places the text) or 'own' (the person's text margin back).
Plan = collections.namedtuple('Plan', 'decided steps margin')
_ON = ('restriction', 'on', 'CoreELEC\'s subtitle restriction switched on for an image subtitle')


def plan(kind, distances, distance=BEFORE_SHAPE, measurable=True):
    """The Plan for a subtitle of kind (None: not known to be an image) with distances the image distances for both
    shapes; distance: the one for the film's shape once it is known (placement.image_distance), BEFORE_SHAPE until then.
    The restriction set before the shape is known is never undone by the shape: with one shape "As on the disc" it waits
    for the shape (rather than going on, then off again a second later for a film of that shape)."""
    if not measurable:
        return Plan(COREELEC, (('bitmap', 'own', None), ('restriction', 'own', None)), 'own')
    decided = decide(kind, distances)
    if decided == TEXT:
        return Plan(TEXT, (('bitmap', 'own', 'text subtitle: CoreELEC\'s bitmap subtitle margin put back'),
                           ('restriction', 'off', None)), 'ours')
    if distance is BEFORE_SHAPE:
        if decided == DISC:
            return Plan(DISC, (('restriction', 'off', None), ('bitmap', 'own', None)), 'own')
        if any(each is geometry.DISC for each in distances):
            return Plan(IMAGE, (), 'own')
        return Plan(IMAGE, (_ON,), 'own')
    if distance is geometry.DISC:
        return Plan(DISC, (('restriction', 'off', None), ('bitmap', 'own', None)), 'own')
    return Plan(IMAGE, (_ON, ('bitmap', distance, None)), 'own')


class P3i:

    def __init__(self, service):
        self.service = service               # on CoreELEC or not, the restores, Kodi's player, the decode guard

    def offered(self):
        """True on a CoreELEC build that offers P3i's subtitle restriction (it is readable only there)."""
        return self.service.on_coreelec and kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is not None

    def hold(self):
        """P3i's restriction off while the add-on is on: the add-on places text subtitles itself; image subtitles
        have it on while they show (plan, Restores.for_subtitle). Nothing is written elsewhere."""
        if not (self.service.on_coreelec and self.service.enabled()):
            return
        if not self.service.checks.ffmpeg_usable:   # nothing can be measured: CoreELEC places every subtitle itself
            self.service.restores.release_all('nothing can be measured on this box')
            return
        self._held(self.service.restores.hold())
        self.hold_detection()

    def hold_detection(self):
        """P3i's detection settings for the next playback (restores.Detection): its subtitle scan only while an image
        distance is chosen, its Dolby Vision scan off while the add-on corrects Level 5."""
        if not (self.service.on_coreelec and self.service.enabled() and self.service.checks.ffmpeg_usable):
            return
        self.service.restores.hold_detection(any(distance is not geometry.DISC for distance in image_distances()),
                                             level5.enabled())

    def _held(self, switched):
        """After a hold: told once when the person's own "on" was switched off just now."""
        if switched:
            kodi.log('CoreELEC\'s subtitle restriction switched off: the add-on places text subtitles itself',
                     always=True)
            self.service.checks.restrict_notice()

    def unmeasurable(self, playback):
        """Why the playing file can not be measured on this box, or None. CoreELEC is measured only from the file."""
        if not self.service.checks.ffmpeg_usable:
            return 'CoreELEC\'s FFmpeg can not be used'
        target, unreadable = playback.target()
        if target is None:
            return unreadable
        if not self.service.guard.allowed(target.identity):
            return 'left to Kodi after an interrupted decode'
        self.file_streams(playback, target)                 # read once per playback, the kind lookup reuses it
        if not playback.shown.streams[2]:
            # Not opened at all. Streams that could not be read in a file that opened (a stream layout this
            # add-on does not know) still leave the picture measurable: an unknown kind, placed as text.
            return 'the file could not be opened'
        return None

    def subtitle_track(self):
        """(index, shown) of Kodi's current subtitle track, None when Kodi does not say; only that
        track asked for, never the list (a remux can carry dozens)."""
        player = kodi.video_player()
        if player is None:
            return None
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None
        return (found.get('currentsubtitle') or {}).get('index'), bool(found.get('subtitleenabled'))

    def by_kind(self, playback, epoch, again=False):
        """CoreELEC's settings for the kind of subtitle shown in playback, and whether to measure and place.
        Text (or a kind not known to be an image): the restriction held off, the add-on places it. An image
        subtitle, which only CoreELEC can move: the person's own margin back, the restriction on at once when
        every shape gets a distance (with one shape "As on the disc", once the shape is known), then measured for
        the distance its shape gets (bitmap margin); with both image distances "As on the disc" the restriction
        stays off and nothing is measured (False)."""
        restores = self.service.restores
        unmeasurable = self.unmeasurable(playback)
        if unmeasurable is not None:
            # Holding the restriction off would leave text at the person's margin (in the bar of a scope film) and
            # image subtitles unrestricted: worse than no add-on. CoreELEC places both, as without the add-on.
            kodi.log('nothing can be measured (%s): CoreELEC places the subtitles as you set it' % unmeasurable)
            done = playback.write(epoch, lambda: restores.for_subtitle(plan(None, (), measurable=False).steps))
            if done and done['restriction']:
                kodi.log('CoreELEC\'s subtitle restriction back as you set it, for this video')
            playback.restore_if_current(epoch, 'nothing can be measured')
            return False
        found = self.learn_kind(playback, epoch)
        if found is None:
            return False
        kind, why = found
        chosen = plan(kind, image_distances())
        kodi.log('%s subtitle (%s): the add-on places it' % ('text' if kind else 'unknown kind of', why)
                 if chosen.decided == TEXT else 'image subtitle (%s): left as on the disc' % why
                 if chosen.decided == DISC else 'image subtitle (%s): CoreELEC places it' % why)
        # Through the playback's own write, not the idle hold: with a playlist skip just before the hold the old film's
        # thread would switch the restriction off after the new film switched it on for an image subtitle. With one
        # shape "As on the disc" nothing is written before the shape (Placing.write).
        done = playback.write(epoch, lambda: restores.for_subtitle(chosen.steps)) if chosen.steps else None
        if chosen.decided == TEXT:
            self._held(done and done['restriction'])
            return True
        playback.restore_if_current(epoch, 'image subtitle')    # the text margin does not apply to it
        if chosen.decided == DISC:
            playback.level5.for_the_disc(epoch, again)   # the picture signal to the TV still gets right Level 5
            return False
        return True

    def learn_kind(self, playback, epoch):
        """The kind of subtitle shown and its track, kept on the playback for the watch's looks: (kind, why), or None
        when epoch is no longer current. Also for a playback carried over from the previous service, where nothing is
        written to CoreELEC (without the kind the watch never looks, and a switch to an image subtitle would leave the
        restriction off and no bitmap margin for the rest of the film)."""
        shown = playback.shown
        track = self.subtitle_track()       # before the kind: a switch in between is seen
        kind, why = self.subtitle_kind(playback)

        def seen():
            shown.kind = kind or subtitles.TEXT
            if track is not None:
                shown.track = track         # the watch's first look then has nothing new to judge
            return True
        if playback.write(epoch, seen) is None:     # checked and written together: an older epoch never writes
            return None                             # over a newer one's kind
        return kind, why

    def looked(self, playback, epoch):
        """The watch's look at the subtitle track (see Service._watch_step): placed again when the track changed to
        one of the other kind. Judged here, one look after another, so the newest switch always wins (someone
        switching back and forth); only the placing runs on its own thread."""
        track = self.subtitle_track()
        if track is not None and track != playback.shown.track:
            playback.shown.track = track
            self.subtitle_changed(playback, epoch)

    def subtitle_changed(self, playback, epoch):
        """Another subtitle track during playback: placed again (on a thread of its own) when it is now
        of the other kind, with the shape measured for this playback and its Level 5 as it is."""
        try:
            if playback.shown.kind is None or not self.offered():
                return
            kind = self.subtitle_kind(playback)[0] or subtitles.TEXT
            if not (playback.is_current(epoch) and playback.shown.kind is not None and kind != playback.shown.kind):
                return
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('subtitle track not looked at: %r' % error, always=True)
            return
        kodi.log('subtitle track changed to %s: placed again' % ('an image' if kind == subtitles.IMAGE else 'text'))
        playback.shown.kind = kind          # the next look compares with this, even before the placing starts
        playback.place_again(epoch)         # the epoch judged here, not one read again

    def subtitle_kind(self, playback):
        """(subtitles.IMAGE, TEXT or None, why) for the current subtitle, from Kodi's list and the file's own
        subtitle streams (read once per playback)."""
        player = kodi.video_player()
        if player is None:
            return None, 'no video player'
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['subtitles', 'currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None, 'Kodi did not say'
        if not found.get('subtitleenabled'):
            return subtitles.TEXT, 'subtitles off'
        listed = [entry for entry in found.get('subtitles') or [] if isinstance(entry, dict)]
        current = (found.get('currentsubtitle') or {}).get('index')
        target, _unreadable = playback.target()
        return subtitles.current_kind(listed, current, self.file_streams(playback, target), self.sidecars())

    def file_streams(self, playback, target):
        """The playing file's own subtitle streams, or None when they can not be read (read once per playback)."""
        if target is None:
            return None
        if playback.shown.streams[0] == target.identity:
            return playback.shown.streams[1]
        streams, opened = None, False
        if self.service.guard.allowed(target.identity):
            # Not lowered in priority: a header read, and it can run on the service's own thread (the watch).
            # A slow share stops being read once the playback is gone (a read stalled inside Kodi still waits).
            # The stream structures are read through ctypes as well: guarded like a decode (the reader does), so a
            # layout this add-on misjudges leaves the file to Kodi after one crash instead of crashing it at every play.
            reader = self.service.film(target, playback.still_playing, background=False)
            began = self.service.clock()
            try:
                streams = reader.streams()
                kodi.log('subtitle streams read: %d in the file (%.1f s)' % (len(streams or ()),
                                                                             self.service.clock() - began))
            except Exception as error:  # unreadable here: the kind stays unknown
                kodi.log('subtitle streams not read: %s' % error)
            opened = reader.opened
        playback.shown.streams = (target.identity, streams, opened)
        return streams

    def sidecars(self):
        """subtitles.IMAGE or TEXT for the subtitle files next to the playing video, None when mixed or unknown."""
        try:
            playing = self.service.getPlayingFile().partition('|')[0]
            if '://' in playing and playing.split('://')[0] not in ('smb', 'nfs', 'file'):
                return None             # a web address (a Plex server): no folder to look in
            folder, name = playing.replace('\\', '/').rsplit('/', 1)
            return subtitles.sidecar_kind(xbmcvfs.listdir(folder + '/')[1], name)
        except Exception:  # not playing any more, or the folder can not be listed
            return None
