"""The add-on's own menu: a wide window with the status at the top, the switches and buttons in a
list, and the focused row's explanation at the bottom. The values live in Kodi's add-on settings,
so the service and Kodi's own settings window see the same thing."""
import xbmc
import xbmcgui

from . import hdr, kodi

WINDOW = 'activearea-menu.xml'
TITLE, SYSTEM_LABEL, SYSTEM_VALUE, METHOD_LABEL, METHOD_VALUE, LIST = 10, 21, 22, 23, 24, 100
CLOSE_ACTIONS = (10, 92)        # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
COREELEC_CONDITION = 'System.HasAddon(service.coreelec.settings)'
WINDOWS_CONDITION = 'System.Platform.Windows'
ON, OFF, VERSION = 32104, 32105, 32106


class Row:

    def __init__(self, key, label, help_text, switch=False):
        self.key, self.label, self.help, self.switch = key, label, help_text, switch


def rows(setting_bool, condition):
    """The menu's rows for this device, in order. Switches carry a setting id as key."""
    found = [Row('enabled', 32002, 32003, switch=True)]
    if condition(COREELEC_CONDITION) and setting_bool('enabled'):
        found += [Row('coreelec_gap', 32107, 32108, switch=True), Row('fix_level5', 32102, 32103, switch=True)]
    if condition(WINDOWS_CONDITION):
        found += [Row('hdr_apply', 32011, 32012), Row('hdr_restore', 32013, 32014), Row('hdr_steps', 32015, 32016)]
    found += [Row('diagnostics', 32004, 32005, switch=True), Row('check_updates', 32051, 32052)]
    return found


def value(row, setting_bool, version):
    """What the row shows on its right."""
    if row.switch:
        return kodi.text(ON if setting_bool(row.key) else OFF)
    if row.key == 'check_updates':
        return kodi.text(VERSION).format(version)
    return ''


def _setting_bool(name):
    return kodi.setting_bool(name, default=name == 'enabled')


class Menu(xbmcgui.WindowXMLDialog):

    def onInit(self):
        self.after = None       # an action that needs the menu closed first
        self.fill()
        self.setFocusId(LIST)

    def fill(self, position=0):
        addon = kodi.addon()
        version = addon.getAddonInfo('version')
        self.getControl(TITLE).setLabel('%s %s' % (kodi.text(32000), version))
        for label, shown, string_id, setting_id in ((SYSTEM_LABEL, SYSTEM_VALUE, 32081, 'status_system'),
                                                    (METHOD_LABEL, METHOD_VALUE, 32082, 'status_method')):
            self.getControl(label).setLabel(kodi.text(string_id))
            self.getControl(shown).setLabel(addon.getSetting(setting_id))
        self.rows = rows(_setting_bool, xbmc.getCondVisibility)
        listing = self.getControl(LIST)
        listing.reset()
        for row in self.rows:
            item = xbmcgui.ListItem(kodi.text(row.label), value(row, _setting_bool, version))
            item.setProperty('help', kodi.text(row.help))
            listing.addItem(item)
        listing.selectItem(min(position, len(self.rows) - 1))

    def onClick(self, control_id):
        if control_id != LIST:
            return
        position = self.getControl(LIST).getSelectedPosition()
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        if row.switch:
            kodi.addon().setSettingBool(row.key, not _setting_bool(row.key))
        elif row.key == 'check_updates':
            self.after = row.key            # it may open Kodi's list of updates: closed first
            self.close()
            return
        else:
            getattr(hdr, row.key[len('hdr_'):])()
        self.fill(position)

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.close()


def show():
    """Opens the menu; returns the action to run once it is closed, if any."""
    menu = Menu(WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')
    menu.doModal()
    after = getattr(menu, 'after', None)
    del menu
    return after
