"""Finding the picture inside a captured video frame.

Everything here is plain Python without Kodi, so it can be tested on its own.
A frame is BGRA (4 bytes a pixel, from xbmc.RenderCapture) or BGR (3, the grey frames
ffmpeg.Decoder makes from a keyframe's brightness); only the green channel is read.
"""

# Common picture shapes. shape() takes the widest of these the measurement allows.
STANDARD_RATIOS = (1.33, 1.37, 1.43, 1.50, 1.66, 1.78, 1.85, 1.90, 2.00, 2.20, 2.35, 2.39, 2.40, 2.55, 2.76)
# Shapes this close are one picture measured a row apart at its edges (a dark edge row reads as bar):
# at 288 rows one row at each edge is 0.7 to 1.1 per cent, and the widest standard shape in range can add
# a step such as 2.39 to 2.40. Different pictures of one film (IMAX 1.90 and 2.39) are far wider apart.
SAME_PICTURE = 0.02

# Bars are flat black. A row counts as bar while no pixel in it is brighter than
# the bar's own level plus this much (green channel, 0 to 255), and never above BLACK_MAX.
# 48, not 32, since 1.1.5: bars at 33 to 48 (dark grey letterboxing, a faded transfer, a Dolby
# Vision profile 5 reshaped black above 32) read as a full-screen picture before, which put the
# subtitles into the bar; only a dark scene filling the frame can now read as a black frame instead
# (refused for that keyframe, the others decide). Found with the detection corpus (deep review).
BAR_NOISE = 6
BLACK_MAX = 48
# The bars' own level is the first dark row from each edge (within LEVEL_ROWS of it), its level being its
# brightest pixel but the speckles; rows brighter than BLACK_MAX are passed over as a line left at the edge. Taken from the one outermost row until 1.1.5, a
# bright line left at the frame's edge by a transfer or a crop set the level to 0, and every bar
# row of limited-range video (black at 16) then read as picture: a confident 16:9 for a scope film.
# A row's spread (its 90th less its 10th percentile) is grain in the mattes; the noise allowance
# grows with it, NOISE_SPREAD times, never past BLACK_MAX.
LEVEL_ROWS = 4
NOISE_SPREAD = 2
# A lit band at most this share of the frame high with flat black beyond it is a stripe in the
# bar, not the picture's edge: real picture never has a flat black row right behind its edge.
# Without it, a dim full-width stripe at the same height in both bars read as the edge (found
# with synthetic frames by P3i's developer, 2026-10-11).
STRIPE_SHARE = 0.03
# A bar row may hold this share of stray bright pixels (compression noise, dust in a film scan):
# one in the decoder's 128-wide frames, five in a 512-wide screen grab. The bar's own level ignores as many.
SPECKLE_SHARE = 0.01
# The first row of picture next to a bar must be lit across most of its width.
# A dark scene still lifts nearly every pixel above the flat black of a bar; a logo
# or credits on black light only a narrow part of the row.
EDGE_COVERAGE = 0.5
# Real bars are the same height at the top and the bottom.
SYMMETRY_ROWS = 2
# Text or a logo in one bar (burned-in subtitles, a channel logo) ends that bar early. Rows lit across
# less than this share, between the shorter bar and the taller one, are taken as such text: the
# taller bar then counts for both, as long as the picture's edge behind it is lit across. A real
# picture edge is lit across most of its width, a dark scene too, so it never reads as text.
TEXT_SHARE = 0.35
# The row where bar meets picture can come out faint and uneven: a smoothed frame grab mixes the two
# (seen in a real Kodi at 512x288, 2026-10-11), and masters soften the edge. Up to this many rows at
# the bar's edge with nothing brighter than BLACK_MAX and at least FAINT_SHARE of the row still at the
# bar's own level count as bar; the edge behind them must still be lit across. A dark scene lifts most
# pixels above the bar, so its rows rarely count. Errors only make bars taller. Screen grabs only (analyse's faint).
FAINT_ROWS = 2
FAINT_SHARE = 0.5
# Bars taller than this share of the frame (each) are not believed. 2.39 letterboxed in a 4:3 file (a
# non-anamorphic DVD) is 22.1 per cent, so 0.24 since 1.1.5 (0.22 refused it, and a file in a shape of its
# own then keeps that shape: subtitles at the frame's bottom, inside the bar). ffmpeg.EDGE_SHARE reads 25.
MAX_BAR_SHARE = 0.24

# An empty capture buffer converted to colour comes out as solid green: red and blue near
# zero, green high. Seen from the Amlogic capture device with 4K HDR10 video on P3i
# (2026-10-08), which the add-on no longer reads; kept for Kodi's frame grab on other Amlogic
# systems, which may hand back the same. Real green scenes keep some red and blue, so the
# rule is strict.
EMPTY_GREEN_SHARE = 0.6


class Sample:
    """One analysed frame."""

    def __init__(self, clear, top, bottom, height, reason='', coverage=None, black=None, exact=False, strong=True):
        self.exact = exact        # top and bottom are the frame's own rows, found at full resolution (exact_bars)
        self.strong = strong      # the picture's edge rows are lit across above the bar ceiling (see analyse)
        self.clear = clear
        self.top = top          # rows of black above the picture
        self.bottom = bottom    # rows of black below the picture
        self.height = height
        self.reason = reason
        self.coverage = coverage  # lit share of the top and bottom picture rows
        self.black = black        # the level a bar row may reach in this frame

    def picture_ratio(self, video_ratio):
        """The picture's shape, given the shape of the whole video frame."""
        rows = self.height - self.top - self.bottom
        return video_ratio * self.height / rows

    def __repr__(self):
        extra = ''
        if self.coverage:
            extra += ', lit %.2f/%.2f' % self.coverage
        if self.reason:
            extra += ', ' + self.reason
        return 'Sample(clear=%s, top=%d, bottom=%d, height=%d%s%s%s)' % (
            self.clear, self.top, self.bottom, self.height, ', exact' if self.exact else '',
            ', weak edge' if self.clear and not self.strong else '', extra)


class Picture(float):
    """A picture's symmetric shape that also knows its own bars, in the frame's rows.

    It is the ratio (a float: every comparison, log line and cache round works on it unchanged), and where it was
    measured in the frame's own rows it carries top, bottom and height, so placement can use the bar on the
    subtitle's side (geometry.placed_ratio): real films' bars are often a row or more apart, and placing
    bottom text from the symmetric average put one of them 10 rows into its thicker bottom bar (2026-10-15).
    top, bottom and height are 0 when only the symmetric shape is known (analysed rows, a cropped file's own
    shape)."""

    top = bottom = height = 0
    provisional = False      # an answer from dim grabs only: placed, never cached, replaceable

    def __new__(cls, ratio, top=0, bottom=0, height=0, provisional=False):
        shape = float.__new__(cls, ratio)
        shape.top, shape.bottom, shape.height = top, bottom, height
        if provisional:
            shape.provisional = True
        return shape

    def __repr__(self):
        return 'Picture(%s, top=%d, bottom=%d, height=%d)' % (float(self), self.top, self.bottom, self.height)


def _greens(frame, width, row, channels):
    start = row * width * channels + 1
    return frame[start:start + width * channels:channels]


def empty_green(frame, width, height, channels):
    """True when the frame is the solid green of an empty capture buffer."""
    total = green = 0
    for row in range(0, height, 8):
        base = row * width * channels
        for x in range(0, width, 8):
            b, g, r = frame[base + x * channels], frame[base + x * channels + 1], frame[base + x * channels + 2]
            total += 1
            if r < 12 and b < 12 and g > 60:
                green += 1
    return total > 0 and green / total >= EMPTY_GREEN_SHARE


def _speckles(width):
    return max(1, int(width * SPECKLE_SHARE))


_ABOVE = {}     # level -> a table turning every value above it into 1, the rest into 0


def _above(greens, level):
    """How many of these values are above level. At C speed through bytes.translate and count: the row test
    runs on every row of every grab (300 grabs per film on a PC), and the Python sum it replaced was most of the
    detector's time (deep review profile, 2026-10-13: 5.8 ms a frame, now under 1)."""
    table = _ABOVE.get(level)
    if table is None:
        level = max(0, min(255, level))
        table = _ABOVE[level] = bytes([0] * (level + 1) + [1] * (255 - level))
    return greens.translate(table).count(1)


def _is_bar(frame, width, row, channels, black):
    """No more than a few stray pixels above black in this row."""
    return _above(_greens(frame, width, row, channels), black) <= _speckles(width)


def _bar_rows(frame, width, height, channels, black, limit, row):
    """Rows of bar from one edge (row(n) is the frame row n rows in), up to limit + 1; lit
    stripes thinner than STRIPE_SHARE with flat black beyond them count as bar."""
    stripe = max(1, int(height * STRIPE_SHARE))
    rows = 0
    while rows <= limit:
        if _is_bar(frame, width, row(rows), channels, black):
            rows += 1
            continue
        beyond = next((n for n in range(rows + 1, min(limit + 1, rows + stripe + 1))
                       if _is_bar(frame, width, row(n), channels, black)), None)
        if beyond is None:
            break
        rows = beyond
    return rows


def bar_level(frame, width, height, channels):
    """(the bars' own level, the level a bar row may reach): see LEVEL_ROWS. 0 and BAR_NOISE when no outer
    row is dark at all."""
    speckles = _speckles(width)
    sides = []
    for first in (0, height - 1):
        for n in range(min(LEVEL_ROWS, height)):
            at = first + n if first == 0 else first - n
            greens = sorted(_greens(frame, width, at, channels))
            level = greens[-1 - speckles]
            if level <= BLACK_MAX:       # the first dark row from this edge: a bar, or the picture
                sides.append((level, greens[int(width * 0.9)] - greens[int(width * 0.1)]))
                break
    if not sides:
        return 0, BAR_NOISE
    # The brighter of the two sides, as before 1.1.5 (a dim line at one edge then counts as bar). Not the
    # darkest row of all, which a black stripe inside a bar would set, and not a median, which a dark picture
    # outvotes next to a one-row bar (both found by the property tests).
    level, spread = max(sides)
    return level, min(BLACK_MAX, level + BAR_NOISE + NOISE_SPREAD * spread)


def analyse(frame, width, height, channels=4, uneven=False, faint=True):
    """Measure the black bars at the top and bottom of one frame.

    uneven: bars of different heights with picture between them are taken with the taller bar on both sides (the
    file analysis, whose keyframes then get exact edges and are settled within half a per cent, so a dark scene's
    one-off reading does not win); otherwise refused, as screen grabs need (a scene fading out at one edge would
    agree with itself over several grabs).
    faint: faint rows at the bar's edge count as bar (FAINT_ROWS), as screen grabs need. The file analysis passes
    False: its exact edge finds a soft edge at full resolution, and the faint rows only added bar there (a corpus of real
    films, 2026-10-14: without them some read closer to the true edge, up to 2.4 px at 1080, none further, and
    a dark scene filling the picture no longer reads 9.7 px high). The exact edge itself keeps a tighter faint rule
    for encoder ringing, in _source_bar."""
    if not frame or len(frame) < width * height * channels:
        return Sample(False, 0, 0, height, 'no image')
    if empty_green(frame, width, height, channels):
        return Sample(False, 0, 0, height, 'no image (empty capture buffer)')
    limit = int(height * MAX_BAR_SHARE)

    level, black = bar_level(frame, width, height, channels)

    top = _bar_rows(frame, width, height, channels, black, limit, lambda n: n)
    bottom = _bar_rows(frame, width, height, channels, black, limit, lambda n: height - 1 - n)
    if faint:
        top = _faint_rows(frame, width, channels, black, limit, lambda n: n, top)
        bottom = _faint_rows(frame, width, channels, black, limit, lambda n: height - 1 - n, bottom)

    if top > limit and bottom > limit:
        return Sample(False, top, bottom, height, 'black frame')
    if top > limit or bottom > limit:
        return Sample(False, top, bottom, height, 'bar too tall')
    lit = level + BAR_NOISE // 2
    reason = ''
    if abs(top - bottom) > SYMMETRY_ROWS:
        row = (lambda n: n) if top < bottom else (lambda n: height - 1 - n)
        shorter, taller = min(top, bottom), max(top, bottom)
        sides = (top, bottom)
        if not all(_lit_share(frame, width, row(n), channels, lit) < TEXT_SHARE for n in range(shorter, taller)):
            if not uneven:
                return Sample(False, top, bottom, height, 'not symmetric')
            # Picture where one bar is shorter: a film whose bars are uneven (seen in real films, in every
            # keyframe; refused until 1.2.0, so they got no placement), or a dark scene making one bar look taller.
            # The taller bar on both sides keeps subtitles inside the picture either way; a dark scene's reading
            # stays a one-off that measure.decide does not settle on.
            reason = 'uneven bars'
        else:
            reason = 'text in the %s bar' % ('top' if top < bottom else 'bottom')
        top = bottom = taller

    coverage = tuple(_lit_share(frame, width, row, channels, lit) for row in (top, height - 1 - bottom))
    if min(coverage) < EDGE_COVERAGE:
        return Sample(False, top, bottom, height, 'edge not lit across', coverage)
    # A strongly lit edge: the same rows lit across above the level a bar row may reach (black + 3), not only
    # above the bars' own level. A dark scene's dim content clears the bar test but rarely this one, while a
    # real picture edge nearly always does (the test corpus, 2026-10-14: 91 per cent of true edges
    # strong, 56 of 60 dark wide misreads weak); measure believes a wider shape only from strong samples.
    # +3 and not more: an IMAX film whose scope scenes are dim must keep its scope readings strong, or its
    # subtitles land in the bar (one film at +9 would have, by 29 px).
    strong = min(_lit_share(frame, width, row, channels, min(255, black + BAR_NOISE // 2))
                 for row in (top, height - 1 - bottom)) >= EDGE_COVERAGE
    sample = Sample(True, top, bottom, height, reason, coverage, black, strong=strong)
    if reason == 'uneven bars':
        sample.sides = sides             # each bar as measured, for exact_bars
    return sample


def _faint_rows(frame, width, channels, black, limit, row, rows):
    """rows of bar, with up to FAINT_ROWS faint rows right behind them: none brighter than BLACK_MAX,
    at least FAINT_SHARE still at the bar's level."""
    for _ in range(FAINT_ROWS):
        if rows > limit:
            break
        greens = _greens(frame, width, row(rows), channels)
        if max(greens) > BLACK_MAX or width - _above(greens, black) < FAINT_SHARE * width:
            break
        rows += 1
    return rows


def _lit_share(frame, width, row, channels, lit):
    return _above(_greens(frame, width, row, channels), lit) / width


def exact_bars(read_values, width, height, sample):
    """The bars of a clear analysed sample in the frame's own rows, or None to keep the analysed answer.

    The analysed frame's rows stand for the middles of bands of source rows (7.5 rows each at 2160), so the
    picture's edge lies somewhere in the band between the last analysed bar row and the first analysed picture
    row. Only those source rows are read (read_values(y): source row y as 8-bit values, the decoder's frame
    still in memory) and the edge is the first that is not bar, by the detector's own tests: a row of bar, or a
    faint row (none above BLACK_MAX, at least FAINT_SHARE at the bar's level), as analyse takes them. A band
    that is bar to its end keeps the analysed row's edge. Not refined: a sample whose bars were evened out for
    text in one of them (that side's band holds the text, not the edge). Uneven bars are refined side by side and
    each side keeps its own edge: placement reads the bar on the subtitle's side, so evening them out (as until
    1.4.0) only moved text away from the real edge."""
    uneven = sample.reason == 'uneven bars'
    if not sample.clear or (sample.reason and not uneven) or sample.black is None or sample.exact:
        return None
    out_h, black = sample.height, sample.black

    def source(n):                       # the source row analysed row n stands for
        return (2 * n + 1) * height // (2 * out_h)

    def first_picture(rows):
        return next((n for n, y in enumerate(rows) if not _source_bar(read_values(y), black)), None)

    top, bottom = sample.sides if uneven else (sample.top, sample.bottom)
    band = range(source(top - 1) + 1 if top else 0, source(top) + 1)
    found = first_picture(band)
    top_px = band[found] if found is not None else source(top)
    # From the bottom: the last analysed bar row's source row towards the first analysed picture row.
    band = range(source(out_h - bottom) - 1 if bottom else height - 1, source(out_h - 1 - bottom) - 1, -1)
    found = first_picture(band)
    bottom_px = height - 1 - (band[found] if found is not None else source(out_h - 1 - bottom))
    return Sample(True, top_px, bottom_px, height, sample.reason, sample.coverage, black, exact=True,
                  strong=sample.strong)


def _source_bar(values, black):
    """One full-resolution row is bar: a row of bar, or a faint row, at least FAINT_SHARE at the bar's level with
    nothing brighter than the ceiling plus BAR_NOISE. The faint rule is for encoder ringing beside a hard edge
    (half-lit rows no brighter than the bar's own noise); its old limit of BLACK_MAX also swallowed the first row
    of dim picture content and lifted text off the edge on some films of the test corpus (2026-10-15)."""
    above = _above(values, black)
    if above <= _speckles(len(values)):
        return True
    return max(values) <= black + BAR_NOISE and len(values) - above >= FAINT_SHARE * len(values)


def bars_hold(read_values, exact):
    """True when every row of an exact sample's bars is bar in the frame read_values reads. exact_bars only looks
    between the analysed rows and trusts the analysed frame for the rest; a second frame (the full-size screen grab
    after settling) may show another scene, whose picture across that band would otherwise read as the edge."""
    rows = list(range(exact.top)) + list(range(exact.height - exact.bottom, exact.height))
    return all(_source_bar(read_values(y), exact.black) for y in rows)


EXACT_SLACK = 2     # rows an exact edge may be off by: an encoder's soft edge, a band of ringing


def shape(sample, video_ratio):
    """The picture's shape from a clear sample.

    An exact sample (the frame's own rows) is the shape, as measured. An analysed sample's bar can be
    up to a row short (the row where bar meets picture comes out half lit in a smoothed frame grab, or
    is sampled on the picture's side) and up to half a row long, so the picture's true height is
    between two rows less and one row more than measured: a standard shape in that range is used when
    it is at least as wide as measured (within half a row), otherwise the measured shape, taking a row
    lost to the edges. Snapping to the nearest standard within 4 per cent instead could pick a narrower
    one, putting subtitles low, into the bar (a user's PC, 2026-10-11)."""
    rows = sample.height - sample.top - sample.bottom
    if sample.exact:                                          # the frame's own rows (exact_bars)
        # The frame's own ratio, nothing snapped or rounded. An exact edge is a whole source row, so
        # the true edge of a 1080 film (or a 2160 film with an even bar) is a whole canvas pixel, and
        # Kodi's margin step rounds up to the next whole pixel: snapping to a standard or rounding the
        # ratio up put most of the test corpus one pixel high at On the edge (a nominal 2.39 encode
        # at 3840x2160 has 1608 picture rows, 2.3881, never 2.39; found 2026-10-15).
        return video_ratio * sample.height / rows
    measured = video_ratio * sample.height / (rows + 0.5)     # a bar sampled half a row long at most
    narrowest = video_ratio * sample.height / (rows + 1)
    widest = video_ratio * sample.height / max(1, rows - 2)
    possible = [standard for standard in STANDARD_RATIOS if narrowest <= standard <= widest]
    if possible and max(possible) >= measured:
        return max(possible)
    # No standard shape as wide as the measurement within its precision (TV series come in 2.05 or
    # 2.10; snapping those to 2.00 put subtitles up to 28 px into the bar at 1440 lines).
    return round(video_ratio * sample.height / max(1, rows - 1), 2)


def same_picture(ratios, share=None):
    """True when all these shapes are one picture within the measuring precision (SAME_PICTURE, or share)."""
    return max(ratios) <= min(ratios) * (1 + (SAME_PICTURE if share is None else share))
