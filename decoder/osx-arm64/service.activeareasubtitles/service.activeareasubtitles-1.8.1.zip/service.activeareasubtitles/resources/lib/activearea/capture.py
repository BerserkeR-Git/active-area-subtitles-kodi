"""Kodi's frame grab: KodiScreen, the one Kodi adapter of the screen route (measure.screen), and the one-look helpers
around it: first_look, a PC's one grab as its first estimate, and finer_rows and read_finer, a shape read again in a
full-size grab once Kodi's window allows a larger one. They read the screen through measure.look and
measure.exact_picture, the screen route's own one look. The PC's scene follower reads the screen through the same grab
(screenreader.ScreenReader over grabreader.GrabReader). Kept outside the detector's modules (shapes.DETECTOR_MODULES),
so a change here measures no cached shape again. The tests hand a list of frames instead. Loads without Kodi.
"""
from . import detect, measure, pictures
# The scene follower's modules, once in this file: named here too for one release, for the tests and tools that still
# say capture.
from .filmclock import (ANCHOR_EVERY, ANSWER_JUMP, FRESH, FRESH_STEP, FRESHEST, LAG_MOST, STALL_BACK,  # noqa: F401
                        TEMPO_LEAST, TEMPO_MOST, _FilmClock)
from .grabreader import DIM_NARROWER_GRABS, NARROWER_GRABS, GrabReader  # noqa: F401
from .screenlead import (PROBE_FIRST, SHOWN_AHEAD, SHOWN_AHEAD_LEAST, SHOWN_AHEAD_MOST, SHOWN_KEPT,  # noqa: F401
                         SHOWN_TIGHT, ScreenLead)
from .screenreader import (DUE_SLACK, EMPTY_FOR, EMPTY_STEP, FAST_STEP, HOLD_JUMP, PLANNED_NEAR,  # noqa: F401
                           PROBE_LATE, SEEK_ANSWER_WAIT, SLOW_GRAB_KEPT, SLOW_STEP, ScreenReader)

SCREEN_SETTLE = 1.0           # the longest Kodi gets to render into a capture: it hands it over as soon as it has (30
                              # to 85 ms in the test rig). A fixed 0.15 s first is too short under load: the grabs come
                              # back empty, nothing measured


class KodiScreen:
    """Kodi's frame grab (xbmc.RenderCapture), the screen route's adapter; the tests hand screen a list of frames
    instead. grab(width, height) -> (the frame Kodi rendered into a capture that size, empty when none came within
    SCREEN_SETTLE, whether Kodi is closing); width() -> the screen's own width, or None when Kodi can not say."""

    def __init__(self, wait):
        import xbmc   # only here: the module loads without Kodi (test_measure reads SCREEN_SETTLE on its own)
        self._xbmc, self._wait = xbmc, wait

    def grab(self, width, height):
        capture = self._xbmc.RenderCapture()
        capture.capture(width, height)
        frame = capture.getImage(int(SCREEN_SETTLE * 1000))
        del capture                       # releasing it stops Kodi copying frames
        return frame, not frame and self._wait(0.001)

    def width(self):
        try:
            return int(self._xbmc.getInfoLabel('System.ScreenWidth'))
        except Exception:  # Kodi could not say: the small grab's answer stands
            return None


def first_look(screen, video_ratio):
    """One grab as a first estimate for a PC that reads the file first (its first keyframe waits for smooth
    playback): the picture with its exact edge where that is strongly lit, when the grab is clear and strongly lit;
    else None. One grab is no answer (measure.screen wants AGREEING_SAMPLES); the measurement confirms or corrects it."""
    _frame, _width, _height, sample = measure.look(screen, video_ratio)
    if not (sample.clear and sample.strong):
        return None
    return measure.exact_picture(screen, video_ratio, sample) or detect.shape(sample, video_ratio)


def finer_rows(screen, video_ratio, shape):
    """The rows of the full-size grab Kodi's window allows now, where they are more than those of the smaller screen
    grab that read shape's rows (pictures.Grabbed); else 0. Never the file's edges (exact at its rows), nor a picture
    without bars; nothing asked of Kodi for a shape read at the largest grab already."""
    if not pictures.from_grab(shape) or not (shape.top or shape.bottom) \
            or shape.height >= int(round(measure.SCREEN_EXACT_WIDTH / video_ratio)):
        return 0
    width = screen.width()
    rows = int(round(min(width, measure.SCREEN_EXACT_WIDTH) / video_ratio)) if width else 0
    return rows if rows > shape.height else 0


def read_finer(screen, video_ratio, shape):
    """shape's picture read again in one full-size grab, taken at a strongly lit small look of it (exact_bars reads
    between that look's analysed rows); None when the look is not strongly lit or shows another picture (nothing
    grabbed at full size), shape itself when the full-size grab gave no edge of that picture."""
    _frame, _width, _height, sample = measure.look(screen, video_ratio)
    if not (sample.clear and sample.strong) or not pictures.same(detect.shape(sample, video_ratio), shape):
        return None
    finer = measure.exact_picture(screen, video_ratio, sample)
    return pictures.grabbed(finer) if finer is not None and pictures.same(finer, shape) else shape
