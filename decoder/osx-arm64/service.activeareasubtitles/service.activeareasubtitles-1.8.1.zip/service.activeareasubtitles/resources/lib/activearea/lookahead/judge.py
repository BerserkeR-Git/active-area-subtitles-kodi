"""What a decoded frame shows to the read-ahead (FrameJudge), against the pictures the film is known to show."""

from .. import detect, pictures


class FrameJudge:
    """What a decoded frame shows, in the video's own shape (non-square pixels), against the pictures the film is
    known to show: those believed (read strongly lit, or known from the measurement), one version of each
    (pictures.Versions: the first, its rows filled in by a later one), and those only known of (the cache's map, the
    map being read: mapped). A weak reading of a believed picture counts; a weak reading is never a picture of its own
    (a dark scene reads wide), and Level 5 places a frame only where the trust says so."""

    def __init__(self, video_ratio, trust, known=(), shown=(), mapped=lambda: []):
        """trust: the read-ahead's Trust; known: shapes the film is known to show (the measurement's settled one),
        believed; shown: shapes a scene map from the cache says the film shows (another picture is known, but a weak
        reading of one is not believed for it); mapped(): the shapes of the map being read."""
        self._video_ratio, self._trust, self._mapped = video_ratio, trust, mapped
        self.believed = pictures.Versions()
        self._cached = list(shown)      # shapes the cache's scene map says the film shows
        for shape in known:
            self.believe(shape)

    def learn(self, keyframes):
        """The measurement's keyframes: the picture of each strongly lit clear one, with its exact edge, believed."""
        for keyframe in keyframes:
            sample = keyframe.sample
            if sample is not None and sample.clear and sample.strong and keyframe.size:
                self.believe(self._shown(keyframe, exact=True))

    def believe(self, shape):
        """One version of each picture: the first believed (the measurement's settled shape comes first), replaced
        only by one with the rows it lacks."""
        if shape:
            self.believed.add(shape)

    def full(self, picture):
        """Whether picture is the whole video frame's."""
        return pictures.same(picture, self._video_ratio)

    def wider_known(self, picture):
        """Whether a picture wider than this one is believed, in the map or in the cache's (the film shows one)."""
        return pictures.wider_than(picture, self.believed, self._mapped(), self._cached)

    def narrower_known(self, picture):
        """Whether a picture narrower than this one is believed, in the map or in the cache's."""
        return pictures.narrower_than(picture, self.believed, self._mapped(), self._cached)

    def narrower_shapes(self, picture):
        """The shapes believed or in the cache's map narrower than picture: only what the film is known to show."""
        return [shape for shape in self.believed + self._cached if pictures.narrower(shape, picture)]

    def picture(self, frame, exact=False):
        """What a decoded frame shows (keyframes.Keyframe, analysed), in the video's own shape: from a strongly lit
        picture (with its exact edge where asked and strongly lit), or a weakly lit one of a shape already believed (a
        weak reading can show a picture wider than it is, a dark scene, never picture where the bars are black: one of
        a shape never seen lit is not believed) unless trusted Level 5 says a taller picture
        (_taller_level5: then Level 5's, or with 0/0 none, for full_if_dark); else from its Level 5 where the film's
        Level 5 is trusted, but never 0/0 (a fade to black says 0/0 too: full_if_dark, confirmed by the keyframe
        after); None where nothing tells. A picture believed is given as its believed version (with rows, the settled
        one first), so one picture never comes in two versions a row apart (the settled
        276/278 against the read-ahead's 276/276 would move the text up into every scope scene)."""
        shape, strong = self.seen_in(frame, exact)
        if shape is not None:
            if strong:
                self.believe(shape)
                return self.believed.find(shape)
            known = self.believed.find(shape)
            if known is not None and not self._taller_level5(frame, shape):
                return known
        level5 = frame.level5_pair
        if level5 is None or level5 == (0, 0) or not frame.size or frame.side_bars or not self._trust.trusted():
            return None
        height = frame.size[1]
        rows = height - level5[0] - level5[1]
        if rows <= 0:
            return None
        return pictures.version(detect.Picture(self._video_ratio * height / rows, level5[0], level5[1], height),
                                self.believed)

    def full_if_dark(self, frame):
        """The full picture for a frame not strongly lit whose trusted Level 5 is 0/0, else None. A weak reading is
        no picture of its own: a dark frame's dark rows read as bar, so it can read as wide as the old scope picture
        while the frame is a dark 16:9 IMAX one (a dark IMAX opening reading weak 2.20 would keep the text at the scope
        height for 6 s). In the corpus no dim keyframe of a film whose Level 5 is trusted carries 0/0 under a weak
        reading of a shape it shows (0 of 1700)."""
        if (frame.level5_pair != (0, 0) or frame.side_bars or not frame.size or not self._trust.trusted()
                or self.seen_in(frame)[1]):
            return None
        return detect.Picture(self._video_ratio, 0, 0, frame.size[1])

    def unbelieved(self, frame):
        """The shape of a weakly lit frame (or one read only with faint rows) whose picture is not believed yet, else
        None."""
        shape, strong = self.seen_in(frame, exact=True)
        if shape is None or strong or self.believed.find(shape) is not None:
            return None
        return shape

    def seen_in(self, frame, exact=False):
        """(the frame's picture, whether strongly lit), or (None, False) where it shows none. A frame that reads unclear
        as the measurement reads it (no faint rows) is read again with them: a soft edge then counts as a weak reading
        (the test rig's clip: its scope keyframes read no edge at all without faint rows). An unclear frame whose
        picture reaches the frame's edge through every bar the film is known to show there is the full picture, as if
        strongly lit (_lit_edge)."""
        sample = frame.sample
        if sample is None or not frame.size:
            return None, False
        if sample.clear:
            return self._shown(frame, exact), sample.strong
        edge = self._lit_edge(frame)
        if edge is not None:
            return edge, True
        if not frame.frame or not frame.analysed:
            return None, False
        width = len(frame.frame) // (3 * frame.analysed)
        soft = detect.analyse(frame.frame, width, frame.analysed, 3, uneven=True, faint=True)
        if not soft.clear:
            return None, False
        return detect.Picture(detect.shape(soft, self._video_ratio)), False

    def kind(self, frame, picture, old, new):
        """What a frame between two keyframes showed, for the log: lit old, weak old, new, new lit at an edge
        (_lit_edge), Level 5 new, dark 0/0 (taken as the full picture), weak 0/0, black 0/0, dark 0/0 not used (Level 5
        not trusted), black, dark, other."""
        shape, strong = self.seen_in(frame)
        if picture is not None:
            if pictures.same(picture, old):
                return 'lit old' if strong else 'weak old'
            if pictures.same(picture, new):
                if shape is not None and strong and not frame.sample.clear:
                    return 'new lit at an edge'
                return 'new' if shape is not None else 'Level 5 new'
            return 'other'
        black = frame.sample is not None and frame.sample.reason == 'black frame'
        if frame.level5_pair == (0, 0):
            if not self._trust.trusted():
                return '%s 0/0 not used' % ('black' if black else 'dark')
            return 'weak 0/0' if shape is not None else 'black 0/0' if black else 'dark 0/0'
        return 'black' if black else 'dark' if shape is None else 'other'

    def _lit_edge(self, frame):
        """The full picture for a frame whose rows from its top or bottom edge are picture through the thinnest bar any
        letterboxed picture the film is known to show has on either side (pictures.lit_at_edge), else None. Such a
        frame reads unclear (one edge lit, the other dark: 'edge not lit across', 'bar too tall'), so it would be a dark
        one, and the map would carry the old scope picture across a 16:9 IMAX scene or leave it to the screen (lit sky
        at the top, dark ground below: the text at the scope height for 10 s). Off where a picture
        known has a bar thinner than detect.EDGE_ROWS (its picture at one edge). In the real-film corpus no keyframe of
        a letterboxed film showed picture through its bar at one edge with a black bar at the other (of 18126
        keyframes in 811 letterboxed films 27 unclear ones are lit at one edge, all in IMAX films, the other edge dark
        picture; none in the 793 films without a full-frame scene)."""
        if not frame.frame or not frame.analysed or not frame.size or frame.side_bars:
            return None
        rows = frame.analysed
        if not pictures.lit_at_edge(frame.frame, len(frame.frame) // (3 * rows), rows, 3,
                                    self.believed + self._mapped() + self._cached, self._video_ratio,
                                    detect.LIMITED_BLACK):
            return None
        return pictures.version(detect.Picture(self._video_ratio, 0, 0, frame.size[1]), self.believed)

    def _taller_level5(self, frame, shape):
        """Whether a weakly lit frame reading shape has trusted Level 5 that says a taller picture (0/0: the full one).
        A weak reading is a lower bound on the picture's height (a dark scene reads wide, never picture where the bars
        are black), so it does not say the wider picture goes on: Level 5 tells (the corpus: dim keyframes of trusted
        films whose Level 5 says taller than their weak reading are within a few rows of their truth)."""
        level5 = frame.level5_pair
        if level5 is None or frame.side_bars or not frame.size or not self._trust.trusted():
            return False
        if level5 == (0, 0):
            return not self.full(shape)
        rows = frame.size[1] - level5[0] - level5[1]
        if rows <= 0:
            return False
        taller = self._video_ratio * frame.size[1] / rows
        return pictures.narrower(taller, shape)

    def _shown(self, frame, exact):
        found = frame.exact if exact else None
        if found is not None and found.strong:
            return detect.picture_of(found, self._video_ratio)
        return detect.Picture(detect.shape(frame.sample, self._video_ratio))
