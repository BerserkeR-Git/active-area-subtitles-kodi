"""The background service: Kodi's callbacks, the settings watch, and one Playback at a time.

Per playback: check that there is anything to do, work out the picture's shape (a file in a
shape of its own gets that shape at once and is measured all the same), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command. A film whose picture changes shape (IMAX scenes)
is followed scene by scene: on a P3i box a Dolby Vision film from P3i's Level 5 labels (labelfollow.py),
on a PC every film from Kodi's screen and, with a decoder, the file read ahead (screenfollow.py).
On a P3i box another subtitle track of the other kind (text or image) is placed again.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there); on a PC from the video file first where it has a decoder (the one shipped with the
add-on, or the system's FFmpeg), one screen grab placed meanwhile, else from tiny screen
captures. Everything runs on its own thread; any failure leaves Kodi's normal subtitle position.
"""
import functools
import os
import threading
import time

import xbmc
import xbmcvfs

from . import choices, coreelec, filmreader, kodi, kodi_session, labels, level5, shapes, updates
from .checks import Checks, Notices
from .choices import distances, image_distances
from .guard import DecodeGuard
from .p3i import P3i
from .playback import Playback, watch_due
from .restores import Restores
from .threads import Threads

UPDATE_PACKAGES = 'special://home/addons/packages/'   # where Kodi downloads an update before installing it
ADDON_FILE = 'special://home/addons/%s/addon.xml' % kodi.ADDON_ID     # gone once Kodi removed the add-on
# Kodi says nothing when the subtitle track changes or subtitles are added during playback (no
# callback, no notification, in Kodi 21), so the service looks, as cheaply as it can:
# each step only Kodi's time since the last button press (a counter), the track itself only after a
# press, early in a playback (a player add-on adds subtitles then, without a press), and once in a
# while (a phone remote switches over JSON-RPC, which is not a press). Asking for the current track
# costs about 0.1 ms; normal watching asks nothing at all.
WATCH_STEP = 1.0               # seconds between looks at the time since the last button press
# Seconds between looks at the records already put back (Restores.settle): a person who sets one of the add-on's
# values again after a put back is told from Kodi bringing ours back from disk only by a look in the same Kodi
# session, so a crash or a close within this long after such a change still takes it for ours (accepted: the model
# in tools/properties gives every person's change a look before Kodi starts again).
SETTLE_STEP = 30.0
RECENT_INPUT = 3               # seconds after a press during which the track is looked at every step (watch_due)
# Seconds Kodi must have run before a package of this very version, just downloaded, tells a start during a film from
# Kodi's own: Kodi starts its services within about ten seconds of its own start (the rig), an update comes later.
INSTALLED_KODI_AGE = 60.0
TAKEN_OVER = 'stopping (a newer start of the service took over): changes stay on record for it'


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        kodi.settings_changed()
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


def _in_charge(callback):
    """One of Kodi's callbacks, acted on only by the Service in charge (Service.in_charge)."""
    @functools.wraps(callback)
    def called(service, *args):
        if service.in_charge():
            callback(service, *args)
    return called


class Service(xbmc.Player):

    made = False                # its __init__ finished
    ended = False               # its run() returned or raised
    superseded = False          # a newer start of the add-on took charge: for good

    def __init__(self, threads=None, clock=time.monotonic, decoder=None, claim=None):
        """Three seams the tests put their own adapters in: threads, every thread the add-on starts (threads.Threads);
        clock, the time scene following and the seek hold go by (time.monotonic); decoder, the film reader's decoder
        class (None: ffmpeg.Decoder). claim: its start's claim in Kodi (kodi_session.claim_service, made by run();
        None: no newer start ever takes over from it)."""
        # Before Kodi registers it: while Kodi installs an update or removes the add-on it does not know it, and a
        # Service that raises after super().__init__() stays registered, getting Kodi's callbacks (in_charge).
        kodi.settings_changed()                 # the settings as they are now, not as an earlier start read them
        version = kodi.addon().getAddonInfo('version')
        super().__init__()
        self.claim = claim
        self.monitor = _Monitor(self._settings_changed)
        kodi.stopping = lambda: self.monitor.abortRequested()     # kodi.log asks no setting while Kodi stops the add-on
        self.threads = threads if threads is not None else Threads()
        self.clock = clock
        self.decoder = decoder
        self.reads = threading.Lock()        # one reader of the playing file at a time (filmreader.FilmReader)
        # P3i's live labels, read through Kodi's at every look (labels.py)
        self.labels = labels.Labels(lambda name: xbmc.getInfoLabel(name),
                                    lambda condition: xbmc.getCondVisibility(condition), rpc=kodi.rpc,
                                    player=kodi.video_player)
        self.seen = _settings_now()          # what a settings change acts on, as last seen (a change since counts)
        # Every setting it changes, with its record, and the lock shared with the playbacks (restores.py).
        self.restores = Restores(self.enabled, lambda kept: self.checks.scan_let_go(kept))
        self.lock = self.restores.lock
        self.p3i = P3i(self)                 # CoreELEC's own settings for the kind of subtitle shown (p3i.py)
        # Shown one at a time, never over a film (checks.py).
        self.notices = Notices(self.playing_video, lambda kind, target: self.threads.start(kind, target))
        self.checks = Checks(self, self.notices)        # CoreELEC's settings looked at, told when it matters
        self.current = None                  # the Playback now, or None; replaced only under the lock
        self.last_seek = float('-inf')       # the clock at Kodi's last seek event (scene following holds still)
        self.seek = None                     # (that clock, the film time sought in seconds; None for a chapter)
        self.settled = clock()               # the clock at the last look at the records put back (settle_step)
        self.addon_looked = clock()          # the clock at the last look at the add-on in Kodi's add-ons (left_unseen)
        self.settle_failed = False           # a failed look logged, until one goes through
        self.on_coreelec = coreelec.is_coreelec()
        self.version = version
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), self.version, start=claim,
                                 kodi_process=kodi_session.process_id())
        # The picture shapes remembered across playbacks (shapes.py); the setting is read at every use.
        # On CoreELEC an entry without a scene verdict is measured again (shapes.Shapes.begin).
        self.shapes = shapes.Shapes(kodi.data_path(shapes.FILE_NAME),
                                    lambda: kodi.setting_bool('remember_shapes', default=True), kodi.log,
                                    follows=self.on_coreelec)
        self.made = True

    def in_charge(self):
        """Whether this Service acts on anything: every one of Kodi's callbacks asks (_in_charge), and its loop at each
        step. Not one whose __init__ raised (Kodi registered it as a Player and its monitor at super().__init__() and
        goes on calling them), nor one whose run() ended or raised (run() builds the next), nor one a newer start of the
        add-on took over from (Kodi's stop came before this start made its first Monitor, so it never arrived, and Kodi
        started the add-on again beside it). Kodi not saying keeps it in charge."""
        if not self.made or self.ended or self.superseded:
            return False
        self.superseded = not kodi_session.claim_held(self.claim)
        return not self.superseded

    def stand_down(self):
        """A newer start of the add-on took charge: this one stops for good, leaving everything on record to it and
        putting nothing back; what its playback's threads still do changes nothing (Playback.is_current)."""
        with self.lock:
            self.current = None
        kodi.log(TAKEN_OVER, always=True)

    @staticmethod
    def enabled():
        """Whether the add-on is switched on in its settings: read at every use."""
        return kodi.setting_bool('enabled')

    def film(self, target, current, background=True, full=False):
        """A filmreader.FilmReader for target (a locate.Target), every decode inside the decode guard for its file and
        its keyframes held against Kodi's stream until one was (checks.Checks.decoder_check). current: whether its
        playback is still current; background and full as for the reader."""
        return filmreader.FilmReader(target, kodi.data_path('ffmpeg.json'), current,
                                    functools.partial(self.guard.decoding, target.identity),
                                    background=background, full=full, decoder=self.decoder, lock=self.reads,
                                    wait=lambda seconds: self.monitor.waitForAbort(seconds),
                                    check=self.checks.decoder_check(target, current))

    # Kodi's player and monitor callbacks run on this service's own thread, while its loop waits in waitForAbort
    # (Kodi queues them for the add-on's thread): they only start or stop work, so the watch keeps its pace.

    @_in_charge
    def onAVStarted(self):
        self._started_playback()

    def _started_playback(self, carried_over=False, same_film=False):
        playback = self.begin(carried_over, same_film)
        if self.playing_video():
            self.threads.start('placing', playback.fit, playback.epoch)

    def begin(self, carried_over=False, same_film=False):
        """A new Playback, now the current one: whatever an older one's threads still do changes nothing."""
        with self.lock:
            self.current = Playback(self, carried_over, same_film)
            return self.current

    @_in_charge
    def onPlayBackSeek(self, seek_time, seek_offset):
        self.last_seek = self.clock()
        try:
            to = float(seek_time) / 1000.0     # Kodi's milliseconds
        except (TypeError, ValueError):
            to = None
        self.seek = (self.last_seek, to)

    @_in_charge
    def onPlayBackSeekChapter(self, chapter):
        self.last_seek = self.clock()
        self.seek = (self.last_seek, None)

    def held(self):
        """Kodi holds the picture still (paused, seeking, loading) or seeked a moment ago: nothing in scene following
        moves then (labels.Labels.seeking)."""
        return self.labels.seeking(self.last_seek, self.clock())

    @_in_charge
    def onAVChange(self):
        # Streams changed (Kodi says so at the start, not when subtitles are added later): see _watch_step.
        self._subtitles_arrived()

    def _subtitles_arrived(self):
        """Subtitles switched on later in a playback that had none at the start: measured now."""
        playback = self.current
        epoch = playback.waiting if playback is not None else None
        if epoch is not None and kodi.holds('VideoPlayer.HasSubtitles') and playback.claim_waiting(epoch):
            self.threads.start('placing', playback.fit, epoch)

    def _watch_step(self, now=None):
        """One look during playback (see WATCH_STEP): on a PC Kodi's window (canvas_check), subtitles that arrived late,
        Kodi's subtitle position and style and its view mode (position_check, view_check), and on P3i builds a subtitle
        track of the other kind."""
        playback = self.current
        if playback is None:
            return
        watch = playback.watch
        now = time.monotonic() if now is None else now
        if not self.on_coreelec:
            playback.canvas_check()     # every step: dragging a window larger presses no button in Kodi
        # Every step too, asking Kodi only while the playback waits for subtitles: a subtitle file added during a film
        # presses no button and sends no onAVChange.
        self._subtitles_arrived()
        playback.try_again()            # a film without an answer read again once due (Playback.try_later)
        if not watch_due(now, watch, _pressed_lately()):
            return
        watch.looked = now
        # A position set in Kodi's on-screen settings comes with a button press too. The box as well: Bottom of video
        # to Bottom of screen during a cropped scope film would keep the video's margin, the text in Kodi's bar, and a
        # larger border at On the edge would put it partly there.
        try:
            playback.position_check()
        except Exception as error:  # Kodi failing here stays here: looked at again at the next look, told once
            if not watch.position_failed:
                watch.position_failed = True
                kodi.log('subtitle position not looked at: %r' % error, always=True)
        playback.view_check()           # a view mode set with the remote comes with a press as well
        if playback.shown.kind is None or not self.on_coreelec:
            return                      # nothing placed by kind yet, or nothing placed by kind at all
        self.p3i.looked(playback, playback.epoch)

    def settle_step(self):
        """The records already put back looked at again, every SETTLE_STEP (Restores.settle)."""
        if self.clock() - self.settled >= SETTLE_STEP:
            self.settled = self.clock()
            self.restores.settle(idle=lambda: self.current is None)
            self.settle_failed = False

    def left_unseen(self):
        """Whether Kodi switched the add-on off or removed it without this service hearing of it, asked every
        SETTLE_STEP: a stop that came before its start made its first Monitor is lost, and Kodi never tells it again.
        Switched off, or unknown to Kodi with its folder gone and no package of it arriving; unknown alone is an update
        under way or Kodi not saying, and changes nothing."""
        if self.clock() - self.addon_looked < SETTLE_STEP:
            return False
        self.addon_looked = self.clock()
        try:
            enabled = kodi.addon_enabled()
            if enabled is not None:
                return not enabled
            return not self._on_disk() and not updates.arriving(self._packages_folder(), self.version)
        except Exception:  # Kodi could not say: running on
            return False

    @staticmethod
    def _on_disk():
        try:
            return bool(xbmcvfs.exists(ADDON_FILE))
        except Exception:  # Kodi could not say: still there
            return True

    @_in_charge
    def onPlayBackStopped(self):
        self.finish('playback stopped')
        self._hold_p3i_restriction()

    @_in_charge
    def onPlayBackEnded(self):
        self.finish('playback ended')
        self._hold_p3i_restriction()

    @_in_charge
    def onPlayBackError(self):
        self.finish('playback error')
        self._hold_p3i_restriction()

    def run(self):
        left = False
        try:
            self.start()
            while not self.monitor.waitForAbort(WATCH_STEP):
                if not self.in_charge():
                    self._close_notice()
                    self.stand_down()
                    return
                if self.left_unseen():
                    left = True
                    break
                try:
                    self.checks.settings_left()
                    self.checks.update_outcome()
                    self.notices.tell_waiting()
                    self._watch_step()
                except Exception as error:  # Kodi could not say: looked at again next step, logged once per playback
                    playback = self.current
                    watch = playback.watch if playback is not None else None
                    if watch is not None and not watch.failed:
                        watch.failed = True
                        kodi.log('subtitle watch: %r' % error, always=True)
                try:
                    self.settle_step()
                except Exception as error:  # looked at again at the next step; logged once until a look goes through
                    if not self.settle_failed:
                        self.settle_failed = True
                        kodi.log('records put back not looked at: %r' % error, always=True)
        except BaseException:
            with self.lock:
                self.current = None     # what its playback's threads still do changes nothing: run() builds the next
            raise
        finally:
            self.ended = True
        self._close_notice()
        try:
            if left:
                self.let_go()               # Kodi's stop never came, nor will it
            else:
                self.stopping()
        finally:
            self.guard.wait_until_idle()

    def _close_notice(self):
        """Stopping for good: an open notice closes (Notices.close_at_stop)."""
        try:
            self.notices.close_at_stop()
        except Exception as error:  # Kodi closes it when it gives up on the thread
            kodi.log('notice not closed: %r' % error, always=True)

    def start(self):
        """The service's start. Started during playback: Kodi updated the add-on (it does so by
        itself), it was switched on, or the service started again after a failure. What is in
        place belongs to that playback, so it is carried on: no repair, no "next video" clearing,
        measured again (the same answer changes nothing on screen). Only when an earlier service of this Kodi
        made its session: a film playing at the first start in a Kodi session (Kodi started with a file, the add-on
        switched on during a film after Kodi started with it off) is a playback of its own, and what is in place came
        from disk (a placing that gave up would keep the last session's margin and Manual). Versions before the session
        (1.5.0 and older) made none, so an update from one of them during a film is told by this version's package,
        just downloaded, once Kodi has run INSTALLED_KODI_AGE (else the film was put back and placed afresh)."""
        # Read again before the steps: a change from here on counts. Kodi tells of one made while they run once the
        # start is done, and of the status rows they write as a change of nothing.
        self.seen = _settings_now()
        playing = self.playing_video()
        carried = playing and (self.restores.session_known is not False or self.current is not None
                               or self._installed_now())
        # The checks run in one order either way, so their notices queue alike.
        # The FFmpeg check before the status: on a PC it finds the decoder the status names.
        steps = (self._release_when_off, self._check_last_run, self.checks.check_ffmpeg, self.checks.show_status,
                 self.checks.check_level5_handling, self.checks.check_image_margin) if carried \
            else (self._release_when_off, self.restores.repair, self._check_last_run, self.checks.check_ffmpeg,
                  self.checks.show_status, self._hold_p3i_restriction, self.checks.check_level5_handling,
                  self.checks.check_image_margin)
        # Each step at the start on its own: one failing must not keep the others from running.
        for step in steps:
            try:
                step()
            except Exception as error:
                kodi.log('start: %s not done: %r' % (step.__name__.strip('_').replace('_', ' '), error), always=True)
        if playing:
            self._started_playback(carried_over=carried)

    def stopping(self):
        """The service is asked to stop. Kodi closing (it has saved its settings by now) or an
        update (the next service carries on): everything stays as it is, on record, for the next
        start. Switched off or removed in Kodi's add-ons: nobody else would put things back, and Kodi is asked to write
        its settings file with the person's values.
        Kodi loading another profile stops it as a close does, then loads that profile's settings file while it runs;
        so a close ends Kodi's session (kodi_session.end_session) and the next start counts ours in memory as back
        from disk.

        Seen in a real Kodi 21: during an update the add-on is already unknown to Kodi when its
        service stops, as after removing it; what tells them apart is the new version's package,
        which Kodi has just downloaded. When unsure, everything is put back."""
        details = kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID, 'properties': ['enabled']},
                           quiet=True)
        addon = details.get('addon') if isinstance(details, dict) else None
        if isinstance(addon, dict) and addon.get('enabled') is True:
            why = 'Kodi closing'
        elif addon is None and updates.arriving(self._packages_folder(), self.version):
            why = 'the add-on updating'
        else:
            self.let_go()
            return
        with self.lock:
            self.current = None               # a measurement still running changes nothing more
        if why == 'Kodi closing':
            kodi_session.end_session()  # or a profile loaded: Kodi read its settings file again while it ran
        kodi.log('stopping (%s): changes stay on record for the next start' % why, always=True)

    def let_go(self):
        """Switched off or removed in Kodi's add-ons (stopping, or the loop finding it so: left_unseen): nobody else
        would put things back, and Kodi is asked to write its settings file with the person's values."""
        self.finish('add-on switched off or removed', always=True)
        self.restores.release_all('add-on switched off or removed', always=True)
        # Going back to an older version arrives here too, and it may keep no record of what this one changed: a
        # crash before Kodi's next save would bring the add-on's values back for good. Saved now, unless a film
        # plays (Kodi saves as its full-screen window closes, and nothing may disturb playback).
        if not self.playing_video():
            kodi.save_settings(self.restores.SAVED)
        kodi.log('stopping (add-on switched off or removed)', always=True)

    def _installed_now(self):
        """Whether Kodi has just installed this version over an older one while it ran (Service.start)."""
        return kodi.running_for(INSTALLED_KODI_AGE) is not False and \
            updates.installed_now(self._packages_folder(), self.version)

    @staticmethod
    def _packages_folder():
        """Where Kodi downloads an update before installing it, or None when Kodi can not say."""
        try:
            return xbmcvfs.translatePath(UPDATE_PACKAGES)
        except Exception:  # unknown: not an update
            return None

    def _hold_p3i_restriction(self):
        """See P3i.hold. Switched off, the person's restriction and bitmap margin are put back instead, so a write
        Kodi refused when the add-on was switched off is tried again after every playback, not only at Kodi's next
        start. A step of the start under this name: its name is in the log line
        when it fails."""
        self._release_when_off()
        self.p3i.hold()

    def _release_when_off(self):
        """Switched off in its settings: CoreELEC's settings stay the person's. Switching off puts them back in Kodi's
        memory; when Kodi had saved the add-on's value before and then stopped without saving again (a crash),
        it starts with that value, and this finishes putting it back."""
        if not self.enabled():
            self.restores.release_all('turned off in settings', always=True)

    def stale_correction(self):
        """Kodi's settings screens closed (Checks.settings_left): CoreELEC's Level 5 handling switched on again there
        shows its override again, and a correction it kept hidden from an earlier video's clear goes now (P3i would
        apply it to the film playing). The playing film's own correction stays."""
        playback = self.current
        self.restores.stale_correction(lambda: playback is not None and playback.level5.applied)

    def _check_last_run(self):
        interrupted = self.guard.check_last_run()
        if interrupted is None:
            return
        if interrupted.outcome == 'noted':
            kodi.log('Kodi stopped during a decode last time; that video is read again, and left to Kodi if it happens '
                     'again', always=True)
        if interrupted.left:
            kodi.log('Kodi stopped during a decode of the same video twice; that video is left to Kodi from now on',
                     always=True)
        if interrupted.outcome == 'paused':
            kodi.log('Kodi stopped during its first decode twice in a row; video file analysis pauses for a day',
                     always=True)

    @_in_charge
    def _settings_changed(self):
        """Kodi tells the add-on of every change to its settings, the status rows it writes itself and the menu's
        writes among them: only what changed since the last look is acted on, and a change of nothing read here does
        nothing. Switched off: the own margin goes back at once. Switched on during a video: measure it. A distance
        changed during a video: placed again with it. Level 5 correction off: a correction in place is cleared.
        P3i's detection settings only for a change of what they follow (image distances, the Level 5 switch): P3i
        reads them as a film starts, and the end of every film holds them again."""
        now, before = _settings_now(), self.seen
        self.seen = now
        changed = {name for name in now if now[name] != before[name]}
        if not changed:
            return
        if 'distances' in changed and not any(now['distances']):
            self.restores.distances_none()
        if 'level5' in changed:
            if not now['level5']:
                self.restores.fix_off()
            self.checks.check_level5_handling()
        if changed & {'image', 'enabled'}:
            self.checks.check_image_margin()
        if changed & {'image', 'level5'}:
            # Also during a film: a playlist's next film starts without a stop, and P3i reads them at its start.
            self.p3i.hold_detection()
        if 'enabled' not in changed:
            playback = self.current
            if changed & {'distances', 'image', 'scenes'} and now['enabled'] and self.playing_video() \
                    and playback is not None:
                kodi.log('distances changed to %.2f and %.2f: placed again' % now['distances'])
                playback.place_again(playback.epoch)
            return
        if not now['enabled']:
            self.finish('turned off in settings')
            self.restores.release_all('turned off in settings')
            return
        self._hold_p3i_restriction()
        if self.playing_video():
            self._started_playback(same_film=True)  # the service's own start: onAVStarted is Kodi's to call

    # Kodi's player, asked the one way: None when Kodi can not say, never a raise. Kodi raises for the file, the length
    # and the time once nothing plays (a thread that outlives its playback), and for any of them while it closes. Each
    # caller decides what None means where it asks. Kept below __init__, whose clock default reads the time module.

    def playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return None

    def playing_file(self):
        try:
            return self.getPlayingFile()
        except Exception:  # not playing any more, or Kodi could not say
            return None

    def length(self):
        """The film's length in seconds."""
        try:
            return float(self.getTotalTime())
        except Exception:  # not playing any more, or Kodi could not say
            return None

    def time(self):
        """The playing position in seconds: -1 before Kodi knows it."""
        try:
            return float(self.getTime())
        except Exception:  # not playing any more, or Kodi could not say
            return None

    # Bookkeeping.

    def finish(self, why, always=False, playback=None):
        # Also called by Playback._layout when the add-on is switched off while a playback starts.
        """always: log without asking for the detailed log setting (Kodi logs an error for that
        while the add-on is being switched off, even though the answer is not needed). playback: the one ending, from
        its own thread; nothing happens once another is current."""
        def ended():
            if playback is not None and self.current is not playback:
                return False
            self.current = None
            return True
        self.restores.finish(why, ended, always)


def _settings_now():
    """What a settings change acts on, as the add-on's settings say now (Service._settings_changed)."""
    return {'enabled': Service.enabled(), 'distances': distances(), 'image': image_distances(),
            'scenes': choices.scene_settings(), 'level5': level5.enabled()}


def _pressed_lately():
    """Whether a button was pressed in the last RECENT_INPUT seconds."""
    try:
        return xbmc.getGlobalIdleTime() < RECENT_INPUT
    except Exception:  # Kodi could not say: looked at once in a while all the same
        return False


RESTART_S, RESTART_MAX_S = 30, 1800    # after an unexpected failure of the service as a whole
SWITCHED_OFF, INSTALLING = "switched off in Kodi's add-ons", 'Kodi is installing or removing the add-on'


def run():
    """The service, started again after anything unexpected (waiting longer each time), so one
    failure never leaves it off for the rest of the session. Kodi runs each start of the add-on in an interpreter of its
    own and can start the next while the last one runs on (its stop missed it, see Service.in_charge): the newest start
    is in charge (kodi_session.claim_service), and an older one stops for good once it sees that, never building another
    Service."""
    monitor, pause = xbmc.Monitor(), RESTART_S
    # Kodi marks the add-on switched off before it tells its Monitors to stop: a stop before the one above was lost,
    # and this is all this start hears of it. Kodi not saying starts it as usual. Asked before it claims: an older
    # start still running then stays in charge and finds the add-on off itself (Service.left_unseen).
    if kodi.addon_enabled() is False:
        kodi.log('not started: %s' % SWITCHED_OFF, always=True)
        return
    claim = kodi_session.claim_service()
    while not monitor.abortRequested():
        if not kodi_session.claim_held(claim):
            kodi.log(TAKEN_OVER, always=True)
            return
        try:
            Service(claim=claim).run()
            return
        except Exception as error:
            if _refused(error):
                # Kodi's Addon() refuses the add-on once it is switched off or removed, and while an update replaces
                # it; Kodi never tells this start of its stop again, and starts the add-on afresh once it is back.
                kodi.log('not started: %s' % (SWITCHED_OFF if kodi.addon_enabled() is False else INSTALLING),
                         always=True)
                return
            if kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID}, quiet=True) is None:
                # Kodi does not know the add-on while it installs an update or removes it (seen in a real Kodi 21)
                kodi.log('not started: %s, starting again in %d s' % (INSTALLING, pause), always=True)
            else:
                kodi.log('stopped by an unexpected error, starting again in %d s: %r' % (pause, error), always=True)
        if monitor.waitForAbort(pause):
            return
        pause = min(pause * 2, RESTART_MAX_S)


def _refused(error):
    """Whether error is Kodi refusing the add-on itself ("Unknown addon id", from xbmcaddon.Addon())."""
    return isinstance(error, RuntimeError) and str(error).startswith('Unknown addon id')
