"""Following one playback's scenes on CoreELEC with P3i, from P3i's Level 5 labels: whether the film is followed
(follow.trust on the keyframes measuring decoded, or the cached verdict), the follower that moves the text with the
labels, the checks it asks for, the start-up search for the film's other shapes and the early start while measuring
goes on. follow.py holds the rules; this holds one playback's use of them. A PC follows Kodi's screen instead
(screenfollow.py).

LabelFollowing is the box's followloop.Following: the epoch's playback.Placing asks it what the Following interface
says, and each follower thread is a followloop.FollowLoop reading P3i's labels (labels.Reader) through it. The
follower moves the text through the same Placing, so work for an epoch that is no longer current changes nothing.
Every thread goes through the service's threads (threads.py); the time is the service's clock, and Kodi holding the
picture still is the service's held().
"""

from . import choices, follow, followloop, kodi, libav, subtitles


def _pairs(level5):
    """Level 5 (top, bottom) pairs for the log, in order, or 'none'."""
    return ', '.join('%d/%d' % tuple(pair) for pair in sorted(level5)) or 'none'


class LabelFollowing(followloop.Following):

    hinted = True                            # margins worked out as for CoreELEC (placement.text_margin)

    def __init__(self, playback):
        followloop.Following.__init__(self, playback)
        self.watching = None                 # the epoch whose early start is being watched for
        self.searching = False               # the start-up search for other shapes started this playback
        self.checks = 0                      # scene checks started this playback (follow.CHECKS_MOST)

    def measuring(self, placing, keyframes):
        """An estimate placed (placing: the epoch's playback.Placing) while the measurement goes on (keyframes: the file
        analysis' list, growing, or None: no file read yet): the early start is watched for, once per epoch."""
        if self.followed == placing.epoch:
            return                              # the follower places
        if keyframes is not None and self.watching != placing.epoch:
            self.watching = placing.epoch
            self.playback.service.threads.start('early start', self._follow_early, placing, keyframes)

    def _settle(self, placing, keyframes, picture):
        """A settled placement: whether this film's scenes are followed (judged from the keyframes measuring decoded,
        or as judged before: this playback, the cache), and if so the follower on a thread of its own, started once per
        epoch, and the start-up search. True when the follower places this epoch's text; a follower started early stops
        when the settled judgement says no, and takes the settled shape's scene rule."""
        playback = self.playback
        with self._lock:
            self._judge(placing.layout, picture, settled=True)
            self._judge_and_start(placing, keyframes, early=False)
            # An image subtitle chosen while a follower started early: the follower places nothing for it (P3i follows
            # Level 5 for those itself), so the settled shape's image settings are written as for a film not followed
            # (they stayed those of a 1.90 estimate, the restriction off, in a 2.39 film); text again starts a follower
            # of its own epoch.
            if not self.verdict or (playback.shown.kind == subtitles.IMAGE and self.followed == placing.epoch):
                self.followed = None
            return self.followed == placing.epoch

    def _judge_and_start(self, placing, keyframes, early):
        playback, epoch = self.playback, placing.epoch
        if keyframes is not None:
            verdict = follow.trust(keyframes)
            if self.verdict is not None and self.followed == epoch:
                self.verdict.merge(verdict)             # started early: the follower holds this verdict's lists
            else:
                self.verdict = verdict
            if not early:
                playback.memory.remember_judgement('follow', self.verdict, with_shape=True)   # the shape comes next
            kodi.log('scenes: %s, %s%s' % ('following' if self.verdict else 'not followed', self.verdict.reason,
                                            ' (started early, measuring goes on)' if early else ''))
        elif self.verdict is None and playback.memory is not None and playback.memory.entry is not None:
            # never None here: on CoreELEC an entry without a verdict is measured again (measure)
            self.verdict = playback.memory.entry.follow
            verdict = self.verdict
            known = ('; Level 5 seen fitting: %s; refused: %s; %s' % (
                _pairs(verdict.verified), _pairs(verdict.refused), 'searched' if verdict.searched else 'not searched yet')
                if verdict else '')
            kodi.log('scenes: %s (cached), %s%s' % ('following' if verdict else 'not followed', verdict.reason, known))
        if not self.verdict:
            return
        if not choices.following():
            kodi.log('scenes: not followed, switched off in the settings')
            return
        why = ('an image subtitle shows' if playback.shown.kind == subtitles.IMAGE
               else 'no text margin placed' if playback.margin_placed is None
               else 'no picture height known' if not self.verdict.height
               else 'this CoreELEC build has no Level 5 labels' if not playback.service.p3i.offered() else None)
        if why:
            kodi.log('scenes: not watched, %s' % why)
            return
        if self.followed != epoch:
            self.followed = epoch
            kodi.log("scenes: watching P3i's Level 5")
            self.loop = followloop.FollowLoop(self, placing, self.chosen, height=self.verdict.height)
            playback.service.threads.start('follower', followloop.FollowLoop.follow, self.loop)
        if early:
            return                                      # the search waits for the settled shape
        # Nothing the search could find would move the text with Same as black bars: left for a later epoch that wants
        # it, searched still False.
        if not self.verdict.searched and not self.searching and not self.still:
            self.searching = True
            playback.service.threads.start('search', self._search_shapes, placing, self.verdict.height)

    def _follow_early(self, placing, keyframes):
        """While the measurement goes on (its own thread): following starts as soon as follow.TRUST_KEYFRAMES
        keyframes show Level 5 fitting, so a film's first playback follows its scenes within seconds rather than after
        every keyframe. keyframes: the measurement's list, growing as it decodes."""
        playback = self.playback
        try:
            # Until the measurement ends: its list grows no more after that.
            while (placing.is_current() and playback.measured is None and playback.measuring is not None
                   and self.followed != placing.epoch):
                so_far = list(keyframes)                # judged once: the list grows meanwhile
                if len(so_far) >= follow.TRUST_KEYFRAMES and follow.trust(so_far):
                    with self._lock:
                        if self.rule is None and playback.picture is not None:
                            # The estimate's rule until the shape settles (settled replaces it).
                            self._judge(placing.layout, playback.picture[1])
                        self._judge_and_start(placing, so_far, early=True)
                    return
                if playback.service.monitor.waitForAbort(0.2):
                    return
        except Exception as error:  # never let a surprise disturb playback; the settled shape still decides
            kodi.log('scenes: early start stopped: %r' % error, always=True)

    # A follower's moments (followloop.Following).

    def reader(self, loop):
        """P3i's Level 5 labels, bound to the followed picture's rows and the video's shape, on the follower's thread."""
        return self.playback.service.labels.reader(loop.height, loop.placing.layout.video_ratio,
                                                   film_time=self.film_seconds)

    def check(self, loop, picture):
        """A check of a reading on a thread of its own, follow.CHECKS_MOST at most in the playback (every epoch's
        follower counts). True when started. Asked only from a follower's look, under looking: one at a time."""
        if self.checks >= follow.CHECKS_MOST:
            return False
        self.checks += 1
        self.playback.service.threads.start('check', self._answer_check, loop.placing, picture, loop.follower,
                                            loop.reader)
        return True

    def _answer_check(self, placing, picture, follower, reader):
        """A check for a reading the text already went down to, on its own thread; the answer goes to the follower.
        Passed, the shape is kept with the cached verdict, so the next playback of the film knows it. reader: the
        follower's, so the check reads the labels as it does."""
        shown = (picture.top, picture.bottom)
        result = None
        try:
            result = self._check_scene(placing, picture, reader)
            # Kept with the film either way: a refused one is never followed down in any playback.
            if self.verdict.learn(shown, result, picture.height):
                self.playback.memory.remember_judgement('follow', self.verdict)
        except Exception as error:  # a surprise: no answer, so the text stays where it went
            kodi.log('scene check stopped: %r' % error, always=True)
        follower.answered(shown, result)

    def _check_scene(self, placing, picture, reader):
        """follow.check on the keyframes from CHECK_AHEAD past the playing position, CHECK_SPACING apart, for a reading
        not seen fitting yet: True or False from the first keyframe that can say, None when none of CHECK_FRAMES could
        (dark, another scene, no keyframe, unreadable, left to Kodi) or the labels moved on (no point in looking
        further). On the check's own thread: decoding lowers its thread's priority for good."""
        playback = self.playback
        service = playback.service
        target, _unreadable = playback.target()
        if target is None or not service.guard.allowed(target.identity):
            return None
        try:
            start = float(service.getTime()) + follow.CHECK_AHEAD
        except Exception:  # not playing any more, or Kodi could not say
            return None
        positions = [start + number * follow.CHECK_SPACING for number in range(follow.CHECK_FRAMES)]
        shown = (picture.top, picture.bottom)

        def note(at, reason):
            kodi.log('scene check at %d s (Level 5 %d/%d shown): %s' % (at, shown[0], shown[1], reason))

        # A move undone at a seek (P3i's short "no Level 5") needs no keyframe: looked at again before reading.
        if service.monitor.waitForAbort(follow.CHECK_SETTLE):
            return None
        if service.held() or not reader.shows(shown):
            note(positions[0], 'the reading is gone (a seek), nothing read')
            return None
        # Every read of the playing file waits for smooth playback (playback.steady): a cached playback measured nothing,
        # so a check can be its first read of the file, Kodi's buffer still filling at a start.
        asked = service.clock()
        if not playback.steady.wait(placing.is_current):
            return None
        waited = service.clock() - asked
        if waited > 0:
            note(positions[0], 'waited %.1f s for smooth playback' % waited)
        film = service.film(target, placing.is_current)
        try:
            film.open()            # waits while the measurement or the search reads: the playback's one reader
            # That wait can take tens of seconds: the labels and the film's time are looked at again after it.
            if service.held() or not reader.shows(shown):
                note(positions[0], 'the reading is gone, nothing read')
                return None
            try:
                now = float(service.getTime())
            except Exception:  # not playing any more, or Kodi could not say
                return None
            if now < 0:
                note(positions[0], "Kodi's clock has not started, nothing read")
                return None
            positions = [now + follow.CHECK_AHEAD + number * follow.CHECK_SPACING
                         for number in range(follow.CHECK_FRAMES)]
            began = service.clock()
            for number, at in enumerate(positions):
                if number and (service.held() or playback.steady.seeked_since(began)):
                    # Read through a seek, a keyframe costs Kodi frames (about 50 a seek on the box): asked again
                    # after follow.CHECK_AGAIN.
                    note(at, 'a seek, check stopped')
                    return None
                if number and not reader.shows(shown):
                    note(at, 'another scene now, check stopped')
                    return None
                keyframe = film.keyframe(at, uneven=True, faint=False)
                if keyframe.frame is None:
                    note(at, 'no keyframe decoded')
                    continue
                result, reason = follow.check(keyframe, shown)
                note(at, reason)
                if result is not None:
                    return result
        except libav.Unavailable as reason:
            note(positions[0], str(reason))
        finally:
            if film.opened:
                film.close()
        return None

    def _search_shapes(self, placing, height):
        """The film's other shapes before their scenes come: follow.SEARCH_FRAMES keyframes spread over the film, those
        ahead of the playing position first, each judged against its own Level 5 (follow.check). Fitting Level 5 joins
        the verdict's verified, Level 5 missing its picture joins its refused (seen fitting wins); the follower uses
        both lists as they grow. Run to its end, it is kept with the cached verdict, so it runs once per film. It reads
        the film, not a track: it runs as long as the playback, whatever newer epoch places meanwhile (a track switch
        during it would end it for the rest of the playback otherwise)."""
        playback = self.playback
        service = playback.service
        current = playback.still_playing
        frames = None
        try:
            target, _unreadable = playback.target()
            if target is None or not service.guard.allowed(target.identity):
                return
            length, now = float(service.getTotalTime()), float(service.getTime())
            spread = [(number + 0.5) * length / follow.SEARCH_FRAMES for number in range(follow.SEARCH_FRAMES)]
            positions = [at for at in spread if at >= now] + [at for at in spread if at < now]
            frames = service.film(target, current).keyframes(positions, uneven=True, faint=False)
            began, waiting = service.clock(), 0.0
            for at in positions:
                # playback.steady before each keyframe: a seek never meets the search's reads (on the box about 50
                # skipped frames a seek while it read on, 2 to 3 without). A cached playback measured nothing: its search
                # can be the first read of the file, which waits for Kodi's buffer at the playback's start.
                asked = service.clock()
                if not playback.steady.wait(current):
                    return                          # stopped: searched again next time
                waiting += service.clock() - asked
                keyframe = next(frames, None)
                if not current():
                    return                          # stopped (also during the last keyframe): searched again next time
                if keyframe is None or keyframe.level5_pair is None:
                    continue                    # nothing decoded, or no Dolby Vision metadata
                shown = keyframe.level5_pair
                result, reason = follow.check(keyframe, shown)
                if self.verdict.learn(shown, result, height):
                    kodi.log('scene search at %d s: %s, %s' % (
                        at, reason, 'kept' if result else 'the text never goes down to it'))
            self.verdict.searched = True
            kodi.log('scenes searched: %d keyframes; Level 5 seen fitting: %s; %.1f s, %.1f s of it waiting for smooth '
                     'playback' % (len(positions), _pairs(self.verdict.verified), service.clock() - began, waiting))
            playback.memory.remember_judgement('follow', self.verdict)
        except Exception as error:  # libav.Unavailable, or a surprise: searched again at the next playback
            kodi.log('scene search stopped: %s' % (str(error) if isinstance(error, libav.Unavailable) else repr(error)))
        finally:
            if frames is not None:
                frames.close()
