"""The background service: find the picture's shape once per playback, then step aside.

Per playback: check that there is anything to do, work out the picture's shape (from the
file's own shape when it is already cropped, otherwise by measuring), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command, and once the shape is known it does
nothing more until the next playback.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there), elsewhere from tiny screen captures with the video file as a fallback where the
system has FFmpeg. Everything runs on its own thread; any failure leaves Kodi's normal
subtitle position.
"""
import contextlib
import functools
import os
import re
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

from . import coreelec, diagnostics, geometry, kodi, locate, measure, override, status, updates
from .guard import DecodeGuard
from .keeper import Keeper, Switch
from .memo import Memo

MARGIN_SETTING = 'subtitles.marginvertical'
SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 is taken as already cropped
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
VIDEO_HEIGHT = 'Player.Process(videoheight)'   # the frame's height, Level 5 offsets are rows of it
HDR_TYPE = 'Player.Process(video.source.hdr.type)'
LEFT_TO_COREELEC = 'coreelec'  # session memory: CoreELEC places this film's subtitles
LEVEL5_EARLIEST = 3.0          # seconds after the start before a Level 5 correction is written
UPDATE_PACKAGES = 'special://home/addons/packages/'   # where Kodi downloads an update before installing it
UPDATE_RECENT_S = 600.0        # a package this new belongs to the update now under way


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = _Monitor(self._settings_changed)
        self.enabled = kodi.setting_bool('enabled')
        self.distances = distances()
        # Each change keeps a record until Kodi's memory and its settings file are free of it.
        self.override = override.Override(lambda: kodi.get_setting(override.SETTING),
                                          lambda value: kodi.set_setting(override.SETTING, value),
                                          kodi.data_path('level5.json'),
                                          lambda: kodi.saved_setting(override.SETTING))
        self.keeper = Keeper(lambda: _number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'),
                             lambda: _number(kodi.saved_setting(MARGIN_SETTING)))
        # CoreELEC's "Apply configured subtitle margin", switched on for a distance (off by default).
        self.margin_switch = Switch(lambda: kodi.get_setting(coreelec.MARGIN_SETTING),
                                    lambda value: kodi.set_setting(coreelec.MARGIN_SETTING, value),
                                    kodi.data_path('margin_switch.json'),
                                    lambda: _switch(kodi.saved_setting(coreelec.MARGIN_SETTING)),
                                    kodi.saved_settings_stamp)
        self.lock = threading.Lock()
        self.generation = 0
        self.manual_notice_shown = False
        self.on_coreelec = coreelec.is_coreelec()
        self.version = kodi.addon().getAddonInfo('version')
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), self.version)
        self.memo = Memo()
        self.waiting_for_subtitles = None   # playback that had no subtitles yet; measured once some appear
        self.started = time.time()           # when the current playback started
        self.carried_over = None             # a playback this service found running when it started

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        self.started = time.time()
        generation = self._next_generation()
        if self._playing_video():
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onAVChange(self):
        # Streams changed: subtitles switched on later in a playback that had none at the start.
        generation = self.waiting_for_subtitles
        if generation is not None and _holds('VideoPlayer.HasSubtitles') and self._claim_waiting(generation):
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onPlayBackStopped(self):
        self._finish('playback stopped')

    def onPlayBackEnded(self):
        self._finish('playback ended')

    def onPlayBackError(self):
        self._finish('playback error')

    def run(self):
        self.start()
        while not self.monitor.waitForAbort(30):
            pass
        try:
            self.stopping()
        finally:
            self.guard.wait_until_idle()

    def start(self):
        """The service's start. Started during playback: Kodi updated the add-on (it does so by
        itself), it was switched on, or the service started again after a failure. What is in
        place belongs to that playback, so it is carried on: no repair, no "next video" clearing,
        measured again (the same answer changes nothing on screen)."""
        playing = self._playing_video()
        steps = (self._move_old_settings, self._check_last_run, self._show_status) if playing else \
            (self._move_old_settings, self._repair, self._check_last_run, self._show_status)
        # Each step at the start on its own: one failing must not keep the others from running.
        for step in steps:
            try:
                step()
            except Exception as error:
                kodi.log('start: %s not done: %r' % (step.__name__.strip('_').replace('_', ' '), error), always=True)
        self.distances = distances()     # after the move: that change is no reason to place again
        if playing:
            self.carried_over = self.generation + 1
            self.onAVStarted()

    def stopping(self):
        """The service is asked to stop. Kodi closing (it has saved its settings by now) or an
        update (the next service carries on): everything stays as it is, on record, for the next
        start. Switched off or removed in Kodi's add-ons: nobody else would put things back.

        Seen in a real Kodi 21: during an update the add-on is already unknown to Kodi when its
        service stops, as after removing it; what tells them apart is the new version's package,
        which Kodi has just downloaded. When unsure, everything is put back."""
        details = kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID, 'properties': ['enabled']},
                           quiet=True)
        addon = details.get('addon') if isinstance(details, dict) else None
        if isinstance(addon, dict) and addon.get('enabled') is True:
            why = 'Kodi closing'
        elif addon is None and self._update_arriving():
            why = 'the add-on updating'
        else:
            self._finish('add-on switched off or removed', always=True)
            return
        with self.lock:
            self.generation += 1              # a measurement still running changes nothing more
        kodi.log('stopping (%s): changes stay on record for the next start' % why, always=True)

    def _update_arriving(self):
        """True when Kodi has just downloaded a newer version of this add-on to install."""
        try:
            folder = xbmcvfs.translatePath(UPDATE_PACKAGES)
            mine = updates.parts(self.version)
            for name in os.listdir(folder):
                found = re.match(r'%s-([0-9][0-9.]*)\.zip$' % re.escape(kodi.ADDON_ID), name)
                if found and mine and (updates.parts(found.group(1).rstrip('.')) or ()) > mine and \
                        time.time() - os.path.getmtime(os.path.join(folder, name)) < UPDATE_RECENT_S:
                    return True
        except Exception:  # unknown: not an update
            pass
        return False

    def _repair(self):
        """What an unfinished playback left (Kodi crashed or was cut off) is put back."""
        with self.lock:
            if self.margin_switch.restore():
                kodi.log('CoreELEC\'s subtitle margin option switched off after an unfinished playback', always=True)
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
            if self.override.restore():
                kodi.log('Level 5 correction cleared after an unfinished playback', always=True)

    def _check_last_run(self):
        interrupted = self.guard.check_last_run()
        if interrupted == 'skipped':
            kodi.log('Kodi stopped during a decode last time; that video is left to Kodi from now on', always=True)
        elif interrupted == 'paused':
            kodi.log('Kodi stopped during a decode twice in a row; video file analysis pauses for a day', always=True)

    def _move_old_settings(self):
        """Up to 0.3.23 "Small gap from the black bar" was a switch (edge_gap, now hidden): on
        becomes Small gap for content with black bars, once."""
        if kodi.setting_bool('edge_gap', default=False):
            kodi.addon().setSettingInt('gap_bars', 1)
            kodi.addon().setSettingBool('edge_gap', False)
            kodi.log('"Small gap from the black bar" moved to "Distance in content with black bars"', always=True)

    def _settings_changed(self):
        """Switched off: the own margin goes back at once. Switched on during a video: measure it.
        A distance changed during a video: placed again with it. Level 5 correction off: a
        correction in place is cleared. Other changes (the status fields the service writes
        itself, among them) do nothing."""
        changed, self.distances = self.distances != distances(), distances()
        if not any(self.distances):
            with self.lock:     # CoreELEC goes back to the picture's edge at once
                if self.margin_switch.restore():
                    kodi.log('distances set to none: CoreELEC\'s subtitle margin option switched off')
        if not kodi.setting_bool('fix_level5', default=False):
            with self.lock:     # does nothing unless a correction is in place
                if self.override.restore():
                    kodi.log('Level 5 correction turned off: cleared')
        enabled = kodi.setting_bool('enabled')
        if enabled == self.enabled:
            if changed and enabled and self._playing_video():
                kodi.log('distances changed to %.2f and %.2f: placed again' % self.distances)
                self.onAVStarted()
            return
        self.enabled = enabled
        if not enabled:
            self._finish('turned off in settings')
        elif self._playing_video():
            self.onAVStarted()

    def _playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return False

    def _show_status(self):
        # Quiet: P3i's own setting is only readable while P3i shows it, and its absence says enough.
        p3i = self.on_coreelec and coreelec.is_p3i(lambda setting: kodi.get_setting(setting, quiet=True),
                                                   xbmc.getInfoLabel('System.BuildVersion'))
        system, method = status.describe(self.on_coreelec, p3i, not self.guard.paused(), xbmc.getCondVisibility)
        for setting_id, string_id in (('status_system', system), ('status_method', method)):
            try:
                shown, wanted = kodi.addon().getSetting(setting_id), kodi.text(string_id)
                if shown != wanted:     # Kodi writes its settings file on every change
                    kodi.addon().setSetting(setting_id, wanted)
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        kodi.log('started: %s, %s' % (kodi.text(system), kodi.text(method).lower()))

    # Bookkeeping.

    def _next_generation(self):
        with self.lock:
            self.generation += 1
            return self.generation

    def _claim_waiting(self, generation):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.lock:
            if self.waiting_for_subtitles == generation == self.generation:
                self.waiting_for_subtitles = None
                return True
            return False

    def _current(self, generation):
        return generation == self.generation and not self.monitor.abortRequested()

    def _finish(self, why, always=False):
        """always: log without asking for the detailed log setting (Kodi logs an error for that
        while the add-on is being switched off, even though the answer is not needed)."""
        with self.lock:
            self.generation += 1
            if self.margin_switch.restore():      # before the margin, so nothing moves in between
                kodi.log('%s: CoreELEC\'s subtitle margin option switched off' % why, always)
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why, always)
            if self.override.restore():
                kodi.log('%s: Level 5 correction cleared' % why, always)

    def _restore_if_current(self, generation, why):
        with self.lock:
            if generation == self.carried_over:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                if self._current(generation):
                    kodi.log('%s: what the previous service set for this video stays' % why)
                return
            if self._current(generation) and self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    # The work for one playback, on its own thread.

    def _fit(self, generation):
        try:
            with self.lock:       # a playlist's next video: the previous one's changes go
                carried_over = generation == self.carried_over
                if self._current(generation) and not carried_over and self.override.restore():
                    kodi.log('next video: Level 5 correction cleared')
                if self._current(generation) and not carried_over and self.margin_switch.restore():
                    kodi.log('next video: CoreELEC\'s subtitle margin option switched off')
            self._fit_once(generation)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self._restore_if_current(generation, 'unexpected error')
            except Exception:
                pass

    def _fit_once(self, generation):
        if not self.on_coreelec and self.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self._current(generation):
            return
        layout = self._layout(generation)
        if layout is None:
            return
        area, screen_w, screen_h, video_ratio = layout
        if abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE:
            self._apply(generation, layout, video_ratio, 'file already cropped', time.time())
            return

        started = time.time()
        current = lambda: self._current(generation)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self._target()
        identity = target.identity if target else None
        known = self.memo.get(identity) if identity else None
        if known == LEFT_TO_COREELEC:
            kodi.log('CoreELEC places the subtitles (its Level 5, remembered from earlier this session)')
            self._coreelec_places(generation)
            return
        if known is not None:
            self._apply(generation, layout, known, 'remembered from earlier this session', started)
            return
        for name, attempt in self._ways(video_ratio, current, record, target, unreadable, full_pictures):
            try:
                # Closed explicitly, so a decoder is freed the moment the answer is in.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        self._apply(generation, layout, ratio, how, started, final)
                        if final:
                            if identity:
                                self.memo.put(identity, ratio)
                            return
                kodi.log('%s gave no clear answer' % name)
                self._restore_if_current(generation, 'no clear answer')
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self._coreelec_places(generation)
                if identity:
                    self.memo.put(identity, LEFT_TO_COREELEC)
                return
        kodi.log('no way of measuring worked for this playback; subtitles left where Kodi puts them')
        # The previous item of a playlist may have changed the margin: this one gets the person's own.
        self._restore_if_current(generation, 'not measured')

    def _layout(self, generation):
        """(area, screen width, screen height, video ratio), or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self._finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, generation):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self._restore_if_current(generation, 'no subtitles')
            self.waiting_for_subtitles = generation
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self._claim_waiting(generation)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self._restore_if_current(generation, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self._restore_if_current(generation, 'position not handled')
            self._manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self._restore_if_current(generation, 'view mode not normal')
            return None
        if self.on_coreelec and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.monitor.waitForAbort,
                lambda: self._current(generation), kodi.log):
            self._coreelec_places(generation)
            if self._current(generation) and kodi.setting_bool('fix_level5', default=False):
                self._correct_level5(generation)
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, generation)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self._restore_if_current(generation, 'size unknown')
            return None
        return area, screen_w, screen_h, video_ratio

    def _correct_level5(self, generation):
        """CoreELEC places these subtitles from the film's Level 5: give it the right edges when
        that Level 5 is clearly wrong (Correct faulty Dolby Vision Level 5, off by default)."""
        target, unreadable = self._target()
        if target is None:
            kodi.log('Level 5 not checked: %s' % unreadable)
            return
        if override.set_by_override_ini(target.address, _read_text):
            kodi.log('Level 5 left alone: override.ini supplies it for this folder')
            return
        if xbmc.getInfoLabel(coreelec.SCAN_STATE) == '3':
            # CoreELEC only scans films without Level 5 of their own: nothing to correct.
            kodi.log('Level 5 left alone: CoreELEC measured this film itself')
            return
        key = 'level5|' + target.identity
        known = self.memo.get(key)
        if known is None:
            if not self.guard.allowed(target.identity):
                kodi.log('Level 5 not checked: left to Kodi after an interrupted decode')
                return
            try:
                correction, reason = measure.level5_correction(
                    target, self.getTotalTime(), kodi.data_path('ffmpeg.json'),
                    lambda: self._current(generation), functools.partial(self.guard.decoding, target.identity))
            except Exception as error:  # Unavailable, or Kodi could not say: never a reason to stop
                kodi.log('Level 5 not checked: %s' % error)
                return
            if not self._current(generation):
                return
            kodi.log('Level 5 check: %s' % reason)
            known = override.value_for(*correction) if correction else ''
            self.memo.put(key, known)
        if not known:
            return
        # P3i's per-folder override add-on writes the same setting from override.ini at the start
        # of playback, and saves what it found there to put back afterwards: never write before it.
        wait = self.started + LEVEL5_EARLIEST - time.time()
        if wait > 0 and self.monitor.waitForAbort(wait):
            return
        with self.lock:
            if not self._current(generation):
                return
            applied = self.override.apply(known)
        if applied:
            kodi.log('Level 5 corrected for CoreELEC: %s' % known, always=True)
        else:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 override holds another value '
                     '(override.ini, or another add-on)', always=True)

    def _wait_for(self, condition, seconds, generation, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self._current(generation):
            if condition():
                return True
            if waited >= seconds or self.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def _target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Resolved once per playback: it names the session memory's entry and is what the file
        analysis reads (a Plex transcode costs one question to the server)."""
        try:
            return locate.resolve(self.getPlayingFile(), stat=xbmcvfs.Stat), None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.monitor.waitForAbort, record)

        def from_file():
            if target is None:
                raise measure.Unavailable(unreadable)
            if not self.guard.allowed(target.identity):
                raise measure.Unavailable('left to Kodi after an interrupted decode')
            try:
                length = self.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            hands_over = self.on_coreelec and coreelec.restricts_with_level5(kodi.get_setting, xbmc.getInfoLabel)
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                functools.partial(self.guard.decoding, target.identity), full=full_pictures,
                                level5_hands_over=hands_over)

        if self.on_coreelec:
            return [('video file analysis', from_file)]
        return [('screen capture', screen), ('video file analysis', from_file)]

    def _apply(self, generation, layout, picture_ratio, how, started, final=True):
        area, screen_w, screen_h, video_ratio = layout
        bars_gap, full_gap = distances()
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, not handled')
                return
            value = geometry.margin_value(area, screen_w / screen_h, video_ratio, picture_ratio, bars_gap, full_gap)
            changed = self.keeper.apply(value)
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; margin %.2f -> %.2f%s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, own, value, '' if changed else ' (unchanged)'))
        if final and self._level5_for_the_tv():
            self._correct_level5(generation)

    def _level5_for_the_tv(self):
        """Dolby Vision the add-on places itself, with "Correct faulty Dolby Vision Level 5" on and
        CoreELEC's Level 5 handling on (its override is only readable then): the TV gets the
        corrected Level 5 too."""
        return (self.on_coreelec and kodi.setting_bool('fix_level5', default=False)
                and xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision'
                and kodi.get_setting(override.SETTING, quiet=True) is not None)

    def _coreelec_places(self, generation):
        """CoreELEC places these subtitles on the picture's edge. With a distance chosen for this
        content's shape, Kodi's margin becomes that distance first (CoreELEC ignores it until its
        margin option is on), then that option is switched on; both are put back after playback."""
        full = self._p3i_full_screen(generation)
        if full and distances()[0] != distances()[1] and self._changing_level5(generation):
            full = False
        gap = distances()[1 if full else 0]
        shape = 'full-screen content' if full else 'content with black bars'
        if not gap:
            with self.lock:     # no distance: CoreELEC's margin option off again if we switched it on
                if self._current(generation) and self.margin_switch.restore():
                    kodi.log('CoreELEC places the subtitles: its subtitle margin option switched off')
            kodi.log('CoreELEC places the subtitles of %s on the edge' % shape)
            self._restore_if_current(generation, 'CoreELEC places the subtitles')
            return
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, no distance')
                return
            changed = self.keeper.apply(gap)
            margin = _number(kodi.get_setting(MARGIN_SETTING))
            if margin is None or abs(margin - gap) >= 0.001:
                # Refused: CoreELEC would place the subtitles at the person's own margin instead.
                kodi.log('CoreELEC places the subtitles; no distance, the subtitle margin could not be set')
                return
            if not self.margin_switch.on():
                self.keeper.restore()
                kodi.log('CoreELEC places the subtitles; no distance, its subtitle margin option is not available')
                return
        kodi.log('CoreELEC places the subtitles of %s %.2f from the edge: margin %.2f -> %.2f%s' % (
            shape, gap, own, gap, '' if changed else ' (unchanged)'))

    def _changing_level5(self, generation):
        """Whether keyframes from across a film CoreELEC places carry Level 5 with real bars although
        it starts full-screen: an IMAX film whose cinemascope scenes would otherwise get the
        full-screen distance above their bars. Unreadable files are taken as P3i reports them."""
        target, _unreadable = self._target()
        if target is None or not self.guard.allowed(target.identity):
            return False
        try:
            length = self.getTotalTime()
            tallest = measure.level5_bars(target, length, kodi.data_path('ffmpeg.json'),
                                          lambda: self._current(generation),
                                          functools.partial(self.guard.decoding, target.identity))
        except Exception as error:  # measure.Unavailable, or Kodi could not say the length
            kodi.log('Level 5 of the keyframes not read: %s' % error)
            return False
        if tallest is not None and tallest > geometry.FULL_SCREEN_BARS:
            kodi.log('CoreELEC starts this film full-screen, but its keyframes carry bars of %.1f %%: '
                     'the distance for content with black bars' % (tallest * 100))
            return True
        return False

    def _p3i_full_screen(self, generation):
        """Whether content CoreELEC places fills the screen (each bar at most FULL_SCREEN_BARS),
        from what it reports: Level 5 or scan offsets against the frame's height, or for content
        that is not 16:9 (scan state 1: Kodi's own bars) the file's shape on this screen.
        Anything it does not say counts as content with black bars, as before 0.3.24."""
        top = _count(xbmc.getInfoLabel(coreelec.L5_TOP)) or 0
        bottom = _count(xbmc.getInfoLabel(coreelec.L5_BOTTOM)) or 0
        height = _count(xbmc.getInfoLabel(VIDEO_HEIGHT))
        if (top > 0 or bottom > 0) and height and height > 0:
            return max(top, bottom) / height <= geometry.FULL_SCREEN_BARS
        if xbmc.getInfoLabel(coreelec.SCAN_STATE) != '1':
            return False
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, generation)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            return False
        return geometry.full_screen(screen_w / screen_h, video_ratio, video_ratio)

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None

    def _manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32040), kodi.addon().getAddonInfo('icon'), 8000)


def distances():
    """(content with black bars, full-screen content): the distances chosen in the menu."""
    return (geometry.bar_distance(kodi.setting_int('gap_bars', 0)),
            geometry.full_distance(kodi.setting_int('gap_full', geometry.FULL_DEFAULT),
                                   kodi.setting_number('gap_full_custom', geometry.FULL_DISTANCES[geometry.FULL_DEFAULT])))


def _read_text(path):
    """A small text file's contents, through Kodi's file access (local and network folders), or None."""
    try:
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:  # unreadable: as if there were none
        return None


def _holds(condition):
    try:
        return xbmc.getCondVisibility(condition)
    except Exception:  # Kodi could not say
        return False


def _switch(text):
    """A switch setting's value as Kodi's settings file writes it: True, False or None."""
    return {'true': True, 'false': False}.get(text)


def _count(text):
    """A whole number as Kodi shows it, with or without thousands separators: Player.Process(videoheight)
    reads '2,160' on P3i (seen 2026-10-11), '2.160' or '2 160' in other languages. None otherwise."""
    digits = re.sub(r'[,.\s\u00a0\u202f\u2009\']', '', text if isinstance(text, str) else '')
    return int(digits) if digits.isdigit() else None


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


RESTART_S, RESTART_MAX_S = 30, 1800    # after an unexpected failure of the service as a whole


def run():
    """The service, started again after anything unexpected (waiting longer each time), so one
    failure never leaves it off for the rest of the session."""
    monitor, pause = xbmc.Monitor(), RESTART_S
    while not monitor.abortRequested():
        try:
            Service().run()
            return
        except Exception as error:
            kodi.log('stopped by an unexpected error, starting again in %d s: %r' % (pause, error), always=True)
        if monitor.waitForAbort(pause):
            return
        pause = min(pause * 2, RESTART_MAX_S)
