"""Decoding single keyframes from the playing file with the FFmpeg libraries already on the system.

Used where Kodi's own frame grab cannot see the video (CoreELEC, Amlogic's hardware video
plane), and as the fallback where the frame grab gives no picture. The system's libavformat, libavcodec and libavutil are loaded through ctypes and
found without assumptions about where they live: a remembered path first, then the copy
Kodi itself has loaded (from this process's memory map), then the usual folders.

Files are opened directly (local paths, web addresses) or read through Kodi's own file
access (smb://, nfs://, ...) via a custom FFmpeg I/O context. Probing is kept short: only
the video stream's settings are needed, and they sit in the file's header.

A few FFmpeg structures are read directly. Their layout is only relied on for libavformat 61
and 62 (FFmpeg 7 and 8), and every pointer and size read is checked before it is used. The
playing address can carry an access token: it is never logged or stored.
"""
import collections
import ctypes
import glob
import json
import os
import platform
import re
import sys
import threading
import time

from . import detect, locate

P = ctypes.sizeof(ctypes.c_void_p)
KNOWN_MAJORS = (61, 62)
AVMEDIA_TYPE_VIDEO = 0
AVMEDIA_TYPE_SUBTITLE = 3
AV_DISPOSITION_FORCED, AV_DISPOSITION_HEARING_IMPAIRED = 0x40, 0x80
DISPOSITION_KNOWN = (1 << 22) - 1    # every AV_DISPOSITION flag of FFmpeg 7 and 8 lies below this
AVSEEK_FLAG_BACKWARD = 1
AVDISCARD_NONKEY = 32
AVDISCARD_ALL = 48
AVERROR_EAGAIN = -11      # the decoder wants more input first
MAX_PACKETS_PER_SAMPLE = 600
FOLDERS = ('/usr/lib', '/usr/lib/kodi', '/usr/local/lib', '/lib', '/usr/lib/arm-linux-gnueabihf',
           '/usr/lib/aarch64-linux-gnu', '/usr/lib/x86_64-linux-gnu')


# One sample: the grey frame (None when no keyframe came out) and the text for the log; for a decoded keyframe also
# its Dolby Vision Level 5 offsets (top, bottom, left, right) or None, whether it carried Dolby Vision metadata at
# all, and its own size (width, height).
Keyframe = collections.namedtuple('Keyframe', 'frame detail level5 dovi size')


class Unavailable(Exception):
    """The file can not be measured this way. The message is for the log."""


# Finding the libraries -------------------------------------------------------------------

def _loaded_by_kodi(name):
    found = []
    try:
        with open('/proc/self/maps', encoding='utf-8', errors='replace') as handle:
            for line in handle:
                path = line.rsplit(' ', 1)[-1].strip()
                if '/lib%s.so' % name in path and path not in found:
                    found.append(path)
    except OSError:
        pass
    return found


def _candidates(name, remembered):
    first = [remembered[name]] if remembered.get(name) else []
    folders = [p for folder in FOLDERS for p in sorted(glob.glob('%s/lib%s.so*' % (folder, name)), reverse=True)]
    system = []
    try:
        import ctypes.util
        found = ctypes.util.find_library(name)
        system = [found] if found else []
    except Exception:  # find_library runs external tools; any failure only means "not found"
        pass
    seen, order = set(), []
    for path in first + _loaded_by_kodi(name) + folders + system:
        if path and path not in seen:
            seen.add(path)
            order.append(path)
    return order


def _load(name, remembered, check):
    for path in _candidates(name, remembered):
        try:
            library = ctypes.CDLL(path)
            if not check(library):
                continue
        except (OSError, AttributeError):
            continue
        remembered[name] = path
        return library
    remembered.pop(name, None)
    return None


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, data):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except OSError:
        pass


def matching_majors(avformat_major):
    """The libavcodec and libavutil major versions of the same FFmpeg release: FFmpeg bumps
    libavformat and libavcodec together, with libavutil two lower (FFmpeg 7: 61, 61, 59;
    FFmpeg 8: 62, 62, 60). Mixing releases would hand one release's structures to another."""
    return avformat_major, avformat_major - 2


def libraries(memory_path):
    """(avformat, avcodec, avutil, description). Raises Unavailable."""
    remembered = _read_json(memory_path)
    before = dict(remembered)
    avformat = _load('avformat', remembered, lambda lib: (lib.avformat_version() >> 16) in KNOWN_MAJORS)
    avcodec = avutil = None
    if avformat:
        codec_major, util_major = matching_majors(avformat.avformat_version() >> 16)
        avcodec = _load('avcodec', remembered, lambda lib: (lib.avcodec_version() >> 16) == codec_major)
        avutil = _load('avutil', remembered, lambda lib: (lib.avutil_version() >> 16) == util_major)
    if remembered != before:
        _write_json(memory_path, remembered)
    if not (avformat and avcodec and avutil):
        raise Unavailable('no FFmpeg 7 or 8 libraries found')
    return avformat, avcodec, avutil, 'FFmpeg (libavformat %d)' % (avformat.avformat_version() >> 16)


def usable(memory_path):
    """True when an FFmpeg release this add-on knows can be loaded."""
    try:
        libraries(memory_path)
        return True
    except Unavailable:
        return False


def newer_release(memory_path):
    """The libavformat major of a newer FFmpeg than this add-on knows when that is all the system has
    (FFmpeg 9 and up: its structures are not known here, so nothing is read with it), else None."""
    try:
        libraries(memory_path)
        return None
    except Unavailable:
        pass
    majors = []
    for path in _candidates('avformat', {}):
        try:
            majors.append(ctypes.CDLL(path).avformat_version() >> 16)
        except (OSError, AttributeError):
            continue
    newer = [major for major in majors if major > max(KNOWN_MAJORS)]
    return max(newer) if newer else None


# Decoding --------------------------------------------------------------------------------

AVSEEK_SIZE = 0x10000
AVERROR_EOF = -0x20464F45
IO_BUFFER = 64 * 1024
PROBE_OPTIONS = ((b'probesize', b'2000000'), (b'analyzeduration', b'1000000'),
                 (b'rw_timeout', b'5000000'))   # a stalled network read gives up after 5 s
# Brightness planes this module can read: 8 to 16 bits, little endian, luma first.
PLANAR_YUV = ('yuv', 'nv12', 'nv21', 'nv16', 'nv24', 'p010le', 'p012le', 'p016le', 'gray')
EDGE_SHARE = 0.25          # rows near the top and bottom edges that bars can occupy (detect uses 22 %)


def _pointer(address, offset):
    if not address:
        raise Unavailable('unexpected empty pointer')
    return ctypes.c_void_p.from_address(address + offset).value


def _integer(address, offset):
    return ctypes.c_int.from_address(address + offset).value


def _stream_index_offset(pointer_size, machine):
    """AVPacket: buf, pts, dts, data, size, stream_index. 64-bit numbers sit on 8 bytes except on 32-bit x86."""
    if pointer_size == 8:
        return 36
    return 28 if machine.lower() in ('i386', 'i486', 'i586', 'i686', 'x86') else 32


STREAM_INDEX_AT = _stream_index_offset(P, platform.machine())
PTS_AT = 8 if P == 8 or platform.machine().lower() not in ('i386', 'i486', 'i586', 'i686', 'x86') else 4
DTS_AT = PTS_AT + 8      # AVPacket.dts, right after pts
AV_NOPTS_VALUE = -(1 << 63)


def _stream_fields(pointer_size, machine):
    """AVStream (libavformat 61 and 62): av_class, index, id, codecpar, priv_data, time_base (two ints), then
    start_time, duration and nb_frames (64-bit), disposition, discard, sample_aspect_ratio (two ints) and
    metadata. (disposition, metadata) offsets; 64-bit numbers sit on 8 bytes except on 32-bit x86."""
    align = 4 if pointer_size == 4 and machine.lower() in ('i386', 'i486', 'i586', 'i686', 'x86') else 8
    start_time = -(-(3 * pointer_size + 16) // align) * align
    disposition = start_time + 24
    metadata = -(-(disposition + 16) // pointer_size) * pointer_size
    return disposition, metadata


DISPOSITION_AT, METADATA_AT = _stream_fields(P, platform.machine())
DISCARD_AT = DISPOSITION_AT + 4      # AVStream.discard: an enum, the int right after disposition


READ_PACKET = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int)
SEEK = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_void_p, ctypes.c_int64, ctypes.c_int)


def _declare(avformat, avcodec, avutil):
    vp, i = ctypes.c_void_p, ctypes.c_int
    pp = ctypes.POINTER(vp)
    for function, result, arguments in (
            (avformat.avformat_alloc_context, vp, []),
            (avformat.avformat_open_input, i, [pp, ctypes.c_char_p, vp, pp]),
            (avformat.avformat_find_stream_info, i, [vp, vp]),
            (avformat.av_find_best_stream, i, [vp, i, i, i, pp, i]),
            (avformat.av_seek_frame, i, [vp, i, ctypes.c_int64, i]),
            (avformat.av_read_frame, i, [vp, vp]),
            (avformat.avformat_close_input, None, [pp]),
            (avformat.avio_alloc_context, vp, [vp, i, i, vp, READ_PACKET, vp, SEEK]),
            (avformat.avio_context_free, None, [pp]),
            (avcodec.avcodec_alloc_context3, vp, [vp]),
            (avcodec.avcodec_parameters_to_context, i, [vp, vp]),
            (avcodec.avcodec_open2, i, [vp, vp, vp]),
            (avcodec.avcodec_send_packet, i, [vp, vp]),
            (avcodec.avcodec_receive_frame, i, [vp, vp]),
            (avcodec.avcodec_flush_buffers, None, [vp]),
            (avcodec.avcodec_free_context, None, [pp]),
            (avcodec.av_packet_alloc, vp, []),
            (avcodec.av_packet_unref, None, [vp]),
            (avcodec.av_packet_free, None, [pp]),
            (avutil.av_frame_alloc, vp, []),
            (avutil.av_frame_free, None, [pp]),
            (avutil.av_malloc, vp, [ctypes.c_size_t]),
            (avutil.av_free, None, [vp]),
            (avutil.av_dict_set, i, [pp, ctypes.c_char_p, ctypes.c_char_p, i]),
            (avutil.av_dict_free, None, [pp]),
            (avutil.av_opt_set_int, i, [vp, ctypes.c_char_p, ctypes.c_int64, i]),
            (avutil.av_get_pix_fmt_name, ctypes.c_char_p, [i]),
            (avutil.av_frame_get_side_data, vp, [vp, i]),
            (avutil.av_frame_side_data_name, ctypes.c_char_p, [i]),
            (avutil.av_dict_get, vp, [vp, ctypes.c_char_p, vp, i]),
            (avcodec.avcodec_get_name, ctypes.c_char_p, [i])):
        function.restype, function.argtypes = result, arguments


def _dovi_reader(avutil):
    """(side data type, av_dovi_find_level) for reading Dolby Vision metadata, or None where this
    FFmpeg has no way to (av_dovi_find_level arrived with FFmpeg 7). The type is looked up by
    its name, so a renumbered list in a later FFmpeg can not make it read the wrong data."""
    try:
        find_level = avutil.av_dovi_find_level
    except AttributeError:
        return None
    find_level.restype, find_level.argtypes = ctypes.c_void_p, [ctypes.c_void_p, ctypes.c_uint8]
    for number in range(64):
        if avutil.av_frame_side_data_name(number) == b'Dolby Vision Metadata':
            return number, find_level
    return None


# AVDOVIDmData: the level (uint8_t), then a union aligned to 4; AVDOVIDmLevel5 is four
# uint16_t offsets, left, right, top, bottom (read from FFmpeg 7's own headers).
LEVEL5_LEFT_AT, LEVEL5_RIGHT_AT, LEVEL5_TOP_AT, LEVEL5_BOTTOM_AT = 4, 6, 8, 10


def readable_format(name):
    """True for picture formats whose first plane is brightness, little endian, 8 to 16 bits."""
    return name.startswith(PLANAR_YUV) and not name.endswith('be')


def frame_layout_ok(data, width, height, line, wide):
    """The decoded frame's plane pointer, size and row length make sense before any byte is read."""
    return bool(data) and 16 <= width <= 16384 and 16 <= height <= 16384 and line >= width * wide


def pixel_depth(name):
    """Bits a brightness sample spans, for the shift to 8 bits: yuv420p10le and gray12le carry it at the end
    (their samples sit in the low bits); everything else (yuv420p, nv12, gray) is 8 bits. p010le, p012le and
    p016le keep their samples in the high bits of 16, so they span 16 (read as 10 they came out up to 16383)."""
    if re.match(r'p0(10|12|16)le$', name):
        return 16
    match = re.search(r'(?:p|gray)(9|10|12|14|16)le$', name)
    return int(match.group(1)) if match else 8


def grey_frame(read_row, width, height, depth, out_w, out_h, full=False):
    """A small BGR frame of the brightness plane, out_w x out_h.

    read_row(y) returns the raw bytes of source row y. Without full, only the rows near the
    top and bottom edges are read (where bars can be); the middle is filled with one row, as
    the bar detection never looks there. depth is 8 to 16 bits.
    """
    wide = 2 if depth > 8 else 1
    shift = depth - 8
    step = max(1, width // out_w)
    edge = int(out_h * EDGE_SHARE) + 1

    def row(y):
        data = memoryview(read_row((2 * y + 1) * height // (2 * out_h)))   # the middle of each band
        values = (data.cast('H') if wide == 2 else data)[::step][:out_w]
        grey = bytes(map(shift.__rrshift__, values)) if wide == 2 else bytes(values)   # v >> shift, at C speed
        grey = grey.ljust(out_w, grey[-1:] or b'\0')
        bgr = bytearray(out_w * 3)          # each value three times, at C speed
        bgr[0::3] = bgr[1::3] = bgr[2::3] = grey
        return bytes(bgr)

    if full:
        return b''.join(row(y) for y in range(out_h))
    middle = row(out_h // 2)
    rows = [row(y) if y < edge or y >= out_h - edge else middle for y in range(out_h)]
    return b''.join(rows)


CURRENT_EVERY = 0.5     # seconds between the reader's checks that its playback is still current


def _nothing(detail):
    return Keyframe(None, detail, None, False, None)


class KodiReader:
    """Kodi's file access, for FFmpeg's custom I/O. Errors read as end of file.

    current: asked at most every CURRENT_EVERY seconds while reading; once it says no, every read
    is the end of the file, so a slow share ends the decode within one read instead of carrying on
    for a playback that is gone. A read already stalled inside Kodi can not be cut short.
    """

    def __init__(self, address, current=None):
        import xbmcvfs
        self.current, self.checked, self.stopped = current, time.monotonic(), False
        self.file = xbmcvfs.File(address)
        try:
            self.length = int(self.file.size())
        except Exception:  # Kodi could not say
            self.length = -1
        if self.length == 0:
            self.file.close()
            raise Unavailable('Kodi can not read the source')

    def read(self, size):
        if self.current is not None and not self.stopped and time.monotonic() - self.checked >= CURRENT_EVERY:
            self.checked = time.monotonic()
            try:
                self.stopped = not self.current()
            except Exception:  # Kodi could not say: the measuring loop asks again before the next keyframe
                pass
        if self.stopped:
            return b''
        try:
            return bytes(self.file.readBytes(size))
        except Exception:  # an unreachable share reads as the end of the file
            return b''

    def seek(self, offset, whence):
        if whence & AVSEEK_SIZE:
            return self.length
        try:
            return int(self.file.seek(offset, whence & 3))
        except Exception:
            return -1

    def close(self):
        try:
            self.file.close()
        except Exception:
            pass


class Decoder:
    """One open file. sample(seconds) returns a small grey BGR frame of a keyframe there.

    target: a locate.Target (kind 'direct' opens target.address with FFmpeg, 'kodi' reads it
    through Kodi). Use as a context manager; everything allocated is freed on exit.
    """

    def __init__(self, target, memory_path, width=128, height=288, full=False, background=True, current=None):
        """background: decoding lowers the calling thread's priority (set for the thread's whole life).
        current: whether the playback is still current, for reads through Kodi (see KodiReader)."""
        self.background, self.current = background, current
        self.avformat, self.avcodec, self.avutil, self.description = libraries(memory_path)
        _declare(self.avformat, self.avcodec, self.avutil)
        self.target, self.out_w, self.out_h, self.full = target, width, height, full
        self.fmt, self.ctx = ctypes.c_void_p(), ctypes.c_void_p()
        self.pkt, self.frame, self.avio = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
        self.reader, self.callbacks, self.index = None, None, -1
        self.dovi = _dovi_reader(self.avutil)
        self.seen_pts = set()   # the packet times of the keyframes decoded: the same one again is no new sample
        self.rows = None        # (read_row, width, height, depth) of the keyframe just decoded, for exact()

    def __enter__(self):
        if self.background and sys.platform.startswith('linux'):   # only Linux takes a thread id here
            try:
                os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)
            except (AttributeError, OSError):
                pass
        try:
            self._open()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def _custom_io(self):
        self.reader = KodiReader(self.target.address, self.current)
        reader = self.reader

        def read_packet(_opaque, buffer, size):
            data = reader.read(size)
            if not data:
                return AVERROR_EOF
            ctypes.memmove(buffer, data, len(data))
            return len(data)

        def seek(_opaque, offset, whence):
            return reader.seek(offset, whence)

        self.callbacks = (READ_PACKET(read_packet), SEEK(seek))   # kept alive while FFmpeg uses them
        buffer = self.avutil.av_malloc(IO_BUFFER)
        if not buffer:
            raise Unavailable('out of memory')
        read_packet, seek_callback = self.callbacks
        self.avio = ctypes.c_void_p(self.avformat.avio_alloc_context(buffer, IO_BUFFER, 0, None, read_packet, None,
                                                                     seek_callback))   # no write callback
        if not self.avio.value:
            self.avutil.av_free(buffer)
            raise Unavailable('out of memory')
        self.fmt = ctypes.c_void_p(self.avformat.avformat_alloc_context())
        if not self.fmt.value:
            raise Unavailable('out of memory')
        ctypes.c_void_p.from_address(self.fmt.value + 4 * P).value = self.avio.value   # AVFormatContext.pb

    def _open(self):
        options = ctypes.c_void_p()
        for key, value in PROBE_OPTIONS:
            self.avutil.av_dict_set(ctypes.byref(options), key, value, 0)
        try:
            if self.target.kind == locate.KODI:
                self._custom_io()
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), b'', None, ctypes.byref(options))
            else:
                try:
                    address = self.target.address.encode('utf-8')
                except UnicodeEncodeError:
                    raise Unavailable('the file name can not be passed to FFmpeg')
                opened = self.avformat.avformat_open_input(ctypes.byref(self.fmt), address, None, ctypes.byref(options))
        finally:
            self.avutil.av_dict_free(ctypes.byref(options))
        if opened < 0:
            self.fmt = ctypes.c_void_p()      # FFmpeg frees the context when opening fails
            raise Unavailable('FFmpeg could not open the file')
        if self.avformat.avformat_find_stream_info(self.fmt, None) < 0:
            raise Unavailable('FFmpeg found no stream information')
        decoder = ctypes.c_void_p()
        self.index = self.avformat.av_find_best_stream(self.fmt, AVMEDIA_TYPE_VIDEO, -1, -1, ctypes.byref(decoder), 0)
        count = _integer(self.fmt.value, 5 * P + 4)
        if self.index < 0 or not decoder.value or not 0 <= self.index < count or count > 256:
            raise Unavailable('no video stream FFmpeg can decode')
        stream = _pointer(_pointer(self.fmt.value, 5 * P + 8), self.index * P)
        codecpar = _pointer(stream, P + 8)
        if not codecpar:
            raise Unavailable('no codec parameters')
        self.ctx = ctypes.c_void_p(self.avcodec.avcodec_alloc_context3(decoder))
        if not self.ctx.value or self.avcodec.avcodec_parameters_to_context(self.ctx, codecpar) < 0:
            raise Unavailable('decoder could not be set up')
        # Cheapest decoding that still gives a true picture: one thread, keyframes only,
        # no loop filter (its smoothing does not move the edges of black bars).
        for option, value in ((b'threads', 1), (b'skip_frame', AVDISCARD_NONKEY), (b'skip_loop_filter', AVDISCARD_ALL)):
            self.avutil.av_opt_set_int(self.ctx, option, value, 0)
        if self.avcodec.avcodec_open2(self.ctx, decoder, None) < 0:
            raise Unavailable('decoder would not open')
        self.pkt = ctypes.c_void_p(self.avcodec.av_packet_alloc())
        self.frame = ctypes.c_void_p(self.avutil.av_frame_alloc())
        if not (self.pkt.value and self.frame.value):
            raise Unavailable('out of memory')
        self._discard_other_streams(count)

    def _discard_other_streams(self, count):
        """Every stream but the video marked AVDISCARD_ALL (AVStream.discard, the int after disposition), so the
        demuxer hands over no audio or subtitle packets after a seek and, for Matroska and MP4, reads none of
        their bytes: the keyframe comes in one packet instead of among hundreds (a remux with many streams gave
        11 video packets in 600 until 0.3.27's drain, which stays as the net under it)."""
        for index in range(min(count, 256)):
            if index == self.index:
                continue
            stream = _pointer(_pointer(self.fmt.value, 5 * P + 8), index * P)
            ctypes.c_int.from_address(stream + DISCARD_AT).value = AVDISCARD_ALL

    def subtitle_streams(self):
        """The file's own subtitle streams in file order: (codec name, language, forced, hearing impaired, title)."""
        streams = []
        count = _integer(self.fmt.value, 5 * P + 4)
        for index in range(min(count, 256)):
            stream = _pointer(_pointer(self.fmt.value, 5 * P + 8), index * P)
            codecpar = _pointer(stream, P + 8)
            if not codecpar or _integer(codecpar, 0) != AVMEDIA_TYPE_SUBTITLE:
                continue
            name = self.avcodec.avcodec_get_name(_integer(codecpar, 4)) or b''
            disposition = _integer(stream, DISPOSITION_AT)
            if disposition & ~DISPOSITION_KNOWN:
                # Not a disposition: this layout is not the one expected, so its pointers are not followed
                # (the language stays unknown, and Kodi's list will not line up: the kind stays unknown).
                streams.append((name.decode('ascii', 'replace'), '?', False, False, ''))
                continue
            metadata = ctypes.c_void_p(_pointer(stream, METADATA_AT))
            language, title = (self._tag(metadata, key) for key in (b'language', b'title'))
            streams.append((name.decode('ascii', 'replace'), language[:16],
                            bool(disposition & AV_DISPOSITION_FORCED), bool(disposition & AV_DISPOSITION_HEARING_IMPAIRED),
                            title[:200]))
        return streams

    def _tag(self, metadata, key):
        """A stream's metadata tag as text, '' when missing."""
        entry = self.avutil.av_dict_get(metadata, key, None, 0)
        value = _pointer(entry, P) if entry else None      # AVDictionaryEntry: key, value
        return ctypes.string_at(value).decode('utf-8', 'replace') if value else ''

    def sample(self, seconds):
        """A Keyframe for the position; its frame is None when no keyframe came out there."""
        started = time.time()
        self.rows = None
        sought = self.avformat.av_seek_frame(self.fmt, -1, int(seconds * 1000000), AVSEEK_FLAG_BACKWARD)
        if sought < 0:
            # The file can not be seeked (a stream, a damaged index): what would come next is wherever the
            # last read stopped, not a keyframe from this position, so it is no sample (1.1.5).
            return _nothing('no keyframe decoded (%.1f s; the file could not be seeked, %d)' % (
                time.time() - started, sought))
        self.avcodec.avcodec_flush_buffers(self.ctx)
        stream_index_at = STREAM_INDEX_AT
        got = False
        # Why nothing came out, for the log: packets read, those of the video, the last answers.
        packets = video = 0
        read = sent = received = 0
        pts = None
        for _ in range(MAX_PACKETS_PER_SAMPLE):
            read = self.avformat.av_read_frame(self.fmt, self.pkt)
            if read < 0:
                break
            packets += 1
            try:
                if _integer(self.pkt.value, stream_index_at) == self.index:
                    video += 1
                    pts = ctypes.c_int64.from_address(self.pkt.value + PTS_AT).value   # AVPacket.pts, after buf
                    if pts == AV_NOPTS_VALUE:
                        # VC-1 in Matroska carries no presentation time at all, only the decoding time (real
                        # library, 2026-10-14: every keyframe but the first was refused as the same one).
                        pts = ctypes.c_int64.from_address(self.pkt.value + DTS_AT).value
                    if pts == AV_NOPTS_VALUE:
                        pts = None
                    sent = self.avcodec.avcodec_send_packet(self.ctx, self.pkt)
                    received = self.avcodec.avcodec_receive_frame(self.ctx, self.frame)
                    got = received == 0
            finally:
                self.avcodec.av_packet_unref(self.pkt)
            if got:
                break
        else:
            if video and received == AVERROR_EAGAIN:
                # The limit ran out, not the file, with a keyframe held back for the frames to come:
                # drained, then ready for the next sample. A file with many other streams has few video
                # packets within the limit (a Dolby Vision film over Plex: 11 of 600, every
                # keyframe empty until 0.3.27). At the file's end nothing is drained: past the end
                # there is no picture, rather than the last one again.
                self.avcodec.avcodec_send_packet(self.ctx, None)
                received = self.avcodec.avcodec_receive_frame(self.ctx, self.frame)
                self.avcodec.avcodec_flush_buffers(self.ctx)
                got = received == 0
        if not got:
            return _nothing('no keyframe decoded (%.1f s; %d packets, %d of the video; read %d, send %d, receive %d)' % (
                time.time() - started, packets, video, read, sent, received))
        if pts is not None and pts in self.seen_pts:   # no time at all: nothing to compare, the sample counts
            # Keyframes far apart (a minute and more): two positions land on the same one, which would count
            # as a shape seen twice. One sample per keyframe (1.1.5).
            return _nothing('no keyframe decoded (%.1f s; the same keyframe as an earlier sample)' % (
                time.time() - started))
        if pts is not None:
            self.seen_pts.add(pts)
        level5, carried = self._level5()
        frame, size = self._small()
        return Keyframe(frame, '%.2f s' % (time.time() - started), level5, carried, size)

    def _level5(self):
        """(the keyframe's Dolby Vision Level 5 offsets (top, bottom, left, right) or None without them, whether the
        keyframe carried Dolby Vision metadata at all)."""
        if not self.dovi:
            return None, False
        kind, find_level = self.dovi
        side = self.avutil.av_frame_get_side_data(self.frame, kind)
        if not side:
            return None, False
        metadata = _pointer(side, P)             # AVFrameSideData: type, data, size
        if not metadata:
            return None, False
        block = find_level(metadata, 5)
        if not block or ctypes.c_uint8.from_address(block).value != 5:
            return None, True
        return tuple(ctypes.c_uint16.from_address(block + at).value
                     for at in (LEVEL5_TOP_AT, LEVEL5_BOTTOM_AT, LEVEL5_LEFT_AT, LEVEL5_RIGHT_AT)), True

    def _small(self):
        """(the grey frame, the keyframe's own size)."""
        base = self.frame.value
        data, line = _pointer(base, 0), _integer(base, 8 * P)
        width, height = _integer(base, 9 * P + 32), _integer(base, 9 * P + 36)
        name = (self.avutil.av_get_pix_fmt_name(_integer(base, 9 * P + 44)) or b'').decode('ascii', 'replace')
        if not readable_format(name):
            raise Unavailable('picture format %s not read' % (name or 'unknown'))
        depth = pixel_depth(name)
        wide = 2 if depth > 8 else 1
        if not frame_layout_ok(data, width, height, line, wide):
            raise Unavailable('unexpected frame layout (%dx%d, %s)' % (width, height, name))

        def read_row(y):
            return ctypes.string_at(data + y * line, width * wide)
        self.rows = (read_row, width, height, depth)
        return grey_frame(read_row, width, height, depth, self.out_w, self.out_h, self.full), (width, height)

    def exact(self, sample):
        """detect.exact_bars for the keyframe sample() just returned, analysed as sample: a few of its rows read
        again at full width (the frame stays in memory until the next sample). None when there is nothing to
        refine."""
        if self.rows is None:
            return None
        read_row, width, height, depth = self.rows
        if depth > 8:
            shift = depth - 8

            def values(y):
                return bytes(map(shift.__rrshift__, memoryview(read_row(y)).cast('H')))
        else:
            def values(y):
                return read_row(y)
        return detect.exact_bars(values, width, height, sample)

    def close(self):
        if self.frame.value:
            self.avutil.av_frame_free(ctypes.byref(self.frame))
        if self.pkt.value:
            self.avcodec.av_packet_free(ctypes.byref(self.pkt))
        if self.ctx.value:
            self.avcodec.avcodec_free_context(ctypes.byref(self.ctx))
        if self.fmt.value:
            self.avformat.avformat_close_input(ctypes.byref(self.fmt))
        if self.avio.value:
            buffer = ctypes.c_void_p.from_address(self.avio.value + P).value   # AVIOContext.buffer, may be replaced
            if buffer:
                self.avutil.av_free(buffer)
            self.avformat.avio_context_free(ctypes.byref(self.avio))
        if self.reader:
            self.reader.close()
            self.reader = None
