"""CoreELEC's Level 5 override, set for one playback and always cleared again.

The P3i build reads coreelec.amlogic.dolbyvision.level5.override ("top,bottom,left,right" in
the frame's pixels, empty for none) during playback, for the subtitle restriction and the
Level 5 sent to the TV. The add-on only sets it when it is empty, so a value someone else put
there (P3i's helpers, the person) is never replaced, and only clears it when it still holds
the add-on's own value. A small file records what was set, so it is cleared after a crash too.
"""
import os  # noqa: F401  (tests patch override.os)
import posixpath

from . import keeper

SETTING = 'coreelec.amlogic.dolbyvision.level5.override'
INI = 'override.ini'      # P3i's per-folder setting override add-on (service.p3i.override)
# Addresses that add-on never looks next to; asking a Plex server for override.ini is pointless.
REMOTE_SCHEMES = ('http://', 'https://', 'plugin://', 'pvr://', 'plex://', 'upnp://')


def set_by_override_ini(playing, read_text):
    """True when an override.ini next to the playing file, or one folder up (where P3i's
    per-folder override add-on looks), sets the Level 5 override: the person supplies their
    own Level 5 there, so it is trusted and nothing is checked or changed. read_text(path)
    returns the file's text, or None when there is none."""
    address = playing.partition('|')[0]
    if address.lower().startswith(REMOTE_SCHEMES):
        return False
    folder = posixpath.dirname(address)
    for place in (folder, posixpath.dirname(folder.rstrip('/'))):
        if not place:
            continue
        text = read_text(posixpath.join(place, INI)) or ''
        for line in text.splitlines():
            key = line.split('=', 1)[0].strip()
            if '=' in line and key == SETTING:
                return True
    return False


def value_for(top, bottom):
    return '%d,%d,0,0' % (top, bottom)


class Override:
    """The record stays until neither Kodi's memory nor its settings file holds the add-on's value (keeper.Ledger);
    saved() reads the file (None when unknown), session() is Kodi's session: a value of ours found after the clear in
    the same session is someone else's."""

    def __init__(self, read, write, path, saved=None, session=None):
        self._read = read      # () -> the setting's text, or None when it can not be read
        self._write = write    # (text) -> True when CoreELEC took it
        self._ledger = keeper.Ledger(self._current, path, keeper.TEXT, saved or read, session)

    def _current(self):
        value = self._read()
        return value if isinstance(value, str) else None

    @keeper.waiting(False)
    def apply(self, value):
        """Set value for this playback. False when the setting holds someone else's value, or can
        not be read (it might hold someone else's)."""
        if not value:
            return False            # '' is what restore writes: as a value of ours it would leave a record of nothing
        now, change = self._current(), self._ledger.load()
        ours = self._ledger.ours(change) if change else []
        if now is None or (now and now not in ours):
            return False
        # Earlier values of ours stay on record while Kodi's settings file may hold one (as keeper.Keeper.apply): a
        # stale correction there would apply to every film after a crash.
        earlier = self._ledger.still_saved([v for v in ours if v != value]) if change else []
        return self._ledger.change(None, value, earlier, change, self._write)

    @keeper.waiting(None)
    def settle(self):
        """keeper.look_again on this record."""
        self._ledger.settle(self.restore)

    @keeper.waiting(False)
    def restore(self):
        """Clear the add-on's own value. True when something was cleared."""
        change = self._ledger.load()
        if change is None:
            return False
        ours = self._ledger.ours(change)
        now = self._current()
        written = False
        if now in ours or (now is None and not change.put_back):   # ours (or unreadable): cleared
            if not keeper.took(self._write, ''):
                return False                   # still in place: kept on record, cleared next time
            written = True
        elif now is None:
            return False                       # unreadable: looked at again next time
        elif now != '':
            # Someone else's value now: theirs to keep. Ours stays on record, because the other
            # party may put it back later (P3i's override add-on restores what it found when it
            # applied an override.ini, and a playlist skip gives no stop): then it is cleared.
            return False
        self._ledger.put_back(change, None)    # cleared by us now, or by someone else while ours was in place
        return written
