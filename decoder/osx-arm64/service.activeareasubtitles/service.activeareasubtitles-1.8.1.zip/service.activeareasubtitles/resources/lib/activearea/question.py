"""Active Area Subtitles' own questions and messages, in the style of its menu and the same on every skin:
the add-on's icon and name at the top, the text, and the buttons at the bottom right. Back answers no.
The same window, without buttons and with a bar along the bottom, shows something that takes a few
seconds.

The content is as tall as its text and centred on a screen of the menu's colour. Kodi cannot measure text from an
add-on and cannot size a window to it, so the lines are broken here (from a typical sans-serif's letter widths) and
everything is placed for that many lines."""

import threading

import xbmcgui

from . import kodi

WINDOW = 'activearea-question.xml'
TITLE, TEXT, YES, NO, BAR, FOCUS = 10, 20, 31, 32, 41, 42
ICON, RULE_TOP, RULE_BOTTOM, TRACK = 3, 4, 5, 40
BAR_WIDTH = 1100                # the waiting bar's full width, as the rules in activearea-question.xml
CANCEL_ACTIONS = {10, 92}       # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK

# Advance widths per 1000 units of the em, close to Noto Sans and similar skin fonts.
WIDTHS = {
    ' ': 260, '.': 268, ',': 268, ':': 268, ';': 268, "'": 221, '"': 401, '!': 268, '?': 429, '-': 322, '(': 303,
    ')': 303, '·': 268, '/': 372, '&': 705,
    'a': 561, 'b': 615, 'c': 480, 'd': 615, 'e': 564, 'f': 344, 'g': 615, 'h': 618, 'i': 258, 'j': 258, 'k': 534,
    'l': 258, 'm': 935, 'n': 618, 'o': 605, 'p': 615, 'q': 615, 'r': 413, 's': 479, 't': 361, 'u': 618, 'v': 508,
    'w': 786, 'x': 529, 'y': 510, 'z': 470,
    'A': 639, 'B': 647, 'C': 632, 'D': 723, 'E': 556, 'F': 522, 'G': 726, 'H': 739, 'I': 336, 'J': 259, 'K': 615,
    'L': 524, 'M': 907, 'N': 763, 'O': 778, 'P': 604, 'Q': 778, 'R': 618, 'S': 549, 'T': 553, 'U': 733, 'V': 603,
    'W': 925, 'X': 579, 'Y': 556, 'Z': 566,
}
DIGIT, OTHER = 572, 700         # a digit (as Noto Sans), and a letter not listed: wide, so it breaks a line early
PX_PER_UNIT = 25.5 / 1000       # text_width and TEXT_LIMIT both carry it, so the line breaks do not depend on it.
                                # Reason not recorded

# The text: 1060 px wide in the skin's font13 (Estuary: 28.4 px per em, lines 41 px apart), measured in
# the units above with 8% to spare, so a skin with a slightly wider font13 does not break the lines again.
TEXT_LIMIT = int(1060 * PX_PER_UNIT * 1000 / (28.4 * 1.08))
LINE_H = 41                     # font13's line spacing in Estuary: the textbox is 2 * 41 + 6 high for two lines
TEXT_TOP = 166                  # the text below the content's top, as activearea-question.xml for two lines
BUTTON_H = 64                   # the buttons' height in activearea-question.xml
SCREEN_H = 1080                 # the skin's 1080i coordinates


def text_width(text):
    return sum(WIDTHS.get(c, DIGIT if c.isdigit() else OTHER) for c in text) * PX_PER_UNIT


def lines(text, limit=TEXT_LIMIT):
    """Lines no wider than limit, broken between words; [CR] forces a break, and [CR][CR] leaves an empty line."""
    found = []
    for paragraph in text.replace('[CR]', '\n').split('\n'):
        line = ''
        for word in paragraph.split():
            candidate = word if not line else line + ' ' + word
            if line and text_width(candidate) > limit:
                found.append(line)
                line = word
            else:
                line = candidate
        found.append(line)
    while len(found) > 1 and not found[-1]:
        found.pop()
    return found


def layout(count):
    """The content's height and top for a text of count lines, and the top of each control below the
    heading (relative to the content's top)."""
    text_height = max(1, count) * LINE_H + 6
    rule = TEXT_TOP + text_height + 20
    buttons = rule + 28
    height = buttons + BUTTON_H + 32
    return height, (SCREEN_H - height) // 2, {TEXT: TEXT_TOP, RULE_BOTTOM: rule, YES: buttons, NO: buttons,
                                              TRACK: buttons + 28, BAR: buttons + 28}, text_height


class QuestionWindow(xbmcgui.WindowXML):   # a full window: dialog closes toggle P3i's OSD and eat a press
    """One question or message. answer is True only when the first button was pressed."""

    def __new__(cls, text, yes, no=None, careful=False):
        return super().__new__(cls, WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')

    def __init__(self, text, yes, no=None, careful=False):
        self.text, self.yes, self.no, self.careful = text, yes, no, careful
        self.answer = False
        # Kodi keeps a window of a stopped add-on open until its close() or Kodi quitting, so the service's stop
        # closes it (close_at_stop). Each close() in Kodi also goes back a window, so it is closed once only.
        self.shut_lock = threading.Lock()
        self.showing = False         # Kodi has shown it (onInit): its doModal waits for a close() from now on
        self.stopping = False        # the service stopping: closed as soon as Kodi shows it
        self.shut = False            # closed, by the person, the service's stop or Kodi quitting
        self.unread = False          # closed by the service's stop or by Kodi quitting, not by the person

    def close(self):
        self._close(by_stop=False)

    def _close(self, by_stop):
        with self.shut_lock:
            if self.shut:
                return
            self.shut, self.unread = True, by_stop
        super().close()

    def close_at_stop(self):
        """The service stopping: closed now if Kodi shows it, else as it shows it (a close() before Kodi's doModal
        is lost: doModal makes the window wait again)."""
        with self.shut_lock:
            self.stopping = True
            showing = self.showing
        if showing:
            self._close(by_stop=True)

    def shown(self):
        """Kodi has shown it; False when the service's stop came first and it closed again."""
        with self.shut_lock:
            self.showing = True
            stopping = self.stopping
        if stopping:
            self._close(by_stop=True)
        return not stopping

    def ended(self):
        """Kodi's doModal returned: a window it closed itself as it quit counts as unread, and is never closed again."""
        with self.shut_lock:
            if not self.shut:
                self.shut, self.unread = True, True

    def place(self):
        """The heading, the text broken into lines, and everything placed for that many lines."""
        broken = lines(self.text)
        _height, top, below, text_height = layout(len(broken))
        for control, x, y in ((ICON, 50, 40), (TITLE, 150, 40), (RULE_TOP, 50, 140)):
            self.getControl(control).setPosition(x, top + y)
        # A careful question has its safe answer on the right, where the focus starts.
        no_x, yes_x = (890, 610) if self.no and self.careful else (610, 890)
        for control, x in ((TEXT, 70), (RULE_BOTTOM, 50), (NO, no_x), (YES, yes_x), (TRACK, 50), (BAR, 50)):
            self.getControl(control).setPosition(x, top + below[control])
        self.getControl(TEXT).setHeight(text_height)
        self.getControl(TITLE).setLabel(kodi.text(32000))
        self.getControl(TEXT).setText('[CR]'.join(broken))

    def onInit(self):
        if not self.shown():
            return
        self.place()
        self.getControl(YES).setLabel(self.yes)
        if self.no:
            self.getControl(NO).setLabel(self.no)
        else:
            self.getControl(NO).setVisible(False)
        self.getControl(BAR).setVisible(False)
        # A question whose yes can not be undone starts on no, so a press of OK out of habit changes nothing.
        self.setFocusId(NO if self.no and self.careful else YES)

    def onClick(self, control_id):
        if control_id in (YES, NO):
            self.answer = control_id == YES
            self.close()
        elif control_id == FOCUS and not self.no:
            # Kodi focuses the holder first and onInit moves the focus to OK a moment later: an OK pressed in
            # between, on a slow box right after a film stops, lands on the holder and a second one is needed (seen
            # in the test rig). A message has one answer; a question is never answered by it.
            self.close()

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.close()


def _shown(window, opened):
    """window shown until it closes, or None when opened(window) refuses it (the service stopping). opened: the
    service's note of its open window, so its stop can close it (QuestionWindow.close_at_stop)."""
    if opened is not None and not opened(window):
        return None
    try:
        window.doModal()
    finally:
        window.ended()
    return window


def ask(text, yes, no, careful=False, opened=None):
    """Asks; True for yes. Back is no, and so is a window the service's stop closed."""
    window = _shown(QuestionWindow(text, yes, no, careful), opened)
    return window is not None and window.answer


def tell(text, opened=None):
    """Says something that needs nothing more than OK. True once the person closed it (OK or Back), False when it
    never opened or closed without them (the service's stop, Kodi quitting)."""
    window = _shown(QuestionWindow(text, kodi.text(32109), None), opened)
    return window is not None and not window.unread


class Waiting(QuestionWindow):
    """The window without buttons, shown while something takes a few seconds; a bar fills along the
    bottom. Back stops the wait (cancelled)."""

    def __new__(cls, text):
        return super().__new__(cls, text, '')

    def __init__(self, text):
        super().__init__(text, '')
        self.cancelled = False

    def onInit(self):
        self.fill()

    def fill(self):
        """Also called straight after show(): Kodi calls onInit only once the script lets it (a
        waitForAbort), so the window stood empty, buttons and all, until then."""
        self.place()
        for button in (YES, NO):
            self.getControl(button).setVisible(False)
        self.setFocusId(FOCUS)      # an invisible holder: Kodi logs an error for a window with nothing to focus

    def update(self, percent):
        bar = self.getControl(BAR)
        bar.setWidth(max(1, int(BAR_WIDTH * min(100, max(0, percent)) / 100)))
        bar.setVisible(True)

    def onClick(self, control_id):
        pass

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True


def waiting(text):
    """Opens the waiting window (closed by its close())."""
    window = Waiting(text)
    window.show()
    window.fill()
    window.update(0)
    return window
