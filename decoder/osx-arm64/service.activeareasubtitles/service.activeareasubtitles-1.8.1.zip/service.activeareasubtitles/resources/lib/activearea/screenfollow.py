"""Following one playback's scenes on a PC from Kodi's screen: every film is followed (no Level 5 to judge first), from
its first estimate on, by grabs of the picture Kodi renders (screenreader.ScreenReader) placed on time by the film's
scene map, the one read ahead of playback from the file (lookahead.py) where the add-on reads it and the one a playback
before recorded. The box follows P3i's labels instead (labelfollow.py).

ScreenFollowing is the PC's followloop.Following. Its reader is the playback's, not a follower's: a placing again
during a followed film (Kodi's window, a distance, the position) writes the picture on screen now and starts the new
epoch's follower with the same reader (carries_on), so its grabs, the shapes seen, the evidence against the maps, the
screen's lead and the recording go on. One follower reads it at a time: each look runs under looking, and a follower
goes on only while it is the newest started (loop).
"""
from . import capture, choices, filmknown, follow, followloop, kodi, lookahead, screenreader

FAST_PLAY = 'Player.Forwarding | Player.Rewinding'


class ScreenFollowing(followloop.Following):
    # No check(): a screen reading is not verifiable (ScreenReader.verifiable), so the loop never asks for one.

    def __init__(self, playback):
        followloop.Following.__init__(self, playback)
        # What the followers know of the file, kept for the film: an epoch placed again after a window change or another
        # track starts its follower with it (filmknown.py).
        self.film = filmknown.FilmKnown()
        self.screen_reader = None            # the screen reader the newest follower reads, carried on across epochs

    def measuring(self, placing, keyframes):
        """An estimate placed while the measurement goes on (keyframes: the file analysis' list, growing, or None: a
        screen grab's estimate): the follower starts now, from the estimate (waiting for the settled shape left the
        first IMAX scene's text high for seconds)."""
        self._start(placing, keyframes, self.playback.picture[1], settled=False)

    def _settle(self, placing, keyframes, picture):
        """The settled shape placed: the follower started once per epoch if none runs, the scene rule judged again from
        the settled shape, the film read ahead. True when the follower places this epoch's text."""
        return self._start(placing, keyframes, picture, settled=True)

    def _start(self, placing, keyframes, picture, settled):
        """The follower reads Kodi's rendered picture (grabreader.GrabReader) for every film, started once per epoch, at
        the first estimate or the settled shape; a film whose picture never changes never moves (the reader's rules).
        The settled shape judges the scene rule again (an early start's came from the estimate). The shapes the file
        analysis read with an exact edge go to the reader as they come: the grabs then tell which is showing, the
        decoder gave its edges (a 1.90 picture's full-size grab can fail). True when the follower places this epoch's
        text."""
        playback = self.playback
        with self._lock:
            if self.followed == placing.epoch:
                self.film.learn(keyframes)
                if settled:
                    self._judge(placing.layout, picture, settled=True)
                    self._read_ahead(placing)
                return True
            if not choices.following():
                return False
            # An older placing's settled start after a newer epoch's follower began would end that one: the film
            # followed no more until the next placing again.
            if playback.margin_placed is None or playback.picture is None or not placing.is_current():
                return False
            if not settled:
                self.settled_picture = None
            self._judge(placing.layout, picture, settled=settled)
            self.verdict = follow.Verdict(True, 'the picture on screen is followed')
            self.film.learn(keyframes)
            self.followed = placing.epoch
            kodi.log('scenes: watching the picture on screen%s' % (
                '' if settled else ' (started early, measuring goes on)'))
            self.loop = followloop.FollowLoop(self, placing, self.chosen)
            playback.service.threads.start('follower', followloop.FollowLoop.follow, self.loop)
            if settled:
                self._read_ahead(placing)
            return False

    def carries_on(self, placing, settled):
        """Placed again during a followed film (Kodi's window, a distance, the position): the picture on screen now
        written with the new layout and the rule judged again from the measured shape (settled), and the new epoch's
        follower started with the reader (the measured shape written first put a dark IMAX scene's text at the scope
        height for seconds). False where nothing was followed (following off, no follower placed yet): the measured
        shape then, as before."""
        playback = self.playback
        if not choices.following():
            self.screen_reader = None
            return False
        with self.looking:                      # the previous follower is out of its look: at most one grab
            with self._lock:
                if not placing.is_current():
                    return True                 # a newer epoch places (it may follow already: never ended from here)
                reader = self.screen_reader
                picture = reader.on_screen(placing.layout.moves_shown) if reader is not None else None
                if picture is None:
                    self.screen_reader = None
                    return False
                self._judge(placing.layout, settled, settled=True)
                distances, placed_as = self.rule
                self.loop = None                # the previous follower ends at its next look, before it reads
                self.followed = placing.epoch
            placed = placing.write(placed_as(picture), None, distances)
            if placed is None:
                return True                     # a newer epoch places
            kodi.log('settled: picture %.2f in video %.2f on %dx%d, measured earlier in this playback; the picture on '
                     'screen %.2f carried on: %s' % (float(settled), placing.layout.video_ratio, placing.layout.screen_w,
                                                     placing.layout.screen_h, float(picture), placed))
            with self._lock:
                if self.followed != placing.epoch:
                    return True
                self.screen_reader.placed(picture)
                kodi.log('scenes: watching the picture on screen (carried on)')
                self.loop = followloop.FollowLoop(self, placing, self.chosen, picture)
                playback.service.threads.start('follower', followloop.FollowLoop.follow, self.loop)
                self._read_ahead(placing)
        return True

    def _read_ahead(self, placing):
        """Once per playback, from its first settled shape (the measurement's reads come first, through the one reader
        at a time): the film read ahead of playback where the add-on reads the file itself (lookahead.py), so the
        follower moves the text at the frame of each cut. Not while only a wider picture could move the text (Same as
        black bars); started again where a run of it ended (following switched off and on, a surprise) and it is wanted
        again, so it comes back in that playback."""
        playback = self.playback
        service = playback.service
        film = self.film
        if self.still or not service.checks.file_first or not (film.ahead is None or film.resumable()):
            return
        target, _unreadable = playback.target()
        if target is None or not service.guard.allowed(target.identity):
            return
        cached = playback.memory.scene_map() if playback.memory is not None else None
        # Where nothing measured read the file (a cached playback) its first read is the playback's first, and waits as
        # such (playback.steady decides).
        ahead = lookahead.Lookahead(lambda: service.film(target, playback.still_playing), self.film_seconds,
                                    playback.steady, lambda seconds: service.monitor.waitForAbort(seconds), kodi.log,
                                    placing.layout.video_ratio, seen=list(film.keyframes), wanted=choices.following,
                                    known=[self.settled_picture] + film.exact(placing.layout.video_ratio),
                                    shown=cached.shapes if cached else (),
                                    trust=playback.memory.ahead_trust() if playback.memory is not None else None,
                                    kept=filmknown.kept_trust(playback.memory))
        film.reading(ahead)
        kodi.log('scenes: reading the film ahead of playback')
        service.threads.start('lookahead', self._run_ahead, ahead)

    def _run_ahead(self, ahead):
        try:
            ahead.run(self.playback.still_playing)
        except Exception as error:  # never let a surprise disturb playback; the screen grabs follow as before
            kodi.log('scenes ahead: stopped after an unexpected error: %r' % error, always=True)
            ahead.for_good = True               # started again it would stop the same way at every epoch
        finally:
            self.film.ended(ahead)

    def _new_reader(self, placing):
        """A screen reader for a follower that carries nothing on: Kodi's screen with the film's scene maps, built on the
        follower's own thread (the CPU its looks cost is that thread's)."""
        service, layout, playback = self.playback.service, placing.layout, self.playback
        memory = playback.memory
        known = memory.scene_map() if memory is not None else None
        return screenreader.ScreenReader(capture.KodiScreen(service.monitor.waitForAbort), layout.video_ratio,
                                         playback.picture[1], self.film_seconds, service.clock, kodi.log,
                                         known=known, decoded=lambda: self.film.exact(layout.video_ratio),
                                         moves_shown=layout.moves_shown, seen=self.film.seen,
                                         live=self.film.live, tempo=kodi.tempo)

    # A follower's moments (followloop.Following).

    def held(self):
        """Fast forward and rewind hold the picture too: the film's clock counts at Kodi's tempo, never at a speed."""
        return self.playback.service.held() or kodi.holds(FAST_PLAY)

    def seek(self):
        return self.playback.service.seek

    def between_looks(self, loop, seconds):
        """A wait longer than the fast pace looked into every screenreader.FAST_STEP for a seek event, which ends it:
        the look after the seek then comes within its quiet (follow.SEEK_QUIET), as at the fast pace, and places the
        landing before it shows (at the slow pace the quiet passed between two looks, and a scope landing's text sat in
        its bar until a grab saw it)."""
        monitor, step = self.monitor, screenreader.FAST_STEP
        while seconds > step + 1e-9:
            if monitor.waitForAbort(step):
                return True
            seconds -= step
            if self.seek() is not loop.seek:
                return False
        return monitor.waitForAbort(seconds)

    def reader(self, loop):
        """The playback's reader for this follower, under looking: the one carried on where the follower carries a
        picture on (its layout's way of moving lines now), else a new one; None where a newer follower started first
        (the reader is not this one's to resume). The measured shape goes to it as it stands."""
        with self.looking:
            if self.loop is not loop:
                return None
            if self.screen_reader is not None and loop.carried is not None:
                reader = self.screen_reader
                reader.resume(loop.placing.layout.moves_shown)
            else:
                reader = self._new_reader(loop.placing)
            self.screen_reader = reader
        reader.settled(self.settled_picture)        # settled before this follower began (None: not yet)
        return reader

    def before_look(self, loop):
        # Kodi's window changed (the watch looks only once a second); outside the look, so placing again takes this
        # reader over at once.
        self.playback.canvas_check()

    def look_begins(self, loop, rule_changed):
        """The measured shape's exact edges to the reader from the next look on where the rule was judged again, its
        pace for Same as black bars, and the film read ahead once the measured shape's rule came (Same as black bars no
        longer chosen) or again where a run of it ended while it is still wanted (it saw following off a moment before
        it came back on), not at the next placing."""
        reader = loop.reader
        if rule_changed:
            reader.settled(self.settled_picture)
        reader.only_wider = self.still
        playback = self.playback
        if rule_changed and playback.measured is not None:
            with self._lock:
                self._read_ahead(loop.placing)
        if playback.measured is not None and self.film.resumable() and choices.following():
            with self._lock:
                self._read_ahead(loop.placing)

    def holds(self, loop):
        loop.reader.hold()

    def wrote(self, loop, picture):
        # Any write, the move back up at a seek too: the picture a placing during the film carries on from.
        loop.reader.placed(picture)

    def moved(self, loop, target):
        """A follower's move written: kept as a wider scene once the measurement settled (an entry stops the next
        playback measuring), and the rule judged again from it (a film measured on its tall shape got no IMAX row, no
        Same as black bars and no cap until the next playback). It is the playback's measured shape from now on, as it
        is the cache's: placed again during the film (carries_on), the rule is judged from the measured shape."""
        playback = self.playback
        if playback.measured is not None and loop.reader.widened(target):
            how = 'screen, a wider scene while following'
            if playback.memory is not None:
                playback.memory.remember(target, how)
            with self._lock:
                playback.measured = (target, how)
                self._judge(loop.placing.layout, target, settled=True)

    def _ended(self, loop):
        # Its reader goes with it: nothing carries it on, so the follower keeps its recording as it ends (finished).
        self.screen_reader = None

    def finished(self, loop):
        """A follower's thread ends, whatever ended it: following is its no longer while it is the newest, and the shapes
        it saw stay for the playback whether or not a newer one came first (it usually did when its own look saw Kodi's
        window change). Its reader keeps the map and logs the looks, unless a newer follower carries it on."""
        reader = loop.reader
        with self._lock:
            if self.loop is loop:               # still the newest: following is this one's
                self.followed = None
            if reader is not None:
                self.film.saw(reader.shapes())
        if reader is not None and not (self.loop is not loop and self.screen_reader is reader):
            reader.keep(self.playback.memory, self.playback.service.monitor.abortRequested)
