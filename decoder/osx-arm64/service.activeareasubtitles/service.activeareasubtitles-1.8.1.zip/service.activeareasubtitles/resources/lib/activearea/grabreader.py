"""The scene follower's grab reader on a PC (GrabReader): one small grab of Kodi's rendered picture a look, analysed as
the screen route does (measure.look, measure.exact_picture), and the picture the text should be placed for. Read by
screenreader.ScreenReader, which places its pictures on time by the film's scene map. Kept outside the detector's
modules (shapes.DETECTOR_MODULES). The tests hand a list of frames instead of Kodi's grab.
"""
from . import detect, measure, pictures

NARROWER_GRABS = 2            # strongly lit grabs in a row that agree on a narrower picture never seen before the text
                              # moves down; one is enough for a shape the film is known to show
DIM_NARROWER_GRABS = 3        # dimly lit grabs in a row that agree on a narrower picture


class GrabReader:
    """Kodi's rendered picture as scene readings for the scene follower on a PC, which has no Level 5 labels: one small
    grab a look (KodiScreen, as the screen route's), analysed as the screen route does. read() gives the picture the
    text should be placed for, with a note for the log. A wider picture (into a scope scene, where a lower text would
    sit in the bar) counts at the first strongly lit grab; a narrower one (into a tall scene, where the text stays
    inside the picture meanwhile) at the first strongly lit grab when the film is known to show that shape (seen before,
    read from the file, in the scene map), else once NARROWER_GRABS strongly lit grabs in a row agree on it. A dimly lit
    grab moves the text up only to a wider shape already seen (a dark scope scene after a tall one), and down once
    DIM_NARROWER_GRABS of them in a row agree (a dark IMAX scene with nobody talking, so the text is down before the
    next line), to a shape never seen too, placed but not learned until a lit grab shows it (provisional); at once
    where it reads the narrower picture a map's silent span leads into (read's coming) and the picture placed is not
    lit either (a dark scene, no dissolve). A dim grab can read a bar too wide, never picture where the bars are
    black. In the real-film corpus no strongly lit reading showed its picture taller than it is by more than a grab
    row, so a steady film never moves. The first time a shape is seen, one full-size grab finds its exact edge
    (measure.exact_picture); every later visit uses it, unless that grab was smaller than Kodi's window allows now
    (finer)."""

    def __init__(self, screen, video_ratio, placed):
        """screen: the grab (KodiScreen); placed: the picture placed now (the measured shape, with its bars)."""
        self._screen, self._video_ratio = screen, video_ratio
        placed = pictures.as_picture(placed)    # a bare ratio (no exact grab came back): no rows known
        self.picture = placed
        self.known = pictures.Versions([placed])
        self._candidate, self._count = None, 0
        self.run_back = 0               # looks since the first grab of the run that changed picture last
        self._exact = pictures.Versions()   # the known shapes the file gave (its keyframes, the settled shape)
        self.lit = None                 # the latest picture a strongly lit grab showed, and its count of such grabs
        self.provisional = False        # picture is a taller one only dim grabs showed, never seen lit (not known)
        self.lit_sightings = 0
        self.at_edge = False            # the latest grab read the full picture from its edge alone (read), for the log
        self.clear = False              # the latest grab showed a picture (a black or empty one says nothing)
        self.empty = False              # the latest grab came back with no image at all
        self._finer_tried = set()       # (shape's rows, full-size grab's rows) read again once each (finer)

    def read(self, coming=None):
        """(the picture to place for, ('picture', its shape) for the log); coming: the narrower picture a map's silent
        span leads into where this grab is taken, or None. An unclear grab whose picture reaches the
        frame's top or bottom edge through the thinnest bar of every letterboxed picture known (detect.lit_edges) is a
        strongly lit grab of the full picture: a 16:9 IMAX scene lit only at one edge (sky at the top, the ground below
        as dark as a bar) reads 'not symmetric', and the text would stay at the scope height until its bottom lit up
        (10 s on a PC). A letterboxed picture's bar there is black, so it is none of them; with bars at both edges in
        each, it is the full one (pictures.lit_at_edge, as for the file's frames in lookahead.FrameJudge)."""
        frame, width, height, sample = measure.look(self._screen, self._video_ratio)
        self.empty = sample.reason.startswith('no image')
        if not sample.clear and pictures.lit_at_edge(frame, width, height, 4, self.known + [self.picture],
                                                     self._video_ratio):
            sample = detect.Sample(True, 0, 0, height, 'picture at the frame\'s edge', exact=True)
        self.at_edge = sample.reason == 'picture at the frame\'s edge'
        self.clear = sample.clear
        if sample.clear:
            if coming is not None and not sample.strong and self._placed_lit(frame, width, height, sample):
                # A dissolve, no dark scene: the picture placed still lit inside the dim one fading in through its
                # bars, which are nearly black yet (a night scene's few lights read as a dim taller picture).
                coming = None
            self._judge(sample, coming)
        return self.picture, ('picture', round(float(self.picture), 2))

    def _placed_lit(self, frame, width, height, sample):
        """Whether the rows of the picture placed now next to its bars are strongly lit in this grab, as
        detect.analyse's strong edge is: lit across (detect.EDGE_COVERAGE of the row) above the level a bar row may
        reach by detect.BAR_NOISE // 2."""
        picture = self.picture
        if pictures.has_rows(picture):
            top, bottom = (int(round(rows * height / picture.height)) for rows in (picture.top, picture.bottom))
        else:
            top = bottom = int(round(height * (1 - self._video_ratio / float(picture)) / 2))
        rows = (min(height - 1, top + 1), max(0, height - 2 - bottom))      # a row inside each edge
        level = min(255, sample.black + detect.BAR_NOISE // 2)
        return all(sum(1 for green in frame[row * width * 4 + 1:(row + 1) * width * 4:4] if green > level)
                   >= detect.EDGE_COVERAGE * width for row in rows)

    @staticmethod
    def note(shown):
        return 'picture %.2f on screen' % shown[1]

    def prefer(self, shape):
        """The file analysis' settled shape: it replaces the same picture among the known ones (a keyframe's too: the
        settled shape takes the taller bar on each side among them), and the picture placed now when that is the one."""
        self._replace(shape)

    def from_file(self, shapes):
        """Keyframe shapes the file analysis read with an exact edge: each replaces what the grabs, the map or the
        estimate knew of the same picture (the decoder's edges, not the small grab's), unless the file gave that
        picture already."""
        for shape in shapes:
            if pictures.has_rows(shape) and self._exact.find(shape) is None:
                self._replace(shape)

    def _replace(self, shape):
        self.known.put(shape)
        self._exact.put(shape)
        if pictures.same(shape, self.picture):
            self.picture = shape
        if self.lit is not None and pictures.same(shape, self.lit):
            self.lit = shape

    def version(self, picture):
        """This reader's version of picture: the known shape of the same picture (the settled shape, the file's edges
        before a map's or a grab's), so one picture is placed at one margin whichever map or grab names it (a row-less
        shape from a grab, or a keyframe's edges a row apart, would place it a step higher)."""
        # Rows over none: a planned picture with its rows over a known one without (a row-less first estimate must
        # not replace the map's exact edges).
        return pictures.version(picture, self._exact, self.known)

    def learn(self, shapes):
        """Shapes known from before (a scene map): a grab of the same picture places that shape's own edges. Rows over
        none: a shape with its rows fills in the version kept without (the placed shape, a row-less estimate), so the
        grabs place the rows the map's plan places (version), not the row-less one a row off."""
        for shape in shapes:
            self.known.add(shape)
        if not pictures.has_rows(self.picture):
            self.picture = pictures.version(self.picture, self.known)

    def _judge(self, sample, coming=None):
        ratio = detect.shape(sample, self._video_ratio)
        known = self.known.find(ratio)
        if known is None and not sample.strong and ratio > float(self.picture):
            # A dim reading wider than the picture placed and like no shape known: it reads a bar too wide, so the
            # picture is one no wider than it; the widest known such shape wider than the one placed (a dark scope
            # scene after a tall one reads 2.45 for 2.39, and the text would stay in its bar).
            wider = [shape for shape in self.known
                     if pictures.wider(shape, self.picture) and float(shape) <= ratio * 1.02]
            known = max(wider, key=float) if wider else None
        if sample.strong:
            self.lit = known or detect.Picture(ratio)   # the grab's rows are analysed ones: its shape
            self.lit_sightings += 1
        if pictures.same(ratio, self.picture):
            self._candidate = None
            if self.provisional and sample.strong:
                self._confirm(known, ratio, sample)     # now seen lit: known, with its edges
            elif sample.strong:
                # At a look that moves nothing: a move into a wider picture never waits for the full-size grab.
                self.picture = self._finer(self.picture, sample)
            return
        if ratio > float(self.picture):              # wider
            self._candidate = None
            if sample.strong:
                self._confirm(known, ratio, sample)
            elif known is not None:
                self.picture, self.run_back, self.provisional = known, 0, False
            return
        if self._candidate is not None and pictures.same(ratio, self._candidate):
            self._count += 1
        else:
            self._candidate, self._count = ratio, 1
        # A dim grab of a shape never seen counts too: it can read a bar too wide, never picture in a bar, so the
        # picture is at least that tall (a dark IMAX scene on a first playback would keep the scope height until lit).
        needed = (NARROWER_GRABS if sample.strong else DIM_NARROWER_GRABS) if known is None \
            else 1 if sample.strong else DIM_NARROWER_GRABS
        if known is not None and coming is not None and pictures.same(known, coming):
            # The map says this picture comes after its silent span, and a dim reading is no taller than the picture:
            # one such grab is that picture (a dark first shot's three took the text down 0.35 to 0.54 s late).
            needed = 1
        if self._count >= needed:
            self._confirm(known, ratio, sample, self._count - 1)

    def _confirm(self, known, ratio, sample, back=0):
        self._candidate, self.run_back = None, back
        if known is None and not sample.strong:
            # Placed, not known: a dim reading may still be a little wide of the picture (a lit grab finishes the
            # move), and neither the map nor the next epoch learns it.
            self.picture, self.provisional = detect.Picture(ratio), True
            return
        if known is None:
            # A grab with its edges in its own rows (the full picture lit at one edge) needs no full-size one.
            known = (detect.picture_of(sample, self._video_ratio) if sample.exact
                     else measure.exact_picture(self._screen, self._video_ratio, sample)) or detect.Picture(ratio)
            self.known.append(known)
        self.picture = known
        self.provisional = False

    def _finer(self, shape, sample):
        """shape, or the same picture read again in one full-size grab where its rows came from a grab smaller than
        Kodi's window allows now (read in a smaller window, kept in a map from one): a grab's edge row that is partly
        picture reads as picture, so its bars read up to one of its rows thin, and at 720 rows that is a row at 2160
        under the distance on the full screen. Once for each shape and size; never the file's edges, nor a picture
        without bars (the full one read at the frame's edge: its rows are exact at any size)."""
        best = int(round(measure.SCREEN_EXACT_WIDTH / self._video_ratio))
        if not pictures.has_rows(shape) or shape.height >= best or not (shape.top or shape.bottom) \
                or self._exact.find(shape) is not None:
            return shape
        width = self._screen.width()
        rows = int(round(min(width, measure.SCREEN_EXACT_WIDTH) / self._video_ratio)) if width else 0
        tried = (shape.top, shape.bottom, shape.height, rows)
        if rows <= shape.height or tried in self._finer_tried:
            return shape
        self._finer_tried.add(tried)
        finer = measure.exact_picture(self._screen, self._video_ratio, sample)
        if finer is None or not pictures.same(finer, shape):
            return shape
        self.known.put(finer)
        self.lit = finer                # the look that read it again saw this very picture lit (_judge)
        return finer
