"""What the add-on checks about CoreELEC's settings (at the start, when settings change, when Kodi's settings
screens close) and the notices that come of it, shown in the add-on's own window with OK, one at a time and
only while no video plays (a window over a film would interrupt it)."""
import json
import os
import threading

import xbmc

from . import coreelec, ffmpeg, geometry, kodi, question, status
from .keeper import write_record
from .playback import image_distances

P3I_SETTINGS_SEEN = 'p3i_settings.json'   # the unfamiliar CoreELEC settings last shown
RESTRICT_NOTICE = 'restrict_notice.json'   # CoreELEC's restriction now only for image subtitles: told once
LEVEL5_NOTICE = 'level5_notice.json'       # the Level 5 correction can not work with CoreELEC's handling off: told once
IMAGE_MARGIN_NOTICE = 'image_margin_notice.json'   # image distances chosen, no bitmap margin in this CoreELEC: told once
FFMPEG_NOTICE = 'ffmpeg_notice.json'       # CoreELEC's FFmpeg newer than this add-on knows: told once per release
# Kodi's own settings screens where CoreELEC's settings sit (Settings > System, Settings > Player; names seen in a
# real Kodi 21). Kodi tells an add-on only about its own settings, so the service looks again when these close.
SETTINGS_SCREENS = 'Window.IsActive(systemsettings) | Window.IsActive(playersettings)'


class Notices:

    def __init__(self, playing_video):
        self.playing_video = playing_video
        self.waiting = []                    # (string id, done() -> False to drop it)
        self.telling = False

    def add(self, string_id, done=None):
        """A notice for the next moment without video (see tell_waiting); the same one only once in the queue."""
        if all(waiting != string_id for waiting, _done in self.waiting):
            self.waiting.append((string_id, done))

    def tell_waiting(self):
        """The first waiting notice, in the add-on's own window with OK, while no video plays and no other
        notice is open. done() records it as shown, before the window opens: False drops it (a notice that
        can not be recorded would come back at every start)."""
        if self.telling or not self.waiting or self.playing_video():
            return
        string_id, done = self.waiting.pop(0)
        if done is not None and not done():
            return
        self.telling = True

        def tell():
            try:
                question.tell(kodi.text(string_id))
            except Exception as error:  # a notice must never stop the service
                kodi.log('notice %d not shown: %r' % (string_id, error), always=True)
            finally:
                self.telling = False

        threading.Thread(target=tell, daemon=True).start()


class Checks:

    def __init__(self, service, notices):
        self.service = service               # on CoreELEC or not, the P3i policy, the decode guard
        self.notices = notices
        self.in_settings = False             # one of Kodi's settings screens open at the last step
        self.manual_notice_shown = False

    def restrict_notice(self):
        """Said once, so a person who finds that CoreELEC setting off again knows why (and does
        not take it for a fault in CoreELEC)."""
        path = kodi.data_path(RESTRICT_NOTICE)
        if not os.path.exists(path):
            self.notices.add(32132, lambda: _recorded(path, True))

    def check_level5_handling(self):
        """"Correct faulty Dolby Vision Level 5" on while CoreELEC's Level 5 handling is off: CoreELEC then takes
        no correction. Told once (again if it happens again after being resolved). The handling is never switched
        on here: it decides how every Dolby Vision video is sent to the TV, so it stays the person's choice."""
        path = kodi.data_path(LEVEL5_NOTICE)
        if not (self.service.on_coreelec and kodi.setting_bool('fix_level5', default=False)
                and kodi.get_setting(coreelec.LEVEL5_HANDLING, quiet=True) is False):
            if os.path.exists(path):
                os.remove(path)
            return
        kodi.log('"Correct faulty Dolby Vision Level 5" is on, but CoreELEC\'s Level 5 handling is off: '
                 'nothing can be corrected', always=True)
        if not os.path.exists(path):
            self.notices.add(32133, lambda: _recorded(path, True))

    def settings_left(self):
        """Kodi's settings screens just closed: CoreELEC's Level 5 handling may have been switched off there, while
        "Correct faulty Dolby Vision Level 5" is on (owner, 2026-10-13: otherwise nobody would know until Kodi restarts)."""
        if not self.service.on_coreelec:
            return
        open_now = kodi.holds(SETTINGS_SCREENS)
        if self.in_settings and not open_now:
            self.check_level5_handling()
        self.in_settings = open_now

    def check_image_margin(self):
        """A distance chosen for image subtitles on a P3i build without "Bitmap subtitle margin" (before build 5212):
        they are still kept inside the picture, but at no distance. Told once (again if it happens again after
        being resolved)."""
        path = kodi.data_path(IMAGE_MARGIN_NOTICE)
        if not (self.service.p3i.offered() and kodi.setting_bool('enabled')
                and any(distance is not geometry.DISC for distance in image_distances())
                and kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True) is None):
            if os.path.exists(path):
                os.remove(path)
            return
        kodi.log('this CoreELEC has no bitmap subtitle margin: image subtitles are kept inside the picture '
                 'without a distance', always=True)
        if not os.path.exists(path):
            self.notices.add(32146, lambda: _recorded(path, True))

    def check_ffmpeg(self):
        """CoreELEC's FFmpeg newer than this add-on knows (a CoreELEC update): no film can be measured, and every
        playback would only log it. Told once per FFmpeg release (again if it happens again after being resolved)."""
        path = kodi.data_path(FFMPEG_NOTICE)
        memory = kodi.data_path('ffmpeg.json')
        self.service.ffmpeg_usable = not self.service.on_coreelec or ffmpeg.usable(memory)
        if not self.service.ffmpeg_usable:
            kodi.log('CoreELEC\'s FFmpeg can not be used: CoreELEC places the subtitles as you set it', always=True)
        major = None if self.service.ffmpeg_usable else ffmpeg.newer_release(memory)
        if major is None:
            if os.path.exists(path):
                os.remove(path)
            return
        kodi.log('CoreELEC\'s FFmpeg (libavformat %d) is newer than this add-on knows: nothing can be measured' % major,
                 always=True)
        try:
            with open(path, encoding='utf-8') as handle:
                if json.load(handle) == major:
                    return
        except (OSError, ValueError):
            pass
        self.notices.add(32147, lambda: _recorded(path, major))

    def show_status(self):
        # Quiet: P3i's own setting is only readable while P3i shows it, and its absence says enough.
        p3i = self.service.on_coreelec and coreelec.is_p3i(lambda setting: kodi.get_setting(setting, quiet=True),
                                                   xbmc.getInfoLabel('System.BuildVersion'))
        system, method = status.describe(self.service.on_coreelec, p3i, not self.service.guard.paused(), xbmc.getCondVisibility)
        for setting_id, string_id in (('status_system', system), ('status_method', method)):
            try:
                shown, wanted = kodi.addon().getSetting(setting_id), kodi.text(string_id)
                if shown != wanted:     # Kodi writes its settings file on every change
                    kodi.addon().setSetting(setting_id, wanted)
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        kodi.log('started: %s, %s' % (kodi.text(system), kodi.text(method).lower()))
        if p3i:
            self.check_p3i_settings()

    def check_p3i_settings(self):
        """P3i's builds change often. A subtitle or Level 5 setting this add-on does not know is only logged, at
        every start: new builds add harmless ones (owner, 2026-10-13: a message for each would irritate). One it
        relies on that is gone, also what a rename looks like, is logged and told once (again if it happens again
        after being resolved)."""
        found = kodi.rpc('Settings.GetSettings', {'level': 'expert'}, quiet=True)
        if not isinstance(found, dict):
            return
        ids = [item.get('id', '') for item in found.get('settings', []) if isinstance(item, dict)]
        new = coreelec.unfamiliar_settings(ids)
        missing = coreelec.missing_settings(ids, lambda setting: kodi.get_setting(setting, quiet=True))
        if new:
            kodi.log('CoreELEC offers subtitle settings this add-on does not know: %s' % ', '.join(new), always=True)
        if missing:
            kodi.log('CoreELEC no longer offers settings this add-on relies on: %s' % ', '.join(missing), always=True)
        path = kodi.data_path(P3I_SETTINGS_SEEN)
        changes = ['missing: %s' % setting_id for setting_id in missing]
        if not changes:
            if os.path.exists(path):
                os.remove(path)
            return
        try:
            with open(path, encoding='utf-8') as handle:
                if json.load(handle) == changes:
                    return
        except (OSError, ValueError):
            pass
        self.notices.add(32131, lambda: _recorded(path, changes))

    def manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        self.notices.add(32040)


def _recorded(path, data):
    """write_record, True when it was written."""
    try:
        write_record(path, data)
        return True
    except OSError:
        return False
