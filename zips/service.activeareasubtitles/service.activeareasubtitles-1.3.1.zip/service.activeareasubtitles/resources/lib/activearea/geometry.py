"""Turning a picture shape into Kodi's subtitle margin setting.

Kodi's setting subtitles.marginvertical is a percentage, but for text
subtitles Kodi hands it to libass as MarginV = 10.8 * value * (1080 / 720)
on a 1080 line canvas (OverlayRenderer.cpp and DVDSubtitlesLibass.cpp,
Kodi 21). One unit of the setting therefore moves subtitles by 1.5 per cent
of the height they are laid out in: the whole screen for the "of screen"
positions, the video for the "of video" positions.
"""

import math

MARGIN_SCALE = 1.5
MARGIN_MIN, MARGIN_MAX, MARGIN_STEP = 0.0, 50.0, 0.05

# subtitles.align values in Kodi 21.
ALIGN_MANUAL, ALIGN_BOTTOM_OF_VIDEO, ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_VIDEO, ALIGN_TOP_OF_SCREEN = range(5)


def layout_area(align):
    """'screen', 'video', or None when the position is Manual (not handled)."""
    if align in (ALIGN_BOTTOM_OF_SCREEN, ALIGN_TOP_OF_SCREEN):
        return 'screen'
    if align in (ALIGN_BOTTOM_OF_VIDEO, ALIGN_TOP_OF_VIDEO):
        return 'video'
    return None


def video_on_screen(screen_ratio, video_ratio):
    """Height of the video as a share of the screen (Kodi's normal view mode: fitted and centred)."""
    return 1.0 if video_ratio <= screen_ratio else screen_ratio / video_ratio


def bar_share(area, screen_ratio, video_ratio, picture_ratio):
    """Height of one black bar, as a share of the area subtitles are laid out in.

    Bars at the top and bottom are equal, so the same share applies to
    subtitles placed at the top.
    """
    picture_in_video = min(1.0, video_ratio / picture_ratio)
    if area == 'video':
        return (1.0 - picture_in_video) / 2
    return (1.0 - video_on_screen(screen_ratio, video_ratio) * picture_in_video) / 2


# Distances kept between the subtitles and the picture's edge, in setting units of the screen,
# as offered in the menu. Content with black bars: None or Small gap. At 0 the descenders of g, j,
# p, q and y touch the edge, outline included (owner's test, 2026-10-07; the outline since 1.3.0,
# see text_outline). Small gap is 0.75 since 1.3.0: about 1 per cent of the screen height (12 px
# at 1080, 24 at 2160), a quarter of a text line at Kodi's default font, halfway to Low; 0.35 was
# the outline's own thickness, a patch for the outline in the bar while distances were measured to
# the white of the letters. Full-screen content: None, Small gap, Low, Medium, Standard (Kodi's own
# default margin), High, then Custom (any value in CUSTOM_RANGE).
EDGE_GAP = 0.75
BAR_DISTANCES = (0.0, EDGE_GAP)                      # then Custom
FULL_DISTANCES = (0.0, EDGE_GAP, 1.5, 3.0, 4.95, 6.5)
FULL_DEFAULT, CUSTOM = 4, 6
CUSTOM_RANGE = (0.0, 10.0)
# Content counts as full-screen when each bar is at most this share of the screen's height:
# 16:9, 1.85 and 1.90 on a 16:9 screen (bars up to 3.2 %), not 2.00 (5.6 %) and wider.
FULL_SCREEN_BARS = 0.04


BAR_CUSTOM = len(BAR_DISTANCES)

# The outline Kodi draws around text subtitles reaches below the letters, so a distance of 0 put the white of a
# descender on the edge and its black outline in the bar (the owner's 4K photo, 2026-10-14: at Small gap, 11 px,
# a 3 px sliver of picture showed under the g). Text distances are therefore measured from the outline's bottom.
# Kodi's margin places the bottom of the line box, which already lies below the lowest letters (the font's
# descender slack); what must be added is how far the outline reaches below that box. Measured in a real Kodi 21
# (rig, 1920x1080, DejaVu Sans): the outline's thickness depends on "Border size" alone, not on the font size,
# bold or blur: 0 -> none, 10 -> 2 px, 25 (Kodi's default) -> 4, 50 -> 8, 100 -> 15; "Background type" Shadow adds
# 2 px below, Box 7 px more than the outline. The slack grows with the font size. Calibrated on the owner's box
# (4K screenshots of a 2.39 clip, font size 32, border 25, 2026-10-14; Kodi places text in whole pixels of its
# 1080 canvas, 2 rows at 4K): the outline's bottom sat 4 rows above the picture's edge at margin 8.80, 2 rows past
# it at 8.70, and on it at 8.75: 0.20 units, 3.24 px at 1080, above the bar; 1.3.0 had added the outline's whole
# thickness (4 px) and left a 4-row sliver under the g. Kodi's setting unit is 1.5 per cent of the height, so one
# 1080-line pixel is 1 / 16.2 of a unit at any size.
OUTLINE_PER_BORDER, OUTLINE_BASE = 0.15, 0.4       # 1080-line pixels per unit of Border size, and the rounding
SHADOW_BELOW, BOX_BELOW = 2.0, 7.0                 # 1080-line pixels
# The slack does not change with the font size on the box's font: at size 56 (2026-10-15) 8.65 and 8.70 both cut the
# outline by about 2 rows (Kodi truncates both to the same whole pixel) and 8.75 is needed, as at size 32; the rig's
# font grows about 0.055 px per size unit instead, so this is the font's own property (see the font-file item in
# PLAN.md). Border 50 at size 32 ended 2 rows above the edge, 1 px from the model, left as it is.
DESCENDER_SLACK = 0.91                             # 1080-line pixels between the lowest letters and the line box
BACKGROUND_NONE, BACKGROUND_SHADOW, BACKGROUND_BOX, BACKGROUND_SQUARE_BOX = range(4)   # subtitles.backgroundtype
KODI_BORDER_SIZE, KODI_BACKGROUND = 25, BACKGROUND_NONE                               # Kodi's own defaults
PIXELS_PER_UNIT = 10.8 * MARGIN_SCALE               # on the 1080-line canvas


def _whole(value, default, floor=0):
    try:
        return max(floor, int(value))
    except (TypeError, ValueError):
        return default


def text_outline(border_size=KODI_BORDER_SIZE, background=KODI_BACKGROUND):
    """How far below the line box Kodi's margin places a text subtitle's outline, shadow or box reaches, in setting
    units: what every text distance must add so that it is measured from the outline's bottom."""
    border_size = _whole(border_size, KODI_BORDER_SIZE)
    pixels = OUTLINE_PER_BORDER * border_size + OUTLINE_BASE if border_size else 0.0
    if background == BACKGROUND_SHADOW:
        pixels += SHADOW_BELOW
    elif background in (BACKGROUND_BOX, BACKGROUND_SQUARE_BOX):
        pixels += BOX_BELOW
    pixels -= DESCENDER_SLACK
    return max(0.0, pixels) / PIXELS_PER_UNIT


def bar_distance(choice, custom=EDGE_GAP):
    if choice == BAR_CUSTOM:
        typed = custom_distance(custom)
        return EDGE_GAP if typed is None else typed
    return BAR_DISTANCES[choice] if choice in range(len(BAR_DISTANCES)) else BAR_DISTANCES[0]


def custom_distance(value, maximum=CUSTOM_RANGE[1]):
    """A typed distance in Kodi's steps, from 0 to maximum; None when it is not a number."""
    try:
        value = float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return None
    if value != value:      # NaN
        return None
    value = min(maximum, max(CUSTOM_RANGE[0], value))
    return round(round(value / MARGIN_STEP) * MARGIN_STEP, 2)


def full_distance(choice, custom):
    if choice == CUSTOM:
        typed = custom_distance(custom)
        return FULL_DISTANCES[FULL_DEFAULT] if typed is None else typed
    return FULL_DISTANCES[choice] if choice in range(len(FULL_DISTANCES)) else FULL_DISTANCES[FULL_DEFAULT]


# Image subtitles (PGS, DVD) on P3i builds: P3i places them with its "Restrict subtitles to active picture"
# and keeps them at least its "Bitmap subtitle margin" (a share of the screen's height) from the picture's
# edge. The distances use the scale of the text distances, so a choice keeps the same space on screen;
# DISC ("As on the disc") switches the restriction off, so they stay where the disc puts them. Image
# subtitles carry their own padding: the steps stop lower than for text. P3i's margin goes up to 10 per
# cent of the screen's height, 6.65 on this scale.
DISC = None
IMAGE_BAR_DISTANCES = (DISC, 0.0, EDGE_GAP, 1.5, 3.0)                 # then Custom
IMAGE_FULL_DISTANCES = (DISC, 0.0, EDGE_GAP, 1.5, 3.0, 4.95, 6.5)     # then Custom
IMAGE_DEFAULT = 0          # As on the disc: most image subtitles sit inside the picture already (owner, 2026-10-13)
IMAGE_BAR_CUSTOM, IMAGE_FULL_CUSTOM = len(IMAGE_BAR_DISTANCES), len(IMAGE_FULL_DISTANCES)
BITMAP_MARGIN_MAX = 10.0
IMAGE_CUSTOM_MAX = 6.65


def image_distance(choice, distances, custom):
    """The distance for image subtitles, or DISC. choice indexes distances, one past them is Custom."""
    if choice == len(distances):
        typed = custom_distance(custom, IMAGE_CUSTOM_MAX)
        return EDGE_GAP if typed is None else typed     # unreadable: the field's default, as the menu shows it
    return distances[choice] if choice in range(len(distances)) else distances[IMAGE_DEFAULT]


def bitmap_margin(distance):
    """P3i's bitmap subtitle margin (per cent of the screen's height, steps of 0.1) for a distance."""
    return round(min(BITMAP_MARGIN_MAX, max(0.0, distance * MARGIN_SCALE)), 1)


def full_screen(screen_ratio, video_ratio, picture_ratio):
    return bar_share('screen', screen_ratio, video_ratio, picture_ratio) <= FULL_SCREEN_BARS


def margin_value(area, screen_ratio, video_ratio, picture_ratio, bars_gap, full_gap):
    """The margin setting that puts subtitles the chosen distance inside the picture.

    The distance is full_gap for full-screen content and bars_gap for content with black bars,
    measured from the picture's edge, whether the bars are in the file or added by Kodi, and
    whether the "of video" position has already lifted them above Kodi's own bars. Bars thinner
    than half a per cent (rounding between a measured and a standard shape) count as none.
    """
    gap = full_gap if full_screen(screen_ratio, video_ratio, picture_ratio) else bars_gap
    area_share = bar_share(area, screen_ratio, video_ratio, picture_ratio)
    if area_share < 0.005:
        area_share = 0.0
    # The same distance on screen: units of the "of video" positions are shares of the video's height.
    scale = video_on_screen(screen_ratio, video_ratio) if area == 'video' else 1.0
    value = (gap / scale + area_share * 100 / MARGIN_SCALE)
    # Up to the setting's step, never down: a rounding error moves the text a row into the picture, never into the
    # bar (the owner's box, 2026-10-14: 8.6735 rounded to 8.65 put the outline a row into the bar at On the edge).
    value = math.ceil(value / MARGIN_STEP - 1e-9) * MARGIN_STEP
    return round(min(MARGIN_MAX, max(MARGIN_MIN, value)), 2)
