"""Recognising when CoreELEC already keeps subtitles inside the picture itself.

Some CoreELEC builds (P3i) restrict subtitles to the active area, from Level 5 metadata or
their own scan (Dolby Vision only up to their T4 build, SDR and HDR too from T5). They report
it per playback through info labels; the restriction setting is only readable while that build
offers it. When the build has it covered, the add-on stays out of the way so subtitles are not
lifted twice.
"""
RESTRICT_SETTING = 'coreelec.amlogic.dolbyvision.restrict.subs.active.area'
MARGIN_SETTING = 'coreelec.amlogic.dolbyvision.restrict.subs.user.pos'   # Apply configured subtitle margin
SDR_SCAN_SETTING = 'subtitles.detectactivearea'   # P3i's own scan for SDR and HDR; it reports no result
BITMAP_MARGIN_SETTING = 'subtitles.bitmapmargin'  # "Bitmap subtitle margin": image subtitles' least distance (build 5212)
WAIT_SETTING = 'subtitles.waitactivearea'         # "Pause for black-border or L5 detection" (build 5555): held off
THROTTLE_SETTING = 'coreelec.amlogic.dolbyvision.detect.throttle'   # "Throttle detection I/O": held off
DV_SCAN_SETTING = 'coreelec.amlogic.dolbyvision.detect.active.area'   # "Detect Dolby Vision active area"
# P3i's labels are read through labels.Labels. Scan states: 0 failed, 1 skipped as not 16:9 (it then uses Kodi's own bars), 2 skipped
# for IMAX, 3 detected, 4 skipped, 5 disabled, 6 running.
HANDLED_STATES = ('1', '3')
RUNNING = '6'
REPORT_WAIT = 3.0        # seconds to wait for the report itself right after playback starts


def is_coreelec(path='/etc/os-release'):
    try:
        with open(path, encoding='utf-8') as handle:
            return 'coreelec' in handle.read().lower()
    except OSError:
        return False


P3I_SETTING = 'coreelec.amlogic.independentpresenter'   # a setting only P3i builds have


def is_p3i(get_setting, build_version):
    """True on a P3i build of CoreELEC."""
    return get_setting(P3I_SETTING) is not None or 'p3i' in (build_version or '').lower()


def _number(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return 0.0


def places_subtitles(restricting, labels, wait, current, log):
    """True when CoreELEC restricts subtitles to the active area for this playback. restricting: its restriction
    setting is on; labels: P3i's live labels (labels.Labels).

    Level 5 with only zero offsets does not count: it says the picture fills the frame
    even when the bars are in the file, so there is nothing to restrict to.
    """
    if not restricting:
        log('CoreELEC does not restrict subtitles here (its setting is off or not offered for this output)')
        return False
    waited = 0.0
    while current():
        has_l5, top, bottom, state = labels.report()
        usable = has_l5 == '1' and (_number(top) > 0 or _number(bottom) > 0)
        if usable or state in HANDLED_STATES:
            log('CoreELEC places the subtitles itself (L5 %r, top %r, bottom %r, scan %r)'
                % (has_l5, top, bottom, state))
            return True
        # Right at the start the report may still be empty: give it a moment before deciding.
        not_reported_yet = has_l5 == '' and state == '' and waited < REPORT_WAIT
        # While its scan runs, CoreELEC restricts the subtitles as soon as it finishes, however
        # long that takes (it waits for the playback cache before each sample): placing them
        # meanwhile would lift them twice. So wait for the scan's end, never for a set time.
        if not (state == RUNNING or not_reported_yet):
            log('CoreELEC leaves the subtitles to the add-on (L5 %r, top %r, bottom %r, scan %r, after %d s)'
                % (has_l5, top, bottom, state, waited))
            return False
        if wait(1.0):
            break
        waited += 1.0
    return True   # playback changed or Kodi closing: do nothing


# P3i's settings about subtitles in the picture and Level 5, from its T5 build's settings.xml. One outside this list is
# a setting this add-on does not know: likely one of these renamed, which it would otherwise only notice as subtitles
# placed wrong. Only CoreELEC's and the subtitle settings are watched: Kodi's own have such words too
# (locale.activekeyboardlayout).
KNOWN_SETTINGS = frozenset((
    RESTRICT_SETTING, MARGIN_SETTING, SDR_SCAN_SETTING, DV_SCAN_SETTING,
    'coreelec.amlogic.dolbyvision.l5.auto.letterbox',
    'coreelec.amlogic.dolbyvision.level5',
    'coreelec.amlogic.dolbyvision.level5.override',
    'coreelec.amlogic.dolbyvision.level5.signal.subs',
    'coreelec.amlogic.dolbyvision.std.source.metadata.level5',
    'coreelec.amlogic.dolbyvision.std.source.metadata.level5.osdst',
    # Build 5212 (a settings export): image subtitle settings, one of them used (the bitmap margin).
    BITMAP_MARGIN_SETTING, 'subtitles.bitmapposition', 'subtitles.bitmapzoom', 'subtitles.bitmapsdrbrightness',
    'subtitles.bitmapsdrpeak', 'subtitles.bitmapsdrsaturation',
    # Build 4731 (a settings export): "Remember detected picture area" and "Use separate CPUs for
    # picture-area detection"; neither changes what the add-on does.
    'subtitles.cacheactivearea', 'subtitles.isolateactivearea',
    # Build 5555 (a settings export): "Pause at startup for black-border detection"; held off by the add-on
    # with the detection I/O throttle (restores.Detection).
    WAIT_SETTING, THROTTLE_SETTING,
    # Build 0615 (its settings.xml): "Border detection time per position" and "Skip HTTP(S) border detection", for
    # P3i's own scan, and the bitmap subtitle offset and aspect, shown for some bitmap positions; none changes what the
    # add-on does.
    'subtitles.activeareatimeout', 'subtitles.excludehttpactivearea', 'subtitles.bitmapoffset', 'subtitles.bitmapaspect',
))
WATCHED_PREFIXES = ('coreelec.', 'subtitles.')
WATCHED_WORDS = ('activ', 'restrict', 'level5', '.l5', 'bitmap')


# What the add-on reads on every P3i build. Kodi reports a setting only while it is shown, so a setting
# that can be hidden by another one (the margin option, under the restriction) can not be told from a
# removed one and is left out. The message for a missing one (32131) names the restriction: change it with this.
RELIED_ON = (RESTRICT_SETTING,)
LEVEL5_HANDLING = 'coreelec.amlogic.dolbyvision.level5'


def missing_settings(listed_ids, get_setting):
    """The settings in RELIED_ON a P3i build no longer offers: neither listed nor readable. None while
    CoreELEC's Level 5 handling is off, since P3i builds have shown subtitle settings under it."""
    if get_setting(LEVEL5_HANDLING) is False:
        return []
    return [setting_id for setting_id in RELIED_ON if setting_id not in listed_ids and get_setting(setting_id) is None]


def unfamiliar_settings(setting_ids):
    """The CoreELEC and subtitle settings among setting_ids about subtitle restriction or Level 5
    that are not in KNOWN_SETTINGS."""
    return sorted(setting_id for setting_id in setting_ids
                  if setting_id.lower().startswith(WATCHED_PREFIXES)
                  and any(word in setting_id.lower() for word in WATCHED_WORDS) and setting_id not in KNOWN_SETTINGS)


def restricts_with_level5(get_setting, labels):
    """True when CoreELEC restricts subtitles as soon as the film's Level 5 has values: the
    restriction is on and the stream carries Level 5 (which places_subtitles found all zero so far)."""
    return get_setting(RESTRICT_SETTING) is True and labels.has_level5()
