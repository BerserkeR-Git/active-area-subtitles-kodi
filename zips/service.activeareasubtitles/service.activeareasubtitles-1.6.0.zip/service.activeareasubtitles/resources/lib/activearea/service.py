"""The background service: Kodi's callbacks, the settings watch, and one Playback at a time.

Per playback: check that there is anything to do, work out the picture's shape (a file in a
shape of its own gets that shape at once and is measured all the same), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command. A film whose picture changes shape (IMAX scenes)
is followed scene by scene: on a P3i box a Dolby Vision film from P3i's Level 5 labels (labelfollow.py),
on a PC every film from Kodi's screen and, with a decoder, the file read ahead (screenfollow.py).
On a P3i box another subtitle track of the other kind (text or image) is placed again.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there); on a PC from the video file first where it has a decoder (the one shipped with the
add-on, or the system's FFmpeg), one screen grab placed meanwhile, else from tiny screen
captures. Everything runs on its own thread; any failure leaves Kodi's normal subtitle position.
"""
import functools
import os
import threading
import time

import xbmc
import xbmcvfs

from . import choices, coreelec, keyframes, kodi, labels, level5, shapes, updates
from .checks import Checks, Notices
from .choices import distances, image_distances
from .guard import DecodeGuard
from .p3i import P3i
from .playback import Playback, watch_due
from .restores import Restores
from .threads import Threads

UPDATE_PACKAGES = 'special://home/addons/packages/'   # where Kodi downloads an update before installing it
# Kodi says nothing when the subtitle track changes or subtitles are added during playback (no
# callback, no notification, in Kodi 21), so the service looks, as cheaply as it can:
# each step only Kodi's time since the last button press (a counter), the track itself only after a
# press, early in a playback (a player add-on adds subtitles then, without a press), and once in a
# while (a phone remote switches over JSON-RPC, which is not a press). Asking for the current track
# costs about 0.1 ms; normal watching asks nothing at all.
WATCH_STEP = 1.0               # seconds between looks at the time since the last button press
# Seconds between looks at the records already put back (Restores.settle): a person who sets one of the add-on's
# values again after a put back is told from Kodi bringing ours back from disk only by a look in the same Kodi
# session, so a crash or a close within this long after such a change still takes it for ours (accepted: the model
# in tools/properties gives every person's change a look before Kodi starts again).
SETTLE_STEP = 30.0
RECENT_INPUT = 3               # seconds after a press during which the track is looked at every step (watch_due)
TAKEN_OVER = 'stopping (a newer start of the service took over): changes stay on record for it'


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


def _in_charge(callback):
    """One of Kodi's callbacks, acted on only by the Service in charge (Service.in_charge)."""
    @functools.wraps(callback)
    def called(service, *args):
        if service.in_charge():
            callback(service, *args)
    return called


class Service(xbmc.Player):

    made = False                # its __init__ finished
    ended = False               # its run() returned or raised
    superseded = False          # a newer start of the add-on took charge: for good

    def __init__(self, threads=None, clock=time.monotonic, decoder=None, claim=None):
        """Three seams the tests put their own adapters in: threads, every thread the add-on starts (threads.Threads);
        clock, the time scene following and the seek hold go by (time.monotonic); decoder, the film reader's decoder
        class (None: ffmpeg.Decoder). claim: its start's claim in Kodi (kodi.claim_service, made by run(); None: no
        newer start ever takes over from it)."""
        # Before Kodi registers it: while Kodi installs an update or removes the add-on it does not know it, and a
        # Service that raises after super().__init__() stays registered, getting Kodi's callbacks (in_charge).
        version = kodi.addon().getAddonInfo('version')
        super().__init__()
        self.claim = claim
        self.monitor = _Monitor(self._settings_changed)
        kodi.stopping = lambda: self.monitor.abortRequested()     # kodi.log asks no setting while Kodi stops the add-on
        self.threads = threads if threads is not None else Threads()
        self.clock = clock
        self.decoder = decoder
        self.reads = threading.Lock()        # one reader of the playing file at a time (keyframes.FilmReader)
        # P3i's live labels, read through Kodi's at every look (labels.py)
        self.labels = labels.Labels(lambda name: xbmc.getInfoLabel(name),
                                    lambda condition: xbmc.getCondVisibility(condition), rpc=kodi.rpc,
                                    player=kodi.video_player)
        self.was_enabled = self.enabled()    # switched on in its settings, as last seen (a change since counts)
        self.distances = distances()
        # Every setting it changes, with its record, and the lock shared with the playbacks (restores.py).
        self.restores = Restores(self.enabled)
        self.lock = self.restores.lock
        self.p3i = P3i(self)                 # CoreELEC's own settings for the kind of subtitle shown (p3i.py)
        # Shown one at a time, never over a film (checks.py).
        self.notices = Notices(self._playing_video, lambda kind, target: self.threads.start(kind, target))
        self.checks = Checks(self, self.notices)        # CoreELEC's settings looked at, told when it matters
        self.image_distances = image_distances()
        self.scene_settings = choices.scene_settings()   # following IMAX scenes and their distance
        self.current = None                  # the Playback now, or None; replaced only under the lock
        self.last_seek = float('-inf')       # the clock at Kodi's last seek event (scene following holds still)
        self.seek = None                     # (that clock, the film time sought in seconds; None for a chapter)
        self.settled = clock()               # the clock at the last look at the records put back (settle_step)
        self.settle_failed = False           # a failed look logged, until one goes through
        self.on_coreelec = coreelec.is_coreelec()
        self.version = version
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), self.version)
        # The picture shapes remembered across playbacks (shapes.py); the setting is read at every use.
        # On CoreELEC an entry without a scene verdict is measured again (shapes.Shapes.begin).
        self.shapes = shapes.Shapes(kodi.data_path(shapes.FILE_NAME),
                                    lambda: kodi.setting_bool('remember_shapes', default=True), kodi.log,
                                    follows=self.on_coreelec)
        self.made = True

    def in_charge(self):
        """Whether this Service acts on anything: every one of Kodi's callbacks asks (_in_charge), and its loop at each
        step. Not one whose __init__ raised (Kodi registered it as a Player and its monitor at super().__init__() and
        goes on calling them), nor one whose run() ended or raised (run() builds the next), nor one a newer start of the
        add-on took over from (Kodi's stop came before this start made its first Monitor, so it never arrived, and Kodi
        started the add-on again beside it). Kodi not saying keeps it in charge."""
        if not self.made or self.ended or self.superseded:
            return False
        self.superseded = not kodi.claim_held(self.claim)
        return not self.superseded

    def stand_down(self):
        """A newer start of the add-on took charge: this one stops for good, leaving everything on record to it and
        putting nothing back; what its playback's threads still do changes nothing (Playback.is_current)."""
        with self.lock:
            self.current = None
        kodi.log(TAKEN_OVER, always=True)

    @staticmethod
    def enabled():
        """Whether the add-on is switched on in its settings: read at every use."""
        return kodi.setting_bool('enabled')

    def film(self, target, current, background=True, full=False):
        """A keyframes.FilmReader for target (a locate.Target), every decode inside the decode guard for its file.
        current: whether its playback is still current; background and full as for the reader."""
        return keyframes.FilmReader(target, kodi.data_path('ffmpeg.json'), current,
                                    functools.partial(self.guard.decoding, target.identity),
                                    background=background, full=full, decoder=self.decoder, lock=self.reads,
                                    wait=lambda seconds: self.monitor.waitForAbort(seconds))

    # Kodi's player and monitor callbacks run on this service's own thread, while its loop waits in waitForAbort
    # (Kodi queues them for the add-on's thread): they only start or stop work, so the watch keeps its pace.

    @_in_charge
    def onAVStarted(self):
        self._started_playback()

    def _started_playback(self, carried_over=False, same_film=False):
        playback = self.begin(carried_over, same_film)
        if self._playing_video():
            self.threads.start('placing', playback.fit, playback.epoch)

    def begin(self, carried_over=False, same_film=False):
        """A new Playback, now the current one: whatever an older one's threads still do changes nothing."""
        with self.lock:
            self.current = Playback(self, carried_over, same_film)
            return self.current

    @_in_charge
    def onPlayBackSeek(self, seek_time, seek_offset):
        self.last_seek = self.clock()
        try:
            to = float(seek_time) / 1000.0     # Kodi's milliseconds
        except (TypeError, ValueError):
            to = None
        self.seek = (self.last_seek, to)

    @_in_charge
    def onPlayBackSeekChapter(self, chapter):
        self.last_seek = self.clock()
        self.seek = (self.last_seek, None)

    def held(self):
        """Kodi holds the picture still (paused, seeking, loading) or seeked a moment ago: nothing in scene following
        moves then (labels.Labels.seeking)."""
        return self.labels.seeking(self.last_seek, self.clock())

    @_in_charge
    def onAVChange(self):
        # Streams changed (Kodi says so at the start, not when subtitles are added later): see _watch_step.
        self._subtitles_arrived()

    def _subtitles_arrived(self):
        """Subtitles switched on later in a playback that had none at the start: measured now."""
        playback = self.current
        epoch = playback.waiting if playback is not None else None
        if epoch is not None and kodi.holds('VideoPlayer.HasSubtitles') and playback.claim_waiting(epoch):
            self.threads.start('placing', playback.fit, epoch)

    def _watch_step(self, now=None):
        """One look during playback (see WATCH_STEP): on a PC Kodi's window (canvas_check), subtitles that arrived late,
        and on P3i builds a subtitle track of the other kind."""
        playback = self.current
        if playback is None:
            return
        watch = playback.watch
        now = time.monotonic() if now is None else now
        if not self.on_coreelec:
            playback.canvas_check()     # every step: dragging a window larger presses no button in Kodi
        if not watch_due(now, watch, _pressed_lately()):
            return
        watch.looked = now
        self._subtitles_arrived()
        # A position set in Kodi's on-screen settings comes with a button press too. The box as well: Bottom of video
        # to Bottom of screen during a cropped scope film would keep the video's margin, the text in Kodi's bar, and a
        # larger border at On the edge would put it partly there.
        try:
            playback.position_check()
        except Exception as error:  # Kodi failing here stays here: looked at again at the next look, told once
            if not watch.position_failed:
                watch.position_failed = True
                kodi.log('subtitle position not looked at: %r' % error, always=True)
        if playback.shown.kind is None or not self.on_coreelec:
            return                      # nothing placed by kind yet, or nothing placed by kind at all
        self.p3i.looked(playback, playback.epoch)

    def settle_step(self):
        """The records already put back looked at again, every SETTLE_STEP (Restores.settle)."""
        if self.clock() - self.settled >= SETTLE_STEP:
            self.settled = self.clock()
            self.restores.settle(idle=lambda: self.current is None)
            self.settle_failed = False

    @_in_charge
    def onPlayBackStopped(self):
        self.finish('playback stopped')
        self._hold_p3i_restriction()

    @_in_charge
    def onPlayBackEnded(self):
        self.finish('playback ended')
        self._hold_p3i_restriction()

    @_in_charge
    def onPlayBackError(self):
        self.finish('playback error')
        self._hold_p3i_restriction()

    def run(self):
        try:
            self.start()
            while not self.monitor.waitForAbort(WATCH_STEP):
                if not self.in_charge():
                    self.stand_down()
                    return
                try:
                    self.checks.settings_left()
                    self.checks.update_outcome()
                    self.notices.tell_waiting()
                    self._watch_step()
                except Exception as error:  # Kodi could not say: looked at again next step, logged once per playback
                    playback = self.current
                    watch = playback.watch if playback is not None else None
                    if watch is not None and not watch.failed:
                        watch.failed = True
                        kodi.log('subtitle watch: %r' % error, always=True)
                try:
                    self.settle_step()
                except Exception as error:  # looked at again at the next step; logged once until a look goes through
                    if not self.settle_failed:
                        self.settle_failed = True
                        kodi.log('records put back not looked at: %r' % error, always=True)
        except BaseException:
            with self.lock:
                self.current = None     # what its playback's threads still do changes nothing: run() builds the next
            raise
        finally:
            self.ended = True
        try:
            self.stopping()
        finally:
            self.guard.wait_until_idle()

    def start(self):
        """The service's start. Started during playback: Kodi updated the add-on (it does so by
        itself), it was switched on, or the service started again after a failure. What is in
        place belongs to that playback, so it is carried on: no repair, no "next video" clearing,
        measured again (the same answer changes nothing on screen). Only when an earlier service of this Kodi
        made its session: a film playing at the first start in a Kodi session (Kodi started with a file, the add-on
        switched on during a film after Kodi started with it off) is a playback of its own, and what is in place came
        from disk (a placing that gave up would keep the last session's margin and Manual)."""
        playing = self._playing_video()
        carried = playing and (self.restores.session_known is not False or self.current is not None)
        # The checks run in one order either way, so their notices queue alike.
        # The FFmpeg check before the status: on a PC it finds the decoder the status names.
        steps = (self._release_old_scan_hold, self._release_when_off, self._check_last_run, self.checks.check_ffmpeg,
                 self.checks.show_status, self.checks.check_level5_handling, self.checks.check_image_margin) if carried \
            else (self._release_old_scan_hold, self._release_when_off, self.restores.repair, self._check_last_run,
                  self.checks.check_ffmpeg, self.checks.show_status, self._hold_p3i_restriction,
                  self.checks.check_level5_handling, self.checks.check_image_margin)
        # Each step at the start on its own: one failing must not keep the others from running.
        for step in steps:
            try:
                step()
            except Exception as error:
                kodi.log('start: %s not done: %r' % (step.__name__.strip('_').replace('_', ' '), error), always=True)
        self.distances, self.image_distances = distances(), image_distances()   # no reason to place again
        self.was_enabled = self.enabled()     # read when the service was made: a change since counts
        if playing:
            self._started_playback(carried_over=carried)

    def stopping(self):
        """The service is asked to stop. Kodi closing (it has saved its settings by now) or an
        update (the next service carries on): everything stays as it is, on record, for the next
        start. Switched off or removed in Kodi's add-ons: nobody else would put things back.

        Seen in a real Kodi 21: during an update the add-on is already unknown to Kodi when its
        service stops, as after removing it; what tells them apart is the new version's package,
        which Kodi has just downloaded. When unsure, everything is put back."""
        details = kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID, 'properties': ['enabled']},
                           quiet=True)
        addon = details.get('addon') if isinstance(details, dict) else None
        if isinstance(addon, dict) and addon.get('enabled') is True:
            why = 'Kodi closing'
        elif addon is None and updates.arriving(self._packages_folder(), self.version):
            why = 'the add-on updating'
        else:
            self.finish('add-on switched off or removed', always=True)
            self.restores.release_all('add-on switched off or removed', always=True)
            kodi.log('stopping (add-on switched off or removed)', always=True)
            return
        with self.lock:
            self.current = None               # a measurement still running changes nothing more
        kodi.log('stopping (%s): changes stay on record for the next start' % why, always=True)

    @staticmethod
    def _packages_folder():
        """Where Kodi downloads an update before installing it, or None when Kodi can not say."""
        try:
            return xbmcvfs.translatePath(UPDATE_PACKAGES)
        except Exception:  # unknown: not an update
            return None

    def _hold_p3i_restriction(self):
        """See P3i.hold. Switched off, the person's restriction and bitmap margin are put back instead, so a write
        Kodi refused when the add-on was switched off is tried again after every playback, not only at Kodi's next
        start. A step of the start under this name: its name is in the log line
        when it fails."""
        self._release_when_off()
        self.p3i.hold()

    def _release_when_off(self):
        """Switched off in its settings: CoreELEC's settings stay the person's. Switching off puts them back in Kodi's
        memory; when Kodi had saved the add-on's value before and then stopped without saving again (a crash),
        it starts with that value, and this finishes putting it back."""
        if not self.enabled():
            self.restores.release_all('turned off in settings', always=True)

    def stale_correction(self):
        """Kodi's settings screens closed (Checks.settings_left): CoreELEC's Level 5 handling switched on again there
        shows its override again, and a correction it kept hidden from an earlier video's clear goes now (P3i would
        apply it to the film playing). The playing film's own correction stays."""
        playback = self.current
        self.restores.stale_correction(lambda: playback is not None and playback.level5.applied)

    def _release_old_scan_hold(self):
        self.restores.release_old_scan_hold()

    def _check_last_run(self):
        interrupted = self.guard.check_last_run()
        if interrupted == 'skipped':
            kodi.log('Kodi stopped during a decode last time; that video is left to Kodi from now on', always=True)
        elif interrupted == 'paused':
            kodi.log('Kodi stopped during a decode twice in a row; video file analysis pauses for a day', always=True)

    @_in_charge
    def _settings_changed(self):
        """Switched off: the own margin goes back at once. Switched on during a video: measure it.
        A distance changed during a video: placed again with it. Level 5 correction off: a
        correction in place is cleared. Other changes (the status fields the service writes
        itself, among them) do nothing."""
        changed = (self.distances != distances() or self.image_distances != image_distances()
                   or self.scene_settings != choices.scene_settings())
        self.distances, self.image_distances = distances(), image_distances()
        self.scene_settings = choices.scene_settings()
        if not any(self.distances):
            self.restores.distances_none()
        if not level5.enabled():
            self.restores.fix_off()
        self.checks.check_level5_handling()
        self.checks.check_image_margin()
        self.p3i.hold_detection()               # image distances or the Level 5 switch may have changed; read at the next film
        enabled = self.enabled()
        if enabled == self.was_enabled:
            playback = self.current
            if changed and enabled and self._playing_video() and playback is not None:
                kodi.log('distances changed to %.2f and %.2f: placed again' % self.distances)
                playback.place_again(playback.epoch)
            return
        self.was_enabled = enabled
        if not enabled:
            self.finish('turned off in settings')
            self.restores.release_all('turned off in settings')
            return
        self._hold_p3i_restriction()
        if self._playing_video():
            self._started_playback(same_film=True)  # the service's own start: onAVStarted is Kodi's to call

    def _playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return False

    # Bookkeeping.

    def finish(self, why, always=False, playback=None):
        # Also called by Playback._layout when the add-on is switched off while a playback starts.
        """always: log without asking for the detailed log setting (Kodi logs an error for that
        while the add-on is being switched off, even though the answer is not needed). playback: the one ending, from
        its own thread; nothing happens once another is current."""
        def ended():
            if playback is not None and self.current is not playback:
                return False
            self.current = None
            return True
        self.restores.finish(why, ended, always)


def _pressed_lately():
    """Whether a button was pressed in the last RECENT_INPUT seconds."""
    try:
        return xbmc.getGlobalIdleTime() < RECENT_INPUT
    except Exception:  # Kodi could not say: looked at once in a while all the same
        return False


RESTART_S, RESTART_MAX_S = 30, 1800    # after an unexpected failure of the service as a whole


def run():
    """The service, started again after anything unexpected (waiting longer each time), so one
    failure never leaves it off for the rest of the session. Kodi runs each start of the add-on in an interpreter of its
    own and can start the next while the last one runs on (its stop missed it, see Service.in_charge): the newest start
    is in charge (kodi.claim_service), and an older one stops for good once it sees that, never building another
    Service."""
    claim = kodi.claim_service()
    monitor, pause = xbmc.Monitor(), RESTART_S
    while not monitor.abortRequested():
        if not kodi.claim_held(claim):
            kodi.log(TAKEN_OVER, always=True)
            return
        try:
            Service(claim=claim).run()
            return
        except Exception as error:
            if kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID}, quiet=True) is None:
                # Kodi does not know the add-on while it installs an update or removes it (seen in a real Kodi 21)
                kodi.log('not started: Kodi is installing or removing the add-on, starting again in %d s' % pause,
                         always=True)
            else:
                kodi.log('stopped by an unexpected error, starting again in %d s: %r' % (pause, error), always=True)
        if monitor.waitForAbort(pause):
            return
        pause = min(pause * 2, RESTART_MAX_S)
