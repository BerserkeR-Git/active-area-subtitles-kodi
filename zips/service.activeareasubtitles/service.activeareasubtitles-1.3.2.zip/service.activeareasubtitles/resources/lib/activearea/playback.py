"""One playback, from Kodi's start of it to its end: what is known about it, and the work of placing its
subtitles, on threads of its own.

The service makes a Playback when Kodi starts one and drops it when it ends (Service.current). Every
thread works for one Playback and one of its epochs: placing the same playback again (another subtitle
track, another distance) starts a new epoch. Work for a playback that is no longer the current one, or for
an epoch that is no longer its newest, changes nothing (is_current). Nothing about one playback can be read
by the next: each starts with a fresh object (until 1.1.4 the state lived on the service and was reset by
hand).
"""
import contextlib
import functools
import os
import threading
import time
import types

import xbmc
import xbmcvfs

from . import coreelec, diagnostics, fonts, geometry, kodi, locate, measure, override, subtitles
from .restores import number as _number

SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 has a shape of its own (cropped, or 4:3 and the like)
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
HDR_TYPE = 'Player.Process(video.source.hdr.type)'
FILE_ANALYSIS = 'video file analysis'
LEVEL5_EARLIEST = 3.0          # seconds after the start before a Level 5 correction is written
# The watch (see Service._watch_step) looks at the subtitle track only after a button press, early in a playback,
# and once in a while; asking costs about 0.1 ms, normal watching asks nothing at all.
WATCH_EARLY = 30.0             # seconds after the start during which it is looked at regardless
WATCH_EARLY_STEP = 2.0         # how often then
WATCH_SLOW = 30.0              # how often otherwise


def watch_due(now, watch, pressed_lately):
    """Whether the watch looks at the subtitle track now: after a button press, early in the playback (a player
    add-on adds subtitles then, without a press), or once in a while (a phone remote switches without one)."""
    since = now - watch.looked
    return pressed_lately or since >= WATCH_SLOW or (now - watch.started < WATCH_EARLY and since >= WATCH_EARLY_STEP)


class Playback:

    def __init__(self, service, carried_over=False):
        self.service = service               # Kodi's player, the lock, the restores, the P3i policy
        self.started = time.time()
        self.epoch = 0                       # placed again: a new epoch of the same playback
        # Carried over from the previous service (an update during the film): its first epoch keeps what that
        # service put in place; placed again, it gets the add-on's own placement.
        self.carried_epoch = 0 if carried_over else None
        self.watch = types.SimpleNamespace(started=self.started, looked=self.started, track=None, failed=False)
        self.subtitle_kind = None            # IMAGE or TEXT
        self.measured = None                 # (picture ratio, how) once its shape settled
        self.measuring = None                # the mark of the measurement running, if one is
        self.picture = None                  # (layout, picture ratio): the latest shape found
        self.top = False                     # subtitles positioned at the top (their outline reaches up to the edge)
        self.level5_checked = False
        self.streams_of = (None, None, False)   # (identity, the file's subtitle streams, whether FFmpeg opened it)
        self.waiting = None                  # the epoch that had no subtitles yet; measured once some appear

    def is_current(self, epoch):
        """Whether work for epoch may still change anything: this is the playback now, epoch its newest."""
        return self.service.current is self and epoch == self.epoch and not self.service.monitor.abortRequested()

    def write(self, epoch, change):
        """The one way this playback writes to Kodi: change() under the lock, only while epoch is current, so a
        stop or a newer placing in between keeps it from writing. change()'s answer, or None when not current
        (until 1.1.4 the check was done by hand at each write, and one forgotten or done outside the lock raced
        with a stop)."""
        with self.service.lock:
            if not self.is_current(epoch):
                return None
            return change()

    def claim_waiting(self, epoch):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.service.lock:
            if self.waiting == epoch == self.epoch and self.service.current is self:
                self.waiting = None
                return True
            return False


    def restore_if_current(self, epoch, why):
        def back():
            if epoch == self.carried_epoch:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                kodi.log('%s: what the previous service set for this video stays' % why)
            elif self.service.restores.margin_back():
                kodi.log('%s: own subtitle margin put back' % why)
        self.write(epoch, back)

    # The work for one playback, on its own thread.

    def fit(self, epoch, again=False):
        """again: the same playback placed again for another subtitle track."""
        try:
            carried_over = epoch == self.carried_epoch
            if not (carried_over or again):     # a playlist's next video: the previous one's changes go
                self.write(epoch, self.service.restores.next_video)
            # A playback carried over from the previous service keeps CoreELEC's restriction as it was:
            # nothing moves during an update; the next video gets the add-on's own placement. Switched off in its
            # own settings: no P3i policy either, fit_once's layout check puts the margin back (until 1.1.4
            # a PGS film switched the restriction, and nothing put it back until Kodi started again).
            if (not carried_over and kodi.setting_bool('enabled') and self.service.p3i.offered()
                    and not self.service.p3i.by_kind(self, epoch, again)):
                return                    # an image subtitle left as on the disc: nothing to measure
            self.fit_once(epoch, again)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self.restore_if_current(epoch, 'unexpected error')
            except Exception:
                pass

    def while_measuring(self, epoch):
        """Another track or distance while the first measurement runs: CoreELEC's settings for the kind shown, and
        the shape found so far placed with what is chosen now."""
        try:
            if not self.service.p3i.by_kind(self, epoch, again=True):
                return
            picture = self.picture
            if picture is not None:
                self._apply(epoch, picture[0], picture[1], 'the shape found so far', time.time(), final=False)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('subtitle track not placed: %r' % error, always=True)

    def place_again(self, epoch):
        """The same playback placed again (another subtitle track, another distance), on a thread of its own.
        While its first measurement runs, that measurement carries on (it reads the distances and the kind at
        every answer) and the shape found so far is placed now; once settled, with that shape and its Level 5
        as it is. Until 1.1.4 a distance change while measuring started a second measurement from the first
        keyframe. Before the measurement starts (the waits for subtitles, the shape and CoreELEC's scan in _layout)
        there is nothing to carry on: a new epoch starts the placing over, and the old one ends at its next check
        (deep review, 2026-10-13: harmless). epoch: the one this change was judged for; an older one changes nothing. Kodi
        failing here stays here (the failure sweep found is_current's question escaping the watch)."""
        try:
            with self.service.lock:
                if not self.is_current(epoch):
                    return
                if self.measuring is None:
                    self.epoch += 1
                    target, args = self.fit, (self.epoch, True)
                else:
                    target, args = self.while_measuring, (epoch,)
            threading.Thread(target=target, args=args, daemon=True).start()
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('not placed again: %r' % error, always=True)


    def fit_once(self, epoch, again=False):
        if not self.service.on_coreelec and self.service.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self.is_current(epoch):
            return
        layout = self._layout(epoch)
        if layout is None:
            return
        area, screen_w, screen_h, video_ratio = layout
        started = time.time()
        measured = self.measured
        if again and measured is not None:
            # Placed again for another subtitle track: the shape this playback settled on, not decoded again.
            self._apply(epoch, layout, measured[0], '%s, measured earlier in this playback' % measured[1],
                        started, level5=not self.level5_checked)
            return
        # A file in a shape of its own is usually cropped to its picture: that shape at once. It is
        # measured all the same, since a 4:3 or 1.85 file can hold a wider picture with black bars
        # of its own (letterboxed DVDs, older TV); without a clear answer its own shape stays.
        own_shape = abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE
        if own_shape:
            self._apply(epoch, layout, video_ratio, 'the file\'s own shape, measuring', started, final=False)

        def give_up(why):
            if own_shape:
                self._apply(epoch, layout, video_ratio, 'the file\'s own shape (%s)' % why, started)
            else:
                self.restore_if_current(epoch, why)

        current = lambda: self.is_current(epoch)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self._target()
        keyframes = []      # what the file analysis decoded, for a Level 5 check without decoding again
        mine = self.measuring = object()    # this measurement's own mark: one per measurement, not per playback
        try:
            self._measure(epoch, layout, video_ratio, own_shape, give_up, current, record, target, unreadable,
                          full_pictures, keyframes, started)
        finally:
            if self.measuring is mine:      # a newer measurement keeps its own mark
                self.measuring = None

    def _measure(self, epoch, layout, video_ratio, own_shape, give_up, current, record, target, unreadable,
                 full_pictures, keyframes, started):
        """Each way of measuring in turn, until one settles (see _ways)."""
        for name, attempt in self._ways(video_ratio, current, record, target, unreadable, full_pictures, keyframes):
            try:
                settled = False
                # Closed explicitly, so a decoder is freed the moment the answer is in. A way may settle
                # more than once (screen capture widening for IMAX scenes): each settled shape counts.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        if own_shape and ratio <= video_ratio * (1 + CROPPED_TOLERANCE):
                            ratio = video_ratio     # no bars in the file: its own shape, not moved again
                        self._apply(epoch, layout, ratio, how, started, final, keyframes)
                        if final:
                            settled = True
                            self.measured = (ratio, how)
                if settled:
                    return
                if not current():       # stopped, or a newer placing of this film took over: not the file's fault
                    kodi.log('%s ended: the playback stopped or was placed again' % name)
                    return
                kodi.log('%s gave no clear answer' % name)
                give_up('no clear answer')
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
                if settled:               # what was settled stands
                    return
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self._coreelec_places(epoch)
                self._correct_late_level5(epoch)
                return
        kodi.log('no way of measuring worked for this playback')
        # The previous item of a playlist may have changed the margin: this one gets the person's own,
        # or the margin for the file's own shape.
        give_up('not measured')

    def _layout(self, epoch):
        """(area, screen width, screen height, video ratio), or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self.service._finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, epoch):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self.restore_if_current(epoch, 'no subtitles')
            self.waiting = epoch
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self.claim_waiting(epoch)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self.restore_if_current(epoch, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        self.top = geometry.layout_top(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self.restore_if_current(epoch, 'position not handled')
            self.service.checks.manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self.restore_if_current(epoch, 'view mode not normal')
            return None
        if self.service.on_coreelec and self.subtitle_kind != subtitles.IMAGE and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.service.monitor.waitForAbort,
                lambda: self.is_current(epoch), kodi.log):
            self._coreelec_places(epoch)
            if self.is_current(epoch) and kodi.setting_bool('fix_level5', default=False):
                self._correct_level5(epoch)
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, epoch)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self.restore_if_current(epoch, 'size unknown')
            return None
        return area, screen_w, screen_h, video_ratio

    def _correct_late_level5(self, epoch):
        """Level 5 that starts at zero and has values later: CoreELEC follows it as it plays, so a
        wrong or flickering one is corrected the same way as one reported at the start."""
        if self.is_current(epoch) and kodi.setting_bool('fix_level5', default=False):
            self._correct_level5(epoch)

    def _correct_level5(self, epoch, keyframes=None):
        """CoreELEC places these subtitles from the film's Level 5: give it the right edges when
        that Level 5 is clearly wrong (Correct faulty Dolby Vision Level 5, off by default). True
        when CoreELEC now has the picture's edges from an override: this one, or override.ini's.
        keyframes: what measuring decoded, judged instead of decoding again."""
        applied = self._check_level5(epoch, keyframes)
        if self.is_current(epoch):
            self.level5_checked = True   # not decoded again when a track change places again
        return applied

    def _check_level5(self, epoch, keyframes):
        target, unreadable = self._target()
        if target is None:
            kodi.log('Level 5 not checked: %s' % unreadable)
            return
        if override.set_by_override_ini(target.address, _read_text):
            kodi.log('Level 5 left alone: override.ini supplies it for this folder')
            return True
        if xbmc.getInfoLabel(coreelec.SCAN_STATE) == '3':
            # CoreELEC only scans films without Level 5 of their own: nothing to correct.
            kodi.log('Level 5 left alone: CoreELEC measured this film itself')
            return
        if not self.service.guard.allowed(target.identity):
            kodi.log('Level 5 not checked: left to Kodi after an interrupted decode')
            return
        try:
            correction, reason = measure.level5_correction(
                target, self.service.getTotalTime(), kodi.data_path('ffmpeg.json'),
                lambda: self.is_current(epoch), functools.partial(self.service.guard.decoding, target.identity),
                keyframes=keyframes, min_length=self._min_length())
        except Exception as error:  # Unavailable, or Kodi could not say: never a reason to stop
            kodi.log('Level 5 not checked: %s' % error)
            return
        if not self.is_current(epoch):
            return
        kodi.log('Level 5 check: %s' % reason)
        known = override.value_for(*correction) if correction else ''
        if not known:
            return
        # P3i's per-folder override add-on writes the same setting from override.ini at the start
        # of playback, and saves what it found there to put back afterwards: never write before it.
        wait = self.started + LEVEL5_EARLIEST - time.time()
        if wait > 0 and self.service.monitor.waitForAbort(wait):
            return
        applied = self.write(epoch, lambda: self.service.restores.override.apply(known))
        if applied is None:
            return
        if applied:
            kodi.log('Level 5 corrected for CoreELEC: %s' % known, always=True)
        else:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 override holds another value '
                     '(override.ini, or another add-on)', always=True)
        return applied

    def _wait_for(self, condition, seconds, epoch, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self.is_current(epoch):
            if condition():
                return True
            if waited >= seconds or self.service.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def _target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Resolved once per playback: its identity names the file for the decode guard, and it is what
        the file analysis reads (a Plex transcode costs one question to the server)."""
        try:
            return locate.resolve(self.service.getPlayingFile(), stat=xbmcvfs.Stat), None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    def _min_length(self):
        """The shortest video the file analysis reads: shorter on CoreELEC, where it is the only way to measure."""
        return measure.FILM_MIN_LENGTH_ALONE if self.service.on_coreelec else measure.FILM_MIN_LENGTH

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures, keyframes=None):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.service.monitor.waitForAbort, record)

        def from_file():
            if target is None:
                raise measure.Unavailable(unreadable)
            if not self.service.guard.allowed(target.identity):
                raise measure.Unavailable('left to Kodi after an interrupted decode')
            try:
                length = self.service.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            hands_over = (self.service.on_coreelec and self.subtitle_kind != subtitles.IMAGE
                          and coreelec.restricts_with_level5(kodi.get_setting, xbmc.getInfoLabel))
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                functools.partial(self.service.guard.decoding, target.identity), full=full_pictures,
                                level5_hands_over=hands_over, keyframes=keyframes, min_length=self._min_length())

        if self.service.on_coreelec:
            return [(FILE_ANALYSIS, from_file)]
        return [('screen capture', screen), (FILE_ANALYSIS, from_file)]

    def _apply(self, epoch, layout, picture_ratio, how, started, final=True, keyframes=None, level5=True):
        """The shape found, placed for the kind of subtitle shown (see _place), then logged; a settled shape of
        Dolby Vision gets its Level 5 for the TV."""
        placed = self.write(epoch, lambda: self._place(layout, picture_ratio))
        if placed is None:
            return
        _area, screen_w, screen_h, video_ratio = layout
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; %s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, placed))
        if final and level5 and self._level5_for_the_tv():
            self._correct_level5(epoch, keyframes)

    def _place(self, layout, picture_ratio):
        """With the lock held, for a current epoch: the settings for the kind of subtitle shown, decided under the
        same lock as the writes (decided before it until 1.1.4, a switch in between put the text margin under an
        image subtitle). The end of the log line, or None when nothing could be placed.

        A text subtitle: Kodi's margin for this shape. An image subtitle on a P3i build: CoreELEC places it with its
        restriction, at least the distance chosen for this shape from the picture's edge (its bitmap margin, from
        build 5212 on; older builds keep it inside the picture without a distance); "As on the disc": the
        restriction off. The text margin is the person's meanwhile."""
        area, screen_w, screen_h, video_ratio = layout
        restores = self.service.restores
        self.picture = (layout, picture_ratio)
        if self.subtitle_kind == subtitles.IMAGE:
            full = geometry.full_screen(screen_w / screen_h, video_ratio, picture_ratio)
            distance = image_distances()[1 if full else 0]
            restores.margin_back()
            if distance is geometry.DISC:
                restores.disc()
                placed = 'as on the disc'
            else:
                margin = restores.image(distance)
                placed = ('inside the picture (this CoreELEC has no bitmap subtitle margin)' if margin is None
                          else '%.2f from the edge (bitmap subtitle margin %.1f %%)' % (distance, margin))
            return 'image subtitles of %s %s' % ('full-screen content' if full else 'content with black bars', placed)
        own = restores.own_margin()
        if own is None:
            kodi.log('could not read the subtitle margin, not handled')
            return None
        bars_gap, full_gap = distances()
        reach, give, font = text_reach(self.top)
        value = geometry.margin_value(area, screen_w / screen_h, video_ratio, picture_ratio, bars_gap, full_gap, reach,
                                      give)
        changed = restores.apply_margin(value)
        return 'margin %.2f -> %.2f%s (reach %.1f px, give %.1f px, %s)' % (
            own, value, '' if changed else ' (unchanged)', reach, give, font.family if font else 'font not read')

    def _level5_for_the_tv(self):
        """Dolby Vision the add-on places itself, with "Correct faulty Dolby Vision Level 5" on and
        CoreELEC's Level 5 handling on (its override is only readable then): the TV gets the
        corrected Level 5 too."""
        if not (self.service.on_coreelec and kodi.setting_bool('fix_level5', default=False)
                and xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision'):
            return False
        if kodi.get_setting(override.SETTING, quiet=True) is None:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 handling is off')
            return False
        return True

    def _coreelec_places(self, epoch):
        """CoreELEC's own restriction covers this playback: it was on when the playback started (a film
        carried over from an update, the hold refused, or the person switched it on during the film). CoreELEC
        places the subtitles on its own edge with the person's settings, so the add-on's margin goes back to the
        person's (a carried-over film keeps what the previous service set)."""
        kodi.log('CoreELEC places the subtitles with its own settings')
        self.restore_if_current(epoch, 'CoreELEC places the subtitles')

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None


def image_distances():
    """(content with black bars, full-screen content) for image subtitles on P3i builds: a distance, or
    geometry.DISC for "As on the disc"."""
    return (geometry.image_distance(kodi.setting_int('image_bars', geometry.IMAGE_DEFAULT), geometry.IMAGE_BAR_DISTANCES,
                                    kodi.setting_number('image_bars_custom', geometry.EDGE_GAP)),
            geometry.image_distance(kodi.setting_int('image_full', geometry.IMAGE_DEFAULT), geometry.IMAGE_FULL_DISTANCES,
                                    kodi.setting_number('image_full_custom', geometry.EDGE_GAP)))


FONT_DEFAULT_FILE = 'arial.ttf'                        # Kodi's name for its default subtitle font (FontUtils.h)
SYSTEM_FONTS, USER_FONTS = 'special://xbmc/media/Fonts/', 'special://home/media/Fonts/'
_fonts = {}                                            # (path, face, modification time) -> fonts.Metrics or None
MOST_FONTS = 8


def font_metrics(name, bold=False):
    """The metrics of the font Kodi draws text subtitles with (fonts.Metrics), or None when its file can not be found
    or read; one log line per font file. name: subtitles.fontname, DEFAULT or a family from the user fonts folder;
    bold: the face of that weight when the family has one."""
    if name in (None, '', geometry.KODI_FONT):
        found = (os.path.join(xbmcvfs.translatePath(SYSTEM_FONTS), FONT_DEFAULT_FILE), 0)
    else:
        found = fonts.find(xbmcvfs.translatePath(USER_FONTS), name, bold)
        if found is None:
            _remember(('family', name), None, 'font %s: no file of that family in %s, outline added in full' % (
                name, USER_FONTS))
            return None
    path, face = found
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = None
    key = (path, face, stamp)
    if key not in _fonts:
        try:
            metrics = fonts.read(path, face)
            _remember(key, metrics, 'font %s from %s: %d units per em, ascent %d, descent %d, lowest letter %s, '
                      'tallest %s%s' % (metrics.family, path, metrics.units_per_em, metrics.ascent, metrics.descent,
                                        metrics.depth, metrics.height, ', bold' if metrics.bold else ''))
        except fonts.Broken as why:
            _remember(key, None, 'font file %s not read (%s), outline added in full' % (path, why))
    return _fonts[key]


def _remember(key, metrics, line):
    """Keep what a font file gave, and say so once (a family whose file is gone is looked for every time, in case
    it comes back, but reported once)."""
    if key in _fonts:
        return
    if len(_fonts) >= MOST_FONTS:
        _fonts.clear()
    _fonts[key] = metrics
    kodi.log(line, always=True)


def text_reach(top=False):
    """(how far the ink of a text subtitle reaches past its line box towards the edge, how much of it may end up past
    the edge, its font's metrics or None): geometry.text_reach and edge_give from Kodi's subtitle settings and the font
    file; Kodi's defaults for settings an older Kodi does not have."""
    def setting(name, default):
        value = kodi.get_setting('subtitles.' + name, quiet=True)
        return default if value is None else value
    style = _number(setting('style', geometry.KODI_STYLE))
    bold = style in (geometry.STYLE_BOLD, geometry.STYLE_BOLD_ITALIC)
    metrics = font_metrics(setting('fontname', geometry.KODI_FONT), bold)
    border = setting('bordersize', geometry.KODI_BORDER_SIZE)
    background = setting('backgroundtype', geometry.KODI_BACKGROUND)
    shadow = setting('shadowsize', geometry.KODI_SHADOW_SIZE)
    return (geometry.text_reach(metrics, setting('fontsize', geometry.KODI_FONT_SIZE), border, background, shadow, bold,
                                top),
            geometry.edge_give(border, background, shadow), metrics)


def distances():
    """(content with black bars, full-screen content): the distances chosen in the menu."""
    return (geometry.bar_distance(kodi.setting_int('gap_bars', 0), kodi.setting_number('gap_bars_custom', geometry.EDGE_GAP)),
            geometry.full_distance(kodi.setting_int('gap_full', geometry.FULL_DEFAULT),
                                   kodi.setting_number('gap_full_custom', geometry.FULL_DISTANCES[geometry.FULL_DEFAULT])))


def _read_text(path):
    """A small text file's contents, through Kodi's file access (local and network folders), or None."""
    try:
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:  # unreadable: as if there were none
        return None
