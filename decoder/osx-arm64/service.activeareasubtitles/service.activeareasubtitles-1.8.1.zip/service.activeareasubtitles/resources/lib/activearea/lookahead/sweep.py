"""The read-ahead itself (Lookahead): the loop that reads the film ahead of playback a step at a time, the sweep's
keyframes and what it places, and the pending searches given their turn (Searching runs them)."""

from .. import libav, pictures, scenemap, steady
from ..scenemap import timecode
from .judge import FrameJudge
from .keyindex import KeyframeIndex
from .searches import LEAD, SEARCH_FLOOR, Job, Searches
from .searching import SEARCHED, Searching, full_if
from .trust import Trust

SPARSE = 2.0          # seconds between the keyframes read: a scene shorter than this may be left to the screen grabs
IDLE = 0.5            # seconds between looks at the film's time once LEAD ahead: two looks in each STALL_WINDOW, so a
                      # stall of 0.55 s or more while the read-ahead waits is seen (Steady.played; at 1 s a 0.6 s stall
                      # across two looks showed in neither, and a keyframe was read 2.65 s after it in the film
                      # simulator's short stalls)
PLAYBACK_JUMP = 5.0   # seconds past the next keyframe asked for beyond which playback jumped ahead (a seek)
WENT_BACK = 0.5       # seconds before where reading began, or the step before's look, from which playback went back
REFILL = 20.0         # seconds of the lead used up before it reads again: a batch of keyframes per open of the file
                      # (not an open for every keyframe, every 2 s)
DARK_SEARCH = 20.0    # seconds between the keyframes on both sides of a dark run up to which its frames are searched
STOP_FLOOR = 4.0      # seconds of lead at which a search under way stops and waits again: room for the next keyframe
                      # and the coarse cut it may bring (two of SPARSE)
RETRIES = 5           # times a failed reopen of the file is tried again (another reader, a source busy for a moment)
RETRY_WAIT = 2.0      # seconds before the first try again, doubled at each
AHEAD_READS = 4.0     # keyframes' cost (measured on its own reads) ahead of playback a stretch begins after a seek:
                      # the first keyframes and a cut search read before playback gets there (in the film simulator at a
                      # second a keyframe, begun at the playing position it stayed behind playback for half a minute
                      # after a seek, and the grabs took 6 of its 10 cuts, 0.47 s in the bar)
AHEAD_MOST = 10.0     # seconds ahead of playback at most
TOLD_EVERY = 15       # keyframes read in a row (no wait between) between two log lines of the lead over playback
TOLD_BELOW = 30.0     # seconds of lead under which those lines are written (above it reading keeps up: no lines)


class DarkRun:
    """A run of keyframes that showed nothing, waiting for the keyframe after it to tell: the first one's film time,
    the film times of all (the keyframes a walk reads between), whether every one is dark with trusted Level 5 0/0
    (trusted_zero: the full picture where the keyframe after confirms it), and whether every one's Level 5 is 0/0,
    trusted or not (zero, for the log)."""

    def __init__(self, at, trusted_zero, zero):
        self.first, self.times, self.trusted_zero, self.zero = at, [at], trusted_zero, zero

    def add(self, at, trusted_zero, zero):
        self.times.append(at)
        self.trusted_zero = self.trusted_zero and trusted_zero
        self.zero = self.zero and zero


class Lookahead:
    """The read-ahead itself: the loop that reads the film ahead of playback (the sweep and the pending searches) and
    the scene map it builds, judging each frame with its FrameJudge and Level 5 with its Trust."""

    def __init__(self, film, film_time, steady, wait, log, video_ratio, seen=(), wanted=None, known=(), shown=(),
                 trust=None, kept=None):
        """film(): a filmreader.FilmReader for the playing file, not opened; film_time(): Kodi's playing position in
        seconds or None; steady: the playback's steady.Steady (every step waits on it, a read under way asks it whether
        to go on, Kodi's time at every look is told to it); wait(seconds) -> True when Kodi closes; log(line,
        always=False); video_ratio: the video's own shape (a frame's rows count in it: non-square pixels); seen: the
        keyframes the measurement decoded (their Level 5 against their pictures); wanted(): False once following stops
        (nothing read for it then); known: shapes the film is known to show (the measurement's settled one): a weakly
        lit reading of one of them is believed; shown: shapes a scene map from the cache says the film shows: another
        picture is known (the keyframes between two read ones, the frames inside a dark run), but a weak reading of one
        is not believed for it; trust: the trust in Level 5 an earlier playback of the file came to, from the cache
        ({'fits': the film times of the fits counted, 'refused': True once a keyframe's picture did not fit}), or None;
        kept(trust): the cache keeps a new one (a fit counted towards TRUST_FITS, a refusal)."""
        self._film, self._film_time, self._steady = film, film_time, steady
        self._wait, self._log = wait, log
        self._wanted = wanted or (lambda: True)
        self.map = None                 # the latest scene map (scenemap.SceneMap, exact), or None before the first
        self._building = scenemap.SceneMap(exact=True)
        # A cached playback decodes none of the measurement's keyframes: its trust comes from the cache.
        self._trust = Trust(video_ratio, log, kept, trust)
        self._judge = FrameJudge(video_ratio, self._trust, known, shown, lambda: self._building.shapes)
        self._trust.learn(seen)
        self._judge.learn(seen)
        self._searches = Searches(self._dropped)
        self._searching = Searching(self._building, self._judge, self._trust, self._searches, log, self._now,
                                    self._change, index=lambda: self._index, confirm=self._confirm)
        self._cost = None               # seconds of playback one keyframe read costs (the latest, never below the mean)
        self._start = None              # the playing position the reading began from (at the start, after a seek), or
                                        # where the map let go of what came before it
        self._kept = None               # the map's kept_from as last taken note of (it lets go only when full)
        self._last = None               # (film time, picture) of the latest keyframe placed in the stretch being read
        self._probe = None              # the film time of the sweep's next keyframe
        self._looked = None             # Kodi's time at the latest step's look
        self._dark = None               # the DarkRun the keyframe after tells (see _sweep)
        self._index = None              # the file's keyframe index (KeyframeIndex) while it is believed, read at the
                                        # first open and kept across the reopens; None without one
        self._weak = None               # (film time, shape) of a weakly lit keyframe of a shape not believed yet: believed
                                        # when the keyframe after it agrees (a dark scene's misread varies)
        self._held_back = None          # (film time, picture) of a keyframe read whose coarse cut waits for the keyframe
                                        # just before it (_opens_far)
        self.for_good = False           # stopped for a reason no new start mends (the file, the map full with nothing
                                        # it may let go)
        self._reading = True            # False once LEAD ahead, until REFILL of it was used up
        self._opened = False            # the file was opened once: a failed open after that is tried again
        self._tries = 0                 # failed reopens in a row
        self._told = 0                  # keyframes read since the lead was last logged
        self.keyframes = 0              # keyframes the sweep read (Searching counts its own and the frames)

    def trusted(self):
        """Whether the film's Level 5 places keyframes that show nothing believed (Trust)."""
        return self._trust.trusted()

    def trust(self):
        """The trust in Level 5 so far, as the cache keeps it (Trust.data)."""
        return self._trust.data()

    def run(self, current):
        """Reads ahead until current() says no (the playback ended), following stops, or the film can not be read. A
        step at a time: under SEARCH_FLOOR of lead the sweep's next keyframe; else the pending search worth running,
        where playback is untroubled; else the sweep's next keyframe up to LEAD ahead; else a wait."""
        film = why = None
        try:
            while True:
                if not current():
                    why = 'the playback ended'
                    return
                if not self._wanted():
                    why = 'following is off'
                    return
                # Kodi's time told at every step of the wait, this moment's too: a stall seen keeps it waiting.
                if not self._steady.wait(current, self._looking):
                    why = 'the playback ended or Kodi is closing'
                    return
                now = self._film_time()
                if now is None:
                    if self._wait(IDLE):
                        why = 'Kodi is closing'
                        return
                    continue
                kept = self._building.kept_from
                if kept != self._kept:
                    # The map was full and let go of what was read before kept: a seek back there is one to where
                    # nothing was read (it used to stop for good once full, leaving the rest of a dense film to the
                    # grabs, about 1.5 % of the time in the bar).
                    self._log('scenes ahead: the scene map is full, what came before %s let go' % timecode(kept))
                    self._start, self._kept = max(self._start, kept), kept
                if self._probe is None or now < self._start - WENT_BACK or now > self._probe + PLAYBACK_JUMP:
                    self._begin(now)
                    if film is not None:
                        # A fresh decoder: one that decoded keyframes before a seek back refuses them as decoded
                        # already, and the sweep paired the keyframes on both sides of them (40 s apart in the film
                        # simulator: one coarse cut over a whole scene).
                        film.close()
                        film = None
                elif now < self._looked - WENT_BACK:
                    self._back(now)
                self._looked = now
                self._building.playing(now)
                ahead = self._probe - now
                job = None
                if ahead >= SEARCH_FLOOR and self._steady.untroubled(steady.FRAMES_QUIET):
                    job = self._searches.next(now, ahead, self._estimate)
                if job is None and self._held_back is None and (
                        ahead > LEAD or (not self._reading and ahead > LEAD - REFILL)):
                    self._reading = False
                    if film is not None:
                        film.close()            # another reader may take its turn while this one waits
                        film = None
                    if self._wait(IDLE):
                        why = 'Kodi is closing'
                        return
                    continue
                if film is not None and job is not None and job.reopens:
                    film.close()
                    film = None
                if film is None:
                    if job is None:
                        if not self._reading and ahead < TOLD_BELOW:
                            self._log('scenes ahead: reading again, %d s ahead of playback' % ahead)
                        self._told = 0
                        self._reading = True
                    film = self._open()
                    if film is None:
                        if job is not None:
                            self._searches.add(job)     # its turn once the file opens again
                        if self._wait(RETRY_WAIT * 2 ** (self._tries - 1)):
                            why = 'Kodi is closing'
                            return
                        continue
                if job is not None:
                    self._search(film, job, current)
                    continue
                self._told += 1
                if self._told >= TOLD_EVERY and ahead < TOLD_BELOW:
                    self._log('scenes ahead: %d s ahead of playback' % ahead)
                    self._told = 0
                self._sweep(film)
        except libav.Unavailable as reason:
            why = str(reason)
            self.for_good = True
        finally:
            if film is not None:
                film.close()
            if why is not None:
                self._log('scenes ahead: stopped, %s' % why)
            self._log('scenes ahead: %d keyframes and %d frames read' % (
                self.keyframes + self._searching.keyframes, self._searching.frames))

    def _now(self):
        """Kodi's playing position (None where it can not say), told to the steady playback at every look: a stall it
        sees there holds the reads."""
        now = self._film_time()
        self._steady.played(now)
        return now

    def _looking(self, reading=False):
        """A look at every step of the steady playback's wait (Steady.wait's meanwhile): a stall that goes on while the
        reads wait is seen to its end, and they wait HELD_STEADY after that."""
        if not reading:
            self._now()

    def _timed(self, before, after):
        """A keyframe read while playback went from before to after (not across a seek or a pause)."""
        if before is None or after is None or not 0 <= after - before <= AHEAD_MOST:
            return
        spent = after - before
        self._cost = spent if self._cost is None else max(spent, (spent + self._cost) / 2)

    def _estimate(self, job):
        """Seconds of playback a search is estimated to take (Searching.estimate), at the keyframe cost measured."""
        return self._searching.estimate(job, self._cost)

    def _dropped(self, job):
        self._log('scenes ahead: %s from %s to %s not read, playback came too near' % (
            SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0])))

    def _open(self):
        """The film opened for a batch, or None after a reopen that failed: run tries again after a wait, RETRIES times
        (one failed reopen would end the read-ahead for good). A failed first open raises libav.Unavailable, as does
        the last try."""
        film = self._film()
        try:
            film.open()
        except libav.Unavailable as reason:
            if not self._opened or self._tries >= RETRIES:
                raise
            self._tries += 1
            self._log('scenes ahead: reopening the file failed (%s), trying again in %d s' % (
                reason, RETRY_WAIT * 2 ** (self._tries - 1)))
            return None
        if not self._opened:
            self._index = self._acquire(film)
        self._opened, self._tries = True, 0
        return film

    def _acquire(self, film):
        """The file's keyframe index (KeyframeIndex), read once the file is open the first time, or None: none to
        read, or one that can not be (filmreader.FilmReader.keyframe_times). Logged either way."""
        read = getattr(film, 'keyframe_times', None)
        try:
            index = KeyframeIndex.of(read()) if read is not None else None
        except libav.Unavailable:
            index = None
        if index is None:
            self._log('scenes ahead: no keyframe index, keyframes found by reading')
        else:
            self._log('scenes ahead: keyframe index: %d keyframes, %.1f s apart on average' % (len(index), index.apart))
        return index

    def _confirm(self, keyframe, asked=None):
        """Whether the keyframe index still holds after a keyframe read (a sweep's or a search's): one decoded at a time
        the index covers but does not hold, or a read asked for an index time (asked) that did not give that keyframe
        (none came out, the one read before, another), ends its use for the playback (False), every read after as
        without one."""
        index = self._index
        if index is None:
            return True
        at = keyframe.at if keyframe.frame is not None else None
        if asked is not None:
            if at is not None and index.lands(at, asked):
                return True
        elif at is None or not index.covers(at) or index.matches(at):
            return True
        self._index = None
        self._log('scenes ahead: the file\'s keyframe index does not match its keyframes (one at %s), not used'
                  % timecode(asked if at is None else at))
        return False

    def _indexed(self, at):
        """The keyframe index where it covers film time at, else None."""
        index = self._index
        return index if index is not None and index.covers(at) else None

    def _begin(self, now):
        """A new stretch from the playing position (at the start, after a seek), AHEAD_READS keyframes' cost ahead of it
        once that is measured: what it reads first is still ahead of playback when read. Nothing pending is worth
        reading any more."""
        if self._probe is None:
            why = ''
        elif now < self._start - WENT_BACK:
            why = ', playback went back'
        else:
            why = ', playback %d s past the read-ahead (a seek, or reading too slow)' % (now - self._probe)
        start = max(0.0, now)
        ahead = 0.0 if self._cost is None else min(AHEAD_READS * self._cost, AHEAD_MOST)
        self._log('scenes ahead: reading from %s%s%s' % (
            timecode(start + ahead), ', %d s ahead of playback' % round(ahead) if ahead >= 0.5 else '', why))
        self._building.hold()
        self._searches.clear()
        self._last, self._dark, self._weak, self._held_back = None, None, None, None
        self._start, self._probe = start, start + ahead

    def _back(self, now):
        """Playback went back inside what was read (a seek): the map holds on and the sweep reads on far ahead, so the
        coarse cuts still ahead of playback are searched again where in time (theirs came too late before, or never
        ran: the replay would rise as early as the first playback)."""
        again = [Job('cut', before, after, None, 0) for before, after in self._building.coarse_cuts()]
        again = [job for job in again if job.deadline > now]
        for job in again:
            self._searches.add(job)
        self._log('scenes ahead: playback went back to %s, %d coarse %s ahead to search again' % (
            timecode(now), len(again), 'cut' if len(again) == 1 else 'cuts'))

    # The sweep: keyframes only, in film order, each placed at once (one opening a coarse cut far after the last, well
    # ahead of playback, at the next step, after the keyframe just before it).

    def _sweep(self, film):
        """The sweep's next keyframe, at the probe: read, judged and placed (_place), or the keyframe just before one
        held back (_opens_far) and then that one; nothing where its look sees a stall (one begun while the file opened,
        a second or more on a share): the wait first."""
        before = self._film_time()
        if self._steady.played(before):
            return
        if self._held_back is not None:
            self._place_held_back(film, before)
            return
        probe, index = self._probe, self._indexed(self._probe)
        asked = probe if index is not None and index.holds(probe) else None
        keyframe = film.keyframe(index.read_at(probe) if asked is not None else probe, uneven=True, faint=False)
        if keyframe.frame is None:
            self._confirm(keyframe, asked)
            self._probe = self._next_probe(probe, None)
            return                              # the same keyframe as the one before, or none decoded there
        self._timed(before, self._now())
        self.keyframes += 1
        if keyframe.at is None:
            raise libav.Unavailable('the file gives its keyframes no times')
        self._confirm(keyframe, asked)
        self._probe = self._next_probe(probe, keyframe.at)
        self._trust.judge(keyframe)
        picture = self._judge.picture(keyframe, exact=True)
        weak, self._weak = self._weak, None
        if picture is None:
            candidate = self._judge.unbelieved(keyframe)
            if candidate is not None:
                if weak is None or not pictures.same(candidate, weak[1]):
                    self._unconfirmed(weak)
                    self._weak = (keyframe.at, candidate)   # told by the next keyframe
                    return
                # Two weakly lit keyframes in a row agree (the test rig's clip: its scope keyframes read weak, and every
                # cut into scope would be left to the screen if no weak reading of a new shape counted).
                self._judge.believe(candidate)
                self._place(weak[0], weak[1])
                picture, weak = candidate, None
        self._unconfirmed(weak)
        if picture is None:
            trusted_zero = self._judge.full_if_dark(keyframe) is not None
            zero = keyframe.level5_pair == (0, 0)
            if self._dark is None:
                self._dark = DarkRun(keyframe.at, trusted_zero, zero)   # the first of the run: the keyframe after tells
            else:
                self._dark.add(keyframe.at, trusted_zero, zero)
            return
        if self._opens_far(keyframe.at, picture, before):
            self._held_back = (keyframe.at, picture)    # placed once the keyframe before it is read, the next step
            return
        self._place(keyframe.at, picture)

    def _next_probe(self, probe, at):
        """The film time of the sweep's next keyframe after the read at probe that decoded the keyframe at film time at
        (None: none came out). With the keyframe index where it covers them, the next keyframe itself: the latest at or
        before SPARSE after this one, else the one after it (no read lands on a keyframe read already, which on a share
        cost 1.2 to 1.5 s each, the lead's largest waste). Else SPARSE after the probe, and past the index's end."""
        index = self._indexed(probe)
        if index is not None:
            found = index.next_read(at, SPARSE) if at is not None and index.matches(at) else index.after(probe)
            if found is not None and found > probe:
                return found
        return probe + SPARSE

    def _opens_far(self, at, picture, now):
        """Whether a keyframe at film time at showing picture would open a coarse cut across a keyframe not read, SEARCH_
        FLOOR or more ahead of playback (at film time now): the keyframe just before it is read first. With the keyframe
        index, where it lists one between the last keyframe placed and this one; without, where they lie more than
        SPARSE apart (the sweep reads the keyframe at or before each probe, and a cut's own keyframe just before a probe
        is read in place of the regular one before it: in the film simulator's dense cuts the text rose 2.48 s early,
        from the keyframe before that). Nearer, the step after could come once playback reached the cut, the map silent
        there: placed at once, early at worst."""
        last = self._last
        if not (last is not None and self._dark is None and float(picture) > float(last[1]) and now is not None
                and at - now >= SEARCH_FLOOR):
            return False
        inside = self._between(last[0], at)
        return bool(inside) if inside is not None else at - last[0] > SPARSE + 0.001

    def _between(self, before, after):
        """The index times of the keyframes between the ones decoded at film times before and after, where the keyframe
        index covers both; None where nothing is known."""
        index = self._indexed(before)
        return index.between(before, after) if index is not None and index.covers(after) else None

    def _place_held_back(self, film, before):
        """The keyframe just before the one held back (_opens_far) read and placed first, then that one: the coarse cut
        rises from the keyframe before it, one keyframe gap early at most. With the keyframe index that keyframe itself;
        without, the one at or before a moment earlier, where keyframes further apart than SPARSE give the one read
        before (refused): nothing between."""
        (at, picture), self._held_back = self._held_back, None
        inside = self._between(self._last[0], at)
        asked = inside[-1] if inside else None
        keyframe = film.keyframe(self._index.read_at(asked) if asked is not None else at - 0.001, uneven=True,
                                 faint=False)
        if asked is not None:
            self._confirm(keyframe, asked)
        if keyframe.frame is not None and keyframe.at is not None and self._last[0] < keyframe.at < at:
            self._timed(before, self._now())
            self.keyframes += 1
            self._trust.judge(keyframe)
            shown = self._judge.picture(keyframe, exact=True)
            if shown is not None:               # a dark or weak one tells nothing here: the cut rises as it would
                self._place(keyframe.at, shown)
        self._place(at, picture)

    def _unconfirmed(self, weak):
        """A weakly lit keyframe of a shape not believed (weak: its film time and shape, or None) that the keyframe
        after it did not confirm: it showed nothing believed, so it is a dark one, and the stretch goes on across it
        only where _across says so (dropped, a dim scope shot reading 2.45 between two 1.90 keyframes would be mapped
        1.90, the text in its bar in the film simulator). Inside a run already begun it is one of the run's
        keyframes, not dark with trusted Level 5 0/0: a walk across the run would meet it decoded already, named as
        none, and never judge it."""
        if weak is None:
            return
        if self._dark is None:
            self._dark = DarkRun(weak[0], False, False)
        else:
            self._dark.add(weak[0], False, False)

    def _place(self, at, picture):
        """A keyframe the sweep read showing picture at film time at, after the last one: on the map at once, from the
        keyframes alone, the reads it needs pending. The stretch grows, across a dark run where _across says so (its
        frames searched for shots of a narrower picture known: _inside) or not (the keyframes between searched where
        another picture is known: _shots); into another picture past a coarse cut or a silent span (_change); across a
        dark run into another picture past a silent span, its frames to search; or the stretch ends at the last
        keyframe and a new one begins at this one."""
        dark, last, self._dark, self._last = self._dark, self._last, None, (at, picture)
        if last is None:
            self._full_if(self._building.begin(at, picture))
        elif dark is not None and not self._across(dark, last, at, picture):
            self._log('scenes ahead: dark from %s to %s, left to the screen (%s)' % (
                timecode(dark.first), timecode(at), self._why_left(dark, last, at, picture)))
            self._full_if(self._building.begin(at, picture))
        elif pictures.same(picture, last[1]):
            self._building.shapes.fill(picture)     # its rows, where a keyframe gave them
            self._building.grow(at)
            if dark is not None:
                # Logged: a shot the map claims for the picture on both sides would show in the log only as grabs of
                # another picture nothing placed.
                self._log('scenes ahead: dark from %s to %s, carried across as picture %.2f' % (
                    timecode(dark.first), timecode(at), float(picture)))
                if self._judge.narrower_known(picture):
                    self._searches.add(Job('inside', last, (at, picture), dark, 0))
            elif (self._judge.wider_known(picture) or self._judge.narrower_known(picture)) and \
                    self._between(last[0], at) != []:
                # Not where the keyframe index has nothing between (a seek back for nothing, 1.2 to 1.9 s on a share).
                self._searches.add(Job('shots', last, (at, picture), None, 0))
        elif dark is None:
            self._change(last, (at, picture))
            self._building.grow(at)
        else:
            self._full_if(self._building.silence(last[0], at, picture))
            self._searches.add(Job('cut', last, (at, picture), dark, 0))
        self.map = self._building.copy()

    def _change(self, before, after):
        """Two keyframes in a row of different pictures with nothing dark between ((film time, picture) each): into a
        wider picture a coarse cut a frame after the first (the text rises up to their gap early, inside the old
        picture, never late into the bar), into a narrower one a silent span between them (the grabs move the text down
        there, never early into the bar); the frames between them a pending search."""
        (start, old), (end, new) = before, after
        if float(new) > float(old):
            self._full_if(self._building.coarse(start, end, new))
            told = 'from the first'
        else:
            self._full_if(self._building.silence(start, end, new))
            told = 'the screen\'s'
        self._log('scenes ahead: picture %.2f between %s and %s, %s till its frames tell' % (
            float(new), timecode(start), timecode(end), told))
        self._searches.add(Job('cut', before, after, None, 0))

    def _across(self, dark, last, at, picture):
        """Whether the stretch goes on across the DarkRun dark from the keyframe last ((film time, picture)) to the one
        at film time at showing picture. The same picture on both sides carries across where a wrong call can only leave
        the text a little high: no wider picture is known (a dark scene of a wider one would put the text in its bar),
        whatever Level 5 said (a Dolby Vision file without Level 5 says 0/0 on every frame: a dark scope scene between
        two IMAX keyframes would be carried as full). Different pictures: the cut is searched across the run's frames
        (_cut: into a narrower picture never early) up to DARK_SEARCH apart, and always into a full picture after a run
        dark with trusted Level 5 0/0 (Level 5 tells it from a fade)."""
        if pictures.same(picture, last[1]):
            return not self._judge.wider_known(picture)
        return (dark.trusted_zero and self._judge.full(picture)) or at - last[0] <= DARK_SEARCH

    def _why_left(self, dark, last, at, picture):
        """Why a run of dark keyframes before at was not carried across nor searched, for the log."""
        zero = 'Level 5 0/0 on every dark keyframe' if dark.zero else 'Level 5 not 0/0 on every dark keyframe'
        if pictures.same(picture, last[1]):
            why = 'the same picture on both sides, a wider one known'
        else:
            why = '%.1f s from the keyframe before, more than %d s' % (at - last[0], DARK_SEARCH)
        return '%s; %s, %s' % (why, zero, self._trust.note())

    _full_if = staticmethod(full_if)

    # The pending searches, each telling what the sweep's keyframes could not (Searching).

    def _search(self, film, job, current):
        """A pending search run (Searching.run), its reads stopped as soon as the playback ends, Kodi holds or playback
        is troubled, the lead falls to STOP_FLOOR or playback comes within LATE of its span (_limits); the map taken
        anew where it told something."""
        if self._searching.run(film, job, self._limits(current, job.deadline)):
            self.map = self._building.copy()

    def _limits(self, current, latest):
        """go() for a search's reads: whether it may read on. go.why says why it stopped: 'ended' (the playback ended),
        'off' (following is off), 'held' (Kodi holds, its buffer is low or its time stalled: Steady.going), 'late' (the
        lead fell to STOP_FLOOR, or playback passed latest)."""
        def go():
            now = self._now()
            if not current():
                go.why = 'ended'
            elif not self._wanted():
                go.why = 'off'
            elif not self._steady.going():
                go.why = 'held'
            elif now is not None and (now > latest or self._probe - now < STOP_FLOOR):
                go.why = 'late'
            else:
                return True
            return False
        go.why = None
        return go
