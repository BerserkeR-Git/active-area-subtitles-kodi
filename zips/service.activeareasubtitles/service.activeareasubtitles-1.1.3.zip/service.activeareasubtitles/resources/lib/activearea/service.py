"""The background service: find the picture's shape once per playback, then step aside.

Per playback: check that there is anything to do, work out the picture's shape (a file in a
shape of its own gets that shape at once and is measured all the same), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command. Once the shape is known nothing moves again,
except that screen capture keeps looking, slowly, for a wider picture (IMAX scenes), and that
on P3i builds another subtitle track of the other kind (text or image) is placed again.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there), elsewhere from tiny screen captures with the video file as a fallback where the
system has FFmpeg. Everything runs on its own thread; any failure leaves Kodi's normal
subtitle position.
"""
import contextlib
import functools
import json
import os
import re
import threading
import time
import types

import xbmc
import xbmcvfs

from . import coreelec, diagnostics, geometry, kodi, locate, measure, override, question, status, subtitles, updates
from .guard import DecodeGuard
from .keeper import Keeper, Switch, write_record

MARGIN_SETTING = 'subtitles.marginvertical'
SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 has a shape of its own (cropped, or 4:3 and the like)
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
HDR_TYPE = 'Player.Process(video.source.hdr.type)'
OLD_MEMO_FILE = 'shapes.json'  # shapes remembered by 0.3.32 to 1.0.4: removed at start, every playback is measured
FILE_ANALYSIS = 'video file analysis'
LEVEL5_EARLIEST = 3.0          # seconds after the start before a Level 5 correction is written
UPDATE_PACKAGES = 'special://home/addons/packages/'   # where Kodi downloads an update before installing it
P3I_SETTINGS_SEEN = 'p3i_settings.json'   # the unfamiliar CoreELEC settings last shown
RESTRICT_NOTICE = 'restrict_notice.json'   # CoreELEC's restriction now only for image subtitles: told once
LEVEL5_NOTICE = 'level5_notice.json'       # the Level 5 correction can not work with CoreELEC's handling off: told once
UPDATE_RECENT_S = 600.0        # a package this new belongs to the update now under way
# Kodi says nothing when the subtitle track changes or subtitles are added during playback (no
# callback, no notification; rig, Kodi 21, 2026-10-12), so the service looks, as cheaply as it can:
# each step only Kodi's time since the last button press (a counter), the track itself only after a
# press, early in a playback (a player add-on adds subtitles then, without a press), and once in a
# while (a phone remote switches over JSON-RPC, which is not a press). Asking for the current track
# costs about 0.1 ms; normal watching asks nothing at all.
WATCH_STEP = 1.0               # seconds between looks at the time since the last button press
RECENT_INPUT = 3               # seconds after a press during which the track is looked at every step
WATCH_EARLY = 30.0             # seconds after the start during which it is looked at regardless
WATCH_EARLY_STEP = 2.0         # how often then
WATCH_SLOW = 30.0              # how often otherwise


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = _Monitor(self._settings_changed)
        self.enabled = kodi.setting_bool('enabled')
        self.distances = distances()
        # Each change keeps a record until Kodi's memory and its settings file are free of it.
        self.override = override.Override(lambda: kodi.get_setting(override.SETTING),
                                          lambda value: kodi.set_setting(override.SETTING, value),
                                          kodi.data_path('level5.json'),
                                          lambda: kodi.saved_setting(override.SETTING))
        self.keeper = Keeper(lambda: _number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'),
                             lambda: _number(kodi.saved_setting(MARGIN_SETTING)))
        # CoreELEC's "Apply configured subtitle margin", switched on for a distance (off by default).
        self.margin_switch = Switch(lambda: kodi.get_setting(coreelec.MARGIN_SETTING),
                                    lambda value: kodi.set_setting(coreelec.MARGIN_SETTING, value),
                                    kodi.data_path('margin_switch.json'),
                                    lambda: _switch(kodi.saved_setting(coreelec.MARGIN_SETTING)),
                                    kodi.saved_settings_stamp)
        # P3i's own scan for SDR and HDR, held off by 0.3.31 to 1.0.6 while P3i placed text subtitles too:
        # only put back now (P3i needs it to keep image subtitles out of the bars in SDR and HDR).
        self.scan_switch = Switch(lambda: kodi.get_setting(coreelec.SDR_SCAN_SETTING, quiet=True),
                                  lambda value: kodi.set_setting(coreelec.SDR_SCAN_SETTING, value),
                                  kodi.data_path('scan_switch.json'),
                                  lambda: _switch(kodi.saved_setting(coreelec.SDR_SCAN_SETTING)),
                                  kodi.saved_settings_stamp, value=False)
        # P3i's "Restrict subtitles to active picture", held off while the add-on is enabled, so the add-on
        # places every text subtitle itself; the person's own value while an image subtitle is shown.
        self.restrict_switch = Switch(lambda: kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True),
                                      lambda value: kodi.set_setting(coreelec.RESTRICT_SETTING, value),
                                      kodi.data_path('restrict_switch.json'),
                                      lambda: _switch(kodi.saved_setting(coreelec.RESTRICT_SETTING)),
                                      kodi.saved_settings_stamp, value=False)
        self.subtitle_kind = None            # IMAGE or TEXT for the current playback's subtitle
        self.playback = 0                    # counts playbacks; placing again after a track change is the same one
        self.watch = None                    # what the subtitle watch knows of the current playback
        self.measured = None                 # (playback, picture ratio, how) once its shape settled
        self.level5_checked = None           # the playback whose Level 5 was checked
        self.streams_of = (None, None)       # (identity, the file's subtitle streams), until the playback ends
        self.lock = threading.Lock()
        self.generation = 0
        self.manual_notice_shown = False
        self.on_coreelec = coreelec.is_coreelec()
        self.version = kodi.addon().getAddonInfo('version')
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), self.version)
        self.waiting_for_subtitles = None   # playback that had no subtitles yet; measured once some appear
        self.started = time.time()           # when the current playback started
        self.carried_over = None             # a playback this service found running when it started
        # Notices about settings, shown in the add-on's own window with OK, one at a time and only while no
        # video plays (a window over a film would interrupt it): (string id, done() -> False to drop it).
        self.notices = []
        self.telling = False

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        self.started = time.time()
        generation = self._next_generation()
        self.playback += 1
        self.subtitle_kind = None
        self.watch = types.SimpleNamespace(started=self.started, looked=self.started, track=None, failed=False)
        if self._playing_video():
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onAVChange(self):
        # Streams changed (Kodi says so at the start, not when subtitles are added later): see _watch_step.
        self._subtitles_arrived()

    def _subtitles_arrived(self):
        """Subtitles switched on later in a playback that had none at the start: measured now."""
        generation = self.waiting_for_subtitles
        if generation is not None and _holds('VideoPlayer.HasSubtitles') and self._claim_waiting(generation):
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def _watch_step(self, now=None):
        """One look during playback (see WATCH_STEP): subtitles that arrived late, and on P3i builds a
        subtitle track of the other kind."""
        watch = self.watch
        if watch is None:
            return
        now = time.time() if now is None else now
        since = now - watch.looked
        if not (_pressed_lately() or since >= WATCH_SLOW
                or (now - watch.started < WATCH_EARLY and since >= WATCH_EARLY_STEP)):
            return
        watch.looked = now
        self._subtitles_arrived()
        if self.subtitle_kind is None or not self.on_coreelec:
            return                      # nothing placed by kind yet, or nothing placed by kind at all
        track = self._subtitle_track()
        if track is not None and track != watch.track:
            watch.track = track
            # Judged here, one look after another, so the newest switch always wins (someone switching
            # back and forth); only the placing runs on its own thread.
            self._subtitle_changed(self.generation)

    def onPlayBackStopped(self):
        self._finish('playback stopped')
        self._hold_p3i_restriction()

    def onPlayBackEnded(self):
        self._finish('playback ended')
        self._hold_p3i_restriction()

    def onPlayBackError(self):
        self._finish('playback error')
        self._hold_p3i_restriction()

    def run(self):
        self.start()
        while not self.monitor.waitForAbort(WATCH_STEP):
            try:
                self._tell_waiting()
                self._watch_step()
            except Exception as error:  # Kodi could not say: looked at again next step, logged once per playback
                watch = self.watch
                if watch is not None and not watch.failed:
                    watch.failed = True
                    kodi.log('subtitle watch: %r' % error, always=True)
        try:
            self.stopping()
        finally:
            self.guard.wait_until_idle()

    def start(self):
        """The service's start. Started during playback: Kodi updated the add-on (it does so by
        itself), it was switched on, or the service started again after a failure. What is in
        place belongs to that playback, so it is carried on: no repair, no "next video" clearing,
        measured again (the same answer changes nothing on screen)."""
        playing = self._playing_video()
        steps = (self._move_old_settings, self._remove_old_memo, self._release_old_scan_hold, self._check_last_run,
                 self._show_status, self._check_level5_handling) if playing \
            else (self._move_old_settings, self._remove_old_memo, self._release_old_scan_hold, self._repair,
                  self._check_last_run, self._show_status, self._hold_p3i_restriction, self._check_level5_handling)
        # Each step at the start on its own: one failing must not keep the others from running.
        for step in steps:
            try:
                step()
            except Exception as error:
                kodi.log('start: %s not done: %r' % (step.__name__.strip('_').replace('_', ' '), error), always=True)
        self.distances = distances()     # after the move: that change is no reason to place again
        if playing:
            self.carried_over = self.generation + 1
            self.onAVStarted()

    def stopping(self):
        """The service is asked to stop. Kodi closing (it has saved its settings by now) or an
        update (the next service carries on): everything stays as it is, on record, for the next
        start. Switched off or removed in Kodi's add-ons: nobody else would put things back.

        Seen in a real Kodi 21: during an update the add-on is already unknown to Kodi when its
        service stops, as after removing it; what tells them apart is the new version's package,
        which Kodi has just downloaded. When unsure, everything is put back."""
        details = kodi.rpc('Addons.GetAddonDetails', {'addonid': kodi.ADDON_ID, 'properties': ['enabled']},
                           quiet=True)
        addon = details.get('addon') if isinstance(details, dict) else None
        if isinstance(addon, dict) and addon.get('enabled') is True:
            why = 'Kodi closing'
        elif addon is None and self._update_arriving():
            why = 'the add-on updating'
        else:
            self._finish('add-on switched off or removed', always=True)
            self._release_p3i_restriction('add-on switched off or removed', always=True)
            self._release_p3i_scan('add-on switched off or removed', always=True)
            return
        with self.lock:
            self.generation += 1              # a measurement still running changes nothing more
        kodi.log('stopping (%s): changes stay on record for the next start' % why, always=True)

    def _update_arriving(self):
        """True when Kodi has just downloaded a newer version of this add-on to install."""
        try:
            folder = xbmcvfs.translatePath(UPDATE_PACKAGES)
            mine = updates.parts(self.version)
            for name in os.listdir(folder):
                found = re.match(r'%s-([0-9][0-9.]*)\.zip$' % re.escape(kodi.ADDON_ID), name)
                if found and mine and (updates.parts(found.group(1).rstrip('.')) or ()) > mine and \
                        time.time() - os.path.getmtime(os.path.join(folder, name)) < UPDATE_RECENT_S:
                    return True
        except Exception:  # unknown: not an update
            pass
        return False

    def _repair(self):
        """What an unfinished playback left (Kodi crashed or was cut off) is put back."""
        with self.lock:
            if self.margin_switch.restore():
                kodi.log('CoreELEC\'s subtitle margin option switched off after an unfinished playback', always=True)
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
            if self.override.restore():
                kodi.log('Level 5 correction cleared after an unfinished playback', always=True)

    def _p3i_restricts_offered(self):
        """True on a CoreELEC build that offers P3i's subtitle restriction (it is readable only there)."""
        return self.on_coreelec and kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is not None

    def _hold_p3i_restriction(self):
        """P3i's restriction off while the add-on is on: the add-on places text subtitles itself, image
        subtitles get the person's own value back while they are shown. Nothing is written elsewhere."""
        if not (self.on_coreelec and kodi.setting_bool('enabled')):
            return
        if kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is True:
            with self.lock:
                switched = self.restrict_switch.on()
            if switched:
                kodi.log('CoreELEC\'s subtitle restriction switched off: the add-on places text subtitles itself',
                         always=True)
                self._restrict_notice()

    def _restrict_notice(self):
        """Said once, so a person who finds that CoreELEC setting off again knows why (and does
        not take it for a fault in CoreELEC)."""
        path = kodi.data_path(RESTRICT_NOTICE)
        if not os.path.exists(path):
            self._notify(32132, lambda: _recorded(path, True))

    def _check_level5_handling(self):
        """"Correct faulty Dolby Vision Level 5" on while CoreELEC's Level 5 handling is off: CoreELEC then takes
        no correction. Told once (again if it happens again after being resolved). The handling is never switched
        on here: it decides how every Dolby Vision video is sent to the TV, so it stays the person's choice."""
        path = kodi.data_path(LEVEL5_NOTICE)
        if not (self.on_coreelec and kodi.setting_bool('fix_level5', default=False)
                and kodi.get_setting(coreelec.LEVEL5_HANDLING, quiet=True) is False):
            if os.path.exists(path):
                os.remove(path)
            return
        kodi.log('"Correct faulty Dolby Vision Level 5" is on, but CoreELEC\'s Level 5 handling is off: '
                 'nothing can be corrected', always=True)
        if not os.path.exists(path):
            self._notify(32133, lambda: _recorded(path, True))

    def _notify(self, string_id, done=None):
        """A notice for the next moment without video (see _tell_waiting); the same one only once in the queue."""
        if all(waiting != string_id for waiting, _done in self.notices):
            self.notices.append((string_id, done))

    def _tell_waiting(self):
        """The first waiting notice, in the add-on's own window with OK, while no video plays and no other
        notice is open. done() records it as shown, before the window opens: False drops it (a notice that
        can not be recorded would come back at every start)."""
        if self.telling or not self.notices or self._playing_video():
            return
        string_id, done = self.notices.pop(0)
        if done is not None and not done():
            return
        self.telling = True

        def tell():
            try:
                question.tell(kodi.text(string_id))
            except Exception as error:  # a notice must never stop the service
                kodi.log('notice %d not shown: %r' % (string_id, error), always=True)
            finally:
                self.telling = False

        threading.Thread(target=tell, daemon=True).start()

    def _release_p3i_restriction(self, why, always=False, generation=None):
        """generation: only while that playback is the current one (a stop meanwhile holds it again)."""
        with self.lock:
            if generation is not None and not self._current(generation):
                return
            if self.restrict_switch.restore():
                kodi.log('%s: CoreELEC\'s subtitle restriction back as it was' % why, always)

    def _release_old_scan_hold(self):
        self._release_p3i_scan('no longer needed')

    def _release_p3i_scan(self, why, always=False):
        with self.lock:
            if self.scan_switch.restore():
                kodi.log('%s: CoreELEC\'s own picture detection for SDR and HDR switched on again' % why, always)

    def _check_last_run(self):
        interrupted = self.guard.check_last_run()
        if interrupted == 'skipped':
            kodi.log('Kodi stopped during a decode last time; that video is left to Kodi from now on', always=True)
        elif interrupted == 'paused':
            kodi.log('Kodi stopped during a decode twice in a row; video file analysis pauses for a day', always=True)

    def _remove_old_memo(self):
        """0.3.32 to 1.0.4 kept measured shapes in a file across restarts; every playback is measured now
        (it takes a second or two), so a box test always shows what the add-on measures."""
        path = kodi.data_path(OLD_MEMO_FILE)
        if os.path.exists(path):
            os.remove(path)

    def _move_old_settings(self):
        """Up to 0.3.23 "Small gap from the black bar" was a switch (edge_gap, now hidden): on
        becomes Small gap for content with black bars, once."""
        if kodi.setting_bool('edge_gap', default=False):
            kodi.addon().setSettingInt('gap_bars', 1)
            kodi.addon().setSettingBool('edge_gap', False)
            kodi.log('"Small gap from the black bar" moved to "Distance in content with black bars"', always=True)

    def _settings_changed(self):
        """Switched off: the own margin goes back at once. Switched on during a video: measure it.
        A distance changed during a video: placed again with it. Level 5 correction off: a
        correction in place is cleared. Other changes (the status fields the service writes
        itself, among them) do nothing."""
        changed, self.distances = self.distances != distances(), distances()
        if not any(self.distances):
            with self.lock:     # CoreELEC goes back to the picture's edge at once
                if self.margin_switch.restore():
                    kodi.log('distances set to none: CoreELEC\'s subtitle margin option switched off')
        if not kodi.setting_bool('fix_level5', default=False):
            with self.lock:     # does nothing unless a correction is in place
                if self.override.restore():
                    kodi.log('Level 5 correction turned off: cleared')
        self._check_level5_handling()
        enabled = kodi.setting_bool('enabled')
        if enabled == self.enabled:
            if changed and enabled and self._playing_video():
                kodi.log('distances changed to %.2f and %.2f: placed again' % self.distances)
                self._place_again()
            return
        self.enabled = enabled
        if not enabled:
            self._finish('turned off in settings')
            self._release_p3i_restriction('turned off in settings')
            self._release_p3i_scan('turned off in settings')
            return
        self._hold_p3i_restriction()
        if self._playing_video():
            self.onAVStarted()

    def _playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return False

    def _show_status(self):
        # Quiet: P3i's own setting is only readable while P3i shows it, and its absence says enough.
        p3i = self.on_coreelec and coreelec.is_p3i(lambda setting: kodi.get_setting(setting, quiet=True),
                                                   xbmc.getInfoLabel('System.BuildVersion'))
        system, method = status.describe(self.on_coreelec, p3i, not self.guard.paused(), xbmc.getCondVisibility)
        for setting_id, string_id in (('status_system', system), ('status_method', method)):
            try:
                shown, wanted = kodi.addon().getSetting(setting_id), kodi.text(string_id)
                if shown != wanted:     # Kodi writes its settings file on every change
                    kodi.addon().setSetting(setting_id, wanted)
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        kodi.log('started: %s, %s' % (kodi.text(system), kodi.text(method).lower()))
        if p3i:
            self._check_p3i_settings()

    def _check_p3i_settings(self):
        """P3i's builds change often: a subtitle or Level 5 setting this add-on does not know, or one
        it relies on that is gone, is logged at every start and shown once per new set, so a rename
        or a removal is not silent."""
        found = kodi.rpc('Settings.GetSettings', {'level': 'expert'}, quiet=True)
        if not isinstance(found, dict):
            return
        ids = [item.get('id', '') for item in found.get('settings', []) if isinstance(item, dict)]
        new = coreelec.unfamiliar_settings(ids)
        missing = coreelec.missing_settings(ids, lambda setting: kodi.get_setting(setting, quiet=True))
        if new:
            kodi.log('CoreELEC offers subtitle settings this add-on does not know: %s' % ', '.join(new), always=True)
        if missing:
            kodi.log('CoreELEC no longer offers settings this add-on relies on: %s' % ', '.join(missing), always=True)
        changes = new + ['missing: %s' % setting_id for setting_id in missing]
        if not changes:
            return
        path = kodi.data_path(P3I_SETTINGS_SEEN)
        try:
            with open(path, encoding='utf-8') as handle:
                if json.load(handle) == changes:
                    return
        except (OSError, ValueError):
            pass
        self._notify(32131, lambda: _recorded(path, changes))

    # Bookkeeping.

    def _next_generation(self):
        with self.lock:
            self.generation += 1
            return self.generation

    def _claim_waiting(self, generation):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.lock:
            if self.waiting_for_subtitles == generation == self.generation:
                self.waiting_for_subtitles = None
                return True
            return False

    def _current(self, generation):
        return generation == self.generation and not self.monitor.abortRequested()

    def _finish(self, why, always=False):
        """always: log without asking for the detailed log setting (Kodi logs an error for that
        while the add-on is being switched off, even though the answer is not needed)."""
        self.streams_of = (None, None)       # read afresh for the next playback
        self.watch = self.subtitle_kind = None
        with self.lock:
            self.generation += 1
            if self.margin_switch.restore():      # before the margin, so nothing moves in between
                kodi.log('%s: CoreELEC\'s subtitle margin option switched off' % why, always)
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why, always)
            if self.override.restore():
                kodi.log('%s: Level 5 correction cleared' % why, always)

    def _restore_if_current(self, generation, why):
        with self.lock:
            if generation == self.carried_over:
                # Carried over from the previous service: what it put in place for this film
                # stays (on record, put back at stop) rather than moving now for want of an answer.
                if self._current(generation):
                    kodi.log('%s: what the previous service set for this video stays' % why)
                return
            if self._current(generation) and self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    # The work for one playback, on its own thread.

    def _fit(self, generation, again=False):
        """again: the same playback placed again for another subtitle track."""
        try:
            with self.lock:       # a playlist's next video: the previous one's changes go
                carried_over = generation == self.carried_over
                if self._current(generation) and not (carried_over or again) and self.override.restore():
                    kodi.log('next video: Level 5 correction cleared')
                # CoreELEC's margin option is never switched on since 1.1.3; one an older version left on (it
                # handed CoreELEC a distance) goes off here, at every new video, and at stop and start.
                if self._current(generation) and not (carried_over or again) and self.margin_switch.restore():
                    kodi.log('next video: CoreELEC\'s subtitle margin option switched off')
            # A playback carried over from the previous service keeps CoreELEC's restriction as it was:
            # nothing moves during an update; the next video gets the add-on's own placement.
            if not carried_over and self._p3i_restricts_offered() and not self._text_subtitle(generation, again):
                return                    # an image subtitle: CoreELEC's own restriction places it
            self._fit_once(generation, again)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self._restore_if_current(generation, 'unexpected error')
            except Exception:
                pass

    def _text_subtitle(self, generation, again=False):
        """P3i builds: True when the current subtitle is text (or not known to be an image), with P3i's
        restriction held off so the add-on places it; False for an image subtitle, which only P3i's
        restriction can move: the person's own value goes back and the add-on steps aside."""
        watch = self.watch
        track = self._subtitle_track() if watch is not None else None    # before the kind: a switch in between is seen
        kind, why = self._subtitle_kind()
        if not self._current(generation):
            return False
        self.subtitle_kind = kind or subtitles.TEXT
        if watch is not None and track is not None:
            watch.track = track             # the watch's first look then has nothing new to judge
        if kind == subtitles.IMAGE:
            kodi.log('image subtitle (%s): CoreELEC places it' % why)
            self._release_p3i_restriction('image subtitle', generation=generation)
            self._restore_if_current(generation, 'image subtitle')
            if xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision' and not (again and self.level5_checked == self.playback):
                self._correct_late_level5(generation)  # the picture signal to the TV still gets right Level 5
            return False
        kodi.log('%s subtitle (%s): the add-on places it' % ('text' if kind else 'unknown kind of', why))
        self._hold_p3i_restriction()
        return True

    def _subtitle_changed(self, generation):
        """Another subtitle track during playback: placed again (on a thread of its own) when it is now
        of the other kind, with the shape measured for this playback and its Level 5 as it is."""
        try:
            if self.subtitle_kind is None or not self._p3i_restricts_offered():
                return
            kind = self._subtitle_kind()[0] or subtitles.TEXT
            if not (self._current(generation) and self.subtitle_kind is not None and kind != self.subtitle_kind):
                return
        except Exception as error:  # never let a surprise disturb playback; looked at again on the next change
            kodi.log('subtitle track not looked at: %r' % error, always=True)
            return
        kodi.log('subtitle track changed to %s: placed again' % ('an image' if kind == subtitles.IMAGE else 'text'))
        self.subtitle_kind = kind           # the next look compares with this, even before the placing starts
        self._place_again()

    def _place_again(self):
        """The same playback placed again (another subtitle track, another distance): with the shape it
        settled on and its Level 5 as it is, on a thread of its own."""
        threading.Thread(target=self._fit, args=(self._next_generation(), True), daemon=True).start()

    def _subtitle_track(self):
        """(index, shown) of Kodi's current subtitle track, None when Kodi does not say; only that
        track asked for, never the list (a remux can carry dozens)."""
        players = kodi.rpc('Player.GetActivePlayers', quiet=True)
        player = next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                       and entry.get('type') == 'video'), None)
        if player is None:
            return None
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None
        return (found.get('currentsubtitle') or {}).get('index'), bool(found.get('subtitleenabled'))

    def _subtitle_kind(self):
        """(subtitles.IMAGE, TEXT or None, why) for the current subtitle, from Kodi's list and the file's own
        subtitle streams (read once per playback)."""
        players = kodi.rpc('Player.GetActivePlayers', quiet=True)
        player = next((entry.get('playerid') for entry in players or [] if isinstance(entry, dict)
                       and entry.get('type') == 'video'), None)
        if player is None:
            return None, 'no video player'
        found = kodi.rpc('Player.GetProperties', {'playerid': player, 'properties':
                         ['subtitles', 'currentsubtitle', 'subtitleenabled']}, quiet=True)
        if not isinstance(found, dict):
            return None, 'Kodi did not say'
        if not found.get('subtitleenabled'):
            return subtitles.TEXT, 'subtitles off'
        listed = [entry for entry in found.get('subtitles') or [] if isinstance(entry, dict)]
        current = (found.get('currentsubtitle') or {}).get('index')
        target, _unreadable = self._target()
        return subtitles.current_kind(listed, current, self._file_streams(target), self._sidecars())

    def _file_streams(self, target):
        """The playing file's own subtitle streams, or None when they can not be read (read once per playback)."""
        if target is None:
            return None
        if self.streams_of[0] == target.identity:
            return self.streams_of[1]
        streams = None
        if self.guard.allowed(target.identity):
            try:
                # Not lowered in priority: a header read, and it can run on the service's own thread (the watch).
                decoder = measure.ffmpeg.Decoder(target, kodi.data_path('ffmpeg.json'), background=False)
                # The stream structures are read through ctypes as well: guarded like a decode, so a layout this
                # add-on misjudges leaves the file to Kodi after one crash instead of crashing it at every play.
                with self.guard.decoding(target.identity):
                    try:
                        decoder.__enter__()
                        streams = decoder.subtitle_streams()
                    finally:
                        decoder.close()
            except Exception as error:  # unreadable here: the kind stays unknown
                kodi.log('subtitle streams not read: %s' % error)
        self.streams_of = (target.identity, streams)
        return streams

    def _sidecars(self):
        """subtitles.IMAGE or TEXT for the subtitle files next to the playing video, None when mixed or unknown."""
        try:
            playing = self.getPlayingFile().partition('|')[0]
            if '://' in playing and playing.split('://')[0] not in ('smb', 'nfs', 'file'):
                return None             # a web address (a Plex server): no folder to look in
            folder, name = playing.replace('\\', '/').rsplit('/', 1)
            return subtitles.sidecar_kind(xbmcvfs.listdir(folder + '/')[1], name)
        except Exception:  # not playing any more, or the folder can not be listed
            return None

    def _fit_once(self, generation, again=False):
        if not self.on_coreelec and self.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self._current(generation):
            return
        layout = self._layout(generation)
        if layout is None:
            return
        area, screen_w, screen_h, video_ratio = layout
        started = time.time()
        measured = self.measured
        if again and measured is not None and measured[0] == self.playback:
            # Placed again for another subtitle track: the shape this playback settled on, not decoded again.
            self._apply(generation, layout, measured[1], '%s, measured earlier in this playback' % measured[2],
                        started, level5=self.level5_checked != self.playback)
            return
        # A file in a shape of its own is usually cropped to its picture: that shape at once. It is
        # measured all the same, since a 4:3 or 1.85 file can hold a wider picture with black bars
        # of its own (letterboxed DVDs, older TV); without a clear answer its own shape stays.
        own_shape = abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE
        if own_shape:
            self._apply(generation, layout, video_ratio, 'the file\'s own shape, measuring', started, final=False)

        def give_up(why):
            if own_shape:
                self._apply(generation, layout, video_ratio, 'the file\'s own shape (%s)' % why, started)
            else:
                self._restore_if_current(generation, why)

        current = lambda: self._current(generation)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self._target()
        keyframes = []      # what the file analysis decoded, for a Level 5 check without decoding again
        for name, attempt in self._ways(video_ratio, current, record, target, unreadable, full_pictures, keyframes):
            try:
                settled = False
                # Closed explicitly, so a decoder is freed the moment the answer is in. A way may settle
                # more than once (screen capture widening for IMAX scenes): each settled shape counts.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        if own_shape and ratio <= video_ratio * (1 + CROPPED_TOLERANCE):
                            ratio = video_ratio     # no bars in the file: its own shape, not moved again
                        self._apply(generation, layout, ratio, how, started, final, keyframes)
                        if final:
                            settled = True
                            self.measured = (self.playback, ratio, how)
                if settled:
                    return
                kodi.log('%s gave no clear answer' % name)
                give_up('no clear answer')
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
                if settled:               # what was settled stands
                    return
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self._coreelec_places(generation)
                self._correct_late_level5(generation)
                return
        kodi.log('no way of measuring worked for this playback')
        # The previous item of a playlist may have changed the margin: this one gets the person's own,
        # or the margin for the file's own shape.
        give_up('not measured')

    def _layout(self, generation):
        """(area, screen width, screen height, video ratio), or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self._finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, generation):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self._restore_if_current(generation, 'no subtitles')
            self.waiting_for_subtitles = generation
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self._claim_waiting(generation)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self._restore_if_current(generation, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self._restore_if_current(generation, 'position not handled')
            self._manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self._restore_if_current(generation, 'view mode not normal')
            return None
        if self.on_coreelec and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.monitor.waitForAbort,
                lambda: self._current(generation), kodi.log):
            self._coreelec_places(generation)
            if self._current(generation) and kodi.setting_bool('fix_level5', default=False):
                self._correct_level5(generation)
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, generation)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self._restore_if_current(generation, 'size unknown')
            return None
        return area, screen_w, screen_h, video_ratio

    def _correct_late_level5(self, generation):
        """Level 5 that starts at zero and has values later: CoreELEC follows it as it plays, so a
        wrong or flickering one is corrected the same way as one reported at the start."""
        if self._current(generation) and kodi.setting_bool('fix_level5', default=False):
            self._correct_level5(generation)

    def _correct_level5(self, generation, keyframes=None):
        """CoreELEC places these subtitles from the film's Level 5: give it the right edges when
        that Level 5 is clearly wrong (Correct faulty Dolby Vision Level 5, off by default). True
        when CoreELEC now has the picture's edges from an override: this one, or override.ini's.
        keyframes: what measuring decoded, judged instead of decoding again."""
        applied = self._check_level5(generation, keyframes)
        if self._current(generation):
            self.level5_checked = self.playback   # not decoded again when a track change places again
        return applied

    def _check_level5(self, generation, keyframes):
        target, unreadable = self._target()
        if target is None:
            kodi.log('Level 5 not checked: %s' % unreadable)
            return
        if override.set_by_override_ini(target.address, _read_text):
            kodi.log('Level 5 left alone: override.ini supplies it for this folder')
            return True
        if xbmc.getInfoLabel(coreelec.SCAN_STATE) == '3':
            # CoreELEC only scans films without Level 5 of their own: nothing to correct.
            kodi.log('Level 5 left alone: CoreELEC measured this film itself')
            return
        if not self.guard.allowed(target.identity):
            kodi.log('Level 5 not checked: left to Kodi after an interrupted decode')
            return
        try:
            correction, reason = measure.level5_correction(
                target, self.getTotalTime(), kodi.data_path('ffmpeg.json'),
                lambda: self._current(generation), functools.partial(self.guard.decoding, target.identity),
                keyframes=keyframes)
        except Exception as error:  # Unavailable, or Kodi could not say: never a reason to stop
            kodi.log('Level 5 not checked: %s' % error)
            return
        if not self._current(generation):
            return
        kodi.log('Level 5 check: %s' % reason)
        known = override.value_for(*correction) if correction else ''
        if not known:
            return
        # P3i's per-folder override add-on writes the same setting from override.ini at the start
        # of playback, and saves what it found there to put back afterwards: never write before it.
        wait = self.started + LEVEL5_EARLIEST - time.time()
        if wait > 0 and self.monitor.waitForAbort(wait):
            return
        with self.lock:
            if not self._current(generation):
                return
            applied = self.override.apply(known)
        if applied:
            kodi.log('Level 5 corrected for CoreELEC: %s' % known, always=True)
        else:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 override holds another value '
                     '(override.ini, or another add-on)', always=True)
        return applied

    def _wait_for(self, condition, seconds, generation, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self._current(generation):
            if condition():
                return True
            if waited >= seconds or self.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def _target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Resolved once per playback: its identity names the file for the decode guard, and it is what
        the file analysis reads (a Plex transcode costs one question to the server)."""
        try:
            return locate.resolve(self.getPlayingFile(), stat=xbmcvfs.Stat), None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures, keyframes=None):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.monitor.waitForAbort, record)

        def from_file():
            if target is None:
                raise measure.Unavailable(unreadable)
            if not self.guard.allowed(target.identity):
                raise measure.Unavailable('left to Kodi after an interrupted decode')
            try:
                length = self.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            hands_over = self.on_coreelec and coreelec.restricts_with_level5(kodi.get_setting, xbmc.getInfoLabel)
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                functools.partial(self.guard.decoding, target.identity), full=full_pictures,
                                level5_hands_over=hands_over, keyframes=keyframes)

        if self.on_coreelec:
            return [(FILE_ANALYSIS, from_file)]
        return [('screen capture', screen), (FILE_ANALYSIS, from_file)]

    def _apply(self, generation, layout, picture_ratio, how, started, final=True, keyframes=None, level5=True):
        area, screen_w, screen_h, video_ratio = layout
        bars_gap, full_gap = distances()
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, not handled')
                return
            value = geometry.margin_value(area, screen_w / screen_h, video_ratio, picture_ratio, bars_gap, full_gap)
            changed = self.keeper.apply(value)
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; margin %.2f -> %.2f%s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, own, value, '' if changed else ' (unchanged)'))
        if final and level5 and self._level5_for_the_tv():
            self._correct_level5(generation, keyframes)

    def _level5_for_the_tv(self):
        """Dolby Vision the add-on places itself, with "Correct faulty Dolby Vision Level 5" on and
        CoreELEC's Level 5 handling on (its override is only readable then): the TV gets the
        corrected Level 5 too."""
        if not (self.on_coreelec and kodi.setting_bool('fix_level5', default=False)
                and xbmc.getInfoLabel(HDR_TYPE) == 'Dolby Vision'):
            return False
        if kodi.get_setting(override.SETTING, quiet=True) is None:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 handling is off')
            return False
        return True

    def _coreelec_places(self, generation):
        """CoreELEC's own restriction covers this playback: it was on when the playback started (a film
        carried over from an update, the hold refused, or the person switched it on during the film). CoreELEC
        places the subtitles on its own edge with the person's settings, so the add-on's margin goes back to the
        person's (a carried-over film keeps what the previous service set)."""
        kodi.log('CoreELEC places the subtitles with its own settings')
        self._restore_if_current(generation, 'CoreELEC places the subtitles')

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None

    def _manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        self._notify(32040)


def distances():
    """(content with black bars, full-screen content): the distances chosen in the menu."""
    return (geometry.bar_distance(kodi.setting_int('gap_bars', 0)),
            geometry.full_distance(kodi.setting_int('gap_full', geometry.FULL_DEFAULT),
                                   kodi.setting_number('gap_full_custom', geometry.FULL_DISTANCES[geometry.FULL_DEFAULT])))


def _read_text(path):
    """A small text file's contents, through Kodi's file access (local and network folders), or None."""
    try:
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:  # unreadable: as if there were none
        return None


def _recorded(path, data):
    """write_record, True when it was written."""
    try:
        write_record(path, data)
        return True
    except OSError:
        return False


def _pressed_lately():
    """Whether a button was pressed in the last RECENT_INPUT seconds."""
    try:
        return xbmc.getGlobalIdleTime() < RECENT_INPUT
    except Exception:  # Kodi could not say: looked at once in a while all the same
        return False


def _holds(condition):
    try:
        return xbmc.getCondVisibility(condition)
    except Exception:  # Kodi could not say
        return False


def _switch(text):
    """A switch setting's value as Kodi's settings file writes it: True, False or None."""
    return {'true': True, 'false': False}.get(text)



def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


RESTART_S, RESTART_MAX_S = 30, 1800    # after an unexpected failure of the service as a whole


def run():
    """The service, started again after anything unexpected (waiting longer each time), so one
    failure never leaves it off for the rest of the session."""
    monitor, pause = xbmc.Monitor(), RESTART_S
    while not monitor.abortRequested():
        try:
            Service().run()
            return
        except Exception as error:
            kodi.log('stopped by an unexpected error, starting again in %d s: %r' % (pause, error), always=True)
        if monitor.waitForAbort(pause):
            return
        pause = min(pause * 2, RESTART_MAX_S)
