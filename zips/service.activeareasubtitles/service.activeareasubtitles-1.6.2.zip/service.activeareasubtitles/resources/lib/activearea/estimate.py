"""A first placement before the file is read, where one is to be had without reading it: on the box a Dolby Vision
film's Level 5 as P3i reports it, live from the first frame. A measurement's first keyframe waits for smooth playback
(steady.Steady), so the estimate is tried as the measurement starts and at every step of that wait, through the wait's
meanwhile callable, whether or not a read went before it in the playback; the measurement then confirms or corrects it
as any estimate, except that a keyframe of a taller picture does not lower the text below what Level 5 showed on
screen (Placing.level5_shown, set once the estimate was placed: the keyframes are elsewhere in the film). A PC that
reads the file first takes one screen grab instead (capture.first_look), placed once by the playback: nothing to try
again.
"""
from . import kodi


class FirstEstimate:
    """The Level 5 estimate for one measurement. placing: the epoch's playback.Placing; reader: labels.Reader bound to
    the video's height (the offsets count in its rows; without a height it reads nothing); held(): Kodi holds the
    picture still (no Level 5 shows around a seek, and a hold is no moment to move the text); report(): P3i's raw
    labels, for the log line when the read came first."""

    def __init__(self, placing, reader, held, report):
        self._placing, self._reader, self._held, self._report = placing, reader, held, report
        self.pending = True              # not placed yet, and not given up
        self._unwritten = None           # the Level 5 of a try Kodi did not take (its margin could not be read)

    def step(self, reading_now=False):
        """One try: True when placed now, once P3i shows Level 5 with bars and Kodi does not hold (P3i shows none
        for a moment before the first frame, and a resume seeks first). A try that wrote nothing (Kodi's margin could
        not be read) is tried again at the next step: the person's margin would sit in the bar until the first keyframe.
        reading_now: the first read goes now; nothing placed by then, the detailed log says what P3i showed, once."""
        if not self.pending:
            return False
        if reading_now:
            self.pending = False
            if self._unwritten is not None:
                kodi.log('first estimate from Level 5 %d/%d: not written before the first read' % self._unwritten)
                return False
            has_l5, top, bottom, state = self._report()
            # P3i's own Level 5 scan state: whether its labels may carry its scan rather than the film's Level 5.
            kodi.log('first estimate from Level 5: none (has.l5 %r, %r/%r, video height %r)%s%s' % (
                has_l5, top, bottom, self._reader.height,
                '; 0/0 says nothing of bars in the file' if has_l5 == '1' and (top, bottom) == ('0', '0') else '',
                '; scan state %r' % state if state else ''))
            return False
        if self._held():
            return False
        picture, shown = self._reader.read()
        # Level 5 of 0/0 says the full frame, the same guess as none at all: the corpus' Dolby Vision films carry a Level 5
        # block of 0/0 over a letterboxed picture in 117 of 713 (110 on every keyframe), where it put the text in the
        # bar until the first keyframe.
        if picture is None or shown[0] != '1' or not (picture.top or picture.bottom):
            return False
        if not self._placing.place(picture, 'Level 5 %d/%d reported, measuring' % shown[1:], final=False):
            self._unwritten = shown[1:]
            return False
        # Only once placed: a Level 5 that never reached Kodi holds no taller keyframe back.
        self._placing.level5_shown = picture
        self.pending = False
        return True
