"""Steady playback: the one wait before any read of the playing file, one per playback (Playback.steady).

Every reader of the file (the measurement, the start-up search, a scene check, the Level 5 check, the read-ahead) asks
wait() before each read. At a film's start Kodi fills its buffer, and on a slow source (the NAS scrubbing its disks) the
measurement's keyframes, read at once, cost 95 skipped frames; read through a seek, a keyframe costs Kodi about 50
frames on the box. So nothing is read while Kodi is paused, seeking or caching (its hold) or while its buffer
is low, and after any of that only once Kodi has played on smoothly for a moment.

The playback's first read is decided here, not by the reader: whichever reader comes first waits until the playback
has run START_STEADY and, for a while, for a buffer Kodi reports to fill; every later read goes at once unless Kodi
holds, its buffer is low or it sought within HELD_STEADY. A reader that reads several keyframes in a row asks
seeked_since(t) between them, or going() before each read.

A source Kodi does not buffer reports no level (a PC's network share said 0 throughout), so the read-ahead also tells
Kodi's time at its looks, its waits' steps included (played): where that time moves less than half as fast as the
service's clock over STALL_WINDOW while Kodi says it plays, it is a stall, held as a hold is. After a stall or a buffer
that fell low the read-ahead searches no frames for a while (untroubled): its keyframes are cheap, its frame searches
are not, and the coarse cuts keep the text out of the bars meanwhile.
"""

WAIT_STEP = 0.25               # seconds a wait sleeps between two looks at Kodi
START_STEADY = 3.0             # seconds of smooth playback since the playback began before its first read
HELD_STEADY = 3.0              # seconds of smooth playback after a seek, pause or buffering before any later read
CACHE_FLOOR = 50               # per cent of Kodi's buffer under which nothing of the film is read
CACHE_WAIT = 10.0              # seconds a first read waits for a buffer Kodi reports to fill
CACHE_ZERO_WAIT = 2.0          # seconds a first read gives a buffer reported at nothing to start filling (a network
                               # stream's first seconds; a source Kodi does not buffer says 0 for good)
CACHE_WAIT_MOST = 60.0         # seconds the reads wait for a buffer that stays low: then one keyframe is read
CACHE_STILL = 3.0              # seconds after a buffer fell low by which, nothing read meanwhile, it has fallen further
                               # and never risen when the reads are not what drains it: they go on (over HTTP the rest
                               # of the film in Kodi's cache counts down with the film to the end)
CACHE_FULL = 90                # per cent: a first read goes as soon as Kodi stops holding (one keyframe can not run
                               # a buffer this full dry; a box resume waited 3 s more at 98 per cent)
STALL_WINDOW = 0.8             # seconds of the service's clock a stall is measured over at least: Kodi's time moving
                               # less than half of it while Kodi says it plays. Kodi's answer steps (0.2 s) up to the
                               # window itself never make one; at the read-ahead's looks (0.2 to 0.45 s apart on a
                               # laptop's 4K decoding) a stall of 0.55 s or more is seen at any phase (over 1 s windows
                               # one of 0.6 s is never seen between keyframe reads 0.45 s apart)
FRAMES_QUIET = 60.0            # seconds after a stall or a buffer that fell low before the read-ahead searches frames
                               # again (keyframes go on after HELD_STEADY)


class Steady:
    """One playback's steady playback. clock(): the service's clock; held(): Kodi holds the picture (Service.held);
    last_seek(): the clock at Kodi's latest seek event (-inf before any); cache_level(): Kodi's buffer in per cent, or
    None when Kodi does not say; wait(seconds) -> True when Kodi closes; log(line). read: a read of the file went
    through already in this playback. The add-on never passes it (its measurement reads through this same object);
    the film simulator does, as it simulates no measurement: a first read waits by other rules than a later one (the
    START_STEADY count from the start, the CACHE_FULL shortcut, a buffer given time to fill), so no begun moved back or
    buffer level reported can stand in for the read it did not make."""

    def __init__(self, clock, held, last_seek, cache_level, wait, log, read=False):
        self._clock, self._held, self._last_seek = clock, held, last_seek
        self._cache_level, self._wait, self._log = cache_level, wait, log
        self.begun = clock()                 # the service's clock when Kodi started the playback
        self.buffer_reported = False         # Kodi's buffer level was seen above CACHE_FLOOR in this playback
        self._read = read                    # a first wait let a read of the file through
        self._filled = False                 # the buffer seen above CACHE_FLOOR since Kodi's latest seek
        self._seek_known = last_seek()       # the seek _filled counts from
        self._looks = []                     # (clock, Kodi's time) of the looks since the newest STALL_WINDOW old
        self._running = False                # Kodi's time seen going on since the latest hold or seek
        self._stalled = float('-inf')        # the clock at the latest stall seen
        self._troubled = float('-inf')       # the clock at the latest stall or buffer that fell low
        self._fell = None                    # (clock, level, lowest since, _troubled before) of the latest fall
        self._fell_reads = None              # the reads drained it (it rose while they waited), or not; None: unknown

    def wait(self, current, meanwhile=None):
        """Whether to read the film now: True once Kodi plays on smoothly, False when current() says the work ended or
        Kodi is closing. While Kodi holds or its buffer is low (buffer_low) it waits, then HELD_STEADY of smooth
        playback. The playback's first read waits until START_STEADY of smooth playback since the playback began (the
        waits for subtitles and the video's shape before it usually cover that, so a healthy start loses nothing), and
        up to CACHE_WAIT for a buffer Kodi reports to fill (ending as soon as it has: about a second on a fast source).
        A buffer low for CACHE_WAIT_MOST lets one read through. Any later read goes at once unless Kodi holds, its
        buffer is low or it sought within HELD_STEADY: waiting only where it saves Kodi's playback, never as a rule.
        meanwhile(reading_now): called at every step with False and once with True as the read goes, whichever read it
        is (the first estimate, estimate.FirstEstimate.step: a measurement's wait is the only loop running before its
        first keyframe, and a read may have gone before it in the playback)."""
        first = not self._read
        stalled = self._stalled
        # Seconds of smooth playback so far; None: nothing has held yet (read at once).
        calm = max(0.0, self._clock() - self.begun) if first else None
        needed = START_STEADY if first else HELD_STEADY
        # A seek since the last read counts from Kodi's seek event, held or not when asked: one that came while a
        # keyframe decoded (about a second on the box) is over by now, Kodi's hold lasting about SEEK_QUIET, and the
        # next read would go at once. A stall counts as a seek does.
        since_seek = self._clock() - max(self._last_seek(), self._stalled)
        if since_seek < needed:
            calm = max(0.0, since_seek) if calm is None else min(calm, max(0.0, since_seek))
        waited = low_for = 0.0
        levels = None               # Kodi's buffer as the first read's log line names it: (the last, the highest)
        spent = {'Kodi held': 0.0, 'buffer low': 0.0, 'buffer filling': 0.0}   # the first read's log line
        while current():
            if meanwhile is not None:
                meanwhile()
            if self._stalled != stalled:
                # A stall seen at a look meanwhile (played): smooth playback counts from it, so the reads wait
                # HELD_STEADY after a stall's end, not after the look that first saw it.
                stalled, calm = self._stalled, 0.0
            level = self._cache_level()
            if level is not None:
                levels = (level, level if levels is None else max(levels[1], level))
            low = self.buffer_low(level)
            low_for = low_for + WAIT_STEP if low else 0.0
            held = self._held()
            if held:
                self._looks, self._running = [], False      # its time moved nothing over the hold: no stall
            holding = held or (low and low_for <= CACHE_WAIT_MOST)
            # A level of nothing gets CACHE_ZERO_WAIT to start filling, no more: a source Kodi does not buffer may say
            # 0 for good, where a stream's first seconds say 0 too.
            filling = (first and level is not None and not self.buffer_reported
                       and waited < (CACHE_WAIT if level else CACHE_ZERO_WAIT))
            if holding:
                calm = 0.0
            elif calm is None or (calm >= needed and not filling) or (first and level is not None
                                                                       and level >= CACHE_FULL):
                if first:
                    self._read = True
                    self._first_read(waited, levels, spent)
                if meanwhile is not None:
                    meanwhile(True)
                return True
            if self._wait(WAIT_STEP):
                return False
            waited += WAIT_STEP
            if not holding:
                calm += WAIT_STEP
            reason = ('Kodi held' if holding and not low else 'buffer low' if holding else 'buffer filling' if filling
                      else None)
            if reason:
                spent[reason] += WAIT_STEP
        return False

    def seeked_since(self, since):
        """Whether Kodi sought at or after clock time since (its seek event, whether it still holds or not)."""
        return self._last_seek() >= since

    def going(self):
        """Whether a read under way may go on: as a later read would go now (wait), Kodi not holding, its buffer not
        low, no seek or stall within HELD_STEADY. A frame search asks before each frame, so it stops within one frame's
        decode."""
        if self._held() or self.buffer_low(self._cache_level()):
            return False
        return self._clock() - max(self._last_seek(), self._stalled) >= HELD_STEADY

    def played(self, position):
        """Kodi's time (seconds, or None where it could not say) at one of the read-ahead's looks. Where it moved less
        than half the service's clock since the newest look at least STALL_WINDOW before this one, while Kodi said it
        plays and after it was seen going on, that is a stall: reads wait HELD_STEADY after it as after a hold (wait,
        going) and frames are searched only FRAMES_QUIET after it (untroubled). Measured against a look that old, not
        the look before: a stall straddling two windows would split between them. Half, not a fixed lag: at a slower
        tempo (0.8, Kodi's setting) a long gap between two looks would add up to any lag. A time never seen going on
        says nothing (a playback not started yet); Kodi's hold or seek starts the looks over, as does its time gone back
        (a seek told later); the box never tells one,
        and waits as it always did. True where this look saw a stall (each look while it goes on and up to half a
        window after it ends)."""
        now = self._clock()
        looks = self._looks             # a list of its own each time: another reader's wait may start them over
        if position is None or self._held() or (looks and self._last_seek() >= looks[0][0]):
            self._looks, self._running = [], False
            return False
        if not self._running:
            # Kept from the first look that saw its time going on: one before it, still, would read as a stall.
            self._running = bool(looks) and position != looks[-1][1]
            self._looks = [(now, position)]
            return False
        looks = looks + [(now, position)]
        old = [number for number, (when, _at) in enumerate(looks) if now - when >= STALL_WINDOW - 1e-9]
        self._looks = looks = looks[old[-1]:] if old else looks
        if not old:
            return False
        start, at = looks[0]
        spent, moved = now - start, position - at
        if moved < 0:
            # Back: a seek whose event has not come yet (Kodi tells it about half a second later), no stall.
            self._looks, self._running = [(now, position)], False
            return False
        if moved >= spent / 2:
            return False
        if now - self._stalled >= HELD_STEADY:
            self._log('steady: Kodi\'s time moved %.1f s in %.1f while it played (a stall), reading waits' % (
                moved, spent))
        self._stalled = self._troubled = now
        return True

    def untroubled(self, seconds):
        """Whether no stall came and Kodi's buffer did not fall low within seconds."""
        return self._clock() - self._troubled >= seconds

    def buffer_low(self, level):
        """Kodi's buffer (level, per cent, or None) below CACHE_FLOOR. Counted only once it was seen above the floor in
        this playback: a Kodi that reports no level, or one that stays at nothing for a file it does not buffer (a local
        one), never holds the reads. Below the floor after it was above it since Kodi's latest seek, it fell (the reads
        drained it, or the source is slow): trouble (untroubled), unless it falls on and never rises over CACHE_STILL
        while nothing is read, which the reads do not cause; one that has not filled since the seek is Kodi filling
        it."""
        if level is None:
            return False
        seek = self._last_seek()
        if seek != self._seek_known:
            self._seek_known, self._filled = seek, False
            if self._fell is not None and self._fell_reads is None:
                # A fall not judged yet: the seek starts Kodi's buffer over, filled as after any seek (held while low).
                self._troubled, self._fell = self._fell[3], None
        if level >= CACHE_FLOOR:
            self.buffer_reported = self._filled = True
            self._fell = None
            return False
        if not self._filled:
            return self.buffer_reported
        now = self._clock()
        if self._fell is None:
            self._fell, self._fell_reads = (now, level, level, self._troubled), None
        since, first, lowest, before = self._fell
        if self._fell_reads is None:
            if level > lowest:
                self._fell_reads = True     # filling again now nothing reads: the reads drained it
            elif now - since >= CACHE_STILL:
                # Lower still with nothing read: Kodi's own playing takes it down. No lower: perhaps the reads.
                self._fell_reads = level >= first
                if not self._fell_reads:
                    self._troubled = before
            else:
                self._fell = (since, first, level, before)
        if self._fell_reads is False:
            return False
        self._troubled = now
        return True

    def _first_read(self, waited, levels, spent):
        """The detailed log's line on what the first read waited for: Kodi holding (a start's seek, its own caching),
        its buffer low or filling; the rest is the smooth playback START_STEADY asks for. levels: Kodi's buffer, (the
        last, the highest), or None when it never said."""
        if levels is None:
            buffer = 'not reported'
        else:
            buffer = '%d %% (most %d %%)%s' % (levels[0], levels[1], '' if self.buffer_reported
                                                else ', never above %d %%' % CACHE_FLOOR)
        parts = ', '.join('%s %.1f s' % (name, seconds) for name, seconds in spent.items() if seconds)
        self._log('first read: %.1f s waited%s, buffer %s' % (waited, ' (%s)' % parts if parts else '', buffer))
