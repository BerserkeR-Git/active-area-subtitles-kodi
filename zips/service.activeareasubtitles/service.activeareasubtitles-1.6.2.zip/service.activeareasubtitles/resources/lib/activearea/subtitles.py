"""Which kind of subtitle is showing: text, which the add-on places itself, or an image (PGS, DVD, DVB),
which only CoreELEC's own restriction can move.

Kodi 21 reports a subtitle's language and flags but not its format, so the file's own subtitle streams
are read with FFmpeg and found in Kodi's list. Kodi lists subtitle files found next to the video before
the file's streams, and files added later (PM4K's subtitles from Plex) after them (seen in Kodi 21): the
file's streams are where their languages line up with Kodi's list; entries before them are the files next
to the video, known by their extensions; entries after them were added during playback, kind unknown
(and so placed as text). Plain Python, no Kodi.
"""
import os

IMAGE_CODECS = frozenset(('hdmv_pgs_subtitle', 'dvd_subtitle', 'dvb_subtitle', 'xsub'))
IMAGE_FILES = ('.sup', '.idx')
TEXT_FILES = ('.srt', '.ass', '.ssa', '.vtt', '.smi', '.sub', '.txt')

IMAGE, TEXT = 'image', 'text'


def _language(code):
    code = (code or '').strip().lower()
    return '' if code == 'und' else code


def _matches(entry, stream, check):
    """Whether one of Kodi's entries can be this stream of the file, by one more check."""
    if check == 'separate':      # a separate file is named "... (External)" (in English Kodi)
        return '(External)' not in (entry.get('name') or '')
    if check == 'flags':
        return (bool(entry.get('isforced')) == stream[2] if 'isforced' in entry else True) and \
            (bool(entry.get('isimpaired')) == stream[3] if 'isimpaired' in entry else True)
    title = stream[4] if len(stream) > 4 else ''
    return not title or (entry.get('name') or '') == title


def file_start(kodi_subtitles, streams):
    """Where the file's own streams begin in Kodi's list, or None when that is not one clear place.

    Languages decide; when they line up in more than one place (a Film.en.srt next to a file with
    English tracks), Kodi's naming of separate files, the forced and impaired flags and the titles do."""
    wanted = [_language(stream[1]) for stream in streams]
    shown = [_language(entry.get('language')) for entry in kodi_subtitles]
    fits = [start for start in range(len(shown) - len(wanted) + 1) if shown[start:start + len(wanted)] == wanted]
    for check in ('separate', 'flags', 'title'):
        if len(fits) <= 1:
            break
        narrower = [start for start in fits if all(_matches(kodi_subtitles[start + n], stream, check)
                                                   for n, stream in enumerate(streams))]
        fits = narrower or fits
    return fits[0] if len(fits) == 1 else None


def sidecar_kind(names, video_name):
    """IMAGE or TEXT when every subtitle file next to the video is of that kind, else None."""
    stem = os.path.splitext(video_name)[0].lower()
    lowered = [name.lower() for name in names]
    kinds = set()
    for name in lowered:
        if not name.startswith(stem):
            continue
        base, extension = os.path.splitext(name)
        if extension in IMAGE_FILES or (extension == '.sub' and base + '.idx' in lowered):
            kinds.add(IMAGE)
        elif extension in TEXT_FILES:
            kinds.add(TEXT)
    return kinds.pop() if len(kinds) == 1 else None


def current_kind(kodi_subtitles, current, streams, sidecars):
    """(IMAGE, TEXT or None, why) for Kodi's current subtitle.

    kodi_subtitles: Kodi's list (index, language, name, ...); current: the current subtitle's index;
    streams: the file's own subtitle streams (codec, language, forced, impaired, title), or None when the file
    could not be read; sidecars: IMAGE, TEXT or None for the subtitle files next to the video."""
    if current is None or not 0 <= current < len(kodi_subtitles):
        return None, 'no current subtitle'
    if streams is not None:
        start = file_start(kodi_subtitles, streams) if streams else len(kodi_subtitles)
        if start is not None and start <= current < start + len(streams):
            codec = streams[current - start][0]
            return (IMAGE if codec in IMAGE_CODECS else TEXT), 'from the file (%s)' % codec
        if start is not None and current >= start + len(streams) and streams:
            return None, 'a subtitle added during playback'
        if start is not None:
            return sidecars, 'a separate subtitle file'
        return None, 'the file\'s subtitle streams do not line up with Kodi\'s list'
    return None, 'the file\'s subtitle streams are unknown'
