"""Recognising when CoreELEC already keeps subtitles inside the picture itself.

Some CoreELEC builds (P3i) restrict subtitles to the active area during Dolby Vision
output, from Level 5 metadata or their own scan. They report it per playback through info
labels; the restriction setting is only readable while that build offers it. When the
build has it covered, the add-on stays out of the way so subtitles are not lifted twice.
"""
RESTRICT_SETTING = 'coreelec.amlogic.dolbyvision.restrict.subs.active.area'
HAS_L5 = 'Player.Process(video.dovi.has.l5)'
L5_TOP = 'Player.Process(video.dovi.l5.top.offset)'
L5_BOTTOM = 'Player.Process(video.dovi.l5.bottom.offset)'
SCAN_STATE = 'Player.Process(video.dovi.l5.detect.state)'
# Scan states: 0 failed, 1 skipped as not 16:9 (it then uses Kodi's own bars), 2 skipped
# for IMAX, 3 detected, 4 skipped, 5 disabled, 6 running.
HANDLED_STATES = ('1', '3')
RUNNING = '6'
SCAN_WAIT = 20.0


def is_coreelec(path='/etc/os-release'):
    try:
        with open(path, encoding='utf-8') as handle:
            return 'coreelec' in handle.read().lower()
    except OSError:
        return False


def _number(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return 0.0


def places_subtitles(get_setting, info_label, wait, current, log):
    """True when CoreELEC restricts subtitles to the active area for this playback.

    Level 5 with only zero offsets does not count: it says the picture fills the frame
    even when the bars are in the file, so there is nothing to restrict to.
    """
    if get_setting(RESTRICT_SETTING) is not True:
        return False
    waited = 0.0
    while current():
        has_l5, state = info_label(HAS_L5), info_label(SCAN_STATE)
        top, bottom = info_label(L5_TOP), info_label(L5_BOTTOM)
        usable = has_l5 == '1' and (_number(top) > 0 or _number(bottom) > 0)
        if usable or state in HANDLED_STATES:
            log('CoreELEC places the subtitles itself (L5 %r, top %r, bottom %r, scan %r)'
                % (has_l5, top, bottom, state))
            return True
        if state != RUNNING or waited >= SCAN_WAIT:
            return False
        if wait(1.0):
            break
        waited += 1.0
    return True   # playback changed or Kodi closing: do nothing
