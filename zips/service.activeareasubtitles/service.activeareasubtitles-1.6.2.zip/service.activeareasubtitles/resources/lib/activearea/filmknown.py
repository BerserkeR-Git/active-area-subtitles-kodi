"""What a PC's scene following knows of the playing file across a playback's epochs (screenfollow.ScreenFollowing.film):
the file analysis' keyframes and their exact shapes, the shapes its followers saw on screen, and the film read ahead of
playback (lookahead.Lookahead), run after run, with the maps they read joined. A placing again during the film (Kodi's
window, a distance, the position) starts a follower that knows all of it, so nothing is learnt twice.
"""
from . import detect, pictures, scenemap


class FilmKnown:

    def __init__(self):
        self.keyframes = []                  # the newest file analysis' keyframes (its list, growing while it reads)
        self._exact = (0, None, [])          # (keyframes counted, the video's ratio, their exact shapes)
        self.seen = []                       # the shapes the followers saw on screen
        self.ahead = None                    # the newest read-ahead started, or None
        self._before = None                  # every run before it joined (a scene map): goes on where the newest read
                                             # nothing
        self._ended = None                   # the read-ahead whose run ended
        self._joined = (None, None, None)    # (the map before, the newest's, the two joined): worked out once per pair

    def learn(self, keyframes):
        """The file analysis' keyframes, read from now on (the newest measurement's list, once it holds any; None or an
        empty one leaves what an earlier one read)."""
        if keyframes:
            self.keyframes = keyframes

    def exact(self, video_ratio):
        """The exact shapes of the keyframes read so far (a follower's reader asks at every look), in the video's own
        shape: a file with pixels that are not square (a DVD's 720x576) shows its frame wider or narrower than stored (a
        2.35 picture would come out as 1.65 and never match a grab's)."""
        keyframes = self.keyframes
        count, ratio, shapes = self._exact
        if len(keyframes) != count or ratio != video_ratio:
            read = list(keyframes)
            shapes = [detect.picture_of(kf.exact, video_ratio) for kf in read if kf.exact_picture is not None]
            self._exact = (len(read), video_ratio, shapes)
        return self._exact[2]

    def saw(self, shapes):
        """The shapes a follower's reader saw, kept for the playback's next followers."""
        self.seen = pictures.joined(shapes, self.seen)

    # The film read ahead of playback.

    def reading(self, ahead):
        """A read-ahead started: the newest from now on, the maps of every run before it going on under it (the one
        before had ended: a run is started again only then)."""
        self._before, self.ahead = self.live(), ahead

    def ended(self, ahead):
        """A read-ahead's run ended: read to its end, stopped, or a surprise."""
        self._ended = ahead

    def resumable(self):
        """Whether the newest read-ahead's run ended (following switched off and on, a surprise) and may start again: not
        one that stops the same way every time (for_good)."""
        return self.ahead is not None and self._ended is self.ahead and not getattr(self.ahead, 'for_good', False)

    def live(self):
        """The map read ahead, for the followers and the cache: the newest read-ahead's over the one before's (started
        again, it reads from where playback is: what the one before read still holds), or None."""
        ahead, earlier = self.ahead, self._before
        if ahead is None:
            return None
        found = ahead.map
        if not found or not earlier:
            return found or earlier
        if self._joined[0] is not earlier or self._joined[1] is not found:
            joined = earlier.merged(found)
            # Together past CUTS_MOST, merged ends before what the newest read and the rest would be followed from
            # grabs. The one before read behind playback (the newest starts where playback is): the newest alone.
            reach = found.seen[-1][1] - (0.0 if found.exact else scenemap.TAIL) if found.seen else None
            if reach is not None and (not joined.seen or joined.seen[-1][1] < reach - 0.001):
                joined = found
            self._joined = (earlier, found, joined)
        return self._joined[2]


def kept_trust(memory):
    """How a read-ahead hands its trust in Level 5 to the playback's cache memory (shapes.Memory), or None without one."""
    if memory is None:
        return None
    return lambda trust: memory.remember_judgement('ahead', trust)
