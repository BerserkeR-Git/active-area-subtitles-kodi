"""Active Area Subtitles' own questions and messages, in the style of its menu and the same on every skin:
the add-on's icon and name at the top, the text, and the buttons at the bottom right. Back answers no.
The same window, without buttons and with a bar along the bottom, shows something that takes a few
seconds.

The window is as tall as its text and centred. Kodi cannot measure text from an add-on and cannot size
a window to it, so the lines are broken here (from a typical sans-serif's letter widths) and everything
is placed for that many lines."""
import threading

import xbmcgui

from . import kodi

WINDOW = 'activearea-question.xml'
TITLE, TEXT, YES, NO, BAR = 10, 20, 31, 32, 41
PANEL, ICON, RULE_TOP, RULE_BOTTOM, TRACK = 2, 3, 4, 5, 40
BAR_WIDTH = 1100
CANCEL_ACTIONS = {10, 92}       # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK

# Advance widths per 1000 units of the em, close to Noto Sans and similar skin fonts.
WIDTHS = {
    ' ': 260, '.': 268, ',': 268, ':': 268, ';': 268, "'": 221, '"': 401, '!': 268, '?': 429, '-': 322, '(': 303,
    ')': 303, '·': 268, '/': 372, '&': 705,
    'a': 561, 'b': 615, 'c': 480, 'd': 615, 'e': 564, 'f': 344, 'g': 615, 'h': 618, 'i': 258, 'j': 258, 'k': 534,
    'l': 258, 'm': 935, 'n': 618, 'o': 605, 'p': 615, 'q': 615, 'r': 413, 's': 479, 't': 361, 'u': 618, 'v': 508,
    'w': 786, 'x': 529, 'y': 510, 'z': 470,
    'A': 639, 'B': 647, 'C': 632, 'D': 723, 'E': 556, 'F': 522, 'G': 726, 'H': 739, 'I': 336, 'J': 259, 'K': 615,
    'L': 524, 'M': 907, 'N': 763, 'O': 778, 'P': 604, 'Q': 778, 'R': 618, 'S': 549, 'T': 553, 'U': 733, 'V': 603,
    'W': 925, 'X': 579, 'Y': 556, 'Z': 566,
}
DIGIT, OTHER = 572, 700
PX_PER_UNIT = 25.5 / 1000

# The text: 1060 px wide in the skin's font13 (Estuary: 28.4 px per em, lines 41 px apart), measured in
# the units above with 8% to spare, so a skin with a slightly wider font13 does not break the lines again.
TEXT_LIMIT = int(1060 * PX_PER_UNIT * 1000 / (28.4 * 1.08))
LINE_H = 41
TEXT_TOP = 166
BUTTON_H = 64
SCREEN_H = 1080


def text_width(text):
    return sum(WIDTHS.get(c, DIGIT if c.isdigit() else OTHER) for c in text) * PX_PER_UNIT


def lines(text, limit=TEXT_LIMIT):
    """Lines no wider than limit, broken between words; [CR] forces a break, and [CR][CR] leaves an empty line."""
    found = []
    for paragraph in text.replace('[CR]', '\n').split('\n'):
        line = ''
        for word in paragraph.split():
            candidate = word if not line else line + ' ' + word
            if line and text_width(candidate) > limit:
                found.append(line)
                line = word
            else:
                line = candidate
        found.append(line)
    while len(found) > 1 and not found[-1]:
        found.pop()
    return found


def layout(count):
    """The window's height and top for a text of count lines, and the top of each control below the
    heading (relative to the window's top)."""
    text_height = max(1, count) * LINE_H + 6
    rule = TEXT_TOP + text_height + 20
    buttons = rule + 28
    height = buttons + BUTTON_H + 32
    return height, (SCREEN_H - height) // 2, {TEXT: TEXT_TOP, RULE_BOTTOM: rule, YES: buttons, NO: buttons,
                                              TRACK: buttons + 28, BAR: buttons + 28}, text_height


class QuestionWindow(xbmcgui.WindowXMLDialog):
    """One question or message. answer is True only when the first button was pressed."""

    def __new__(cls, text, yes, no=None, careful=False):
        return super().__new__(cls, WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')

    def __init__(self, text, yes, no=None, careful=False):
        self.text, self.yes, self.no, self.careful = text, yes, no, careful
        self.answer = False

    def place(self):
        """The heading, the text broken into lines, and everything placed for that many lines."""
        broken = lines(self.text)
        height, top, below, text_height = layout(len(broken))
        self.getControl(PANEL).setHeight(height)
        for control, x, y in ((PANEL, 0, 0), (ICON, 50, 40), (TITLE, 150, 40), (RULE_TOP, 50, 140)):
            self.getControl(control).setPosition(x, top + y)
        for control, x in ((TEXT, 70), (RULE_BOTTOM, 50), (NO, 610), (YES, 890), (TRACK, 50), (BAR, 50)):
            self.getControl(control).setPosition(x, top + below[control])
        self.getControl(TEXT).setHeight(text_height)
        self.getControl(TITLE).setLabel(kodi.text(32000))
        self.getControl(TEXT).setText('[CR]'.join(broken))

    def onInit(self):
        self.place()
        self.getControl(YES).setLabel(self.yes)
        if self.no:
            self.getControl(NO).setLabel(self.no)
        else:
            self.getControl(NO).setVisible(False)
        self.getControl(BAR).setVisible(False)
        # A question whose yes can not be undone starts on no, so a press of OK out of habit changes nothing.
        self.setFocusId(NO if self.no and self.careful else YES)

    def onClick(self, control_id):
        if control_id in (YES, NO):
            self.answer = control_id == YES
            self.close()

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.close()


def ask(text, yes, no, careful=False):
    """Asks; True for yes. Back is no."""
    window = QuestionWindow(text, yes, no, careful)
    window.doModal()
    answer = window.answer
    del window
    return answer


def tell(text):
    """Says something that needs nothing more than OK."""
    ask(text, kodi.text(32109), None)


class Waiting(QuestionWindow):
    """The window without buttons, shown while something takes a few seconds; a bar fills along the
    bottom. Back stops the wait (cancelled)."""

    def __new__(cls, text):
        return super().__new__(cls, text, '')

    def __init__(self, text):
        super().__init__(text, '')
        self.cancelled = False

    def onInit(self):
        self.fill()

    def fill(self):
        """Also called straight after show(): Kodi calls onInit only once the script lets it (a
        waitForAbort), so the window stood empty, buttons and all, until then."""
        self.place()
        for button in (YES, NO):
            self.getControl(button).setVisible(False)

    def update(self, percent):
        bar = self.getControl(BAR)
        bar.setWidth(max(1, int(BAR_WIDTH * min(100, max(0, percent)) / 100)))
        bar.setVisible(True)

    def onClick(self, control_id):
        pass

    def onAction(self, action):
        if action.getId() in CANCEL_ACTIONS:
            self.cancelled = True


def waiting(text):
    """Opens the waiting window (closed by its close())."""
    window = Waiting(text)
    window.show()
    window.fill()
    window.update(0)
    return window
