"""The settings' status section: which system was detected and how the picture is measured."""
SCREEN, SCREEN_AND_FILE = 32097, 32099   # the file as fallback only where an FFmpeg loaded, and not while it is paused
SYSTEMS = (('System.Platform.Windows', 32090), ('System.Platform.OSX', 32091), ('System.Platform.Android', 32093),
           ('System.Platform.Linux', 32092))
GENERIC = 32096
COREELEC = 32094   # one name for every CoreELEC: the measurement row says who places image subtitles
FILE_ANALYSIS, FILE_ANALYSIS_P3I, PAUSED = 32098, 32101, 32100
FILE_AND_SCREEN = 32165                  # a PC with the decoder shipped in the add-on
# A hidden add-on setting the service writes at its start: whether CoreELEC offers its own restriction here. Kodi's
# settings window shows the scene and image rows from it (settings.xml can not ask CoreELEC), and the menu reads it
# too, so both show what the service uses.
P3I_SHOWN = 'status_p3i'


def describe(on_coreelec, p3i, decoding_allowed, condition, file_first=False, file_fallback=False):
    """(system string id, measurement string id). file_first: a PC whose shipped decoder loaded at start;
    file_fallback: a PC where the system's FFmpeg loaded at start instead."""
    if on_coreelec:
        system = COREELEC
        if not decoding_allowed:
            return system, PAUSED
        return system, FILE_ANALYSIS_P3I if p3i else FILE_ANALYSIS
    system = next((string_id for name, string_id in SYSTEMS if condition(name)), GENERIC)
    if not decoding_allowed:
        return system, SCREEN
    return system, FILE_AND_SCREEN if file_first else SCREEN_AND_FILE if file_fallback else SCREEN
