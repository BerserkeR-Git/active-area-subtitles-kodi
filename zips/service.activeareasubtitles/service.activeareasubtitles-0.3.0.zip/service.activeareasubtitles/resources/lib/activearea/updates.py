"""Is a newer Active Area Subtitles out? Asked of the repository this device installed it from.

Kodi itself looks at a repository at most once a day, so a new version can take a day
to show up. This asks the repository directly; the update itself is left to Kodi
(see actions.py). Plain Python, no Kodi, so it can be tested on its own.
"""
import urllib.request
import xml.etree.ElementTree as ElementTree

ADDON_ID = 'service.activeareasubtitles'
REPOSITORY_ID = 'repository.activeareasubtitles'
MAX_BYTES = 2 * 1024 * 1024
TIMEOUT_S = 8

# Reasons a check could not be done; actions.py turns them into the person's language.
NO_CONNECTION, NOT_NOW, NO_SOURCE = 'no_connection', 'not_now', 'no_source'


class UpdateProblem(Exception):
    """The check could not be done. args[0] is one of the reasons above."""


def repository_address(repository_addon_xml):
    """The address of the repository's addons.xml, from the repository add-on's own addon.xml."""
    try:
        root = ElementTree.fromstring(repository_addon_xml)
    except ElementTree.ParseError:
        return None
    info = root.find(".//extension[@point='xbmc.addon.repository']/dir/info")
    if info is None:
        info = root.find(".//extension[@point='xbmc.addon.repository']/info")
    address = (info.text or '').strip() if info is not None else ''
    return address if address.startswith('https://') else None


def published_version(addons_xml, addon_id=ADDON_ID):
    try:
        root = ElementTree.fromstring(addons_xml)
    except ElementTree.ParseError:
        return None
    for addon in root.iter('addon'):
        if addon.get('id') == addon_id:
            return addon.get('version')
    return None


def parts(version):
    try:
        return tuple(int(p) for p in str(version).split('.')[:3])
    except ValueError:
        return None


def newer(available, installed):
    mine, theirs = parts(installed), parts(available)
    return bool(mine and theirs and theirs > mine)


def fetch(address, opener=urllib.request.urlopen):
    """The text at address, at most MAX_BYTES. Certificates are checked as usual."""
    try:
        with opener(address, timeout=TIMEOUT_S) as response:
            data = response.read(MAX_BYTES + 1)
    except (OSError, ValueError):
        raise UpdateProblem(NO_CONNECTION) from None
    if len(data) > MAX_BYTES:
        raise UpdateProblem(NOT_NOW)
    return data.decode('utf-8', 'replace')


def latest(repository_addon_xml, opener=urllib.request.urlopen):
    """The version the repository offers now."""
    address = repository_address(repository_addon_xml)
    if not address:
        raise UpdateProblem(NO_SOURCE)
    version = published_version(fetch(address, opener))
    if not version:
        raise UpdateProblem(NOT_NOW)
    return version
