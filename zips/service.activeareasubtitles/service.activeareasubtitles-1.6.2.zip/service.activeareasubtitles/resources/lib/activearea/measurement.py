"""One measurement of a playback's picture: each way of measuring in turn until one settles, and what becomes of each
answer on the way. A file cropped to its picture keeps its own shape; a remembered shape (the cache) is only ever
widened (or read again more exactly where a smaller window's grab read its rows), and an answer from dim grabs alone
never moves it; a settled answer is written to the cache unless every
grab that agreed on it was dim, or the file has one keyframe. Nothing is placed here: place(ratio, how, final) is the
playback's own write, and the outcome tells the playback what is left to do."""
import contextlib

from . import kodi, libav, measure, pictures

CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 has a shape of its own (cropped, or 4:3 and the like)
SAME_SHAPE = 0.005             # a cached shape stands against a measurement this much wider: two routes differ by a
                               # few thousandths on one picture, under a pixel of margin

SETTLED, STOPPED, NO_ANSWER, COREELEC, NONE_WORKED = 'settled', 'stopped', 'no answer', 'coreelec', 'none worked'


def _why_provisional(how, screen):
    """Why an answer is provisional, for the log: the file route's rests on the one keyframe the file has (measure.film),
    the screen route's (screen) on dim grabs."""
    return 'the file gave one keyframe' if how.startswith('file') else screen


def own_shape(video_ratio):
    """True for a video in a shape of its own, usually cropped to its picture."""
    return abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE


class Measurement:

    def __init__(self, ways, video_ratio, own_shape, floor=None, memory=lambda: None, current=lambda: True):
        """ways: (name, attempt) in order of preference, attempt() giving (ratio, how, final) answers. floor: a
        remembered shape the measurement may only widen, or read more exactly (pictures.finer). memory(): the
        playback's shapes.Memory or None, asked at each settled answer. current(): whether the playback still wants the
        answers."""
        self._ways = ways
        self._video_ratio = video_ratio
        self._own_shape = own_shape
        self._floor = floor
        self._memory = memory
        self._current = current
        self.reason = None                  # what CoreELEC's hand-over said, for COREELEC
        self.unavailable = {}               # {way's name: why it could not run}

    def run(self, place):
        """SETTLED, STOPPED (the playback ended or was placed again), NO_ANSWER (a way ran out without one),
        COREELEC (CoreELEC places the subtitles, see reason) or NONE_WORKED (no way could run)."""
        for name, attempt in self._ways:
            try:
                settled = False
                # Closed explicitly, so a decoder is freed the moment the answer is in. A way may settle
                # more than once (screen capture widening for IMAX scenes): each settled shape counts.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        if self._answer(ratio, how, final, place):
                            settled = True
                if settled:
                    return SETTLED
                if not self._current():   # stopped, or a newer placing of this film took over: not the file's fault
                    kodi.log('%s ended: the playback stopped or was placed again' % name)
                    return STOPPED
                kodi.log('%s gave no clear answer' % name)
                return NO_ANSWER
            except libav.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
                self.unavailable[name] = str(reason)
                if settled:               # what was settled stands
                    return SETTLED
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self.reason = str(reason)
                return COREELEC
        kodi.log('no way of measuring worked for this playback')
        return NONE_WORKED

    def _answer(self, ratio, how, final, place):
        """One answer: placed, kept back, or written to the cache. True when it settles the measurement."""
        floor = self._floor
        provisional = getattr(ratio, 'provisional', False)     # read before the clamp below turns it into a number
        if self._own_shape and ratio <= self._video_ratio * (1 + CROPPED_TOLERANCE):
            ratio = self._video_ratio     # no bars in the file: its own shape, not moved again
        if floor is not None and provisional:
            # A measured, cached shape outweighs an answer from dim grabs alone, or from a file's one keyframe.
            kodi.log('cache: kept, %s (%.2f)' % (_why_provisional(how, 'the screen capture agreed only in dim scenes'),
                                                 ratio))
            return True
        if floor is not None and ratio <= floor * (1 + SAME_SHAPE) and not (final and pictures.finer(ratio, floor)):
            # The cached shape is on already: nothing to place again (no writes, no settings read
            # while Kodi may be switching the add-on off), only a wider picture moves it, or the same picture read
            # more exactly than a smaller window's grab read it (its edge row was coarser).
            if final:
                kodi.log('cache: kept, the measurement found %.2f' % ratio)
            return final
        place(ratio, how, final)
        if not final:
            return False
        memory = self._memory()
        if memory is None:
            pass
        elif provisional:
            kodi.log('cache: not saved, %s' % _why_provisional(how, 'every agreeing grab was dim'))
        else:
            memory.remember(ratio, how)   # logs "cache: saved ..." itself
        return True
