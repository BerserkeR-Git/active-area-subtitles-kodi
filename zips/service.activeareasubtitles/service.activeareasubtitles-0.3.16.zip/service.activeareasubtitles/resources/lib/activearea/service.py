"""The background service: find the picture's shape once per playback, then step aside.

Per playback: check that there is anything to do, work out the picture's shape (from the
file's own shape when it is already cropped, otherwise by measuring), set Kodi's subtitle
margin so subtitles sit just inside the picture, and put the person's own margin back when
playback ends. It never sends a playback command, and once the shape is known it does
nothing more until the next playback.

Measuring: on CoreELEC from keyframes of the video file (Kodi can not see the video plane
there), elsewhere from tiny screen captures with the video file as a fallback where the
system has FFmpeg. Everything runs on its own thread; any failure leaves Kodi's normal
subtitle position.
"""
import contextlib
import os
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

from . import coreelec, diagnostics, geometry, kodi, locate, measure, override, status
from .guard import DecodeGuard
from .keeper import Keeper, Switch
from .memo import Memo

MARGIN_SETTING = 'subtitles.marginvertical'
SCREEN_START_DELAY = 1.0       # seconds before the first screen capture, so the picture is on screen
CROPPED_TOLERANCE = 0.02       # a video this far from 16:9 is taken as already cropped
SAVED_PICTURES = 2             # frames saved per playback while the detailed log is on
SUBTITLE_WAIT = 5.0            # seconds to wait for subtitles a player add-on loads just after the start
SHAPE_WAIT = 2.0               # seconds to wait for Kodi to know the video's shape
LEFT_TO_COREELEC = 'coreelec'  # session memory: CoreELEC places this film's subtitles
LEVEL5_EARLIEST = 3.0          # seconds after the start before a Level 5 correction is written


class _Monitor(xbmc.Monitor):
    """Kodi's monitor, passing on changes to the add-on's settings."""

    def __init__(self, settings_changed):
        super().__init__()
        self.settings_changed = settings_changed

    def onSettingsChanged(self):
        try:
            self.settings_changed()
        except Exception as error:  # a settings change must never stop the service
            kodi.log('settings change not handled: %r' % error, always=True)


class Service(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.monitor = _Monitor(self._settings_changed)
        self.enabled = kodi.setting_bool('enabled')
        self.override = override.Override(lambda: kodi.get_setting(override.SETTING),
                                          lambda value: kodi.set_setting(override.SETTING, value),
                                          kodi.data_path('level5.json'))
        self.keeper = Keeper(lambda: _number(kodi.get_setting(MARGIN_SETTING)),
                             lambda value: kodi.set_setting(MARGIN_SETTING, value),
                             kodi.data_path('margin.json'))
        # CoreELEC's "Apply configured subtitle margin", switched on for the small gap (off by default).
        self.margin_switch = Switch(lambda: kodi.get_setting(coreelec.MARGIN_SETTING),
                                    lambda value: kodi.set_setting(coreelec.MARGIN_SETTING, value),
                                    kodi.data_path('margin_switch.json'))
        self.lock = threading.Lock()
        self.generation = 0
        self.manual_notice_shown = False
        self.on_coreelec = coreelec.is_coreelec()
        self.guard = DecodeGuard(os.path.dirname(kodi.data_path('decoding')), kodi.addon().getAddonInfo('version'))
        self.memo = Memo()
        self.waiting_for_subtitles = None   # playback that had no subtitles yet; measured once some appear
        self.started = time.time()           # when the current playback started

    # Kodi's player callbacks only start or stop work; nothing slow runs on them.

    def onAVStarted(self):
        self.started = time.time()
        generation = self._next_generation()
        if self.isPlayingVideo():
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onAVChange(self):
        # Streams changed: subtitles switched on later in a playback that had none at the start.
        generation = self.waiting_for_subtitles
        if generation is not None and xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and \
                self._claim_waiting(generation):
            threading.Thread(target=self._fit, args=(generation,), daemon=True).start()

    def onPlayBackStopped(self):
        self._finish('playback stopped')

    def onPlayBackEnded(self):
        self._finish('playback ended')

    def onPlayBackError(self):
        self._finish('playback error')

    def run(self):
        with self.lock:
            if self.margin_switch.restore():
                kodi.log('CoreELEC\'s subtitle margin option switched off after an unfinished playback', always=True)
            if self.keeper.restore():
                kodi.log('own subtitle margin put back after an unfinished playback', always=True)
            if self.override.restore():
                kodi.log('Level 5 correction cleared after an unfinished playback', always=True)
        if self.guard.check_last_run():
            kodi.log('Kodi stopped during a decode last time; video file analysis is paused until the next update',
                     always=True)
        self._show_status()
        # Started during playback (an update, or the add-on switched on): measure that video too.
        if self._playing_video():
            self.onAVStarted()
        while not self.monitor.waitForAbort(30):
            pass
        self._finish('Kodi closing')
        self.guard.wait_until_idle()

    def _settings_changed(self):
        """Switched off: the own margin goes back at once. Switched on during a video: measure it.
        Level 5 correction off: a correction in place is cleared. Other changes (the status fields
        the service writes itself, among them) do nothing."""
        if not kodi.setting_bool('edge_gap', default=False):
            with self.lock:     # CoreELEC goes back to the picture's edge at once
                if self.margin_switch.restore():
                    kodi.log('small gap turned off: CoreELEC\'s subtitle margin option switched off')
        if not kodi.setting_bool('fix_level5', default=False):
            with self.lock:     # does nothing unless a correction is in place
                if self.override.restore():
                    kodi.log('Level 5 correction turned off: cleared')
        enabled = kodi.setting_bool('enabled')
        if enabled == self.enabled:
            return
        self.enabled = enabled
        if not enabled:
            self._finish('turned off in settings')
        elif self._playing_video():
            self.onAVStarted()

    def _playing_video(self):
        try:
            return self.isPlayingVideo()
        except Exception:  # Kodi could not say
            return False

    def _show_status(self):
        p3i = self.on_coreelec and coreelec.is_p3i(kodi.get_setting, xbmc.getInfoLabel('System.BuildVersion'))
        system, method = status.describe(self.on_coreelec, p3i, self.guard.allowed(), xbmc.getCondVisibility)
        for setting_id, string_id in (('status_system', system), ('status_method', method)):
            try:
                shown, wanted = kodi.addon().getSetting(setting_id), kodi.text(string_id)
                if shown != wanted:     # Kodi writes its settings file on every change
                    kodi.addon().setSetting(setting_id, wanted)
            except Exception:  # the status display is a courtesy, never a reason to stop
                pass
        kodi.log('started: %s, %s' % (kodi.text(system), kodi.text(method).lower()))

    # Bookkeeping.

    def _next_generation(self):
        with self.lock:
            self.generation += 1
            return self.generation

    def _claim_waiting(self, generation):
        """True for exactly one caller once subtitles appear in a playback that was waiting for them."""
        with self.lock:
            if self.waiting_for_subtitles == generation == self.generation:
                self.waiting_for_subtitles = None
                return True
            return False

    def _current(self, generation):
        return generation == self.generation and not self.monitor.abortRequested()

    def _finish(self, why):
        with self.lock:
            self.generation += 1
            if self.margin_switch.restore():      # before the margin, so nothing moves in between
                kodi.log('%s: CoreELEC\'s subtitle margin option switched off' % why)
            if self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)
            if self.override.restore():
                kodi.log('%s: Level 5 correction cleared' % why)

    def _restore_if_current(self, generation, why):
        with self.lock:
            if self._current(generation) and self.keeper.restore():
                kodi.log('%s: own subtitle margin put back' % why)

    # The work for one playback, on its own thread.

    def _fit(self, generation):
        try:
            with self.lock:       # a playlist's next video: the previous one's changes go
                if self._current(generation) and self.override.restore():
                    kodi.log('next video: Level 5 correction cleared')
                if self._current(generation) and self.margin_switch.restore():
                    kodi.log('next video: CoreELEC\'s subtitle margin option switched off')
            self._fit_once(generation)
        except Exception as error:  # never let a surprise disturb playback
            kodi.log('stopped after an unexpected error: %r' % error, always=True)
            try:
                self._restore_if_current(generation, 'unexpected error')
            except Exception:
                pass

    def _fit_once(self, generation):
        if not self.on_coreelec and self.monitor.waitForAbort(SCREEN_START_DELAY):
            return
        if not self._current(generation):
            return
        layout = self._layout(generation)
        if layout is None:
            return
        area, screen_w, screen_h, video_ratio = layout
        if abs(video_ratio - measure.SIXTEEN_NINE) / measure.SIXTEEN_NINE > CROPPED_TOLERANCE:
            self._apply(generation, layout, video_ratio, 'file already cropped', time.time())
            return

        started = time.time()
        current = lambda: self._current(generation)  # noqa: E731
        saved = []
        full_pictures = kodi.setting_bool('diagnostics', default=False)

        def record(number, frame, width, height, channels, sample, detail=''):
            kodi.log('sample %d%s: %r' % (number, ' (%s)' % detail if detail else '', sample))
            if frame and full_pictures and len(saved) < SAVED_PICTURES:
                saved.append(self._save_picture(frame, width, height, channels, len(saved) + 1))

        target, unreadable = self._target()
        identity = target.identity if target else None
        known = self.memo.get(identity) if identity else None
        if known == LEFT_TO_COREELEC:
            kodi.log('CoreELEC places the subtitles (its Level 5, remembered from earlier this session)')
            self._coreelec_places(generation)
            return
        if known is not None:
            self._apply(generation, layout, known, 'remembered from earlier this session', started)
            return
        for name, attempt in self._ways(video_ratio, current, record, target, unreadable, full_pictures):
            try:
                # Closed explicitly, so a decoder is freed the moment the answer is in.
                with contextlib.closing(iter(attempt())) as results:
                    for ratio, how, final in results:
                        self._apply(generation, layout, ratio, how, started, final)
                        if final:
                            if identity:
                                self.memo.put(identity, ratio)
                            return
                kodi.log('%s gave no clear answer' % name)
                self._restore_if_current(generation, 'no clear answer')
                return
            except measure.Unavailable as reason:
                kodi.log('%s not available: %s' % (name, reason))
            except measure.LeftToCoreELEC as reason:
                kodi.log('CoreELEC places the subtitles: %s' % reason)
                self._coreelec_places(generation)
                if identity:
                    self.memo.put(identity, LEFT_TO_COREELEC)
                return
        kodi.log('no way of measuring worked for this playback; subtitles left where Kodi puts them')
        # The previous item of a playlist may have changed the margin: this one gets the person's own.
        self._restore_if_current(generation, 'not measured')

    def _layout(self, generation):
        """(area, screen width, screen height, video ratio), or None when there is nothing to do."""
        if not kodi.setting_bool('enabled'):
            self._finish('turned off in settings')
            return None
        if not self._wait_for(lambda: xbmc.getCondVisibility('VideoPlayer.HasSubtitles'), SUBTITLE_WAIT, generation):
            kodi.log('no subtitles yet; measured when subtitles are switched on')
            self._restore_if_current(generation, 'no subtitles')
            self.waiting_for_subtitles = generation
            # Subtitles that arrived just before the line above would have found nobody waiting.
            if not (xbmc.getCondVisibility('VideoPlayer.HasSubtitles') and self._claim_waiting(generation)):
                return None
        if xbmc.getCondVisibility('VideoPlayer.IsStereoscopic'):
            kodi.log('3D video, not handled')
            self._restore_if_current(generation, '3D video')
            return None
        align = _number(kodi.get_setting('subtitles.align'))
        area = geometry.layout_area(int(align) if align is not None else -1)
        if area is None:
            kodi.log('subtitle position is %s (Manual or unknown), not handled' % align)
            self._restore_if_current(generation, 'position not handled')
            self._manual_notice()
            return None
        view = kodi.rpc('Player.GetViewMode') or {}
        if view and (view.get('viewmode') != 'normal' or abs(view.get('zoom', 1.0) - 1.0) > 0.001
                     or view.get('verticalshift', 0) or abs(view.get('pixelratio', 1.0) - 1.0) > 0.001):
            kodi.log('view mode is not normal (%s), not handled' % view)
            self._restore_if_current(generation, 'view mode not normal')
            return None
        if self.on_coreelec and coreelec.places_subtitles(
                kodi.get_setting, xbmc.getInfoLabel, self.monitor.waitForAbort,
                lambda: self._current(generation), kodi.log):
            self._coreelec_places(generation)
            if kodi.setting_bool('fix_level5', default=False):
                self._correct_level5(generation)
            return None
        screen_w = _number(xbmc.getInfoLabel('System.ScreenWidth'))
        screen_h = _number(xbmc.getInfoLabel('System.ScreenHeight'))
        shape = []
        self._wait_for(lambda: shape.append(xbmc.RenderCapture().getAspectRatio()) or shape[-1], SHAPE_WAIT, generation)
        video_ratio = shape[-1] if shape else 0
        if not (screen_w and screen_h and video_ratio):
            kodi.log('screen or video size unknown, not handled')
            self._restore_if_current(generation, 'size unknown')
            return None
        return area, screen_w, screen_h, video_ratio

    def _correct_level5(self, generation):
        """CoreELEC places these subtitles from the film's Level 5: give it the right edges when
        that Level 5 is clearly wrong (Correct faulty Dolby Vision Level 5, off by default)."""
        target, unreadable = self._target()
        if target is None:
            kodi.log('Level 5 not checked: %s' % unreadable)
            return
        if override.set_by_override_ini(target.address, _read_text):
            kodi.log('Level 5 left alone: override.ini supplies it for this folder')
            return
        if xbmc.getInfoLabel(coreelec.SCAN_STATE) == '3':
            # CoreELEC only scans films without Level 5 of their own: nothing to correct.
            kodi.log('Level 5 left alone: CoreELEC measured this film itself')
            return
        key = 'level5|' + target.identity
        known = self.memo.get(key)
        if known is None:
            if not self.guard.allowed():
                kodi.log('Level 5 not checked: paused after an interrupted decode')
                return
            try:
                correction, reason = measure.level5_correction(
                    target, self.getTotalTime(), kodi.data_path('ffmpeg.json'),
                    lambda: self._current(generation), self.guard.decoding)
            except Exception as error:  # Unavailable, or Kodi could not say: never a reason to stop
                kodi.log('Level 5 not checked: %s' % error)
                return
            if not self._current(generation):
                return
            kodi.log('Level 5 check: %s' % reason)
            known = override.value_for(*correction) if correction else ''
            self.memo.put(key, known)
        if not known:
            return
        # P3i's per-folder override add-on writes the same setting from override.ini at the start
        # of playback, and saves what it found there to put back afterwards: never write before it.
        wait = self.started + LEVEL5_EARLIEST - time.time()
        if wait > 0 and self.monitor.waitForAbort(wait):
            return
        with self.lock:
            if not self._current(generation):
                return
            applied = self.override.apply(known)
        if applied:
            kodi.log('Level 5 corrected for CoreELEC: %s' % known, always=True)
        else:
            kodi.log('Level 5 not corrected: CoreELEC\'s Level 5 override holds another value '
                     '(override.ini, or another add-on)', always=True)

    def _wait_for(self, condition, seconds, generation, step=0.2):
        """True as soon as condition() holds; False after seconds, or when playback changed."""
        waited = 0.0
        while self._current(generation):
            if condition():
                return True
            if waited >= seconds or self.monitor.waitForAbort(step):
                return False
            waited += step
        return False

    def _target(self):
        """(locate.Target, None) for the playing item, or (None, why it can not be read).

        Resolved once per playback: it names the session memory's entry and is what the file
        analysis reads (a Plex transcode costs one question to the server)."""
        try:
            return locate.resolve(self.getPlayingFile(), stat=xbmcvfs.Stat), None
        except locate.Unavailable as reason:
            return None, str(reason)
        except Exception:  # not playing any more, or Kodi could not say
            return None, 'playing item unknown'

    def _ways(self, video_ratio, current, record, target, unreadable, full_pictures):
        """The ways of measuring for this system, in order of preference."""
        def screen():
            return measure.screen(video_ratio, current, self.monitor.waitForAbort, record)

        def from_file():
            if not self.guard.allowed():
                raise measure.Unavailable('paused after an interrupted decode')
            if target is None:
                raise measure.Unavailable(unreadable)
            try:
                length = self.getTotalTime()
            except Exception:  # not playing any more, or Kodi could not say
                raise measure.Unavailable('playing item unknown')
            hands_over = self.on_coreelec and coreelec.restricts_with_level5(kodi.get_setting, xbmc.getInfoLabel)
            return measure.film(target, length, video_ratio, kodi.data_path('ffmpeg.json'), current, record,
                                self.guard.decoding, full=full_pictures, level5_hands_over=hands_over)

        if self.on_coreelec:
            return [('video file analysis', from_file)]
        return [('screen capture', screen), ('video file analysis', from_file)]

    def _apply(self, generation, layout, picture_ratio, how, started, final=True):
        area, screen_w, screen_h, video_ratio = layout
        gap = geometry.EDGE_GAP if kodi.setting_bool('edge_gap', default=False) else 0.0
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, not handled')
                return
            value = geometry.margin_value(own, area, screen_w / screen_h, video_ratio, picture_ratio, gap)
            changed = self.keeper.apply(value)
        kodi.log('%s picture %.2f in video %.2f on %dx%d, %s, %.1f s; margin %.2f -> %.2f%s' % (
            'settled:' if final else 'first estimate:', picture_ratio, video_ratio, screen_w, screen_h, how,
            time.time() - started, own, value, '' if changed else ' (unchanged)'))

    def _coreelec_places(self, generation):
        """CoreELEC places these subtitles on the picture's edge. With "Small gap from the black bar" on,
        Kodi's margin becomes the gap first (CoreELEC ignores it until its margin option is on),
        then that option is switched on; both are put back after playback."""
        if not kodi.setting_bool('edge_gap', default=False):
            self._restore_if_current(generation, 'CoreELEC places the subtitles')
            return
        with self.lock:
            if not self._current(generation):
                return
            own = self.keeper.own()
            if own is None:
                kodi.log('could not read the subtitle margin, no gap')
                return
            changed = self.keeper.apply(geometry.EDGE_GAP)
            if not self.margin_switch.on():
                self.keeper.restore()
                kodi.log('CoreELEC places the subtitles; no gap, its subtitle margin option is not available')
                return
        kodi.log('CoreELEC places the subtitles with a small gap: margin %.2f -> %.2f%s' % (
            own, geometry.EDGE_GAP, '' if changed else ' (unchanged)'))

    @staticmethod
    def _save_picture(frame, width, height, channels, number):
        try:
            path = os.path.join(kodi.picture_folder(), 'active-area-subtitles-%d.png' % number)
            with open(path, 'wb') as handle:
                handle.write(diagnostics.png(frame, width, height, channels))
            return path
        except Exception as error:  # a diagnostic must never get in the way
            kodi.log('could not save a picture: %r' % error)
            return None

    def _manual_notice(self):
        if self.manual_notice_shown:
            return
        self.manual_notice_shown = True
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32040), kodi.addon().getAddonInfo('icon'), 8000)


def _read_text(path):
    """A small text file's contents, through Kodi's file access (local and network folders), or None."""
    try:
        if not xbmcvfs.exists(path):
            return None
        handle = xbmcvfs.File(path)
        try:
            return handle.read()
        finally:
            handle.close()
    except Exception:  # unreadable: as if there were none
        return None


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def run():
    Service().run()
