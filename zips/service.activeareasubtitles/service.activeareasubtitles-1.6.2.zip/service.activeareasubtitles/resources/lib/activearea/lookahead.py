"""Reading a PC's film ahead of playback, so the scene follower moves the text at the frame of each cut, as P3i does
from the picture's own Level 5 on the box (from the screen alone moves up and down come late: text left in the bar at a
cut into scope, a dark IMAX scene with nobody talking still placed at the scope height). Only where the add-on
reads the file itself (a PC with the shipped decoder, Service.checks.file_first).

The sweep reads a keyframe every SPARSE seconds from the playing position to LEAD seconds ahead, each as the measurement
reads one (faint rows off): its picture from the frame where strongly lit (a weak reading is not believed: dark wide
misreads), with the exact edge where that is strongly lit, or from its Dolby Vision Level 5 where the frame shows
nothing believed and the film's Level 5 was seen to fit its pictures (TRUST_FITS strongly lit clear keyframes whose
Level 5 fits, the measurement's and its own, and none that does not: one that does not and Level 5 places nothing more;
a dim keyframe is no evidence either way: one dim scope keyframe read wide would end Level 5 for the playback). A
picture is always given as the version believed first (the measurement's settled shape), so the map never holds two
versions of one picture with edges a row apart. A weak reading is a lower bound on the picture's height: where trusted
Level 5 says a taller picture it goes by Level 5 (0/0: shows nothing believed). The trust is kept with the cache
(trust, kept): a cached playback decodes none of the measurement's keyframes.

What the sweep reads goes on the map at once, from its keyframes alone: two keyframes in a row of the same picture grow
the stretch; into a wider picture the cut is a coarse cut a frame after the keyframe read before (the text rises up to
a keyframe gap early, inside the old picture, never late into the bar; where the two are further apart than SPARSE and
the second SEARCH_FLOOR ahead of playback the keyframe just before it is read first, as a cut's own keyframe is read in
place of the regular one; nearer playback the two can lie SPARSE and a keyframe gap apart, and it rises up to that
early); into a narrower one the map says nothing between the two (a silent span: the screen grabs
move the text down there, never early into the bar). Every other read is a pending search (Searches): the frames between
two keyframes of different pictures (ffmpeg.Decoder.sequence), where the cut is the first frame of the new picture (into
a narrower one) or the first frame no longer showing the old one (into a wider one), which refines a coarse cut to its
frame or closes a silent span; the keyframes inside a dark run whose cut was found up to its first keyframe (a walk);
the keyframes between two read ones of the same picture where another picture is known (a shot shorter than SPARSE
starting with a keyframe of its own); a carried dark run's frames, for shots of a narrower picture. The sweep reads to
SEARCH_FLOOR ahead first; then the nearest pending search runs where the lead pays for it (a coarse cut whose keyframe
gap passes COARSE_MOST first, and once the film has shown one, the lead kept for the next: Searches), else the sweep
reads on to LEAD. On a laptop's 4K decoding one cut's frames cost about 9 s, and cuts every 3 to 6 s searched before the
next keyframe put the read-ahead behind playback and the text in the bar after half the cuts into scope.

A run of keyframes that show nothing (dark; a weakly lit one of a shape not believed that the next does not confirm is
one too) waits for the keyframe after it: the same picture on both sides carries across where a wrong call can only
leave the text a little high (nothing wider known, or a 0/0 run), its frames searched for shots of a narrower picture
known; different pictures have their cut searched across the run's frames up to DARK_SEARCH apart, the map silent
until then (no coarse cut across a dark run: it could rise far too early); otherwise the stretch ends: the map says
nothing there and the screen grabs decide (holding the old shape over a dark tall scene would be worse: text in a bar
is the worst call, a late move down the lesser one). A run of dark keyframes whose Level 5 is 0/0 is a full picture
only when the keyframe after it shows one (a fade to black says 0/0 too); its cut lies before the run's first keyframe,
so only the frames up to it are decoded and the keyframes inside the run read after (a walk). What it found is a scene
map (scenemap.SceneMap, exact) over the stretches it read, a new one each time it changes: the follower's reader takes
the latest (capture.ScreenReader).

The film is read only while Kodi plays on smoothly (steady.Steady, the playback's one wait), through the playback's one
reader at a time, a batch of reads per open (closed while it waits ahead of playback, so another reader gets its turn),
never while following is off. A read under way stops once Kodi holds, its buffer is low or its time stalls
(Steady.going, asked before every frame); a search stopped short waits to run again (JOB_TRIES), and searches wait
FRAMES_QUIET after a stall or a buffer that fell low (Steady.untroubled), the sweep going on. A seek drops every pending
search and starts a new stretch where playback went, as far ahead of it as a few keyframes cost to read (AHEAD_READS,
measured on its own reads); one back inside what was read keeps the map, and its coarse cuts still ahead are searched
again. A film that changes shape shot by shot fills the map: it then lets go of what lies scenemap.KEPT_BEHIND behind
playback (SceneMap._let_go), and a seek back past that reads there again as after any seek. A reopen of the file that
fails is tried again after a wait (RETRIES, RETRY_WAIT); a failed first open ends the reading. The log says when it
stops and why, and how far ahead of playback it is at each batch.
Every picture is in the video's own shape (non-square pixels). Keyframes far apart (one in many seconds) leave
stretches the screen grabs follow as before.
"""

import collections

from . import detect, libav, pictures, scenemap, steady
from .scenemap import timecode

LEAD = 60.0           # seconds ahead of playback read
SPARSE = 2.0          # seconds between the keyframes read: a scene shorter than this may be left to the screen grabs
IDLE = 1.0            # seconds between looks at the film's time once LEAD ahead
PLAYBACK_JUMP = 5.0   # seconds past the next keyframe asked for beyond which playback jumped ahead (a seek)
WENT_BACK = 0.5       # seconds before where reading began, or the step before's look, from which playback went back
REFILL = 20.0         # seconds of the lead used up before it reads again: a batch of keyframes per open of the file
                      # (not an open for every keyframe, every 2 s)
TRUST_FITS = 5        # strongly lit clear keyframes of different shots whose Level 5 fits their picture before Level 5
                      # places a dark one (the corpus: one film whose Level 5 says a taller picture on a third of its
                      # shots fits 3 shots before its first misfit; 408 of the 416 films whose Level 5 fits every
                      # keyframe the measurement reads are trusted from those alone at 5)
TRUST_APART = 30.0    # seconds of film between two keyframes whose fits both count (keyframes 2 s apart are one shot)
DARK_SEARCH = 20.0    # seconds between the keyframes on both sides of a dark run up to which its frames are searched
RATE = 1.0            # seconds of decoding a second of film's frames costs until a search measured it (UHD on a NAS:
                      # 1.2 to 1.6; 4K HEVC on a laptop, one core: about 5)
READ = 1.0            # seconds of playback a keyframe read costs until the sweep measured one
SEARCH_FLOOR = 8.0    # seconds of lead a pending search must leave at its estimated cost, else the sweep reads first
                      # (in the film simulator's dense cuts at a laptop's 4K costs 6 to 20 s kept every move into scope
                      # on time; at 4 a search estimated too cheap ate the lead)
SHOTS_FLOOR = 20.0    # the same for a search for shots the keyframes did not show (the keyframes between two read ones,
                      # a carried dark run's frames): each pair asked for costs a seek back even where nothing lies
                      # between (1.2 to 1.9 s a step on a laptop's network share); run from SEARCH_FLOOR on, after
                      # nearly every keyframe, they kept the film simulator's dense cuts 10 s ahead, and no cut's frames
                      # could be searched in time
STOP_FLOOR = 4.0      # seconds of lead at which a search under way stops and waits again: room for the next keyframe
                      # and the coarse cut it may bring (two of SPARSE)
LATE = 1.0            # seconds before its span a search must end: what it finds is planned before playback gets there
                      # (EXACT_AHEAD, the screen's lead up to capture.SHOWN_AHEAD_MOST, a look); else it is dropped
COARSE_MOST = 2.1     # seconds of keyframe gap a coarse cut may rise early by before its search goes ahead of nearer
                      # ones: the person accepted the text rising about one keyframe gap of their film early (2 s;
                      # "about 1 to 2 s"), with a few frames for a gap of 2.002 s at 23.976 frames a second; some
                      # encodes have keyframes 5 to 10 s apart
JOB_TRIES = 3         # times a search stopped short (Kodi held, a stall, the lead or playback too near) runs again
SHOTS_MOST = 8        # keyframes read between two read ones at most
INSIDE_FRAMES = 2     # strongly lit frames in a row of a narrower picture that make a shot inside a carried dark run
UNREAD = 0.5          # seconds of frames showing nothing before a narrower picture's first frame from which the map
                      # says nothing between the old picture's last frame and the new one's first (the screen's dim
                      # grabs tell there); shorter, the cut is at the new picture's first frame
WALK_MOST = 12        # keyframes read between two of a run of dark keyframes whose Level 5 is 0/0 before a full
                      # picture, at most (each must be dark with 0/0 or full: else the screen decides after the run's
                      # first keyframe)
RETRIES = 5           # times a failed reopen of the file is tried again (another reader, a source busy for a moment)
RETRY_WAIT = 2.0      # seconds before the first try again, doubled at each
AHEAD_READS = 4.0     # keyframes' cost (measured on its own reads) ahead of playback a stretch begins after a seek:
                      # the first keyframes and a cut search read before playback gets there (in the film simulator at a
                      # second a keyframe, begun at the playing position it stayed behind playback for half a minute
                      # after a seek, and the grabs took 6 of its 10 cuts, 0.47 s in the bar)
AHEAD_MOST = 10.0     # seconds ahead of playback at most
TOLD_EVERY = 15       # keyframes read in a row (no wait between) between two log lines of the lead over playback
TOLD_BELOW = 30.0     # seconds of lead under which those lines are written (above it reading keeps up: no lines)
SEARCHED = {'cut': 'the frames', 'walk': 'the keyframes inside the dark run', 'shots': 'the keyframes',
            'inside': 'the frames of the dark run'}       # what each kind of search reads, for the log
STOPPED = {'ended': 'the playback ended', 'off': 'following is off', 'held': 'playback held or troubled',
           'late': 'too late'}                             # why a search stopped short, for the log


class DarkRun:
    """A run of keyframes that showed nothing, waiting for the keyframe after it to tell: the first one's film time,
    the film times of all (the keyframes a walk reads between), whether every one is dark with trusted Level 5 0/0
    (trusted_zero: the full picture where the keyframe after confirms it), and whether every one's Level 5 is 0/0,
    trusted or not (zero, for the log)."""

    def __init__(self, at, trusted_zero, zero):
        self.first, self.times, self.trusted_zero, self.zero = at, [at], trusted_zero, zero

    def add(self, at, trusted_zero, zero):
        self.times.append(at)
        self.trusted_zero = self.trusted_zero and trusted_zero
        self.zero = self.zero and zero


class Job(collections.namedtuple('Job', 'kind before after dark tries')):
    """A pending search: kind 'cut' (the frames between two keyframes of different pictures, across a dark run or
    not), 'walk' (the keyframes inside a dark run whose cut was found up to its first keyframe), 'shots' (the keyframes
    between two read ones of the same picture) or 'inside' (a carried dark run's frames, for shots of a narrower
    picture); before and after, the keyframes it lies between ((film time, picture) each); dark, the DarkRun between
    them or None; tries, the times it was stopped short."""

    __slots__ = ()

    @property
    def coarse(self):
        """Whether a coarse cut waits on it: into a wider picture, no dark run between."""
        return self.kind == 'cut' and self.dark is None and float(self.after[1]) > float(self.before[1])

    @property
    def gap(self):
        """Seconds between its two keyframes."""
        return self.after[0] - self.before[0]

    @property
    def long(self):
        """A coarse cut whose keyframe gap passes COARSE_MOST: the text would rise more than the person accepted."""
        return self.coarse and self.gap > COARSE_MOST

    @property
    def worth(self):
        """What the text gains by it: 3 a long coarse cut; 2 a coarse cut (up to a keyframe gap early) or a cut across a
        dark run (the grabs read a dark scene dimly or not at all); 1 a silent span into a narrower picture with nothing
        dark between (the grabs move the text down a look after the cut, high meanwhile); 0 shots the keyframes did not
        show. A shot of a wider picture there leaves the text in its bar until a lit grab sees it, but where the lead
        is short a search for it is too late whatever its worth (in the film simulator's dense cuts with short scope
        shots, worth 2 or SHOTS_FLOOR down to 8 placed none more and cost other rows), and each costs a seek back."""
        if self.kind in ('shots', 'inside'):
            return 0
        if self.long:
            return 3
        return 1 if self.kind == 'cut' and self.dark is None and not self.coarse else 2

    def needs(self, cost):
        """The lead it needs to run, at its estimated cost: SEARCH_FLOOR left after it; for a silent span with nothing
        dark between, that after it and one more search like it (the next cut into a wider picture may need the lead:
        in dense cuts on a laptop's 4K decoding these took the searches of the coarse cuts, 3 s more of text high per
        pass); SHOTS_FLOOR after it for shots."""
        if self.worth == 0:
            return SHOTS_FLOOR + cost
        return SEARCH_FLOOR + cost * (2 if self.worth == 1 else 1)

    @property
    def deadline(self):
        """The film time by which playback may come before it is too late to run: LATE before the keyframe before for a
        coarse cut (refined after playback passed that keyframe, the text would go back down for a moment before the
        cut), else LATE before the keyframe after (a silent span closed, a stretch filled in, helps until playback
        leaves it)."""
        return (self.before[0] if self.coarse else self.after[0]) - LATE

    @property
    def reopens(self):
        """Whether it reads keyframes and was stopped short before: the open decoder names one its first try decoded as
        none (the end of the run, or of the keyframes between), so a fresh one reads them."""
        return self.kind in ('walk', 'shots') and self.tries > 0

    def again(self):
        return self._replace(tries=self.tries + 1)


class Searches:
    """The read-ahead's pending searches (Job), one at a time, each in time for what it tells (by its deadline; one that
    can not be any more is dropped). One principle orders them: the lead and the time go first to the coarse cuts, where
    the person sees the text rise early, and to those of a long keyframe gap before all (they rise past what the person
    accepted); what the grabs already do well enough waits for lead to spare. So a long coarse cut runs first; once the
    film has shown one, every other search runs only where it leaves the lead another would need when the sweep finds
    it (its cost, its gap and LATE before its keyframe before, and SEARCH_FLOOR left: found with less it is too late at
    birth); the search playback reaches first goes next, unless that leaves one worth more (Job.worth) too little time;
    a silent span waits for the lead of one more search after it, and shots the keyframes did not show for SHOTS_FLOOR
    (Job.needs). On a laptop's 4K decoding about one cut in three can be searched in dense cuts. It reads nothing: the
    read-ahead runs what next() gives."""

    def __init__(self, dropped=lambda job: None):
        """dropped(job): told of each search dropped (playback came too near)."""
        self._jobs = []
        self._dropped = dropped
        self._longest = None            # the long coarse cut of the widest keyframe gap the film has shown

    def __len__(self):
        return len(self._jobs)

    def add(self, job):
        """A search to run, unless the same one is pending already."""
        if any(other.kind == job.kind and other.before[0] == job.before[0] and other.after[0] == job.after[0]
               for other in self._jobs):
            return
        self._jobs.append(job)
        if job.long and (self._longest is None or job.gap > self._longest.gap):
            self._longest = job

    def clear(self):
        """A seek: nothing pending is worth reading any more (the film's keyframes are as far apart after it)."""
        self._jobs = []

    def next(self, now, lead, cost):
        """The search to run now, taken off the list, or None: now, playback's film time; lead, seconds from it to the
        next keyframe the sweep reads; cost(job), the seconds of playback a search is estimated to take."""
        costs = {id(job): cost(job) for job in self._jobs}
        for job in [job for job in self._jobs if now + costs[id(job)] > job.deadline]:
            self._jobs.remove(job)
            self._dropped(job)
        kept = self._kept(cost)
        for job in sorted(self._jobs, key=lambda job: (not job.long, job.deadline)):
            seconds = costs[id(job)]
            if lead < job.needs(seconds) or (not job.long and lead < kept + seconds):
                continue
            if any(other.worth > job.worth and other.needs(costs[id(other)]) <= LEAD
                   and now + seconds + costs[id(other)] > other.deadline for other in self._jobs):
                continue
            self._jobs.remove(job)
            return job
        return None

    def _kept(self, cost):
        """The lead kept for the next long coarse cut, once the film has shown one: what it needs when the sweep finds
        it at the keyframe after, to end LATE before the one before with SEARCH_FLOOR left; nothing where no lead could
        hold that."""
        if self._longest is None:
            return 0.0
        kept = SEARCH_FLOOR + cost(self._longest) + self._longest.gap + LATE
        return kept if kept <= LEAD else 0.0


Cut = collections.namedtuple('Cut', 'at unread stopped')
Cut.__doc__ = ('What the frames between two keyframes told: at, the cut\'s film time or None; unread, (the old '
               'picture\'s last frame, the new one\'s first) where frames showing nothing lie between, else None; '
               'stopped, why the frames stopped short of the keyframe after (\'held\', \'late\') or None.')


class Trust:
    """The read-ahead's trust in the film's Level 5: whether it may place a keyframe that shows nothing believed.
    Trusted once TRUST_FITS strongly lit clear keyframes of different shots (TRUST_APART apart) had Level 5 that fits
    their picture, the measurement's and the read-ahead's, and none that does not: one that does not and Level 5 places
    nothing more. A dim keyframe is no evidence either way (its edge can read wide). The trust goes to the cache as it
    grows (kept), and a cached playback starts from it: it decodes none of the measurement's keyframes."""

    def __init__(self, video_ratio, log, kept=None, cached=None):
        """log(line): the add-on's log; kept(data): the cache keeps the trust (a fit counted towards TRUST_FITS, a
        refusal); cached: the trust an earlier playback came to (data()), or None."""
        self._video_ratio, self._log = video_ratio, log
        self._kept = kept or (lambda trust: None)
        self._fits = 0                  # strongly lit keyframes whose Level 5 fits their picture; None once one did not
        self._fit_times = []            # the film times of the keyframes counted in _fits (TRUST_APART apart)
        if cached is not None:
            if cached.get('refused'):
                self._fits = None
            else:
                self._fit_times = sorted(cached.get('fits', ()))
                self._fits = len(self._fit_times)

    def learn(self, keyframes):
        """The measurement's keyframes, each judged: one write to the cache after them, where anything changed."""
        kept, self._kept = self._kept, lambda trust: None
        before = (self._fits, len(self._fit_times))
        for keyframe in keyframes:
            self.judge(keyframe)
        self._kept = kept
        if (self._fits, len(self._fit_times)) != before:
            kept(self.data())

    def judge(self, keyframe):
        """A keyframe's Level 5 held against its own clear picture (follow.trust's rule, one keyframe at a time), where
        strongly lit: a dim one's edge can read wide (a dark scope keyframe read 2.20), so it neither counts nor ends
        the trust. A fit counts only TRUST_APART from every one counted before (another shot)."""
        if (self._fits is None or keyframe.level5_pair is None or not keyframe.judgeable
                or not keyframe.sample.strong):
            return
        if keyframe.level5_pair == (0, 0) and pictures.same(detect.shape(keyframe.sample, self._video_ratio),
                                                            self._video_ratio):
            return      # a full frame fits 0/0 whatever Level 5 knows (a file without Level 5 says 0/0 throughout)
        if keyframe.side_bars or not keyframe.fits(keyframe.level5_pair)[0]:
            self._fits = None
            self._log('scenes ahead: Level 5 %d/%d does not fit a keyframe\'s picture, not used' % keyframe.level5_pair)
            self._kept(self.data())
        elif keyframe.at is None or all(abs(keyframe.at - at) >= TRUST_APART for at in self._fit_times):
            # A shot's keyframes fit together or not at all: one counts per shot (three keyframes 2 s apart
            # would earn trust, and in four corpus films Level 5 that fits nearly everywhere says a taller picture than
            # shown on a few shots).
            self._fits += 1
            if keyframe.at is not None:
                self._fit_times.append(keyframe.at)
                if len(self._fit_times) <= TRUST_FITS:
                    self._kept(self.data())
            if self._fits == TRUST_FITS:
                self._log('scenes ahead: Level 5 trusted (%d keyframes %d s apart fit their picture)' % (
                    TRUST_FITS, TRUST_APART))

    def trusted(self):
        return self._fits is not None and self._fits >= TRUST_FITS

    def data(self):
        """The trust so far, as the cache keeps it: {'fits': the film times of the fits counted, 'refused': True once a
        keyframe's picture did not fit}."""
        return {'fits': [] if self._fits is None else list(self._fit_times), 'refused': self._fits is None}

    def note(self):
        """The trust for the log."""
        if self._fits is None:
            return 'Level 5 refused (a keyframe it does not fit)'
        return 'Level 5 %s (%d of %d fits)' % ('trusted' if self.trusted() else 'not trusted yet', self._fits,
                                                TRUST_FITS)


class FrameJudge:
    """What a decoded frame shows, in the video's own shape (non-square pixels), against the pictures the film is
    known to show: those believed (read strongly lit, or known from the measurement), one version of each
    (pictures.Versions: the first, its rows filled in by a later one), and those only known of (the cache's map, the
    map being read: mapped). A weak reading of a believed picture counts; a weak reading is never a picture of its own
    (a dark scene reads wide), and Level 5 places a frame only where the trust says so."""

    def __init__(self, video_ratio, trust, known=(), shown=(), mapped=lambda: []):
        """trust: the read-ahead's Trust; known: shapes the film is known to show (the measurement's settled one),
        believed; shown: shapes a scene map from the cache says the film shows (another picture is known, but a weak
        reading of one is not believed for it); mapped(): the shapes of the map being read."""
        self._video_ratio, self._trust, self._mapped = video_ratio, trust, mapped
        self.believed = pictures.Versions()
        self._cached = list(shown)      # shapes the cache's scene map says the film shows
        for shape in known:
            self.believe(shape)

    def learn(self, keyframes):
        """The measurement's keyframes: the picture of each strongly lit clear one, with its exact edge, believed."""
        for keyframe in keyframes:
            sample = keyframe.sample
            if sample is not None and sample.clear and sample.strong and keyframe.size:
                self.believe(self._shown(keyframe, exact=True))

    def believe(self, shape):
        """One version of each picture: the first believed (the measurement's settled shape comes first), replaced
        only by one with the rows it lacks."""
        if shape:
            self.believed.add(shape)

    def full(self, picture):
        """Whether picture is the whole video frame's."""
        return pictures.same(picture, self._video_ratio)

    def wider_known(self, picture):
        """Whether a picture wider than this one is believed, in the map or in the cache's (the film shows one)."""
        return pictures.wider_than(picture, self.believed, self._mapped(), self._cached)

    def narrower_known(self, picture):
        """Whether a picture narrower than this one is believed, in the map or in the cache's."""
        return pictures.narrower_than(picture, self.believed, self._mapped(), self._cached)

    def narrower_shapes(self, picture):
        """The shapes believed or in the cache's map narrower than picture: only what the film is known to show."""
        return [shape for shape in self.believed + self._cached if pictures.narrower(shape, picture)]

    def picture(self, frame, exact=False):
        """What a decoded frame shows (keyframes.Keyframe, analysed), in the video's own shape: from a strongly lit
        picture (with its exact edge where asked and strongly lit), or a weakly lit one of a shape already believed (a
        weak reading can show a picture wider than it is, a dark scene, never picture where the bars are black: one of
        a shape never seen lit is not believed) unless trusted Level 5 says a taller picture
        (_taller_level5: then Level 5's, or with 0/0 none, for full_if_dark); else from its Level 5 where the film's
        Level 5 is trusted, but never 0/0 (a fade to black says 0/0 too: full_if_dark, confirmed by the keyframe
        after); None where nothing tells. A picture believed is given as its believed version (with rows, the settled
        one first), so one picture never comes in two versions a row apart (the settled
        276/278 against the read-ahead's 276/276 would move the text up into every scope scene)."""
        shape, strong = self.seen_in(frame, exact)
        if shape is not None:
            if strong:
                self.believe(shape)
                return self.believed.find(shape)
            known = self.believed.find(shape)
            if known is not None and not self._taller_level5(frame, shape):
                return known
        level5 = frame.level5_pair
        if level5 is None or level5 == (0, 0) or not frame.size or frame.side_bars or not self._trust.trusted():
            return None
        height = frame.size[1]
        rows = height - level5[0] - level5[1]
        if rows <= 0:
            return None
        return pictures.version(detect.Picture(self._video_ratio * height / rows, level5[0], level5[1], height),
                                self.believed)

    def full_if_dark(self, frame):
        """The full picture for a frame not strongly lit whose trusted Level 5 is 0/0, else None. A weak reading is
        no picture of its own: a dark frame's dark rows read as bar, so it can read as wide as the old scope picture
        while the frame is a dark 16:9 IMAX one (a dark IMAX opening reading weak 2.20 would keep the text at the scope
        height for 6 s). In the corpus no dim keyframe of a film whose Level 5 is trusted carries 0/0 under a weak
        reading of a shape it shows (0 of 1700)."""
        if (frame.level5_pair != (0, 0) or frame.side_bars or not frame.size or not self._trust.trusted()
                or self.seen_in(frame)[1]):
            return None
        return detect.Picture(self._video_ratio, 0, 0, frame.size[1])

    def unbelieved(self, frame):
        """The shape of a weakly lit frame (or one read only with faint rows) whose picture is not believed yet, else
        None."""
        shape, strong = self.seen_in(frame, exact=True)
        if shape is None or strong or self.believed.find(shape) is not None:
            return None
        return shape

    def seen_in(self, frame, exact=False):
        """(the frame's picture, whether strongly lit), or (None, False) where it shows none. A frame that reads unclear
        as the measurement reads it (no faint rows) is read again with them: a soft edge then counts as a weak reading
        (the test rig's clip: its scope keyframes read no edge at all without faint rows). An unclear frame whose
        picture reaches the frame's edge through every bar the film is known to show there is the full picture, as if
        strongly lit (_lit_edge)."""
        sample = frame.sample
        if sample is None or not frame.size:
            return None, False
        if sample.clear:
            return self._shown(frame, exact), sample.strong
        edge = self._lit_edge(frame)
        if edge is not None:
            return edge, True
        if not frame.frame or not frame.analysed:
            return None, False
        width = len(frame.frame) // (3 * frame.analysed)
        soft = detect.analyse(frame.frame, width, frame.analysed, 3, uneven=True, faint=True)
        if not soft.clear:
            return None, False
        return detect.Picture(detect.shape(soft, self._video_ratio)), False

    def kind(self, frame, picture, old, new):
        """What a frame between two keyframes showed, for the log: lit old, weak old, new, new lit at an edge
        (_lit_edge), Level 5 new, dark 0/0 (taken as the full picture), weak 0/0, black 0/0, dark 0/0 not used (Level 5
        not trusted), black, dark, other."""
        shape, strong = self.seen_in(frame)
        if picture is not None:
            if pictures.same(picture, old):
                return 'lit old' if strong else 'weak old'
            if pictures.same(picture, new):
                if shape is not None and strong and not frame.sample.clear:
                    return 'new lit at an edge'
                return 'new' if shape is not None else 'Level 5 new'
            return 'other'
        black = frame.sample is not None and frame.sample.reason == 'black frame'
        if frame.level5_pair == (0, 0):
            if not self._trust.trusted():
                return '%s 0/0 not used' % ('black' if black else 'dark')
            return 'weak 0/0' if shape is not None else 'black 0/0' if black else 'dark 0/0'
        return 'black' if black else 'dark' if shape is None else 'other'

    def _lit_edge(self, frame):
        """The full picture for a frame whose rows from its top or bottom edge are picture through the thinnest bar any
        letterboxed picture the film is known to show has on either side (pictures.lit_at_edge), else None. Such a
        frame reads unclear (one edge lit, the other dark: 'edge not lit across', 'bar too tall'), so it would be a dark
        one, and the map would carry the old scope picture across a 16:9 IMAX scene or leave it to the screen (lit sky
        at the top, dark ground below: the text at the scope height for 10 s). Off where a picture
        known has a bar thinner than detect.EDGE_ROWS (its picture at one edge). In the real-film corpus no keyframe of
        a letterboxed film showed picture through its bar at one edge with a black bar at the other (of 18126
        keyframes in 811 letterboxed films 27 unclear ones are lit at one edge, all in IMAX films, the other edge dark
        picture; none in the 793 films without a full-frame scene)."""
        if not frame.frame or not frame.analysed or not frame.size or frame.side_bars:
            return None
        rows = frame.analysed
        if not pictures.lit_at_edge(frame.frame, len(frame.frame) // (3 * rows), rows, 3,
                                    self.believed + self._mapped() + self._cached, self._video_ratio,
                                    detect.LIMITED_BLACK):
            return None
        return pictures.version(detect.Picture(self._video_ratio, 0, 0, frame.size[1]), self.believed)

    def _taller_level5(self, frame, shape):
        """Whether a weakly lit frame reading shape has trusted Level 5 that says a taller picture (0/0: the full one).
        A weak reading is a lower bound on the picture's height (a dark scene reads wide, never picture where the bars
        are black), so it does not say the wider picture goes on: Level 5 tells (the corpus: dim keyframes of trusted
        films whose Level 5 says taller than their weak reading are within a few rows of their truth)."""
        level5 = frame.level5_pair
        if level5 is None or frame.side_bars or not frame.size or not self._trust.trusted():
            return False
        if level5 == (0, 0):
            return not self.full(shape)
        rows = frame.size[1] - level5[0] - level5[1]
        if rows <= 0:
            return False
        taller = self._video_ratio * frame.size[1] / rows
        return pictures.narrower(taller, shape)

    def _shown(self, frame, exact):
        found = frame.exact if exact else None
        if found is not None and found.strong:
            return detect.picture_of(found, self._video_ratio)
        return detect.Picture(detect.shape(frame.sample, self._video_ratio))


class Lookahead:
    """The read-ahead itself: the loop that reads the film ahead of playback (the sweep and the pending searches) and
    the scene map it builds, judging each frame with its FrameJudge and Level 5 with its Trust."""

    def __init__(self, film, film_time, steady, wait, log, video_ratio, seen=(), wanted=None, known=(), shown=(),
                 trust=None, kept=None):
        """film(): a keyframes.FilmReader for the playing file, not opened; film_time(): Kodi's playing position in
        seconds or None; steady: the playback's steady.Steady (every step waits on it, a read under way asks it whether
        to go on, Kodi's time at every look is told to it); wait(seconds) -> True when Kodi closes; log(line,
        always=False); video_ratio: the video's own shape (a frame's rows count in it: non-square pixels); seen: the
        keyframes the measurement decoded (their Level 5 against their pictures); wanted(): False once following stops
        (nothing read for it then); known: shapes the film is known to show (the measurement's settled one): a weakly
        lit reading of one of them is believed; shown: shapes a scene map from the cache says the film shows: another
        picture is known (the keyframes between two read ones, the frames inside a dark run), but a weak reading of one
        is not believed for it; trust: the trust in Level 5 an earlier playback of the file came to, from the cache
        ({'fits': the film times of the fits counted, 'refused': True once a keyframe's picture did not fit}), or None;
        kept(trust): the cache keeps a new one (a fit counted towards TRUST_FITS, a refusal)."""
        self._film, self._film_time, self._steady = film, film_time, steady
        self._wait, self._log = wait, log
        self._wanted = wanted or (lambda: True)
        self.map = None                 # the latest scene map (scenemap.SceneMap, exact), or None before the first
        self._building = scenemap.SceneMap(exact=True)
        # A cached playback decodes none of the measurement's keyframes: its trust comes from the cache.
        self._trust = Trust(video_ratio, log, kept, trust)
        self._judge = FrameJudge(video_ratio, self._trust, known, shown, lambda: self._building.shapes)
        self._trust.learn(seen)
        self._judge.learn(seen)
        self._searches = Searches(self._dropped)
        self._rate = None               # seconds of decoding per second of film, measured on the frame searches
        self._cost = None               # seconds of playback one keyframe read costs (the latest, never below the mean)
        self._start = None              # the playing position the reading began from (at the start, after a seek), or
                                        # where the map let go of what came before it
        self._kept = None               # the map's kept_from as last taken note of (it lets go only when full)
        self._last = None               # (film time, picture) of the latest keyframe placed in the stretch being read
        self._probe = None              # the film time of the sweep's next keyframe
        self._looked = None             # Kodi's time at the latest step's look
        self._dark = None               # the DarkRun the keyframe after tells (see _sweep)
        self._weak = None               # (film time, shape) of a weakly lit keyframe of a shape not believed yet: believed
                                        # when the keyframe after it agrees (a dark scene's misread varies)
        self._held_back = None          # (film time, picture) of a keyframe read whose coarse cut waits for the keyframe
                                        # just before it (_opens_far)
        self.for_good = False           # stopped for a reason no new start mends (the file, the map full with nothing
                                        # it may let go)
        self._reading = True            # False once LEAD ahead, until REFILL of it was used up
        self._opened = False            # the file was opened once: a failed open after that is tried again
        self._tries = 0                 # failed reopens in a row
        self._told = 0                  # keyframes read since the lead was last logged
        self.keyframes = self.frames = 0

    def trusted(self):
        """Whether the film's Level 5 places keyframes that show nothing believed (Trust)."""
        return self._trust.trusted()

    def trust(self):
        """The trust in Level 5 so far, as the cache keeps it (Trust.data)."""
        return self._trust.data()

    def run(self, current):
        """Reads ahead until current() says no (the playback ended), following stops, or the film can not be read. A
        step at a time: under SEARCH_FLOOR of lead the sweep's next keyframe; else the pending search worth running,
        where playback is untroubled; else the sweep's next keyframe up to LEAD ahead; else a wait."""
        film = why = None
        try:
            while True:
                if not current():
                    why = 'the playback ended'
                    return
                if not self._wanted():
                    why = 'following is off'
                    return
                # Kodi's time told at every step of the wait, this moment's too: a stall seen keeps it waiting.
                if not self._steady.wait(current, self._looking):
                    why = 'the playback ended or Kodi is closing'
                    return
                now = self._film_time()
                if now is None:
                    if self._wait(IDLE):
                        why = 'Kodi is closing'
                        return
                    continue
                kept = self._building.kept_from
                if kept != self._kept:
                    # The map was full and let go of what was read before kept: a seek back there is one to where
                    # nothing was read (it used to stop for good once full, leaving the rest of a dense film to the
                    # grabs, about 1.5 % of the time in the bar).
                    self._log('scenes ahead: the scene map is full, what came before %s let go' % timecode(kept))
                    self._start, self._kept = max(self._start, kept), kept
                if self._probe is None or now < self._start - WENT_BACK or now > self._probe + PLAYBACK_JUMP:
                    self._begin(now)
                    if film is not None:
                        # A fresh decoder: one that decoded keyframes before a seek back refuses them as decoded
                        # already, and the sweep paired the keyframes on both sides of them (40 s apart in the film
                        # simulator: one coarse cut over a whole scene).
                        film.close()
                        film = None
                elif now < self._looked - WENT_BACK:
                    self._back(now)
                self._looked = now
                self._building.playing(now)
                ahead = self._probe - now
                job = None
                if ahead >= SEARCH_FLOOR and self._steady.untroubled(steady.FRAMES_QUIET):
                    job = self._searches.next(now, ahead, self._estimate)
                if job is None and self._held_back is None and (
                        ahead > LEAD or (not self._reading and ahead > LEAD - REFILL)):
                    self._reading = False
                    if film is not None:
                        film.close()            # another reader may take its turn while this one waits
                        film = None
                    if self._wait(IDLE):
                        why = 'Kodi is closing'
                        return
                    continue
                if film is not None and job is not None and job.reopens:
                    film.close()
                    film = None
                if film is None:
                    if job is None:
                        if not self._reading and ahead < TOLD_BELOW:
                            self._log('scenes ahead: reading again, %d s ahead of playback' % ahead)
                        self._told = 0
                        self._reading = True
                    film = self._open()
                    if film is None:
                        if job is not None:
                            self._searches.add(job)     # its turn once the file opens again
                        if self._wait(RETRY_WAIT * 2 ** (self._tries - 1)):
                            why = 'Kodi is closing'
                            return
                        continue
                if job is not None:
                    self._search(film, job, current)
                    continue
                self._told += 1
                if self._told >= TOLD_EVERY and ahead < TOLD_BELOW:
                    self._log('scenes ahead: %d s ahead of playback' % ahead)
                    self._told = 0
                self._sweep(film)
        except libav.Unavailable as reason:
            why = str(reason)
            self.for_good = True
        finally:
            if film is not None:
                film.close()
            if why is not None:
                self._log('scenes ahead: stopped, %s' % why)
            self._log('scenes ahead: %d keyframes and %d frames read' % (self.keyframes, self.frames))

    def _now(self):
        """Kodi's playing position (None where it can not say), told to the steady playback at every look: a stall it
        sees there holds the reads."""
        now = self._film_time()
        self._steady.played(now)
        return now

    def _looking(self, reading=False):
        """A look at every step of the steady playback's wait (Steady.wait's meanwhile): a stall that goes on while the
        reads wait is seen to its end, and they wait HELD_STEADY after that."""
        if not reading:
            self._now()

    def _timed(self, before, after):
        """A keyframe read while playback went from before to after (not across a seek or a pause)."""
        if before is None or after is None or not 0 <= after - before <= AHEAD_MOST:
            return
        spent = after - before
        self._cost = spent if self._cost is None else max(spent, (spent + self._cost) / 2)

    def _estimate(self, job):
        """Seconds of playback a search is estimated to take: a keyframe read for each keyframe it reads back (a walk
        one more than the run has, a shots search two), or the frames it reads first (_first_frames) at the rate the
        frame searches measured (their keyframe in it), a keyframe and RATE until then."""
        read = READ if self._cost is None else self._cost
        if job.kind == 'walk':
            return read * (len(job.dark.times) + 1)
        if job.kind == 'shots':
            return 2 * read
        span = (job.after[0] if job.kind == 'inside' else self._first_frames(job)[0]) - job.before[0]
        return read + span * RATE if self._rate is None else span * self._rate

    def _dropped(self, job):
        self._log('scenes ahead: %s from %s to %s not read, playback came too near' % (
            SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0])))

    def _open(self):
        """The film opened for a batch, or None after a reopen that failed: run tries again after a wait, RETRIES times
        (one failed reopen would end the read-ahead for good). A failed first open raises libav.Unavailable, as does
        the last try."""
        film = self._film()
        try:
            film.open()
        except libav.Unavailable as reason:
            if not self._opened or self._tries >= RETRIES:
                raise
            self._tries += 1
            self._log('scenes ahead: reopening the file failed (%s), trying again in %d s' % (
                reason, RETRY_WAIT * 2 ** (self._tries - 1)))
            return None
        self._opened, self._tries = True, 0
        return film

    def _begin(self, now):
        """A new stretch from the playing position (at the start, after a seek), AHEAD_READS keyframes' cost ahead of it
        once that is measured: what it reads first is still ahead of playback when read. Nothing pending is worth
        reading any more."""
        if self._probe is None:
            why = ''
        elif now < self._start - WENT_BACK:
            why = ', playback went back'
        else:
            why = ', playback %d s past the read-ahead (a seek, or reading too slow)' % (now - self._probe)
        start = max(0.0, now)
        ahead = 0.0 if self._cost is None else min(AHEAD_READS * self._cost, AHEAD_MOST)
        self._log('scenes ahead: reading from %s%s%s' % (
            timecode(start + ahead), ', %d s ahead of playback' % round(ahead) if ahead >= 0.5 else '', why))
        self._building.hold()
        self._searches.clear()
        self._last, self._dark, self._weak, self._held_back = None, None, None, None
        self._start, self._probe = start, start + ahead

    def _back(self, now):
        """Playback went back inside what was read (a seek): the map holds on and the sweep reads on far ahead, so the
        coarse cuts still ahead of playback are searched again where in time (theirs came too late before, or never
        ran: the replay would rise as early as the first playback)."""
        again = [Job('cut', before, after, None, 0) for before, after in self._building.coarse_cuts()]
        again = [job for job in again if job.deadline > now]
        for job in again:
            self._searches.add(job)
        self._log('scenes ahead: playback went back to %s, %d coarse %s ahead to search again' % (
            timecode(now), len(again), 'cut' if len(again) == 1 else 'cuts'))

    # The sweep: keyframes only, in film order, each placed at once (one opening a coarse cut far after the last, well
    # ahead of playback, at the next step, after the keyframe just before it).

    def _sweep(self, film):
        """The sweep's next keyframe, at the probe: read, judged and placed (_place), or the keyframe just before one
        held back (_opens_far) and then that one; nothing where its look sees a stall (one begun while the file opened,
        a second or more on a share): the wait first."""
        before = self._film_time()
        if self._steady.played(before):
            return
        if self._held_back is not None:
            self._place_held_back(film, before)
            return
        keyframe = film.keyframe(self._probe, uneven=True, faint=False)    # read as the measurement reads
        self._probe += SPARSE
        if keyframe.frame is None:
            return                              # the same keyframe as the one before, or none decoded there
        self._timed(before, self._now())
        self.keyframes += 1
        if keyframe.at is None:
            raise libav.Unavailable('the file gives its keyframes no times')
        self._trust.judge(keyframe)
        picture = self._judge.picture(keyframe, exact=True)
        weak, self._weak = self._weak, None
        if picture is None:
            candidate = self._judge.unbelieved(keyframe)
            if candidate is not None:
                if weak is None or not pictures.same(candidate, weak[1]):
                    self._unconfirmed(weak)
                    self._weak = (keyframe.at, candidate)   # told by the next keyframe
                    return
                # Two weakly lit keyframes in a row agree (the test rig's clip: its scope keyframes read weak, and every
                # cut into scope would be left to the screen if no weak reading of a new shape counted).
                self._judge.believe(candidate)
                self._place(weak[0], weak[1])
                picture, weak = candidate, None
        self._unconfirmed(weak)
        if picture is None:
            trusted_zero = self._judge.full_if_dark(keyframe) is not None
            zero = keyframe.level5_pair == (0, 0)
            if self._dark is None:
                self._dark = DarkRun(keyframe.at, trusted_zero, zero)   # the first of the run: the keyframe after tells
            else:
                self._dark.add(keyframe.at, trusted_zero, zero)
            return
        if self._opens_far(keyframe.at, picture, before):
            self._held_back = (keyframe.at, picture)    # placed once the keyframe before it is read, the next step
            return
        self._place(keyframe.at, picture)

    def _opens_far(self, at, picture, now):
        """Whether a keyframe at film time at showing picture would open a coarse cut more than SPARSE after the last
        keyframe placed, SEARCH_FLOOR or more ahead of playback (at film time now): the sweep reads the keyframe at or
        before each probe, and a cut's own keyframe just before a probe is read in place of the regular one before it
        (in the film simulator's dense cuts the text rose 2.48 s early, from the keyframe before that). Nearer, the
        step after could come once playback reached the cut, the map silent there: placed at once, early at worst."""
        last = self._last
        return (last is not None and self._dark is None and float(picture) > float(last[1])
                and at - last[0] > SPARSE + 0.001 and now is not None and at - now >= SEARCH_FLOOR)

    def _place_held_back(self, film, before):
        """The keyframe just before the one held back (_opens_far) read and placed first, then that one: the coarse cut
        rises from the keyframe before it, one keyframe gap early at most. Keyframes further apart than SPARSE give the
        one read before (refused): nothing between."""
        (at, picture), self._held_back = self._held_back, None
        keyframe = film.keyframe(at - 0.001, uneven=True, faint=False)
        if keyframe.frame is not None and keyframe.at is not None and self._last[0] < keyframe.at < at:
            self._timed(before, self._now())
            self.keyframes += 1
            self._trust.judge(keyframe)
            shown = self._judge.picture(keyframe, exact=True)
            if shown is not None:               # a dark or weak one tells nothing here: the cut rises as it would
                self._place(keyframe.at, shown)
        self._place(at, picture)

    def _unconfirmed(self, weak):
        """A weakly lit keyframe of a shape not believed (weak: its film time and shape, or None) that the keyframe
        after it did not confirm: it showed nothing believed, so it is a dark one, and the stretch goes on across it
        only where _across says so (dropped, a dim scope shot reading 2.45 between two 1.90 keyframes would be mapped
        1.90, the text in its bar in the film simulator). Inside a run already begun it is one of the run's
        keyframes, not dark with trusted Level 5 0/0: a walk across the run would meet it decoded already, named as
        none, and never judge it."""
        if weak is None:
            return
        if self._dark is None:
            self._dark = DarkRun(weak[0], False, False)
        else:
            self._dark.add(weak[0], False, False)

    def _place(self, at, picture):
        """A keyframe the sweep read showing picture at film time at, after the last one: on the map at once, from the
        keyframes alone, the reads it needs pending. The stretch grows, across a dark run where _across says so (its
        frames searched for shots of a narrower picture known: _inside) or not (the keyframes between searched where
        another picture is known: _shots); into another picture past a coarse cut or a silent span (_change); across a
        dark run into another picture past a silent span, its frames to search; or the stretch ends at the last
        keyframe and a new one begins at this one."""
        dark, last, self._dark, self._last = self._dark, self._last, None, (at, picture)
        if last is None:
            self._full_if(self._building.begin(at, picture))
        elif dark is not None and not self._across(dark, last, at, picture):
            self._log('scenes ahead: dark from %s to %s, left to the screen (%s)' % (
                timecode(dark.first), timecode(at), self._why_left(dark, last, at, picture)))
            self._full_if(self._building.begin(at, picture))
        elif pictures.same(picture, last[1]):
            self._building.shapes.fill(picture)     # its rows, where a keyframe gave them
            self._building.grow(at)
            if dark is not None:
                # Logged: a shot the map claims for the picture on both sides would show in the log only as grabs of
                # another picture nothing placed.
                self._log('scenes ahead: dark from %s to %s, carried across as picture %.2f' % (
                    timecode(dark.first), timecode(at), float(picture)))
                if self._judge.narrower_known(picture):
                    self._searches.add(Job('inside', last, (at, picture), dark, 0))
            elif self._judge.wider_known(picture) or self._judge.narrower_known(picture):
                self._searches.add(Job('shots', last, (at, picture), None, 0))
        elif dark is None:
            self._change(last, (at, picture))
            self._building.grow(at)
        else:
            self._full_if(self._building.silence(last[0], at, picture))
            self._searches.add(Job('cut', last, (at, picture), dark, 0))
        self.map = self._building.copy()

    def _change(self, before, after):
        """Two keyframes in a row of different pictures with nothing dark between ((film time, picture) each): into a
        wider picture a coarse cut a frame after the first (the text rises up to their gap early, inside the old
        picture, never late into the bar), into a narrower one a silent span between them (the grabs move the text down
        there, never early into the bar); the frames between them a pending search."""
        (start, old), (end, new) = before, after
        if float(new) > float(old):
            self._full_if(self._building.coarse(start, end, new))
            told = 'from the first'
        else:
            self._full_if(self._building.silence(start, end, new))
            told = 'the screen\'s'
        self._log('scenes ahead: picture %.2f between %s and %s, %s till its frames tell' % (
            float(new), timecode(start), timecode(end), told))
        self._searches.add(Job('cut', before, after, None, 0))

    def _across(self, dark, last, at, picture):
        """Whether the stretch goes on across the DarkRun dark from the keyframe last ((film time, picture)) to the one
        at film time at showing picture. The same picture on both sides carries across where a wrong call can only leave
        the text a little high: no wider picture is known (a dark scene of a wider one would put the text in its bar),
        whatever Level 5 said (a Dolby Vision file without Level 5 says 0/0 on every frame: a dark scope scene between
        two IMAX keyframes would be carried as full). Different pictures: the cut is searched across the run's frames
        (_cut: into a narrower picture never early) up to DARK_SEARCH apart, and always into a full picture after a run
        dark with trusted Level 5 0/0 (Level 5 tells it from a fade)."""
        if pictures.same(picture, last[1]):
            return not self._judge.wider_known(picture)
        return (dark.trusted_zero and self._judge.full(picture)) or at - last[0] <= DARK_SEARCH

    def _why_left(self, dark, last, at, picture):
        """Why a run of dark keyframes before at was not carried across nor searched, for the log."""
        zero = 'Level 5 0/0 on every dark keyframe' if dark.zero else 'Level 5 not 0/0 on every dark keyframe'
        if pictures.same(picture, last[1]):
            why = 'the same picture on both sides, a wider one known'
        else:
            why = '%.1f s from the keyframe before, more than %d s' % (at - last[0], DARK_SEARCH)
        return '%s; %s, %s' % (why, zero, self._trust.note())

    @staticmethod
    def _full_if(kept):
        if not kept:
            raise libav.Unavailable('the scene map is full')

    # The pending searches, each telling what the sweep's keyframes could not.

    def _search(self, film, job, current):
        """A pending search run, its reads stopped as soon as the playback ends, Kodi holds or playback is troubled, the
        lead falls to STOP_FLOOR or playback comes within LATE of its span (_limits); stopped short, it waits to run
        again, JOB_TRIES times at most (a seek drops it: _begin)."""
        if job.tries:
            self._log('scenes ahead: %s from %s to %s again' % (
                SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0])))
        go = self._limits(current, job.deadline)
        read = {'cut': self._find, 'walk': self._walked, 'shots': self._shots, 'inside': self._inside}[job.kind]
        if read(film, job, go):
            self.map = self._building.copy()
        elif job.tries < JOB_TRIES:
            self._searches.add(job.again())
        else:
            self._log('scenes ahead: %s from %s to %s not read, stopped short %d times' % (
                SEARCHED[job.kind], timecode(job.before[0]), timecode(job.after[0]), job.tries + 1))

    def _limits(self, current, latest):
        """go() for a search's reads: whether it may read on. go.why says why it stopped: 'ended' (the playback ended),
        'off' (following is off), 'held' (Kodi holds, its buffer is low or its time stalled: Steady.going), 'late' (the
        lead fell to STOP_FLOOR, or playback passed latest)."""
        def go():
            now = self._now()
            if not current():
                go.why = 'ended'
            elif not self._wanted():
                go.why = 'off'
            elif not self._steady.going():
                go.why = 'held'
            elif now is not None and (now > latest or self._probe - now < STOP_FLOOR):
                go.why = 'late'
            else:
                return True
            return False
        go.why = None
        return go

    def _find(self, film, job, go):
        """The cut between two keyframes of different pictures from the frames between them (across the dark run
        between, if any): a coarse cut refined to its frame (SceneMap.refine: one the frames can not tell stays coarse),
        a silent span closed (SceneMap.bridge; into a narrower picture not found, it stays silent). After a run whose
        trusted Level 5 is 0/0 into the full picture the cut lies before the run's first keyframe, which shows the full
        picture already: only the frames up to it are decoded, and the keyframes inside the run wait as a walk (every
        frame up to the lit keyframe of a 6 s dark IMAX opening in UHD came too late after a seek, the text 6 s high);
        not found there, every frame across the run. False when stopped short of an answer."""
        before, after, dark = job.before, job.after, job.dark
        first = self._first_frames(job)
        if first is not after:
            cut = self._cut(film, before, first, go)
            if cut.at is not None:
                self._join(before, after, cut, upto=dark.first)
                self._searches.add(Job('walk', first, after, dark, 0))
                return True
            if cut.stopped is not None:
                return False
        cut = self._cut(film, before, after, go)
        if cut.stopped is not None and cut.at in (None, before[0]):
            return False
        if job.coarse:
            self._building.refine(before[0], after[0], cut.at)
        elif cut.at is not None:
            self._join(before, after, cut)
        return True

    def _first_frames(self, job):
        """The keyframe up to which a cut search reads the frames first ((film time, picture)): after a run whose
        trusted Level 5 is 0/0 into the full picture the run's first keyframe (it shows the full picture already), else
        the keyframe after (job.after itself)."""
        dark, after = job.dark, job.after
        if dark is not None and dark.trusted_zero and self._judge.full(after[1]):
            return dark.first, after[1]
        return after

    def _join(self, before, after, cut, upto=None):
        """A cut found across a silent span between the keyframes before and after: the two stretches join at it
        (SceneMap.bridge), the map silent between the old picture's last frame and the new one's first where frames
        showing nothing lie between, the new picture up to upto only where the frames told no further."""
        last, shown = cut.unread if cut.unread is not None else (None, cut.at)
        self._building.bridge(before[0], after[0], shown, after[1], last, upto)

    def _walked(self, film, job, go):
        """The keyframes inside a dark run whose cut was found up to its first keyframe (job.before): where every one is
        dark with Level 5 0/0 or the full picture, the stretch up to the run and the one from the keyframe after it
        join (SceneMap.bridge); any other, and the map stays silent after the run's first keyframe. False when stopped
        short."""
        walked = self._walk(film, job.dark, job.after[0], go)
        if walked is None:
            return False
        if walked:
            self._building.bridge(job.before[0], job.after[0], job.after[0], job.after[1])
        return True

    def _walk(self, film, dark, end, go):
        """Whether every keyframe inside the DarkRun dark (whose first one showed the full picture) up to the keyframe
        at film time end is dark with Level 5 0/0 or the full picture: any other (a fade back into the old picture,
        another picture), or more than WALK_MOST, and the screen decides after the run's first keyframe. None where go()
        stopped it."""
        times = dark.times + [end]
        for before, after in zip(times, times[1:]):
            inside = self._between(film, before, after, go, WALK_MOST + 1)
            if inside is None:
                self._log('scenes ahead: the keyframes inside the dark run from %s to %s stopped short (%s)' % (
                    timecode(dark.first), timecode(end), STOPPED[go.why]))
                return None
            if len(inside) > WALK_MOST:
                self._log('scenes ahead: the keyframes inside the dark run from %s to %s not all read (more than %d), '
                          'left to the screen' % (timecode(dark.first), timecode(end), WALK_MOST))
                return False
            other = next((keyframe for keyframe in inside if not self._dark_or_full(keyframe)), None)
            if other is not None:
                self._log('scenes ahead: a keyframe at %s inside the dark run from %s to %s is not dark with Level 5 '
                          '0/0, left to the screen' % (timecode(other.at), timecode(dark.first), timecode(end)))
                return False
        return True

    def _dark_or_full(self, keyframe):
        self._trust.judge(keyframe)
        shown = self._judge.picture(keyframe, exact=True)
        if shown is None:
            return self._judge.full_if_dark(keyframe) is not None
        return self._judge.full(shown)

    def _between(self, film, before, after, go, most):
        """The keyframes after film time before and before after, oldest first, read back from after, the latest most
        at most; None where go() said no (asked before every read)."""
        found = []
        seconds = after
        while len(found) < most:
            if not go():
                return None
            keyframe = film.keyframe(seconds - 0.001, uneven=True, faint=False)
            if keyframe.frame is None or keyframe.at is None or not before < keyframe.at < seconds:
                break                           # the one read before (or none between): every one between is found
            self.keyframes += 1
            found.append(keyframe)
            seconds = keyframe.at
        return list(reversed(found))

    def _shots(self, film, job, go):
        """The keyframes between two read ones of the same picture (the latest SHOTS_MOST), so a shot shorter than
        SPARSE starting with a keyframe of its own gets on the map (a scope shot between two 1.90 keyframes would be
        mapped 1.90, the text in its bar; a 0.3 s 1.78 shot between two 2.20 keyframes would keep the text high, a map's
        picture winning over grabs of a narrower one): one showing another picture than the one before it is placed as
        the sweep places a keyframe (_change), its frames a pending search. False when stopped short."""
        found = self._between(film, job.before[0], job.after[0], go, SHOTS_MOST)
        if found is None:
            return False
        last = job.before
        for keyframe in found:
            self._trust.judge(keyframe)
            shown = self._judge.picture(keyframe, exact=True)
            if shown is None:
                continue                        # a dark one tells nothing here
            if not pictures.same(shown, last[1]):
                self._change(last, (keyframe.at, shown))
            last = (keyframe.at, shown)
        if not pictures.same(job.after[1], last[1]):
            self._change(last, job.after)
        return True

    def _inside(self, film, job, go):
        """The shots of a narrower picture among a carried dark run's frames (between two keyframes of the same
        picture), each put on the map (the old picture's keyframe was dark inside a shot lit on screen: the map held the
        text at the old picture's height over it, and a grab of a narrower picture never overrules a map, as its end
        would come unannounced, the text in the bar till the next grab). A shot is INSIDE_FRAMES strongly lit frames in
        a row of a known narrower shape (a weak reading can be wide, a single frame can misread), from the first of them
        to the first frame after its last one that no longer shows it (into the wider picture: early, inside the shot);
        one whose end the frames do not reach is not kept. False when stopped short (nothing kept: its next run finds
        them again)."""
        (start, old), end = job.before, job.after[0]
        # Only shapes the film is known to show, never one a frame of this search would make believed.
        shapes = self._judge.narrower_shapes(old)
        found, run, last_in = [], [], None
        frames, stopped = self._sequence(film, start, end, go)
        for frame in frames:
            self.frames += 1
            if frame.at is None or frame.at <= start:
                continue
            shape, strong = self._judge.seen_in(frame)
            seen = next((known for known in shapes if pictures.same(shape, known)), None) if strong else None
            narrower = seen is not None
            if narrower and (not run or pictures.same(seen, run[0][1])):
                run.append((frame.at, seen))
                if len(run) >= INSIDE_FRAMES:
                    last_in = frame.at
                continue
            if last_in is not None:
                found.append((run[0][0], frame.at, run[0][1]))
            run, last_in = ([(frame.at, seen)] if narrower else []), None
            if frame.at >= end:
                break
        if stopped is not None:
            return False
        for begin, finish, shot in found:
            self._full_if(self._building.add(begin, shot))
            self._full_if(self._building.add(finish, old))
        if found:
            self._log('scenes ahead: inside the dark run from %s to %s, %s' % (
                timecode(job.dark.first), timecode(end), ', '.join(
                    'picture %.2f from %s to %s' % (float(shot), timecode(begin), timecode(finish))
                    for begin, finish, shot in found)))
        return True

    def _cut(self, film, before, after, go):
        """The cut between two keyframes of different pictures, from every frame between them, as Cut: into a wider
        picture the first frame no longer showing the old one, into a narrower one the first showing the new one (into
        a full picture a dark frame whose trusted Level 5 is 0/0 counts, unless the old picture comes back after it).
        Where the frames can not tell (too far apart, dark throughout, stopped short): the first keyframe's time into a
        wider picture (the text up early, inside the old one), None into a narrower one."""
        (start, old), (end, new) = before, after
        wider = float(new) > float(old)
        full = self._judge.full(new)
        gone = shown = unread = None
        last = start                            # the last frame still showing the old picture
        kinds = collections.Counter()           # what the frames showed, for the log
        # Faint rows on: a frame between two keyframes is only told apart from the two pictures known (a B-frame's soft
        # edge reads as no edge at all without them: in an HEVC clip the cut came 1.4 s late).
        frames, stopped = self._sequence(film, start, end, go)
        for frame in frames:
            self.frames += 1
            if frame.at is None or frame.at <= start:
                continue
            picture = self._judge.picture(frame)
            kinds[self._judge.kind(frame, picture, old, new)] += 1
            if picture is not None and pictures.same(picture, old):
                gone = shown = None             # the old picture again: it had not ended yet
                last = frame.at
                continue
            if gone is None:
                gone = frame.at
            if picture is None and full and self._judge.full_if_dark(frame) is not None:
                # Shown: a 16:9 IMAX scene so dark its frames read black, Level 5 0/0 (seen on a PC). A dark scope scene
                # whose Level 5 says 0/0 too would put the text in its bar (3 of 422 well-fitting Dolby Vision films in
                # the corpus show 0/0 on a lit scope keyframe somewhere);
                # trust comes from keyframes of different shots for that (Trust.judge).
                shown = frame.at if shown is None else shown
                continue
            if picture is not None and pictures.same(picture, new):
                shown = frame.at if shown is None else shown
                break
        if wider:
            at = gone if gone is not None and shown is not None else start
        else:
            at = shown
            if shown is not None and gone is not None and shown - gone >= UNREAD:
                unread = (last, min(shown, end))
        if at is not None:
            at = min(at, end)                   # the keyframe after showed the new picture: never later than it
        # What the frames told, for the log: a cut at the keyframe's own frame and one from the keyframe before told
        # apart, and a search stopped short never read as none found.
        if at is None:
            told = 'its frame not found, left to the screen'
        elif at == start:
            told = 'its frame not told, from the keyframe before'
        else:
            told = 'its frame found' + (', the keyframe\'s own' if at == end else '')
        if stopped is not None:
            told += '; frames cut short after %d, %s' % (len(frames), STOPPED[stopped])
        self._log('scenes ahead: picture %.2f from %s (%s)' % (float(new), timecode(end if at is None else at), told))
        if not wider and (at is None or at == end or unread is not None):
            # Why nothing between the two keyframes was taken as the new picture (a dark IMAX opening's frames told
            # apart from a search a seek stopped).
            self._log('scenes ahead: frames from %s to %s: %s; %s' % (
                timecode(start), timecode(end), ', '.join('%d %s' % (count, kind) for kind, count in sorted(
                    kinds.items())) or 'none read', self._trust.note()))
        return Cut(at, unread, stopped)

    def _sequence(self, film, start, end, go):
        """(film.sequence(start, end), why its frames stopped short of end: go.why, 'late' where the file ended, or
        None), its cost measured against Kodi's time (playback goes on meanwhile): seconds of decoding per second of
        film, the higher of the new one and the mean with the one before (a search's cost is estimated by it)."""
        before = self._now()
        frames = film.sequence(start, end, faint=True, go=go)
        after = self._now()
        timed = [frame.at for frame in frames if frame.at is not None]
        stopped = None
        if not timed or timed[-1] < end - 0.001:
            if go.why is None:
                go()                            # short without asking it (the decoder stopped): why, now
            stopped = go.why or 'late'
        # Not across a hold: a seek forward during the frames would count its jump as decoding (27 s ahead, a rate of
        # 60, and no dark run searched across for the rest of the playback).
        if before is not None and after is not None and len(timed) > 1 and stopped not in ('held', 'ended', 'off'):
            spent, decoded = after - before, timed[-1] - timed[0]
            if 0 < spent <= 2 * LEAD and decoded > 0.2:             # not across a seek or a pause
                rate = spent / decoded
                self._rate = rate if self._rate is None else max(rate, (rate + self._rate) / 2)
        return frames, stopped
