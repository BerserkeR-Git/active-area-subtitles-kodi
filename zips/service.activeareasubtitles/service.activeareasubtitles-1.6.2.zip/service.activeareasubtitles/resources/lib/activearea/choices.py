"""The distance rows of the menu: which add-on setting holds each row's choice and its Custom number, the choices'
names (strings.po ids, Custom last), their defaults (as in settings.xml), and the distance a choice gives. The menu
shows these rows and the placement uses their distances, so both read them here, never a copy of their own."""
from . import geometry, kodi


SAME_AS_BARS = 'bars'       # the IMAX scenes row's Same as black bars: the text keeps the scope scenes' height

# The choices' names (strings.po), in the order of geometry's distance lists.
EDGE, SMALL_GAP, LOW, MEDIUM, STANDARD, HIGH, CUSTOM = 32112, 32113, 32114, 32115, 32116, 32117, 32118
AS_ON_THE_DISC, SAME_AS_FULL, SAME_AS_BARS_NAME = 32144, 32170, 32171
TEXT_HINT, IMAGE_HINT = 32121, 32145      # the number pad's hint for a Custom distance


def ahead(choices, distance):
    """A distance function with choices (distances) of its own before distance's: the IMAX scenes row's two."""
    def chosen_distance(choice, custom):
        return choices[choice] if choice in range(len(choices)) else distance(choice - len(choices), custom)
    return chosen_distance


class Row:
    """One distance row. labels: its choices' names, Custom last (custom_index); distance(choice, typed Custom
    number): the distance, or geometry.DISC; default: the choice before anything was chosen; custom_default,
    custom_max, custom_hint: the Custom number before anything was typed, its maximum, the number pad's hint;
    needs: another switch it needs on as well."""

    def __init__(self, key, labels, distance, default, custom_default, custom_max, custom_hint=TEXT_HINT, needs=None):
        self.key, self.custom_key = key, key + '_custom'
        self.labels, self.custom_index = labels, len(labels) - 1
        self.distance, self.default = distance, default
        self.custom_default, self.custom_max, self.custom_hint = custom_default, custom_max, custom_hint
        self.needs = needs


FULL = (EDGE, SMALL_GAP, LOW, MEDIUM, STANDARD, HIGH, CUSTOM)
ROWS = {row.key: row for row in (
    Row('gap_bars', (EDGE, SMALL_GAP, CUSTOM), geometry.bar_distance, 0, geometry.EDGE_GAP, geometry.CUSTOM_RANGE[1]),
    Row('gap_full', FULL, geometry.full_distance, geometry.FULL_DEFAULT, geometry.FULL_DISTANCES[geometry.FULL_DEFAULT],
        geometry.CUSTOM_RANGE[1]),
    Row('gap_imax', (SAME_AS_FULL, SAME_AS_BARS_NAME) + FULL, ahead((None, SAME_AS_BARS), geometry.full_distance), 0,
        geometry.FULL_DISTANCES[geometry.FULL_DEFAULT], geometry.CUSTOM_RANGE[1], needs='follow_scenes'),
    Row('image_bars', (AS_ON_THE_DISC, EDGE, SMALL_GAP, LOW, MEDIUM, CUSTOM),
        lambda choice, custom: geometry.image_distance(choice, geometry.IMAGE_BAR_DISTANCES, custom),
        geometry.IMAGE_DEFAULT, geometry.EDGE_GAP, geometry.IMAGE_CUSTOM_MAX, IMAGE_HINT),
    Row('image_full', (AS_ON_THE_DISC,) + FULL,
        lambda choice, custom: geometry.image_distance(choice, geometry.IMAGE_FULL_DISTANCES, custom),
        geometry.IMAGE_DEFAULT, geometry.EDGE_GAP, geometry.IMAGE_CUSTOM_MAX, IMAGE_HINT))}


def chosen(key):
    """The distance chosen on a row, from the add-on's settings."""
    row = ROWS[key]
    return row.distance(kodi.setting_int(key, row.default), kodi.setting_number(row.custom_key, row.custom_default))


def distances():
    """(content with black bars, full-screen content) for text subtitles."""
    return chosen('gap_bars'), chosen('gap_full')


def scene_distances():
    """(content with black bars, the IMAX scenes of a film that changes shape) for text subtitles: the IMAX scenes
    row, or the full-screen distance while it says Same as full screen or Same as black bars (that one keeps the
    text at the scope scenes' height instead, see keeps_bars_height)."""
    bars, full = distances()
    imax = chosen('gap_imax')
    return bars, full if imax is None or imax == SAME_AS_BARS else imax


def keeps_bars_height():
    """Whether the IMAX scenes of a film with black bars keep the text at the height it has in its scope scenes."""
    return chosen('gap_imax') == SAME_AS_BARS


def following():
    """Whether IMAX scenes are followed (a P3i box from its Level 5 labels, a PC from its screen)."""
    return kodi.setting_bool('follow_scenes', default=True)


def scene_settings():
    """What scene following reads, to tell a change of it."""
    return following(), chosen('gap_imax')


def image_distances():
    """(content with black bars, full-screen content) for image subtitles on P3i builds: a distance, or
    geometry.DISC for "As on the disc"."""
    return chosen('image_bars'), chosen('image_full')
