"""Finding the picture inside a captured video frame.

Everything here is plain Python without Kodi, so it can be tested on its own.
A frame is BGRA (4 bytes a pixel, from xbmc.RenderCapture) or BGR (3, from the
Amlogic capture device); only the green channel is read.
"""

# Common picture shapes. A measured shape close to one of these is snapped to it.
STANDARD_RATIOS = (1.33, 1.37, 1.43, 1.50, 1.66, 1.78, 1.85, 1.90, 2.00, 2.20, 2.35, 2.39, 2.40, 2.55, 2.76)
SNAP_TOLERANCE = 0.04

# Bars are flat black. A row counts as bar while no pixel in it is brighter than
# the bar's own level plus this much (green channel, 0 to 255), and never above BLACK_MAX.
BAR_NOISE = 6
BLACK_MAX = 32
# A lit band at most this share of the frame high with flat black beyond it is a stripe in the
# bar, not the picture's edge: real picture never has a flat black row right behind its edge.
# Without it, a dim full-width stripe at the same height in both bars read as the edge (found
# with synthetic frames by P3i's developer, 2026-10-11).
STRIPE_SHARE = 0.03
# A bar row may hold this share of stray bright pixels (compression noise, dust in a film scan):
# one in a 128-wide sample, two in a 256-wide one. The bar's own level ignores as many.
SPECKLE_SHARE = 0.01
# The first row of picture next to a bar must be lit across most of its width.
# A dark scene still lifts nearly every pixel above the flat black of a bar; a logo
# or credits on black light only a narrow part of the row.
EDGE_COVERAGE = 0.5
# Real bars are the same height at the top and the bottom.
SYMMETRY_ROWS = 2
# Text or a logo in one bar (burned-in subtitles, a channel logo) ends that bar early. Rows lit across
# less than this share, between the shorter bar and the taller one, are taken as such text: the
# taller bar then counts for both, as long as the picture's edge behind it is lit across. A real
# picture edge is lit across most of its width, a dark scene too, so it never reads as text.
TEXT_SHARE = 0.35
# The row where bar meets picture can come out faint and uneven: a smoothed frame grab mixes the two
# (seen in a real Kodi at 512x288, 2026-10-11), and masters soften the edge. Up to this many rows at
# the bar's edge with nothing brighter than BLACK_MAX and at least FAINT_SHARE of the row still at the
# bar's own level count as bar; the edge behind them must still be lit across. A dark scene lifts nearly
# every pixel above the bar, so its rows never count. Errors only make bars taller.
FAINT_ROWS = 2
FAINT_SHARE = 0.5
# Bars taller than this share of the frame (each) are not believed.
MAX_BAR_SHARE = 0.22

AGREEING_SAMPLES = 4

# An empty capture buffer converted to colour comes out as solid green: red and blue near
# zero, green high. Seen from the Amlogic capture device with 4K HDR10 video on P3i
# (2026-10-08), where it can not read the decoder's frames. Real green scenes keep some red
# and blue, so the rule is strict.
EMPTY_GREEN_SHARE = 0.6


class Sample:
    """One analysed frame."""

    def __init__(self, clear, top, bottom, height, reason='', coverage=None):
        self.clear = clear
        self.top = top          # rows of black above the picture
        self.bottom = bottom    # rows of black below the picture
        self.height = height
        self.reason = reason
        self.coverage = coverage  # lit share of the top and bottom picture rows

    def picture_ratio(self, video_ratio):
        """The picture's shape, given the shape of the whole video frame."""
        rows = self.height - self.top - self.bottom
        return video_ratio * self.height / rows

    def __repr__(self):
        extra = ''
        if self.coverage:
            extra += ', lit %.2f/%.2f' % self.coverage
        if self.reason:
            extra += ', ' + self.reason
        return 'Sample(clear=%s, top=%d, bottom=%d, height=%d%s)' % (
            self.clear, self.top, self.bottom, self.height, extra)


def _greens(frame, width, row, channels):
    start = row * width * channels + 1
    return frame[start:start + width * channels:channels]


def empty_green(frame, width, height, channels):
    """True when the frame is the solid green of an empty capture buffer."""
    total = green = 0
    for row in range(0, height, 8):
        base = row * width * channels
        for x in range(0, width, 8):
            b, g, r = frame[base + x * channels], frame[base + x * channels + 1], frame[base + x * channels + 2]
            total += 1
            if r < 12 and b < 12 and g > 60:
                green += 1
    return total > 0 and green / total >= EMPTY_GREEN_SHARE


def _speckles(width):
    return max(1, int(width * SPECKLE_SHARE))


def _is_bar(frame, width, row, channels, black):
    """No more than a few stray pixels above black in this row."""
    return sum(1 for g in _greens(frame, width, row, channels) if g > black) <= _speckles(width)


def _bar_rows(frame, width, height, channels, black, limit, row):
    """Rows of bar from one edge (row(n) is the frame row n rows in), up to limit + 1; lit
    stripes thinner than STRIPE_SHARE with flat black beyond them count as bar."""
    stripe = max(1, int(height * STRIPE_SHARE))
    rows = 0
    while rows <= limit:
        if _is_bar(frame, width, row(rows), channels, black):
            rows += 1
            continue
        beyond = next((n for n in range(rows + 1, min(limit + 1, rows + stripe + 1))
                       if _is_bar(frame, width, row(n), channels, black)), None)
        if beyond is None:
            break
        rows = beyond
    return rows


def analyse(frame, width, height, channels=4):
    """Measure the black bars at the top and bottom of one frame."""
    if not frame or len(frame) < width * height * channels:
        return Sample(False, 0, 0, height, 'no image')
    if empty_green(frame, width, height, channels):
        return Sample(False, 0, 0, height, 'no image (empty capture buffer)')
    limit = int(height * MAX_BAR_SHARE)

    # The bars' own level, from the outermost rows when they are dark at all.
    outer = max(sorted(_greens(frame, width, row, channels))[-1 - _speckles(width)] for row in (0, height - 1))
    bar_level = outer if outer <= BLACK_MAX else 0
    black = min(BLACK_MAX, bar_level + BAR_NOISE)

    top = _faint_rows(frame, width, channels, black, limit, lambda n: n,
                      _bar_rows(frame, width, height, channels, black, limit, lambda n: n))
    bottom = _faint_rows(frame, width, channels, black, limit, lambda n: height - 1 - n,
                         _bar_rows(frame, width, height, channels, black, limit, lambda n: height - 1 - n))

    if top > limit and bottom > limit:
        return Sample(False, top, bottom, height, 'black frame')
    if top > limit or bottom > limit:
        return Sample(False, top, bottom, height, 'bar too tall')
    lit = bar_level + BAR_NOISE // 2
    reason = ''
    if abs(top - bottom) > SYMMETRY_ROWS:
        row = (lambda n: n) if top < bottom else (lambda n: height - 1 - n)
        shorter, taller = min(top, bottom), max(top, bottom)
        if not all(_lit_share(frame, width, row(n), channels, lit) < TEXT_SHARE for n in range(shorter, taller)):
            return Sample(False, top, bottom, height, 'not symmetric')
        reason = 'text in the %s bar' % ('top' if top < bottom else 'bottom')
        top = bottom = taller

    coverage = tuple(_lit_share(frame, width, row, channels, lit) for row in (top, height - 1 - bottom))
    if min(coverage) < EDGE_COVERAGE:
        return Sample(False, top, bottom, height, 'edge not lit across', coverage)
    return Sample(True, top, bottom, height, reason, coverage)


def _faint_rows(frame, width, channels, black, limit, row, rows):
    """rows of bar, with up to FAINT_ROWS faint rows right behind them: none brighter than BLACK_MAX,
    at least FAINT_SHARE still at the bar's level."""
    for _ in range(FAINT_ROWS):
        if rows > limit:
            break
        greens = _greens(frame, width, row(rows), channels)
        if max(greens) > BLACK_MAX or sum(1 for g in greens if g <= black) < FAINT_SHARE * width:
            break
        rows += 1
    return rows


def _lit_share(frame, width, row, channels, lit):
    return sum(1 for g in _greens(frame, width, row, channels) if g > lit) / width


def shape(sample, video_ratio):
    """The picture's shape from a clear sample: the widest standard shape the measurement allows.

    A measured bar can be up to a row short (the row where bar meets picture comes out half lit in
    a smoothed frame grab, or is sampled on the picture's side) and up to half a row long, so the
    picture's true height is between two rows less and one row more than measured. A standard shape
    in that range is used when it is at least as wide as measured (within half a row); otherwise the measured shape,
    taking a row lost to the edges. Snapping to the nearest standard within 4 per cent instead could
    pick a narrower one, putting subtitles low, into the bar (owner's nephew's PC, 2026-10-11)."""
    rows = sample.height - sample.top - sample.bottom
    measured = video_ratio * sample.height / (rows + 0.5)     # a bar sampled half a row long at most
    narrowest = video_ratio * sample.height / (rows + 1)
    widest = video_ratio * sample.height / max(1, rows - 2)
    possible = [standard for standard in STANDARD_RATIOS if narrowest <= standard <= widest]
    if possible and max(possible) >= measured:
        return max(possible)
    # No standard shape as wide as the measurement within its precision (TV series come in 2.05 or
    # 2.10; snapping those to 2.00 put subtitles up to 28 px into the bar at 1440 lines).
    return round(video_ratio * sample.height / max(1, rows - 1), 2)


def snap(ratio):
    """The nearest standard shape, or the measured one if none is close."""
    best = min(STANDARD_RATIOS, key=lambda standard: abs(standard - ratio))
    if abs(best - ratio) / best <= SNAP_TOLERANCE:
        return best
    return round(ratio, 2)


class Agreement:
    """Waits until enough clear samples in a row show the same shape.

    Unclear samples are skipped without breaking the run; a clear sample with
    another shape starts a new run.
    """

    def __init__(self, needed=AGREEING_SAMPLES):
        self.needed = needed
        self.ratio = None
        self.count = 0

    def add(self, ratio):
        if ratio == self.ratio:
            self.count += 1
        else:
            self.ratio = ratio
            self.count = 1
        return self.settled()

    def settled(self):
        return self.count >= self.needed
