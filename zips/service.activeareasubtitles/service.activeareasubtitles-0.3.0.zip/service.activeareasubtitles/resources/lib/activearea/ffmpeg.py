"""Decoding single keyframes from the playing file with the FFmpeg libraries already on the system.

Used where Kodi's own frame grab cannot see the video (CoreELEC, Amlogic's hardware video
plane). The system's libavformat, libavcodec and libavutil are loaded through ctypes and
found without assumptions about where they live: a remembered path first, then the copy
Kodi itself has loaded (from this process's memory map), then the usual folders.

A few FFmpeg structures are read directly. Their layout is only relied on for libavformat 61
and 62 (FFmpeg 7 and 8), and every pointer and size read is checked before it is used. The
playing address can carry an access token: it is never logged or stored.
"""
import ctypes
import glob
import json
import os
import threading
import time

P = ctypes.sizeof(ctypes.c_void_p)
KNOWN_MAJORS = (61, 62)
AVMEDIA_TYPE_VIDEO = 0
AVSEEK_FLAG_BACKWARD = 1
AVDISCARD_NONKEY = 32
AVDISCARD_ALL = 48
MAX_PACKETS_PER_SAMPLE = 600
FOLDERS = ('/usr/lib', '/usr/lib/kodi', '/usr/local/lib', '/lib', '/usr/lib/arm-linux-gnueabihf',
           '/usr/lib/aarch64-linux-gnu', '/usr/lib/x86_64-linux-gnu')


class Unavailable(Exception):
    """The file can not be measured this way. The message is for the log."""


# Finding the libraries -------------------------------------------------------------------

def _loaded_by_kodi(name):
    found = []
    try:
        with open('/proc/self/maps', encoding='utf-8', errors='replace') as handle:
            for line in handle:
                path = line.rsplit(' ', 1)[-1].strip()
                if '/lib%s.so' % name in path and path not in found:
                    found.append(path)
    except OSError:
        pass
    return found


def _candidates(name, remembered):
    first = [remembered[name]] if remembered.get(name) else []
    folders = [p for folder in FOLDERS for p in sorted(glob.glob('%s/lib%s.so*' % (folder, name)), reverse=True)]
    system = []
    try:
        import ctypes.util
        found = ctypes.util.find_library(name)
        system = [found] if found else []
    except Exception:  # find_library runs external tools; any failure only means "not found"
        pass
    seen, order = set(), []
    for path in first + _loaded_by_kodi(name) + folders + system:
        if path and path not in seen:
            seen.add(path)
            order.append(path)
    return order


def _load(name, remembered, check):
    for path in _candidates(name, remembered):
        try:
            library = ctypes.CDLL(path)
            if not check(library):
                continue
        except (OSError, AttributeError):
            continue
        remembered[name] = path
        return library
    remembered.pop(name, None)
    return None


def _read_json(path):
    try:
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_json(path, data):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except OSError:
        pass


def libraries(memory_path):
    """(avformat, avcodec, avutil, description). Raises Unavailable."""
    remembered = _read_json(memory_path)
    before = dict(remembered)
    avformat = _load('avformat', remembered, lambda lib: (lib.avformat_version() >> 16) in KNOWN_MAJORS)
    avcodec = _load('avcodec', remembered, lambda lib: bool(lib.avcodec_version()))
    avutil = _load('avutil', remembered, lambda lib: bool(lib.avutil_version()))
    if remembered != before:
        _write_json(memory_path, remembered)
    if not (avformat and avcodec and avutil):
        raise Unavailable('no FFmpeg 7 or 8 libraries found')
    return avformat, avcodec, avutil, 'FFmpeg (libavformat %d)' % (avformat.avformat_version() >> 16)


# Decoding --------------------------------------------------------------------------------

def _pointer(address, offset=0):
    if not address:
        raise Unavailable('unexpected empty pointer')
    return ctypes.c_void_p.from_address(address + offset).value


def _integer(address, offset):
    return ctypes.c_int.from_address(address + offset).value


def _declare(avformat, avcodec, avutil):
    vp, i = ctypes.c_void_p, ctypes.c_int
    pp = ctypes.POINTER(vp)
    for function, result, arguments in (
            (avformat.avformat_open_input, i, [pp, ctypes.c_char_p, vp, vp]),
            (avformat.avformat_find_stream_info, i, [vp, vp]),
            (avformat.av_find_best_stream, i, [vp, i, i, i, pp, i]),
            (avformat.av_seek_frame, i, [vp, i, ctypes.c_int64, i]),
            (avformat.av_read_frame, i, [vp, vp]),
            (avformat.avformat_close_input, None, [pp]),
            (avcodec.avcodec_alloc_context3, vp, [vp]),
            (avcodec.avcodec_parameters_to_context, i, [vp, vp]),
            (avcodec.avcodec_open2, i, [vp, vp, vp]),
            (avcodec.avcodec_send_packet, i, [vp, vp]),
            (avcodec.avcodec_receive_frame, i, [vp, vp]),
            (avcodec.avcodec_flush_buffers, None, [vp]),
            (avcodec.avcodec_free_context, None, [pp]),
            (avcodec.av_packet_alloc, vp, []),
            (avcodec.av_packet_unref, None, [vp]),
            (avcodec.av_packet_free, None, [pp]),
            (avutil.av_frame_alloc, vp, []),
            (avutil.av_frame_free, None, [pp]),
            (avutil.av_opt_set_int, i, [vp, ctypes.c_char_p, ctypes.c_int64, i]),
            (avutil.av_get_pix_fmt_name, ctypes.c_char_p, [i])):
        function.restype, function.argtypes = result, arguments


class Decoder:
    """One open file. sample(seconds) returns a small BGR frame of its brightness plane.

    Use as a context manager; everything FFmpeg allocated is freed on exit.
    """

    def __init__(self, url, memory_path, width=256, height=144):
        self.avformat, self.avcodec, self.avutil, self.description = libraries(memory_path)
        _declare(self.avformat, self.avcodec, self.avutil)
        self.url, self.out_w, self.out_h = url, width, height
        self.fmt, self.ctx = ctypes.c_void_p(), ctypes.c_void_p()
        self.pkt, self.frame = ctypes.c_void_p(), ctypes.c_void_p()
        self.index = -1

    def __enter__(self):
        try:
            os.setpriority(os.PRIO_PROCESS, threading.get_native_id(), 19)
        except (AttributeError, OSError):
            pass
        try:
            self._open()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def _open(self):
        if self.avformat.avformat_open_input(ctypes.byref(self.fmt), self.url.encode('utf-8'), None, None) < 0:
            raise Unavailable('FFmpeg could not open the file')
        if self.avformat.avformat_find_stream_info(self.fmt, None) < 0:
            raise Unavailable('FFmpeg found no stream information')
        decoder = ctypes.c_void_p()
        self.index = self.avformat.av_find_best_stream(self.fmt, AVMEDIA_TYPE_VIDEO, -1, -1, ctypes.byref(decoder), 0)
        if self.index < 0 or not decoder.value:
            raise Unavailable('no video stream FFmpeg can decode')
        count = _integer(self.fmt.value, 5 * P + 4)
        if not 0 <= self.index < count or count > 256:
            raise Unavailable('unexpected stream count %d' % count)
        stream = _pointer(_pointer(self.fmt.value, 5 * P + 8), self.index * P)
        codecpar = _pointer(stream, P + 8)
        if not codecpar:
            raise Unavailable('no codec parameters')
        self.ctx = ctypes.c_void_p(self.avcodec.avcodec_alloc_context3(decoder))
        if not self.ctx.value or self.avcodec.avcodec_parameters_to_context(self.ctx, codecpar) < 0:
            raise Unavailable('decoder could not be set up')
        # Cheapest decoding that still gives a true picture: one thread, keyframes only,
        # no loop filter (its smoothing does not move the edges of black bars).
        for option, value in ((b'threads', 1), (b'skip_frame', AVDISCARD_NONKEY), (b'skip_loop_filter', AVDISCARD_ALL)):
            self.avutil.av_opt_set_int(self.ctx, option, value, 0)
        if self.avcodec.avcodec_open2(self.ctx, decoder, None) < 0:
            raise Unavailable('decoder would not open')
        self.pkt = ctypes.c_void_p(self.avcodec.av_packet_alloc())
        self.frame = ctypes.c_void_p(self.avutil.av_frame_alloc())
        if not (self.pkt.value and self.frame.value):
            raise Unavailable('out of memory')

    def sample(self, seconds):
        """(frame or None, detail). The frame is BGR, out_w x out_h, grey from the brightness plane."""
        started = time.time()
        self.avformat.av_seek_frame(self.fmt, -1, int(seconds * 1000000), AVSEEK_FLAG_BACKWARD)
        self.avcodec.avcodec_flush_buffers(self.ctx)
        stream_index_at = 36 if P == 8 else 32     # AVPacket: buf, pts, dts (8-byte aligned), data, size, stream_index
        got = False
        for _ in range(MAX_PACKETS_PER_SAMPLE):
            if self.avformat.av_read_frame(self.fmt, self.pkt) < 0:
                break
            try:
                if _integer(self.pkt.value, stream_index_at) == self.index:
                    self.avcodec.avcodec_send_packet(self.ctx, self.pkt)
                    got = self.avcodec.avcodec_receive_frame(self.ctx, self.frame) == 0
            finally:
                self.avcodec.av_packet_unref(self.pkt)
            if got:
                break
        if not got:
            return None, 'no keyframe decoded (%.1f s)' % (time.time() - started)
        return self._small(), '%.2f s' % (time.time() - started)

    def _small(self):
        base = self.frame.value
        data, line = _pointer(base, 0), _integer(base, 8 * P)
        width, height = _integer(base, 9 * P + 32), _integer(base, 9 * P + 36)
        name = (self.avutil.av_get_pix_fmt_name(_integer(base, 9 * P + 44)) or b'').decode('ascii', 'replace')
        depth = next((int(bits) for bits in ('16', '12', '10') if bits in name), 8)
        wide = 2 if depth > 8 else 1
        if not (data and 16 <= width <= 16384 and 16 <= height <= 16384 and line >= width * wide):
            raise Unavailable('unexpected frame layout (%dx%d, %s)' % (width, height, name))
        shift = depth - 8
        out = bytearray()
        for row in range(self.out_h):
            bytes_ = ctypes.string_at(data + (row * height // self.out_h) * line, width * wide)
            for col in range(self.out_w):
                at = (col * width // self.out_w) * wide
                value = ((bytes_[at] | (bytes_[at + 1] << 8)) >> shift) if wide == 2 else bytes_[at]
                out += bytes((value, value, value))
        return bytes(out)

    def close(self):
        if self.frame.value:
            self.avutil.av_frame_free(ctypes.byref(self.frame))
        if self.pkt.value:
            self.avcodec.av_packet_free(ctypes.byref(self.pkt))
        if self.ctx.value:
            self.avcodec.avcodec_free_context(ctypes.byref(self.ctx))
        if self.fmt.value:
            self.avformat.avformat_close_input(ctypes.byref(self.fmt))
