"""The add-on's own menu: a wide window with the status at the top, the switches and buttons in a
list, and the focused row's explanation at the bottom. The values live in Kodi's add-on settings,
so the service and Kodi's own settings window see the same thing.

The list is filled once. A press changes only that row's value, so the highlight and the
explanation never jump; rows that need "Keep subtitles inside the picture" are dimmed while it
is off instead of disappearing. The distance rows show their choice with the margin it gives
in grey before it: left and right choose, OK steps on, and OK on Custom opens the number pad."""
import xbmc
import xbmcgui

from . import coreelec, geometry, hdr, kodi, numberpad

WINDOW = 'activearea-menu.xml'
TITLE, SYSTEM_LABEL, SYSTEM_VALUE, METHOD_LABEL, METHOD_VALUE, LIST = 10, 21, 22, 23, 24, 100
CLOSE_ACTIONS = (10, 92)        # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
LEFT, RIGHT = 1, 2              # ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT
COREELEC_CONDITION = 'System.HasAddon(service.coreelec.settings)'
WINDOWS_CONDITION = 'System.Platform.Windows'
ON, OFF, VERSION = 32104, 32105, 32106
DEFAULTS = {'enabled': True, 'gap_bars': 0, 'gap_full': geometry.FULL_DEFAULT,   # as in settings.xml;
            'image_bars': geometry.IMAGE_DEFAULT, 'image_full': geometry.IMAGE_DEFAULT}  # switches default to off
BAR_CHOICES = (32112, 32113, 32118)                              # On the edge, Small gap, Custom
FULL_CHOICES = (32112, 32113, 32114, 32115, 32116, 32117, 32118)  # ... Low, Medium, Standard, High, Custom
IMAGE_BAR_CHOICES = (32144, 32112, 32113, 32114, 32115, 32118)   # As on the disc, On the edge ... Medium, Custom
IMAGE_FULL_CHOICES = (32144, 32112, 32113, 32114, 32115, 32116, 32117, 32118)   # ... High, Custom
# The rows with a Custom choice: (its index, the setting holding the number, its maximum, the number pad's hint,
# the number before anything was typed).
CUSTOMS = {'gap_bars': (geometry.BAR_CUSTOM, 'gap_bars_custom', geometry.CUSTOM_RANGE[1], 32121, geometry.EDGE_GAP),
           'gap_full': (geometry.CUSTOM, 'gap_full_custom', geometry.CUSTOM_RANGE[1], 32121,
                        geometry.FULL_DISTANCES[geometry.FULL_DEFAULT]),
           'image_bars': (geometry.IMAGE_BAR_CUSTOM, 'image_bars_custom', geometry.IMAGE_CUSTOM_MAX, 32145, geometry.EDGE_GAP),
           'image_full': (geometry.IMAGE_FULL_CUSTOM, 'image_full_custom', geometry.IMAGE_CUSTOM_MAX, 32145, geometry.EDGE_GAP)}
GREY, GREY_DIMMED = 'FF7D828A', '4D7D828A'
# Set on Kodi's home window while the menu is open. On a box the add-on takes a moment to start, and a second
# press of OK meanwhile opened a second menu on top of the first, so Back had to be pressed twice (owner, 2026-10-13).
OPEN = 'activearea.menu.open'
HOME = 10000


class Row:

    def __init__(self, key, label, help_text, switch=False, needs_enabled=False, choices=()):
        self.key, self.label, self.help, self.switch = key, label, help_text, switch
        self.needs_enabled, self.choices = needs_enabled, choices


def rows(condition, p3i=False):
    """The menu's rows for this device, in order. Switches carry a setting id as key. p3i: a P3i build of
    CoreELEC, which places image subtitles itself (the add-on gives it their distances)."""
    found = [Row('enabled', 32002, 32003, switch=True),
             Row('gap_bars', 32107, 32108, needs_enabled=True, choices=BAR_CHOICES),
             Row('gap_full', 32110, 32111, needs_enabled=True, choices=FULL_CHOICES)]
    if p3i and condition(COREELEC_CONDITION):
        found += [Row('image_bars', 32140, 32141, needs_enabled=True, choices=IMAGE_BAR_CHOICES),
                  Row('image_full', 32142, 32143, needs_enabled=True, choices=IMAGE_FULL_CHOICES)]
    if condition(COREELEC_CONDITION):
        found.append(Row('fix_level5', 32102, 32103, switch=True, needs_enabled=True))
    if condition(WINDOWS_CONDITION):
        found += [Row('hdr_apply', 32011, 32012), Row('hdr_restore', 32013, 32014), Row('hdr_steps', 32015, 32016)]
    found += [Row('diagnostics', 32004, 32005, switch=True), Row('check_updates', 32051, 32052)]
    return found


class Menu(xbmcgui.WindowXMLDialog):

    def prepare(self):
        """Everything slow, done before the window opens (show calls it ahead of doModal): CoreELEC's settings,
        the rows and every value. While onInit runs Kodi drops the remote's presses, so with this in onInit a Back
        pressed as the menu appeared on a slow box was lost and needed pressing twice (owner's box, 1.2.0;
        reproduced in the rig with a slowed setup: the first Back never reached onAction)."""
        self.after = None       # an action that needs the menu closed first
        self.addon = kodi.addon()
        self.version = self.addon.getAddonInfo('version')
        self.status = [(kodi.text(string_id), self.addon.getSetting(setting_id))
                       for string_id, setting_id in ((32081, 'status_system'), (32082, 'status_method'))]
        p3i = coreelec.is_p3i(lambda setting: kodi.get_setting(setting, quiet=True), xbmc.getInfoLabel('System.BuildVersion'))
        self.rows = rows(xbmc.getCondVisibility, p3i)
        # Read once: a fresh read straight after a change can still return the old value.
        self.values = {row.key: self._read(row) for row in self.rows if row.switch or row.choices}
        self.customs = {key: self._custom(key) for key in CUSTOMS}
        self.items = []
        for row in self.rows:
            item = xbmcgui.ListItem(kodi.text(row.label))
            item.setProperty('help', kodi.text(row.help))
            if row.key == 'check_updates':
                item.setLabel2(kodi.text(VERSION).format(self.version))
            self.items.append(item)

    def onInit(self):
        """Only puts what prepare read on screen: quick, so the window answers the remote from the start."""
        self.getControl(TITLE).setLabel('%s %s' % (kodi.text(32000), self.version))
        for (label, shown), (text, value) in zip(((SYSTEM_LABEL, SYSTEM_VALUE), (METHOD_LABEL, METHOD_VALUE)),
                                                  self.status):
            self.getControl(label).setLabel(text)
            self.getControl(shown).setLabel(value)
        listing = self.getControl(LIST)
        for item in self.items:
            listing.addItem(item)
        self.show_values()
        self.setFocusId(LIST)

    def _read(self, row):
        default = DEFAULTS.get(row.key, False)
        try:
            if row.choices:
                value = self.addon.getSettingInt(row.key)
                return value if value in range(len(row.choices)) else default
            return self.addon.getSettingBool(row.key)
        except Exception:  # missing or malformed: the default from settings.xml
            return default

    def _custom(self, key):
        _index, setting, maximum, _hint, default = CUSTOMS[key]
        try:
            typed = geometry.custom_distance(self.addon.getSettingNumber(setting), maximum)
        except Exception:  # missing or malformed: the default from settings.xml
            typed = None
        return default if typed is None else typed

    def _distance(self, row):
        """The row's distance, or None for As on the disc."""
        choice = self.values[row.key]
        if row.key == 'gap_bars':
            return geometry.bar_distance(choice, self.customs[row.key])
        if row.key == 'gap_full':
            return geometry.full_distance(choice, self.customs[row.key])
        distances = geometry.IMAGE_BAR_DISTANCES if row.key == 'image_bars' else geometry.IMAGE_FULL_DISTANCES
        return geometry.image_distance(choice, distances, self.customs[row.key])

    def show_values(self):
        for row, item in zip(self.rows, self.items):
            if row.switch:
                item.setLabel2(kodi.text(ON if self.values[row.key] else OFF))
            elif row.choices:
                distance = self._distance(row)
                item.setLabel2('%s\u2039  %s  \u203a' % (
                    '' if distance is None else '[COLOR %s]%.2f[/COLOR]      ' % (
                        GREY_DIMMED if self._dimmed(row) else GREY, distance),
                    kodi.text(row.choices[self.values[row.key]])))
            item.setProperty('dimmed', 'true' if self._dimmed(row) else '')

    def _dimmed(self, row):
        return row.needs_enabled and not self.values['enabled']

    def onClick(self, control_id):
        if control_id != LIST:
            return
        position = self.getControl(LIST).getSelectedPosition()
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        if self._dimmed(row):
            return
        if row.switch:
            wanted = not self.values[row.key]
            self.addon.setSettingBool(row.key, wanted)
            self.values[row.key] = wanted
            self.show_values()
        elif row.choices:
            if self._custom_chosen(row):
                self._enter_custom(row)
            else:
                self._choose(row, (self.values[row.key] + 1) % len(row.choices))
                if self._custom_chosen(row):
                    self._enter_custom(row)
        elif row.key == 'check_updates':
            self.after = row.key            # it may open Kodi's list of updates: closed first
            self.close()
        else:
            getattr(hdr, row.key[len('hdr_'):])()

    def _custom_chosen(self, row):
        return row.key in CUSTOMS and self.values[row.key] == CUSTOMS[row.key][0]

    def _choose(self, row, value):
        self.addon.setSettingInt(row.key, value)
        self.values[row.key] = value
        self.show_values()

    def _enter_custom(self, row):
        _index, setting, maximum, hint, _default = CUSTOMS[row.key]
        typed = numberpad.ask(self.customs[row.key], maximum, hint)
        if typed is not None:
            self.addon.setSettingNumber(setting, typed)
            self.customs[row.key] = typed
            self.show_values()

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.close()
        elif action.getId() in (LEFT, RIGHT):
            position = self.getControl(LIST).getSelectedPosition()
            row = self.rows[position] if 0 <= position < len(self.rows) else None
            if row is None or not row.choices or self._dimmed(row):
                return
            step = 1 if action.getId() == RIGHT else -1
            value = min(len(row.choices) - 1, max(0, self.values[row.key] + step))
            if value != self.values[row.key]:
                self._choose(row, value)


def show():
    """Opens the menu; returns the action to run once it is closed, if any. Opened once: a launch while it
    is already open does nothing."""
    home = xbmcgui.Window(HOME)
    if home.getProperty(OPEN):
        return None
    home.setProperty(OPEN, 'true')
    try:
        menu = Menu(WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')
        menu.prepare()
        menu.doModal()
        after = getattr(menu, 'after', None)
        del menu
    finally:
        home.clearProperty(OPEN)
    return after
