"""The add-on's own menu: a wide window with the status at the top, the switches and buttons in a
list, and the focused row's explanation at the bottom. The values live in Kodi's add-on settings,
so the service and Kodi's own settings window see the same thing.

The list is filled once. A press changes only that row's value, so the highlight and the
explanation never jump; rows that need "Keep subtitles inside the picture" are dimmed while it
is off instead of disappearing."""
import xbmc
import xbmcgui

from . import hdr, kodi

WINDOW = 'activearea-menu.xml'
TITLE, SYSTEM_LABEL, SYSTEM_VALUE, METHOD_LABEL, METHOD_VALUE, LIST = 10, 21, 22, 23, 24, 100
CLOSE_ACTIONS = (10, 92)        # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
COREELEC_CONDITION = 'System.HasAddon(service.coreelec.settings)'
WINDOWS_CONDITION = 'System.Platform.Windows'
ON, OFF, VERSION = 32104, 32105, 32106
DEFAULTS = {'enabled': True}    # as in settings.xml; every other switch is off by default


class Row:

    def __init__(self, key, label, help_text, switch=False, needs_enabled=False):
        self.key, self.label, self.help, self.switch = key, label, help_text, switch
        self.needs_enabled = needs_enabled


def rows(condition):
    """The menu's rows for this device, in order. Switches carry a setting id as key."""
    found = [Row('enabled', 32002, 32003, switch=True),
             Row('edge_gap', 32107, 32108, switch=True, needs_enabled=True)]
    if condition(COREELEC_CONDITION):
        found.append(Row('fix_level5', 32102, 32103, switch=True, needs_enabled=True))
    if condition(WINDOWS_CONDITION):
        found += [Row('hdr_apply', 32011, 32012), Row('hdr_restore', 32013, 32014), Row('hdr_steps', 32015, 32016)]
    found += [Row('diagnostics', 32004, 32005, switch=True), Row('check_updates', 32051, 32052)]
    return found


class Menu(xbmcgui.WindowXMLDialog):

    def onInit(self):
        self.after = None       # an action that needs the menu closed first
        self.addon = kodi.addon()
        version = self.addon.getAddonInfo('version')
        self.getControl(TITLE).setLabel('%s %s' % (kodi.text(32000), version))
        for label, shown, string_id, setting_id in ((SYSTEM_LABEL, SYSTEM_VALUE, 32081, 'status_system'),
                                                    (METHOD_LABEL, METHOD_VALUE, 32082, 'status_method')):
            self.getControl(label).setLabel(kodi.text(string_id))
            self.getControl(shown).setLabel(self.addon.getSetting(setting_id))
        self.rows = rows(xbmc.getCondVisibility)
        # Read once: a fresh read straight after a change can still return the old value.
        self.values = {row.key: self._read(row.key) for row in self.rows if row.switch}
        self.items = []
        listing = self.getControl(LIST)
        for row in self.rows:
            item = xbmcgui.ListItem(kodi.text(row.label))
            item.setProperty('help', kodi.text(row.help))
            if row.key == 'check_updates':
                item.setLabel2(kodi.text(VERSION).format(version))
            self.items.append(item)
            listing.addItem(item)
        self.show_values()
        self.setFocusId(LIST)

    def _read(self, key):
        try:
            return self.addon.getSettingBool(key)
        except Exception:  # missing or malformed: the default from settings.xml
            return DEFAULTS.get(key, False)

    def show_values(self):
        for row, item in zip(self.rows, self.items):
            if row.switch:
                item.setLabel2(kodi.text(ON if self.values[row.key] else OFF))
            item.setProperty('dimmed', 'true' if self._dimmed(row) else '')

    def _dimmed(self, row):
        return row.needs_enabled and not self.values['enabled']

    def onClick(self, control_id):
        if control_id != LIST:
            return
        position = self.getControl(LIST).getSelectedPosition()
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        if self._dimmed(row):
            return
        if row.switch:
            wanted = not self.values[row.key]
            self.addon.setSettingBool(row.key, wanted)
            self.values[row.key] = wanted
            self.show_values()
        elif row.key == 'check_updates':
            self.after = row.key            # it may open Kodi's list of updates: closed first
            self.close()
        else:
            getattr(hdr, row.key[len('hdr_'):])()

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self.close()


def show():
    """Opens the menu; returns the action to run once it is closed, if any."""
    menu = Menu(WINDOW, kodi.addon().getAddonInfo('path'), 'default', '1080i')
    menu.doModal()
    after = getattr(menu, 'after', None)
    del menu
    return after
