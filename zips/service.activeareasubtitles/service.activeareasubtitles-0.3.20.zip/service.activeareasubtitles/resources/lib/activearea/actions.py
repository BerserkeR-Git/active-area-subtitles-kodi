"""Opening the add-on (its menu) and the buttons: checking for updates and the HDR brightness steps."""
import json
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import hdr, kodi, menu, question, updates

# How long Kodi gets to look at its repositories before its list of updates is opened.
UPDATE_WAIT_S = 6
PROBLEM_TEXT = {updates.NO_CONNECTION: 32061, updates.NOT_NOW: 32062, updates.NO_SOURCE: 32063}


def _tell(message):
    question.tell(message)


def _repository_xml():
    try:
        path = xbmcaddon.Addon(updates.REPOSITORY_ID).getAddonInfo('path')
        with open(os.path.join(xbmcvfs.translatePath(path), 'addon.xml'), encoding='utf-8') as handle:
            return handle.read()
    except (RuntimeError, OSError):
        return None


def _auto_update_mode():
    """Kodi's own setting: 0 installs updates by itself, 1 only tells, 2 never looks."""
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
            'params': {'setting': 'general.addonupdates'}})))
        return int(answer['result']['value'])
    except (ValueError, KeyError, TypeError):
        return None


def check_updates():
    installed = kodi.addon().getAddonInfo('version')
    repository = _repository_xml()
    if repository is None:
        _tell(kodi.text(32053))
        return
    try:
        available = updates.latest(repository)
    except updates.UpdateProblem as problem:
        _tell(kodi.text(PROBLEM_TEXT.get(problem.args[0], 32062)))
        return
    if not updates.newer(available, installed):
        _tell(kodi.text(32054).format(installed))
        return
    if not question.ask(kodi.text(32055).format(available, installed), kodi.text(32057), kodi.text(32056)):
        return
    if _auto_update_mode() == 0:
        # Kodi installs it and restarts the add-on by itself, but only once this script has
        # ended, so nothing here may wait for an answer. Short and brief, so Kodi's own
        # "updated" notice that follows is shown in full.
        xbmcgui.Dialog().notification(kodi.text(32000), kodi.text(32058).format(available),
                                      kodi.addon().getAddonInfo('icon'), 3000, False)
        xbmc.executebuiltin('UpdateAddonRepos')
        return
    # Kodi looks at repositories only once a day; this makes it look now.
    xbmc.executebuiltin('UpdateAddonRepos')
    progress = question.waiting(kodi.text(32059))
    monitor = xbmc.Monitor()
    for step in range(UPDATE_WAIT_S):
        progress.update(int(100 * (step + 1) / UPDATE_WAIT_S))
        if progress.cancelled or monitor.waitForAbort(1):
            break
    progress.close()
    _tell(kodi.text(32060))
    xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/,return)')


def main(argv):
    action = argv[1] if len(argv) > 1 else ''
    if action == 'check_updates':
        check_updates()
    elif action == 'hdr_apply':
        hdr.apply()
    elif action == 'hdr_restore':
        hdr.restore()
    elif action == 'hdr_steps':
        hdr.steps()
    elif action == 'settings':
        kodi.addon().openSettings()
    elif menu.show() == 'check_updates':
        check_updates()
