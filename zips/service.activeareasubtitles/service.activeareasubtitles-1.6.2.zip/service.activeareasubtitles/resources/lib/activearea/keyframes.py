"""The playing file's keyframes: the film reader that decodes them, and the Keyframe record each one becomes.

FilmReader is built for one question about one file (a measurement, a scene check, the start-up search, a Level 5
check, the subtitle streams) from its target, the FFmpeg memory path, the currency check, the decode guard and the
priority rule. keyframe(seconds) gives one Keyframe, analysed and with its exact edge where it is clear; keyframes
(positions) gives them one by one, opening the file at the first and closing it at the end; streams() gives the
file's own subtitle streams. Everything decoded runs inside the guard. The decoder (ffmpeg.Decoder) is the reader's
own seam: the tests and the real-film corpus put theirs there. ffmpeg.py makes the Keyframes, so it is imported only
when a reader makes its first decoder.

A Keyframe judges itself: its Level 5 as a pair (no Level 5 in Dolby Vision is the full frame, 0/0), whether it can
judge at all (clear, sized, not uneven) and whether a Level 5 fits its picture, at the exact edge or on the analysed
rows. Its rules are part of the detector version (shapes.DETECTOR_MODULES): the cached Level 5 judgements and scene
verdicts were made with them.
"""
from . import detect, libav

ROWS_APART = 4           # rows of the analysed frame (288) Level 5 may be off by at the top or the bottom without an
                         # exact edge: finer is measuring precision (30 pixels at 2160)
EXACT_ROWS = 2           # rows per 1080 Level 5 may be off by from a strongly lit exact edge
READ_WAIT = 0.1          # seconds between looks while another reader of the playback reads


class Keyframe:
    """One decoded keyframe. frame: the small grey frame (None when no keyframe came out; detail says why); detail:
    the decode's text for the log; level5: its Dolby Vision Level 5 offsets (top, bottom, left, right) or None;
    dovi: whether it carried Dolby Vision metadata at all; size: its own (width, height); at: its film time in seconds,
    None where the decoder could not say. Once analysed: sample (the analysed frame), analysed (the analysed frame's
    rows) and exact (the edge found in its own rows, or None)."""

    def __init__(self, frame, detail, level5=None, dovi=False, size=None, at=None):
        self.frame, self.detail, self.level5, self.dovi, self.size, self.at = frame, detail, level5, dovi, size, at
        self.sample = self.analysed = self.exact = None

    @property
    def level5_pair(self):
        """Level 5 (top, bottom); Dolby Vision without Level 5 is the full frame, (0, 0). None without Dolby Vision
        metadata."""
        if self.level5 is None:
            return (0, 0) if self.dovi else None
        return tuple(self.level5[:2])

    @property
    def side_bars(self):
        return self.level5 is not None and any(self.level5[2:])

    @property
    def judgeable(self):
        """Clear, sized and with even bars: a keyframe whose picture can be held against its Level 5 (uneven bars are
        read as the taller one on both sides, not the film's own shape)."""
        return bool(self.sample is not None and self.sample.clear and self.size and self.sample.reason != 'uneven bars')

    @property
    def shape(self):
        """The analysed picture's shape in the frame's own proportions."""
        return detect.shape(self.sample, self.size[0] / self.size[1])

    @property
    def exact_picture(self):
        """The picture with its exact edge in the frame's own rows (a detect.Picture), when that edge is strongly lit;
        else None."""
        found = self.exact
        if found is None or not found.strong or not self.size:
            return None
        return detect.picture_of(found, self.size[0] / self.size[1])

    def fits(self, level5, exact=True):
        """(whether Level 5 (top, bottom) fits this keyframe's picture, the picture's bars for the log). exact: to
        EXACT_ROWS per 1080 against a strongly lit exact edge where there is one; else, and without exact, to
        ROWS_APART analysed rows (the Level 5 correction judges the analysed rows by design)."""
        height = self.size[1]
        found = self.exact
        if exact and found is not None and found.strong:
            return (max(abs(level5[0] - found.top), abs(level5[1] - found.bottom)) <= EXACT_ROWS * height / 1080,
                    '%d/%d of %d rows' % (found.top, found.bottom, height))
        sample, analysed = self.sample, self.analysed
        return (not any(abs(level5[side] * analysed / height - rows) > ROWS_APART
                        for side, rows in ((0, sample.top), (1, sample.bottom))),
                '%d/%d of %d analysed rows' % (sample.top, sample.bottom, analysed))


class FilmReader:

    def __init__(self, target, memory_path, current, guard, background=True, full=False, decoder=None, lock=None,
                 wait=None):
        """guard(): a context for every decode (guard.DecodeGuard.decoding for the file); background: decoding lowers
        the thread's priority for good; full: whole frames for the diagnostic pictures; decoder: the decoder class
        (ffmpeg.Decoder). lock: the playback's one reader at a time (Service.reads), held from open to close; wait
        (seconds) -> True when Kodi is closing: how a reader waits for another to finish (Kodi's monitor, so a test's
        scheduler sees the wait)."""
        self._target, self._memory_path, self._current, self._guard = target, memory_path, current, guard
        self._background, self._full = background, full
        self._make = decoder
        self._decoder = None
        self._lock, self._wait, self._locked = lock, wait, False
        self.opened = False          # the file was opened (streams: told apart from a file that could not be)

    def _new(self):
        make = self._make
        if make is None:
            from . import ffmpeg
            make = ffmpeg.Decoder
        self._decoder = make(self._target, self._memory_path, full=self._full, background=self._background,
                             current=self._current)

    def _take(self):
        """The playback's one reader at a time: waits while another reads the film (the measurement, a scene check, the
        search, the Level 5 check, the streams), so a slow source never gets two readers at once. Raises
        libav.Unavailable when the work ended or Kodi closes meanwhile."""
        if self._lock is None:
            return
        while not self._lock.acquire(blocking=False):
            if (self._current is not None and not self._current()) or self._wait(READ_WAIT):
                raise libav.Unavailable('the playback moved on while another read ran')
        self._locked = True

    def _give(self):
        if self._locked:
            self._locked = False
            self._lock.release()

    def open(self):
        """The decoder made and the file opened, inside the guard, once no other reader of the playback reads.
        Raises libav.Unavailable."""
        self._take()
        try:
            self._new()
            with self._guard():
                self._decoder.__enter__()
        except BaseException:
            self._give()
            raise
        self.opened = True

    def close(self):
        try:
            if self._decoder is not None:
                self._decoder.close()
        finally:
            self._give()

    @property
    def size(self):
        """(width, height) of the analysed frames."""
        return self._decoder.out_w, self._decoder.out_h

    @property
    def description(self):
        """The decoder's own description (which FFmpeg), for the log."""
        return self._decoder.description

    @property
    def where(self):
        """The file's description for the log (locate.Target.description), '' without a target."""
        return self._target.description if self._target is not None else ''

    def playable(self, length):
        """The part of Kodi's length (seconds) the film plays in, once open (ffmpeg.Decoder.playable); the length as it
        is where the decoder can not say (the real-film corpus's stored frames)."""
        playable = getattr(self._decoder, 'playable', None)
        return playable(length) if playable is not None else length

    @property
    def dovi(self):
        """The decoder can read Dolby Vision metadata at all."""
        return getattr(self._decoder, 'dovi', None)

    def keyframe(self, seconds, uneven=False, faint=True):
        """The Keyframe at or before seconds, analysed (detect.analyse with uneven and faint) and, when clear, with its
        exact edge. Its frame is None when no keyframe came out there. Raises libav.Unavailable."""
        decoder = self._decoder
        with self._guard():
            keyframe = decoder.sample(seconds)
        if keyframe.frame is None:
            return keyframe
        keyframe.analysed = decoder.out_h
        keyframe.sample = detect.analyse(keyframe.frame, decoder.out_w, decoder.out_h, 3, uneven=uneven, faint=faint)
        if keyframe.sample.clear:
            with self._guard():
                keyframe.exact = decoder.exact(keyframe.sample)
        return keyframe

    def sequence(self, seconds, until, faint=True, go=None):
        """Every frame from the keyframe at or before seconds to the first past until (ffmpeg.Decoder.sequence),
        analysed (no exact edge: the shape is what tells a cut), decoded inside the guard; fewer once go() says no.
        Raises libav.Unavailable."""
        decoder = self._decoder
        with self._guard():
            frames = list(decoder.sequence(seconds, until, go=go))
        for frame in frames:
            if frame.frame is not None:
                frame.analysed = decoder.out_h
                frame.sample = detect.analyse(frame.frame, decoder.out_w, decoder.out_h, 3, uneven=True, faint=faint)
        return frames

    def keyframes(self, positions, uneven=False, faint=True):
        """The keyframe at or before each of positions (seconds), or None where none came out; nothing is opened or
        decoded until the first, and a caller that stops early closes the generator, which closes the file."""
        self.open()
        try:
            for seconds in positions:
                keyframe = self.keyframe(seconds, uneven, faint)
                yield keyframe if keyframe.frame is not None else None
        finally:
            self.close()

    def streams(self):
        """The file's own subtitle streams in file order (ffmpeg.Decoder.subtitle_streams), read inside the guard: the
        stream structures are read through ctypes as well. Raises libav.Unavailable."""
        self._take()
        try:
            self._new()
            with self._guard():
                try:
                    self._decoder.__enter__()
                    self.opened = True
                    return self._decoder.subtitle_streams()
                finally:
                    self._decoder.close()
        finally:
            self._give()
