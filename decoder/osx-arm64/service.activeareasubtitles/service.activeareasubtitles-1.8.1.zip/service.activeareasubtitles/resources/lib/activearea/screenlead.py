"""How far the picture on screen runs ahead of Kodi's film time (ScreenLead), measured by the scene follower's reader
on a PC (screenreader.ScreenReader) at the cuts of a map read from the file, and the lead its probes test next. Kept
outside the detector's modules (shapes.DETECTOR_MODULES).
"""

SHOWN_AHEAD = 0.1             # seconds the picture on screen is ahead of the film's time Kodi gives, until the grabs
                              # measured it at the cuts of a map read from the file (in the test rig 0.10 to 0.14 s,
                              # five cuts agreeing); SHOWN_AHEAD_MOST the most believed
SHOWN_AHEAD_MOST = 0.5        # seconds: the most lead believed. Reason not recorded
PROBE_FIRST = 0.25            # seconds of lead the first probe tests
SHOWN_AHEAD_LEAST = -0.2      # seconds: the least lead believed, a picture behind Kodi's time (a display latency
                              # setting); the probes measure it, as a lead taken for 0 there brings every move down
                              # early, into the bar
SHOWN_KEPT = 8                # the latest cuts it is measured from
SHOWN_TIGHT = 0.1             # seconds between the bounds from which the lead is taken halfway between them


class ScreenLead:
    """How far the picture on screen runs ahead of Kodi's film time (a display's latency, Kodi's own step): SHOWN_AHEAD
    until the grabs measured it at the cuts of a map read from the file, then from the bounds each such cut gives (the
    latest SHOWN_KEPT of each kind, the older going where two disagree), never outside SHOWN_AHEAD_LEAST and
    SHOWN_AHEAD_MOST. value is the lead now; probe_target() the lead the next probe's grab tests."""

    def __init__(self):
        self.value = SHOWN_AHEAD
        self._low, self._high = [], []          # [order, seconds]: the latest bounds, in the order measured
        self._order = 0
        self._kept = []                         # (the service's clock, value, low, high) before each measure: undo

    def bounds(self):
        """(the least the lead can be, the most it can be), each None until a cut bounded it."""
        return (max(low for _order, low in self._low) if self._low else None,
                min(high for _order, high in self._high) if self._high else None)

    def measure(self, cut, seen_at, before_at, probe=False, when=None):
        """A cut at film time cut, known to the frame: the grab at film time seen_at showed its new picture, so the
        screen was past the cut (ahead by at least cut - seen_at); the look at before_at (None: no look before it)
        still showed the old one (ahead by less than cut - before_at). A pair no screen can give (behind Kodi, or more
        than SHOWN_AHEAD_MOST ahead) is not taken. probe: the grab was a probe's (pace), which bounds the lead either
        way. when: the service's clock at the sighting, so undo can take it back. True when the lead moved by a log's
        worth (5 ms)."""
        low, high = cut - seen_at, None if before_at is None else cut - before_at
        if low > SHOWN_AHEAD_MOST or (high is not None and (high < SHOWN_AHEAD_LEAST or before_at >= seen_at)):
            return False
        if when is not None:
            self._kept = (self._kept + [(when, self.value, [list(bound) for bound in self._low],
                                         [list(bound) for bound in self._high])])[-SHOWN_KEPT:]
        # Each bound on its own: a grab after the cut (none is taken in the second before a planned move but the probe,
        # pace) bounds the lead below by less than nothing and says nothing; the measure would fall to 0 at the first
        # cut on it, every planned move then a few frames late. A probe's says it either way: a screen behind Kodi's
        # time is measured from it.
        if low >= 0 or (probe and low >= SHOWN_AHEAD_LEAST):
            self._order += 1
            self._low = (self._low + [[self._order, low]])[-SHOWN_KEPT:]
        # A high beyond the most a screen leads says nothing, and would push the telling ones out (the look a second
        # before each planned move gives 0.8 to 1.0 s in the film simulator).
        if high is not None and high <= SHOWN_AHEAD_MOST:
            self._order += 1
            self._high = (self._high + [[self._order, high]])[-SHOWN_KEPT:]
        # Bounds that disagree: the older of the two goes (the lead changed, or one was measured wrong).
        while self._high and self._low:
            least = max(self._low, key=lambda bound: bound[1])
            most = min(self._high, key=lambda bound: bound[1])
            if least[1] <= most[1]:
                break
            (self._low if least[0] < most[0] else self._high).remove(least if least[0] < most[0] else most)
        # The default where the bounds allow it, else a little inside the one it breaks; halfway between them once the
        # probes closed them in to SHOWN_TIGHT (a loose high from the look a second before a move, halved with a low,
        # says 0.5 s in the film simulator).
        low, high = self.bounds()
        guess = SHOWN_AHEAD
        if high is not None:
            guess = min(guess, high - 0.02)
        if low is not None:
            guess = max(guess, low + 0.02)
        if low is not None and high is not None and high - low <= SHOWN_TIGHT:
            guess = (low + high) / 2
        ahead = max(SHOWN_AHEAD_LEAST, min(guess, SHOWN_AHEAD_MOST))
        moved = abs(ahead - self.value) >= 0.005
        self.value = ahead
        return moved

    def shift(self, hop):
        """The count moved by hop (a fresher answer of Kodi's, _FilmClock): the lead measured against the old count is
        that much less against the new one."""
        if hop:
            self._low = [[order, low - hop] for order, low in self._low]
            self._high = [[order, high - hop] for order, high in self._high]
            self.value = max(SHOWN_AHEAD_LEAST, min(self.value - hop, SHOWN_AHEAD_MOST))
            self._kept = [(when, max(SHOWN_AHEAD_LEAST, min(value - hop, SHOWN_AHEAD_MOST)),
                           [[order, bound - hop] for order, bound in low],
                           [[order, bound - hop] for order, bound in high])
                          for when, value, low, high in self._kept]

    def undo(self, since):
        """The lead as it was before the first sighting at or after the service's clock since, with the bounds those
        sightings pushed out (measured against a count that ran on through a stall, each was late by it): True when
        any went."""
        undone = [entry for entry in self._kept if entry[0] >= since - 1e-6]
        if not undone:
            return False
        _when, self.value, self._low, self._high = undone[0]
        self._kept = [entry for entry in self._kept if entry[0] < since - 1e-6]
        return True

    def forget(self):
        """Another layout (Kodi's window changed): its picture may run ahead by another lead; the one believed is where
        it starts, every bound gone."""
        self._low, self._high, self._kept = [], [], []

    def probe_target(self):
        """The lead the next probe tests: PROBE_FIRST before anything is bounded (a screen further ahead is learnt at
        once, and one less far leaves the default as it is: an upper bound above it changes nothing), then halfway
        between the least and the most still possible, a halving search over the film's cuts."""
        if not (self._low or self._high):
            return PROBE_FIRST
        low, high = self.bounds()
        low = SHOWN_AHEAD_LEAST if low is None else low
        high = SHOWN_AHEAD_MOST if high is None else high
        return max(SHOWN_AHEAD_LEAST, min((low + high) / 2, SHOWN_AHEAD_MOST))
