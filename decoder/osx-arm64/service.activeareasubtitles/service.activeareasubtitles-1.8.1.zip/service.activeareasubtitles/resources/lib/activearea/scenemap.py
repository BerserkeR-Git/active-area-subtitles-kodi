"""A film's scene map on a PC: where in the film its picture changes shape, as the scene follower saw it from Kodi's
screen, kept with the file's cache entry so a later playback places the text on time.

A PC sees a cut at its next grab, and on Kodi's positions other than Manual a line already on screen when the margin
changes keeps its place until it ends (stock Kodi lays a line out once). With the map, a later playback writes the
wider picture's margin AHEAD seconds before a cut into a wider scene (no line that spans the cut is laid out low, over
the bar) and the narrower one at the cut itself; where a new margin moves the line on screen at once (Kodi's Manual
position, placement.Layout.manual), MANUAL_AHEAD before it. Every rule of a cut's timing lives here: when a recorded
cut came (observe, from the times of the looks it saw), how long before it a later playback moves (plan), what a
lit grab of a wider picture does against the map (plan), and what a later playback's map replaces (merged). Only the
stretches the follower watched count: a seek, a pause or a jump in the film's time ends a stretch, and outside every
stretch the map says nothing (the follower reads the screen live as on a first playback). A map read ahead of a film
that changes shape shot by shot keeps a window: once it holds CUTS_MOST cuts it lets go of what lies KEPT_BEHIND behind
playback, or after a seek back past that of what lies KEPT_AHEAD ahead of it (_let_go), and says nothing there from then
on.

Values: shapes are detect.Pictures (their own bars), one version of each picture (pictures.Versions); cuts are (film
time, shape index), each stretch starting with one; seen is the list of [start, end] stretches, film time in seconds;
exact_seen the spans of them whose cuts are at their frames (read from the file) in a map that holds looks' cuts too
(the cache's: Plans reads each part by its own rules); coarse_spans the [keyframe before, keyframe after] of each coarse
cut (one into a wider picture not searched to its frame yet, kept COARSE_AFTER after the keyframe before); silent_spans
the [start, end] of each silent span (between two stretches read from the file, where the frames of a cut were not
searched yet or showed nothing: the later stretch begins at its end with the cut's picture); untold the film times of
cuts a frame search could not tell, kept at the keyframe before (into a wider picture across a dark run). All of them go
to the cache.
"""
import bisect

from . import detect, pictures

AHEAD = 7.0            # seconds before a cut into a wider scene its margin is written: longer than nearly every line
MANUAL_AHEAD = 0.25    # the same where a margin moves a line on screen: a look and a half before the cut
                       # (screenreader.FAST_STEP with its grab)
EXACT_AHEAD = 0.08     # the same for a cut read from the file at its frame (lookahead.py): two frames early, for the
                       # film's time counted between Kodi's answers
EXACT_AFTER = 0.04     # seconds after such a cut into a narrower picture its margin is written: a frame late rather
                       # than early into the bar
COARSE_AFTER = 0.04    # seconds after the keyframe before it a coarse cut is kept (a frame: never at the keyframe,
                       # where a stretch begun there would hold two cuts at one time)
EXACT_EVIDENCE = 0.25  # seconds after such a cut a lit grab of the wider picture before it is not taken as the map
                       # missing a cut (a grab of the frame just before it, the screen running ahead of Kodi's time);
                       # only where the new picture is known to show from the cut on (plan)
EPS = 1e-6             # film times compared at a planned moment itself: a wake at when - ahead plans at when
LOOKS_KEPT = 8         # times of the latest looks kept while recording (a cut's first sighting is a look or two back)
LOOK_JUMP = 2.0        # seconds between two looks beyond which the film's time jumped (a seek Kodi did not report)
NEAR_BEFORE = 2.0      # seconds before and
NEAR_AFTER = 3.0       # after a known cut in which a PC looks at the screen at its fast pace
SHAPES_MOST = 8        # shapes and
CUTS_MOST = 600        # cuts a map keeps (a two-hour IMAX film has a few dozen); a stretch ends where they run out,
                       # but a map read ahead lets go of what lies behind playback first (_let_go)
KEPT_BEHIND = 300.0    # seconds behind playback a full map read ahead keeps: a seek back lands in it, further back the
                       # read-ahead reads again; far more than anything it still changes behind playback (a search
                       # across a dark run, DARK_SEARCH). A film that changes shape shot by shot fills the map in under
                       # an hour (the film simulator's dense pattern at 45 minutes), and the read-ahead stopped there
KEPT_AHEAD = 120.0     # seconds ahead of playback a full map read ahead keeps where nothing lies KEPT_BEHIND behind it:
                       # the read-ahead reads lookahead.LEAD (60 s) ahead, so more only after a seek back past what it
                       # kept (read again as playback nears it)
TAIL = 2.0             # seconds at the end of a stretch a later playback's map does not claim when merged: a cut into a
                       # narrower scene counts only at its second grab (two looks at the slow pace), so a stretch that
                       # ended (a pause, a seek) just after one still shows the old shape there


class SceneMap:

    def __init__(self, shapes=(), cuts=(), seen=(), exact=False, exact_seen=(), coarse=(), silent=(), untold=()):
        """exact: the cuts are at their frames, read from the file (lookahead.py), not at the looks that saw them;
        exact_seen: where only some are, the spans of seen that hold those; coarse: the spans of its coarse cuts;
        silent: its silent spans (silence, bridge); untold: the times of the cuts a frame search could not tell
        (bridge)."""
        self.exact = exact
        self.exact_seen = sorted([float(start), float(end)] for start, end in exact_seen)
        self.coarse_spans = sorted([float(start), float(end)] for start, end in coarse)
        self.silent_spans = sorted([float(start), float(end)] for start, end in silent)
        self.untold = sorted(float(at) for at in untold)
        self.full = False                   # CUTS_MOST or SHAPES_MOST reached while recording: nothing more is watched
        self.kept_from = None               # the film time a map read ahead holds from since it let go of what came
                                            # before (_let_go), or None
        self._playing = None           # playback's film time, around which a full map lets go (playing), or None: it
                                       # never does
        self.shapes = pictures.Versions(shapes)
        self.cuts = sorted((float(at), int(index)) for at, index in cuts)
        self.seen = sorted([float(start), float(end)] for start, end in seen)
        self._open = None              # the stretch being watched now: [start, end], or None
        self._showing = None           # the shape index on screen in it
        self._looks = []               # the film times of its latest looks, newest last
        self._latest = None            # the latest cut kept in it: (film time, shape index)

    def __bool__(self):
        return bool(self.seen)

    # Recording.

    def observe(self, at, picture, back=0):
        """A look at film time at, the follower placing for picture, first seen back looks ago (a narrower picture
        needs two grabs: its first came a look before). A look after a jump in time starts a stretch of its own. A cut
        into a wider picture is kept at the look before its first sighting, the earliest it can have come (the text
        then moves up early at a later playback, inside the narrower picture, never late into the bar); one into a
        narrower picture at its first sighting, never earlier (moving down early would put the text in the bar). The
        times are the looks' own, whatever the pace."""
        if self.full:
            return
        if self._open is not None and not (self._open[1] - 0.001 <= at <= self._open[1] + LOOK_JUMP):
            self.hold()
        index = self.shapes.add(picture, SHAPES_MOST)   # one version per picture: its rows over a grab's shape without
        if index is None:                       # no room for another shape: the map ends before it
            self.full = True
            self.hold()
            return
        if self._open is None:
            if not self._cut(at, index):
                return
            self._open = [at, at]
            self.seen.append(self._open)
            self._showing = index
            self._looks = [at]
            self._latest = (at, index)
            return
        previous, self._open[1] = self._open[1], at
        self._looks = (self._looks + [at])[-LOOKS_KEPT:]
        if index != self._showing:
            wider = pictures.wider_number(self.shapes[index], self.shapes[self._showing])
            look = -2 - back if wider else -1 - back
            when = self._looks[look] if len(self._looks) >= -look else self._open[0]
            when = max(self._open[0], when)
            if self._latest is not None and when <= self._latest[0] + 0.001:
                # Kept at or before the stretch's latest cut (its first look's picture came from before a seek, the
                # grab unclear): this sighting replaces that cut. Two cuts at one time would be told apart by the
                # shapes' order, and the stale picture could win for the whole stretch.
                self.cuts.remove(self._latest)
                when = self._latest[0]
            if not self._cut(when, index):
                self._open[1] = previous        # the map ends before the cut it could not keep
                self.hold()
                return
            self._showing = index
            self._latest = (when, index)

    def hold(self):
        """Kodi held the picture still (a pause, a seek): the stretch watched so far ends."""
        self._open = None

    def _cut(self, at, index):
        """True when kept; at CUTS_MOST nothing more is (full), unless the map can make room (a map read ahead:
        _let_go)."""
        if len(self.cuts) >= CUTS_MOST and not self._let_go():
            self.full = True
            return False
        bisect.insort(self.cuts, (at, index))
        return True

    def _let_go(self):
        """Room made in a full map read ahead (playing): what lies KEPT_BEHIND behind playback goes, else what lies
        KEPT_AHEAD ahead of it (a seek back past what was kept, its reading begun anew there). True when room was
        made. Only while a stretch is read: a map read ahead gets its cuts in one (begin, add)."""
        if self._playing is None or self._open is None:
            return False
        return self._let_go_behind(self._playing - KEPT_BEHIND) or self._let_go_ahead(self._playing + KEPT_AHEAD)

    def _let_go_behind(self, floor):
        """Every cut before the latest one at or before film time floor goes, with the stretches that ended before that
        cut and the spans and untold cuts begun before it; a stretch holding it begins at it (kept_from). From that cut
        on the map answers as before (its cuts are one sorted list whichever stretch holds a time), but what looks back
        from a time sees nothing before it: in its first NEAR_AFTER, a move shown counted EXACT_AFTER late, the next
        move and a cut near, and a lit grab's quiet after it (EXACT_EVIDENCE: the grab then wins, the text higher).
        Each stretch still begins with the cut that sets its picture: a merge into the cache reads a stretch from its
        start, and one left reaching back over cuts let go would claim them and carry an older map's picture over
        them. Never the stretch being read (the read-ahead reads from the Kodi time it tells playing)."""
        floor = min(floor, self._open[1])
        latest = bisect.bisect_right(self.cuts, (floor + EPS, float('inf'))) - 1
        if latest < 0:
            return False
        kept = self.cuts[latest][0]
        first = bisect.bisect_left(self.cuts, (kept, -1))
        if first == 0:
            return False
        del self.cuts[:first]
        # In place: the stretch being read is one of them (_open).
        self.seen[:] = [span for span in self.seen if span[1] >= kept]
        for span in self.seen:
            span[0] = max(span[0], kept)
        self.exact_seen = [[max(start, kept), end] for start, end in self.exact_seen if end >= kept]
        self.coarse_spans = [span for span in self.coarse_spans if span[0] >= kept]
        self.silent_spans = [span for span in self.silent_spans if span[0] >= kept]
        self.untold = [at for at in self.untold if at >= kept]
        self.kept_from = kept
        return True

    def _let_go_ahead(self, ceiling):
        """Every cut after film time ceiling goes, the stretches ending before the first of them (as a merge ends a map
        that ran out of cuts), with the spans whose cut went. Never the stretch being read."""
        ceiling = max(ceiling, self._open[1])
        first = bisect.bisect_right(self.cuts, (ceiling + EPS, float('inf')))
        if first >= len(self.cuts):
            return False
        gone = self.cuts[first][0]
        del self.cuts[first:]
        self.seen[:] = [span for span in self.seen if span[0] <= gone - 0.001]
        for span in self.seen:
            span[1] = min(span[1], gone - 0.001)
        self.exact_seen = [[start, min(end, gone - 0.001)] for start, end in self.exact_seen if start <= gone - 0.001]
        self.coarse_spans = [span for span in self.coarse_spans if _cut_of(self.cuts, span) is not None]
        self.silent_spans = [span for span in self.silent_spans if span[1] < gone]
        self.untold = [at for at in self.untold if at < gone]
        return True

    # Building from the file (lookahead.py): cuts at their frames, stretches as read.

    def begin(self, at, picture):
        """A stretch read from film time at, showing picture; False when the map is full."""
        self._open = [at, at]
        self.seen.append(self._open)
        return self.add(at, picture)

    def add(self, at, picture):
        """A cut at film time at into picture, in the stretch being read; False when the map is full (CUTS_MOST,
        SHAPES_MOST). A shape with its rows replaces the same picture kept without them."""
        index = self.shapes.add(picture, SHAPES_MOST)
        if index is None or not self._cut(at, index):
            return False
        return True

    def grow(self, at):
        """The stretch being read reaches film time at."""
        self._open[1] = at

    def playing(self, at):
        """Playback is at film time at (the read-ahead tells it at every step): once full, the map makes room around it
        (_let_go). The follower plans only ahead of playback."""
        self._playing = at

    def coarse(self, start, end, picture):
        """A cut into a wider picture known only to lie between the keyframes at film times start and end: kept
        COARSE_AFTER after start (the text rises up to the gap early, inside the narrower picture), its span kept until
        refine finds its frame. Read again (a seek back), it changes nothing where the map has it already, coarse or at
        its frame: a second copy would stay early once the first was refined. False when the map is full."""
        index = self.shapes.index_of(picture)
        if index is not None and (self._spans(start, end) or any(
                start + 0.001 < when <= end + 0.001 and shown == index for when, shown in self.at_frames())):
            return True
        if not self.add(start + COARSE_AFTER, picture):
            return False
        bisect.insort(self.coarse_spans, [start, end])
        return True

    def refine(self, start, end, at):
        """The coarse cut between the keyframes at start and end found at its frame, film time at: moved there, its span
        forgotten (every copy of it). A search that could not tell (at not after start: its frames never showed the new
        picture) leaves it coarse. True when moved."""
        spans = self._spans(start, end)
        if not spans or not start + 0.001 < at <= end + 0.001:
            return False
        index = _cut_of(self.cuts, spans[0])[1]
        coarse = spans[0][0] + COARSE_AFTER
        for span in spans:
            self.coarse_spans.remove(span)
        self.cuts = [entry for entry in self.cuts
                     if not (entry[1] == index and abs(entry[0] - coarse) < COARSE_AFTER / 2)]
        bisect.insort(self.cuts, (at, index))
        return True

    def _spans(self, start, end):
        """The coarse spans between the keyframes at start and end."""
        return [one for one in self.coarse_spans if abs(one[0] - start) < 0.001 and abs(one[1] - end) < 0.001]

    def silence(self, start, end, picture):
        """Nothing said between the keyframes at film times start and end (a cut into a narrower picture not searched
        yet, or one across a dark run: the grabs decide there), picture from end on: the stretch holding start ends
        there and goes on from end (as the stretch being read, where it was that one), the silent span kept. False
        when the map is full or no stretch holds start."""
        span = self._newest([one for one in self.seen if one[0] - 0.001 <= start <= one[1] + 0.001])
        if span is None or not self.add(end, picture):
            return False
        after = [end, max(span[1], end)]
        span[1] = start
        self.seen.append(after)
        self.seen.sort()
        if self._open is span:
            self._open = after
        self._keep_silent(start, end)
        return True

    def _keep_silent(self, start, end):
        if not any(abs(one[0] - start) < 0.001 and abs(one[1] - end) < 0.001 for one in self.silent_spans):
            bisect.insort(self.silent_spans, [start, end])

    def bridge(self, end, start, cut, picture, last=None, upto=None):
        """A cut found after the stretches around it were read (a search Kodi's hold stopped, tried again): the stretch
        ending at film time end and the one begun at start (showing picture there) become one with the cut at cut
        into picture; where the frames before the cut showed nothing (last: the old picture's last frame) the first
        grows to last only, the new picture from the cut, silent between; where only the frames up to upto told it (a
        dark run whose keyframes after were not all read), the new picture from the cut to upto, the second stretch as
        it was. A cut into the picture the first stretch ends in changes nothing: the two join without it. A cut at end
        itself is one the frames could not tell (lookahead keeps one into a wider picture at the keyframe before):
        untold, none at its frame. The silent span between the two, if any, is closed. False where the two are not
        there (a seek began anew)."""
        first = self._newest([span for span in self.seen if abs(span[1] - end) < 0.001])
        second = self._newest([span for span in self.seen if abs(span[0] - start) < 0.001])
        index = self.shapes.index_of(picture)
        begun = next((entry for entry in self.cuts if abs(entry[0] - start) < 0.001 and entry[1] == index), None)
        if first is None or second is None or first is second or begun is None or not end <= cut <= start:
            return False
        ending = [entry[1] for entry in self.cuts if first[0] - 0.001 <= entry[0] <= end + 0.001]
        if not (last is None and ending and ending[-1] == index):
            bisect.insort(self.cuts, (cut, index))
            if cut <= end + 0.001:
                bisect.insort(self.untold, cut)
        self.silent_spans = [one for one in self.silent_spans
                             if not (abs(one[0] - end) < 0.001 and abs(one[1] - start) < 0.001)]
        if upto is not None and upto < start:
            if last is None:
                first[1] = upto
            else:
                first[1] = max(first[1], last)
                self.seen.append([cut, upto])
        else:
            self.cuts.remove(begun)
            if last is None:
                second[0] = first[0]            # the one being read stays the open one
                self.seen.remove(first)
            else:
                first[1], second[0] = max(first[1], last), cut
        if last is not None:
            self._keep_silent(first[1], cut)
        self.seen.sort()
        return True

    def _newest(self, spans):
        """Of stretches that overlap (read again after a seek back), the one being read, else the latest begun; None
        for none."""
        if any(span is self._open for span in spans):
            return self._open
        return max(spans, key=lambda span: span[0], default=None)

    def copy(self):
        """A map of its own with the same shapes, cuts and stretches (handed to another thread)."""
        return SceneMap(self.shapes, self.cuts, self.seen, exact=self.exact, exact_seen=self.exact_seen,
                        coarse=self.coarse_spans, silent=self.silent_spans, untold=self.untold)

    def parts(self):
        """The map as maps each read by one rule: itself, or where only some stretches hold cuts at their frames
        (exact_seen) one map of those, exact, and one of the rest. Each part's stretches begin with a cut."""
        if self.exact or not self.exact_seen:
            return [self]
        rest = []
        for start, end in self.seen:
            rest += _without([start, end], self.exact_seen)
        return [part for part in (self._part(self.exact_seen, True), self._part(rest, False)) if part]

    def _part(self, spans, exact):
        cuts, kept = [], []
        for start, end in spans:
            inside = [(when, index) for when, index in self.cuts if start - 0.001 <= when <= end]
            if not inside or inside[0][0] > start + 0.001:
                shown = self.picture_at(start)
                if shown is not None:
                    inside.insert(0, (start, self.shapes.index(shown)))
                elif inside:
                    # A damaged cache's stretch without a cut at its start: read from its first cut, as picture_at
                    # reads the whole map, never from a picture nobody saw.
                    start = inside[0][0]
                else:
                    continue
            cuts += inside
            kept.append((start, end))

        def inside(at):
            return any(start - 0.001 <= at <= end for start, end in kept)
        coarse = [span for span in self.coarse_spans if inside(span[0] + COARSE_AFTER)]
        silent = [span for span in self.silent_spans if inside(span[0]) and inside(span[1])]
        return SceneMap(self.shapes, cuts, kept, exact=exact, coarse=coarse, silent=silent,
                        untold=[at for at in self.untold if inside(at)])

    # Reading.

    def coarse_cuts(self):
        """The coarse cuts, ((the keyframe before, the picture there), (the keyframe after, the wider picture)) each."""
        return [((start, self.picture_at(start)), (end, self.shapes[_cut_of(self.cuts, [start, end])[1]]))
                for start, end in self.coarse_spans]

    def at_frames(self):
        """The cuts at their frames, (film time, shape index) each: not a stretch's start (where reading began, or the
        keyframe after a silent span), a coarse cut nor an untold one. The screen's lead is measured from these alone
        (one measured from a coarse cut 0.2 s before its frame put every later planned move 0.22 s late)."""
        return [(when, index) for when, index in self.cuts if self._at_frame(when)]

    def _shows_from(self, when):
        """Whether the picture of the cut at film time when is known to show from there on: a cut at its frame, or the
        end of a silent span (where reading began says nothing of what came just before it)."""
        return self._at_frame(when) or any(abs(when - end) < 0.001 for _start, end in self.silent_spans)

    def _at_frame(self, when):
        """Whether a cut at film time when is at its frame (at_frames)."""
        return (not any(abs(when - start) < 0.001 for start, _end in self.seen)
                and not any(abs(when - start - COARSE_AFTER) < COARSE_AFTER / 2 for start, _end in self.coarse_spans)
                and not any(abs(when - at) < 0.001 for at in self.untold))

    def stretch(self, at):
        for start, end in self.seen:
            if start <= at <= end:
                return start, end
        return None

    def picture_at(self, at):
        """The shape on screen at film time at, or None where no stretch watched it."""
        cut = self._latest_cut(at)
        return self.shapes[cut[1]] if cut is not None else None

    def _latest_cut(self, at):
        """The last cut at or before film time at in at's stretch (its start counts): (film time, shape index), or None.
        A search over the sorted cuts, not a walk over all of them: a follower asks at every look, and a full map holds
        CUTS_MOST (a walk cost about 7 us per cut per look)."""
        stretch = self.stretch(at)
        if stretch is None:
            return None
        number = bisect.bisect_right(self.cuts, (at + EPS, float('inf'))) - 1
        if number < 0 or self.cuts[number][0] < stretch[0] - 0.001:
            return None
        return self.cuts[number]

    def silent_into(self, at):
        """The narrower picture a silent span at film time at leads into: the picture at its end where that is narrower
        than the one at its start, outside every stretch (one read again after a seek back may cover it); else None.
        A gap the map was not told is silent is none (a seek's, two read-aheads' merged)."""
        if self.stretch(at) is not None:
            return None
        span = next((one for one in self.silent_spans if one[0] < at < one[1]), None)
        if span is None:
            return None
        old, new = self.picture_at(span[0]), self.picture_at(span[1])
        return new if old is not None and new is not None and pictures.narrower(new, old) else None

    def near_cut(self, at):
        """Whether at is near a cut of this map (NEAR_BEFORE before it to NEAR_AFTER after it): where a PC looks fast
        (Plans.calm asks only inside a stretch watched; outside every one nothing is known, and the pace is fast)."""
        return any(at - NEAR_AFTER <= when <= at + NEAR_BEFORE for when, _index in self.cuts)

    def last_cut(self, at):
        """The film time of the last cut at or before at in at's stretch (its start counts), or None."""
        cut = self._latest_cut(at)
        return cut[0] if cut is not None else None

    def plan(self, at, moves_shown=False, evidence=None, evidence_at=None):
        """The picture to place for at film time at: the one on screen, or a wider one a cut brings within the lead
        (MANUAL_AHEAD where a new margin moves the line on screen, moves_shown, else AHEAD), unless a lit grab showed a
        picture wider than that (evidence, at film time evidence_at) after the map's last cut: the map missed it, and
        the text never goes below a picture seen on screen. None where the map can not say (outside every stretch, or a
        stretch that ends within the lead with no cut into a wider picture before its end: what comes after it is
        unknown)."""
        ahead = self._ahead(moves_shown)
        now = self.picture_at(at)
        if now is not None and self.exact and moves_shown:
            # A cut into a narrower picture counts EXACT_AFTER late; one into a wider one at once (the wider of the two:
            # otherwise a cut into scope is undone for 40 ms).
            lagged = self.picture_at(at - EXACT_AFTER)
            now = max(now, lagged, key=float) if lagged is not None else now
        if now is None:
            return None
        end = self.stretch(at)[1]
        coming = [self.shapes[index] for _when, index in self.cuts[bisect.bisect_right(self.cuts, (at, float('inf'))):
                                                                   bisect.bisect_right(self.cuts, (min(at + ahead, end) + EPS,
                                                                                                   float('inf')))]]
        planned = max([now] + coming, key=float)
        if end < at + ahead and not pictures.wider(planned, now):
            # A cut into a wider picture before the stretch ends comes whatever follows it (a short scope shot's own
            # keyframe ending a stretch read from the file, a silent span after it).
            return None
        cut = self.last_cut(at)
        quiet = EXACT_EVIDENCE if self.exact and cut is not None and self._shows_from(cut) else 0.001
        # Another picture, not the same one with edges a row apart (the text would step up a row's worth a moment
        # after each cut into scope).
        if (evidence is not None and pictures.wider(evidence, planned)
                and (cut is None or evidence_at > cut + quiet)):
            return evidence
        return planned

    def _ahead(self, moves_shown):
        if not moves_shown:
            return AHEAD
        return EXACT_AHEAD if self.exact else MANUAL_AHEAD

    def next_change(self, at, moves_shown=False):
        """Seconds from film time at to the next moment plan() answers otherwise: a cut into a wider picture less its
        lead, one into a narrower picture at it (an exact one EXACT_AFTER after it), or None: where the follower wakes to
        move the text on time (waking at a narrower one's lead finds nothing to do, and its grab then sees the cut
        first)."""
        ahead = self._ahead(moves_shown)
        after = EXACT_AFTER if self.exact and moves_shown else 0.0
        # A moment is never earlier than its cut less the lead: from the first cut that can still come, until one
        # whose earliest moment is past the best found (linear, not a scan of every cut).
        best = None
        for number in range(bisect.bisect_left(self.cuts, (at - after - 0.002, -1)), len(self.cuts)):
            when, index = self.cuts[number]
            if best is not None and when - ahead > best:
                break
            before = self.picture_at(when - 0.002)
            wider = before is None or pictures.wider_number(self.shapes[index], before)
            moment = when - ahead if wider else when + after
            if moment > at + 0.001 and (best is None or moment < best):
                best = moment
        return best - at if best is not None else None

    # Keeping.

    def merged(self, newer):
        """This map with a later playback's: each of the newer one's stretches, less its last TAIL seconds (a cut into
        a narrower scene there may not be confirmed yet; a map read from the file keeps it, its stretches end at a
        keyframe read), replaces whatever this one had there, and this one's shape goes on where it watched past that.
        Where the shapes or the cuts run out (SHAPES_MOST, CUTS_MOST) the map ends: a stretch is never kept without the
        cuts inside it."""
        claims = []
        for start, end in newer.seen:
            if not newer.exact:
                end -= TAIL
            if end > start:
                claims.append((start, end, [(when, newer.shapes[index]) for when, index in newer.cuts
                                            if start - 0.001 <= when <= end]))
        # Where the newer map read the frames, the result's cuts are at them; elsewhere this one's frames stay.
        frames = [list(span) for span in (self.seen if self.exact else self.exact_seen)]
        for start, end, _cuts in claims:
            frames = [left for span in frames for left in _without(span, [[start, end]])]
        if newer.exact:
            frames += [[start, end] for start, end, _cuts in claims]

        def claimed(at):
            return any(start - 0.001 <= at <= end for start, end, _cuts in claims)
        cuts = [(when, self.shapes[index]) for when, index in self.cuts if not claimed(when)]
        coarse = ([span for span in self.coarse_spans if not claimed(span[0] + COARSE_AFTER)]
                  + [span for span in newer.coarse_spans if claimed(span[0] + COARSE_AFTER)])
        untold = [at for at in self.untold if not claimed(at)] + [at for at in newer.untold if claimed(at)]
        silent = ([span for span in self.silent_spans if not (claimed(span[0]) or claimed(span[1]))]
                  + [span for span in newer.silent_spans if claimed(span[0]) or claimed(span[1])])
        for start, end, inside in claims:
            cuts += inside
            after = self.picture_at(end + 0.001)
            if after is not None and not claimed(end + 0.001):
                cuts.append((end + 0.001, after))
        spans = sorted([list(span) for span in self.seen] + [[start, end] for start, end, _cuts in claims])
        result = SceneMap()
        for start, end in spans:
            if result.seen and start <= result.seen[-1][1] + 0.001:
                result.seen[-1][1] = max(result.seen[-1][1], end)
            else:
                result.seen.append([start, end])
        if self.exact and newer.exact:
            result.exact = True                 # two maps read from the file: every cut at its frame
        else:
            result.exact_seen = sorted(frames)
        for when, picture in sorted(cuts, key=lambda cut: cut[0]):
            # The earliest cut's version had no rows: a later one's replaces it.
            index = result.shapes.add(picture, SHAPES_MOST)
            if (index is not None and result.cuts and result.cuts[-1][1] == index
                    and result.stretch(result.cuts[-1][0]) == result.stretch(when)):
                continue                        # changes nothing: a newer stretch's start inside one watched before
            if index is None or len(result.cuts) >= CUTS_MOST:
                result.seen = [[start, min(end, when - 0.001)] for start, end in result.seen if start < when]
                result.exact_seen = [[start, min(end, when - 0.001)] for start, end in result.exact_seen
                                     if start < when]
                break
            result.cuts.append((when, index))
        # A span whose cut did not make it (a stretch's start in it, the map ending) is no coarse cut any more.
        result.coarse_spans = sorted(list(span) for span in coarse if _cut_of(result.cuts, span) is not None)
        result.untold = sorted(at for at in untold if any(abs(when - at) < 0.001 for when, _index in result.cuts))
        # A silent span the result reads through (the other map read its frames) or whose cut did not make it is none.
        result.silent_spans = sorted(
            list(span) for span in silent
            if not any(start < span[1] - 0.001 and span[0] + 0.001 < end for start, end in result.seen)
            and any(abs(when - span[1]) < 0.001 for when, _index in result.cuts))
        return result

    def data(self):
        value = {'shapes': [[round(float(shape), 4), int(getattr(shape, 'top', 0)), int(getattr(shape, 'bottom', 0)),
                             int(getattr(shape, 'height', 0))] for shape in self.shapes],
                 'cuts': [[round(when, 2), index] for when, index in self.cuts],
                 'seen': [[round(start, 2), round(end, 2)] for start, end in self.seen]}
        frames = self.seen if self.exact else self.exact_seen
        if frames:
            value['exact'] = [[round(start, 2), round(end, 2)] for start, end in frames]
        if self.coarse_spans:
            # A key of its own, not a third field on each cut: a package before coarse cuts unpacks the cuts as pairs
            # (it would refuse the whole map) and leaves a key it does not know alone.
            value['coarse'] = [[round(start, 2), round(end, 2)] for start, end in self.coarse_spans]
        if self.silent_spans:
            value['silent'] = [[round(start, 2), round(end, 2)] for start, end in self.silent_spans]
        if self.untold:
            value['untold'] = [round(at, 2) for at in self.untold]
        return value

    @classmethod
    def from_data(cls, value):
        """A map from the cache, or None when it is not one."""
        try:
            shapes = [detect.Picture(float(ratio), int(top), int(bottom), int(height))
                      for ratio, top, bottom, height in value['shapes']]
            cuts = [(float(when), int(index)) for when, index in value['cuts']]
            seen = [(float(start), float(end)) for start, end in value['seen']]
            frames = [(float(start), float(end)) for start, end in value.get('exact', ())]
            coarse = [(float(start), float(end)) for start, end in value.get('coarse', ())]
            silent = [(float(start), float(end)) for start, end in value.get('silent', ())]
            untold = [float(at) for at in value.get('untold', ())]
        except (KeyError, TypeError, ValueError):
            return None
        if (not shapes or len(shapes) > SHAPES_MOST or any(not 1.0 <= float(shape) <= 4.0 for shape in shapes)
                or any(not 0 <= index < len(shapes) for _when, index in cuts)
                or any(end < start for start, end in seen + frames + coarse + silent)):
            return None

        def cut_at(at):
            return any(abs(when - at) < 0.001 for when, _index in cuts)
        # Each coarse span holds its cut, each silent span ends at one, each untold cut is one (a damaged cache's that
        # does not is none).
        return cls(shapes, cuts, seen, exact_seen=frames,
                   coarse=[span for span in coarse if _cut_of(cuts, span) is not None],
                   silent=[span for span in silent if cut_at(span[1])], untold=[at for at in untold if cut_at(at)])


class Plans:
    """The scene maps a PC's follower plans from, combined, so the rules of when the text moves are read in one place:
    the map read from the file ahead of playback (exact: its cuts at their
    frames, planned for what is on screen, shown_ahead seconds ahead of Kodi's film time) before the cache's (its cuts
    at the looks that saw them, in Kodi's time), each where it says anything. For a film time: the picture to place,
    the next planned move, and whether no cut is near (the slow pace may be used)."""

    def __init__(self, live, known, moves_shown, shown_ahead):
        self._live = live
        self._maps = [(part, shown_ahead if part.exact else 0.0)
                      for scenes in (live, known) if scenes for part in scenes.parts()]
        self._moves_shown = moves_shown
        self.answered = None

    def __bool__(self):
        return bool(self._maps)

    def read_ahead(self):
        """Whether the map read ahead in this playback answered last (not the cache's)."""
        return self.answered is not None and self.answered is self._live

    def _answering(self, at):
        """The map that answers for film time at, with its shift, or (None, 0)."""
        for scenes, shift in self._maps:
            if scenes.stretch(at + shift) is not None:
                return scenes, shift
        return None, 0.0

    def picture(self, at, lit=(None, None)):
        """The picture the maps plan for film time at (Kodi's), or None where none can say. lit: (the latest picture a
        strongly lit grab showed, its film time), the evidence against every map: a dim grab reads a dark IMAX scene as
        wide as scope (a dim reading is a lower bound on the picture's height), and would undo the read-ahead's cut into
        it, and the cache's too, which keeps the read-ahead's cuts (in the film simulator dim grabs reading scope undid
        a cached cut at a dark IMAX opening 0.16 s after it)."""
        self.answered = None                # the map that answered, for the log
        evidence, evidence_at = lit
        for scenes, shift in self._maps:
            planned = scenes.plan(at + shift, self._moves_shown, evidence,
                                  None if evidence_at is None else evidence_at + shift)
            if planned is not None:
                self.answered = scenes
                return planned
        return None

    def last_known(self, at, since=None):
        """(the picture a map shows at film time at, or at the end of its latest stretch begun before it where
        playback is past what was read; the film time it knew it for), or None: Plans.picture's fallback where a
        stretch ends within the lead or behind playback. since: the film time playback has run on from (a seek's
        landing, the follower's start): a stretch that ended before it says nothing of the picture now (a seek far ahead
        inside a tall scene would take the scope a stretch ended on minutes before)."""
        for scenes, shift in self._maps:
            picture = scenes.picture_at(at + shift)
            if picture is not None:
                self.answered = scenes
                return picture, at
            # A stretch that knows no picture at its end (a damaged cache's, begun without a cut) says nothing.
            before = [end for start, end in scenes.seen if start <= at + shift
                      and (since is None or end - shift >= since - EPS) and scenes.picture_at(end) is not None]
            if before:
                end = max(before)
                self.answered = scenes
                return scenes.picture_at(end), end - shift
        return None

    def silent_into(self, at):
        """The narrower picture a map's silent span at film time at leads into (SceneMap.silent_into), or None."""
        for scenes, shift in self._maps:
            found = scenes.silent_into(at + shift)
            if found is not None:
                return found
        return None

    def next_move(self, at):
        """Seconds from film time at to the next planned move of the map answering then, or None."""
        soon = []
        for scenes, shift in self._maps:
            due = scenes.next_change(at + shift, self._moves_shown)
            if due is not None and self._answering(at + due)[0] is scenes:
                soon.append(due)
        return min(soon) if soon else None

    def calm(self, at):
        scenes, shift = self._answering(at)
        return scenes is not None and not scenes.near_cut(at + shift)


def timecode(seconds):
    """A film time for the log as h:mm:ss.s, to find the moment in the film again; 'an unknown time' where Kodi could
    not say (None, or its -1 before it knows)."""
    if seconds is None or seconds < 0:
        return 'an unknown time'
    tenths = int(seconds * 10)
    return '%d:%02d:%02d.%d' % (tenths // 36000, tenths // 600 % 60, tenths // 10 % 60, tenths % 10)


def _cut_of(cuts, span):
    """The cut a coarse span holds among cuts, (film time, shape index), or None where it is gone (merged away)."""
    when = span[0] + COARSE_AFTER
    return next((entry for entry in cuts if abs(entry[0] - when) < COARSE_AFTER / 2), None)


def _without(span, holes):
    """The parts of span ([start, end]) outside every one of holes ([start, end] each)."""
    left = [list(span)]
    for start, end in holes:
        pieces = []
        for keep in left:
            if keep[1] <= start or end <= keep[0]:
                pieces.append(keep)
                continue
            pieces += [piece for piece in ([keep[0], start], [end, keep[1]]) if piece[1] > piece[0] + 0.001]
        left = pieces
    return left
