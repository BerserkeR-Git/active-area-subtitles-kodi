"""Shapes measured during this Kodi session, so a film played again is not decoded again.

Kept in memory only and bounded, a few kilobytes at most. Keys are file identities that
change when a file is replaced (size and date, or Plex's file key with its update time), so
a new version of a title is always measured afresh, even without a restart.
"""
import collections
import threading

LIMIT = 64


class Memo:

    def __init__(self, limit=LIMIT):
        self.limit = limit
        self.entries = collections.OrderedDict()
        self.lock = threading.Lock()

    def get(self, identity):
        with self.lock:
            if identity in self.entries:
                self.entries.move_to_end(identity)
                return self.entries[identity]
            return None

    def put(self, identity, ratio):
        with self.lock:
            self.entries[identity] = ratio
            self.entries.move_to_end(identity)
            while len(self.entries) > self.limit:
                self.entries.popitem(last=False)
