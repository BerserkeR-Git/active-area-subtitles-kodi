"""The rules of following a film whose picture changes shape (IMAX): Follower decides when a new reading moves the
text, on the box (P3i's Level 5 labels) and on a PC (the screen reader's pictures, which no keyframe checks: a PC's
followed film carries the Verdict "the picture on screen is followed"). The rest is the box's.

P3i reports the playing frame's Level 5 in info labels, scene by scene (Player.Process(video.dovi.l5.*)). Read on
the box (P3i 4210): the labels change 0.15 to 0.35 s before
Kodi's clock reaches the cut, they carry the film's own Level 5 (not the zeroes P3i sends the TV for the OSD or for
subtitles over a bar), and a margin written while a line shows moves that line at once. So a film whose Level 5 is
right can be placed scene by scene from the labels alone, with the two text distances: black bars in scope scenes,
full screen in the tall ones. Nothing is decoded for it, except one keyframe the first time the labels show a
taller shape than the keyframes saw fitting.

trust: whether this film's Level 5 may place text, from the keyframes measuring decoded, and the Level 5 seen fitting.
check: one keyframe decoded where the labels show a shape not seen
fitting yet. Follower: when a new reading moves the text.
"""
import collections

from . import detect
from .keyframes import EXACT_ROWS

LABEL_STEP = 0.05        # seconds between looks at the labels (a condition and one to three labels a look)
UNPLACED = float('-inf')  # Follower.placed while no margin is known to be in place
HOLD = 'Player.Paused | Player.Seeking | Player.Caching'   # no reading while true: PM4K pauses about 0.4 s before a
                         # seek, and every "no Level 5" blip seen on the box comes while Kodi says paused
UNDO_WINDOW = 0.2        # seconds: a hold that starts this soon after a move down undoes it (a seek without PM4K's pause
                         # gives P3i's "no Level 5" 82 ms before Kodi's seek signals on the box)
SEEK_QUIET = 0.5         # seconds after Kodi's seek event in which nothing is read (the event came 11 to 80 ms before
                         # P3i's blip in every seek measured on the box)
TRUST_KEYFRAMES = 3      # clear keyframes needed, as for the Level 5 correction
FOLLOW_RULE = 2          # trust's rule; a cached verdict of another rule is judged again (1: two pictures needed)
CHECK_AHEAD = 2.0        # seconds past the playing position a check decodes at: the keyframe at or before it is
                         # past the cut while keyframes are at most this far apart
CHECK_FRAMES = 6         # keyframes one check may decode, CHECK_SPACING apart, until one is clear (on the
CHECK_SPACING = 2.0      # box dark keyframes kept the text up 21 s into a scene with one keyframe and
                         # pauses of 10 s, and 6.9 s with three and 5 s; decoding cost no frames)
CHECK_AGAIN = 5.0        # seconds before a check that showed nothing clear is tried again for that shape
CHECKS_MOST = 12         # checks per playback (about 1 to 1.5 s of decoding per keyframe on the box)
CHECK_SETTLE = 0.25      # seconds a check waits before it reads: a move undone at a seek needs no keyframe
ZERO_TRUST = 3.0         # seconds of playback, not held, before "no Level 5" counts as the full frame while P3i has
                         # shown no Level 5 yet in the playback: it shows none before a playback's first frame, 1.3 to
                         # 2.5 s at a cached resume on the box, where the follower would place the full frame and decode
                         # a check (under 1.6 s of it not held)
WRITE_AGAIN = 0.25       # seconds before a margin Kodi did not take is written again (a refusal at every look would
                         # write 20 times a second)
SEARCH_FRAMES = 32       # keyframes the start-up search spreads over a film to find its other shapes before their
                         # scenes (corpus grids: 7 found the second shape in 16 or 17 of 20 films, 24 in 19 or 20,
                         # 32 in all 20, by which grid keyframe stands for a position)


class Verdict:
    """trust's answer: followed (True or False) and why, for the log and the cache. verified: the Level 5 (top,
    bottom) seen fitting a keyframe's picture; the text moves down to those without another look. refused: Level 5
    seen missing its picture, kept with the film so the text never goes down to it in any playback.

    The two lists are written only here (learn, merge), and two Level 5 within the measuring precision (close) are
    the same shape everywhere: the follower, its checks, the search and the early start share one verdict and read
    its lists as they grow."""

    def __init__(self, followed, reason, height=0, verified=(), searched=False, refused=()):
        self.followed, self.reason, self.height, self.verified = followed, reason, height, list(verified)
        self.searched = searched         # the start-up search for other shapes has run to its end for this film
        self.refused = list(refused)     # Level 5 seen missing its picture (search or check): never followed down

    def __bool__(self):
        return self.followed

    def fits(self, shown, height):
        """Level 5 shown (top, bottom) seen fitting its picture."""
        return any(close(shown, known, height) for known in list(self.verified))

    def refuses(self, shown, height):
        """Level 5 shown seen missing its picture, and never seen fitting (seen fitting wins)."""
        return any(close(shown, known, height) for known in list(self.refused)) and not self.fits(shown, height)

    def learn(self, shown, result, height):
        """What a keyframe said about Level 5 shown: True fits, False misses its picture, None nothing. True when a
        list grew (the cache is told then)."""
        shown = tuple(shown)
        if result is None or self.fits(shown, height):
            return False
        if result:
            self.verified.append(shown)
            return True
        if any(close(shown, known, height) for known in self.refused):
            return False
        self.refused.append(shown)
        return True

    def merge(self, settled):
        """The settled judgement into a verdict made early, whose lists a follower already reads: its answer and its
        Level 5 seen fitting."""
        self.followed, self.reason = settled.followed, settled.reason
        self.height = settled.height or self.height
        for shown in settled.verified:
            self.learn(shown, True, self.height)

    def data(self):
        """The verdict as the cache keeps it (shapes.KINDS)."""
        return {'followed': bool(self.followed), 'reason': self.reason, 'height': int(self.height), 'rule': FOLLOW_RULE,
                'verified': [[int(top), int(bottom)] for top, bottom in self.verified], 'searched': bool(self.searched),
                'refused': [[int(top), int(bottom)] for top, bottom in self.refused]}

    @classmethod
    def from_data(cls, value):
        """A verdict from the cache, or None when it is not one. A verdict of another rule (FOLLOW_RULE) counts as never
        judged, so the film is measured again."""
        if not (isinstance(value, dict) and value.get('rule') == FOLLOW_RULE
                and isinstance(value.get('followed'), bool) and isinstance(value.get('reason'), str)
                and isinstance(value.get('height', 0), int) and _level5_list(value.get('verified', []))
                and isinstance(value.get('searched', False), bool) and _level5_list(value.get('refused', []))):
            return None
        return cls(value['followed'], value['reason'], value.get('height', 0),
                   [tuple(pair) for pair in value.get('verified', [])], value.get('searched', False),
                   [tuple(pair) for pair in value.get('refused', [])])


def _level5_list(value):
    """A cached list of Level 5 (top, bottom) pairs, or False when it is anything else."""
    return isinstance(value, list) and all(
        isinstance(pair, list) and len(pair) == 2 and all(isinstance(n, int) and n >= 0 for n in pair) for pair in value)


def trust(keyframes):
    """Whether the labels may place this film's text, from the keyframes measuring decoded (keyframes.Keyframe).

    Followed only when every keyframe carried readable Dolby Vision metadata, at least three are clear, and each clear
    keyframe's Level 5 fits its own picture (0/0 a full one). One keyframe whose Level 5 does not fit (wrong, dropping
    to zero, side bars) and the film keeps one placement, the widest shape, as before: text placed from wrong Level 5
    would land in a bar. A film whose keyframes all show one picture is followed too (its IMAX scenes may be where no
    keyframe landed): the Follower moves the text down only to Level 5 seen fitting, and checks any other first."""
    seen = []
    for keyframe in keyframes:
        if keyframe.level5_pair is None:
            return Verdict(False, 'no Dolby Vision metadata readable')
        if keyframe.side_bars:
            return Verdict(False, 'Level 5 with side bars')
        if keyframe.judgeable:
            seen.append(keyframe)
    if len(seen) < TRUST_KEYFRAMES:
        return Verdict(False, 'too few clear keyframes (%d)' % len(seen))
    for keyframe in seen:
        fits, found = keyframe.fits(keyframe.level5_pair)
        if not fits:
            return Verdict(False, 'Level 5 %d/%d does not fit a keyframe\'s picture (%s)' % (
                keyframe.level5_pair + (found,)))
    shapes = [keyframe.shape for keyframe in seen]
    verified = sorted({keyframe.level5_pair for keyframe in seen})
    height = seen[0].size[1]
    if detect.same_picture(shapes):
        return Verdict(True, 'Level 5 fits the picture in %d keyframes (%.2f); other shapes are checked as they come'
                       % (len(seen), max(shapes)), height, verified)
    return Verdict(True, 'Level 5 follows the picture in %d keyframes (%.2f to %.2f)' % (
        len(seen), min(shapes), max(shapes)), height, verified)


def close(level5, other, height):
    """Two Level 5 (top, bottom) within the measuring precision: EXACT_ROWS per 1080 (keyframes.py)."""
    return max(abs(level5[0] - other[0]), abs(level5[1] - other[1])) <= EXACT_ROWS * height / 1080


def check(keyframe, shown):
    """(True, False or None, why) for one keyframe decoded where the labels showed shown (top, bottom), a shape not
    seen fitting yet: True when the keyframe carries that Level 5 and it fits its picture, False when it carries it
    and it does not (text placed from it would sit in a bar), None when the keyframe can not say (another scene, a
    dark or uneven picture, no Dolby Vision metadata)."""
    level5 = keyframe.level5_pair
    if level5 is None:
        return None, 'no Dolby Vision metadata in the keyframe'
    if not keyframe.judgeable:
        return None, 'the keyframe shows nothing clear (%s)' % (keyframe.sample.reason or 'no size')
    if not close(level5, shown, keyframe.size[1]):
        return None, 'the keyframe carries Level 5 %d/%d, not the %d/%d shown' % (level5 + tuple(shown))
    fits, found = keyframe.fits(level5)
    return fits, 'Level 5 %d/%d %s the keyframe\'s picture (%s)' % (
        level5 + ('fits' if fits else 'does not fit', found))


class Follower:
    """When a reading moves the text. margin_of(picture): Kodi's margin for it. A higher margin goes at once (into a
    scope scene: the labels come early, so the text is up by the cut); a lower one at once too (into a tall scene: any
    wait for the reading to hold showed as lag on the TV, as P3i's labels change with the picture shown, and its short
    "no Level 5" readings come only at seeks, where nothing is read: HOLD, SEEK_QUIET). The same margin moves nothing,
    so a row of jitter in Level 5 writes nothing.

    verdict: the film's Verdict, shared with the caller (the start-up search adds to its lists while this follows):
    the text goes down to Level 5 seen fitting, never to Level 5 seen missing its picture (seen fitting wins), and
    to any other at once too, asking check(picture) to look at it in the background (checking first
    kept the text 1.65 s high in a film's first IMAX scene on the box); check says whether it started
    one (the playback's checks stop at CHECKS_MOST, whichever follower asks). The answer comes back through
    answered(): True keeps it, False refuses it and sends the text back up while it sits there, None asks again the
    next time after CHECK_AGAIN. placed_picture: the picture the margin in place is for; a margin from feed is to be
    placed for it (going back up, it is not the reading). Its base picture is where it goes back to when no margin is
    known to be in place (unplaced): the picture placed when it starts (the measured shape, or the estimate's), then
    the settled shape once the rule is judged from one (rule_changed). undo: a hold right after a move down undoes it
    (hold), for P3i's labels; a screen's grabs show the picture itself."""

    def __init__(self, margin_of, placed_margin, verdict=None, check=None, placed_picture=None, undo=True):
        self._margin_of = margin_of
        self.placed = placed_margin      # the margin in place (UNPLACED: none known, unplaced)
        self.placed_picture = placed_picture
        self._start = placed_picture     # the base picture: placed when it started, then the settled shape
        self._last = None                # (shape, top, bottom, height) of the last reading, and its margin
        self._verdict = verdict if verdict is not None else Verdict(True, '')
        self._check = check
        self._asked = set()              # Level 5 a check is out for
        self._again = {}                 # (top, bottom) -> when a check that said nothing may be asked again
        self._answers = collections.deque()
        self._back = None                # (Level 5, margin and picture before) while the text sits on a shape not
                                         # checked yet
        self._last_down = None           # (when, margin and picture before) of the last move down, for hold()
        self.unmoved = None              # why the last reading fed moved nothing, for the log: 'refused', 'same' or None
        self._again_at = None            # when a margin Kodi did not take may be written again (unplaced)
        self._undo = undo

    def answered(self, shown, result):
        """A check's answer (True, False or None) for Level 5 shown; from the check's own thread."""
        self._answers.append((tuple(shown), result))

    def rule_changed(self, settled=None):
        """margin_of answers differently from now on (the settled shape's scene rule): the last margin is forgotten,
        so the next reading, the same picture or not, is worked out again. settled: the shape the rule was judged from
        once the measurement settled (None before), the base picture from now on: a follower started early from a
        taller estimate went back to that estimate after a write Kodi did not take, in a scope scene's bar."""
        self._last = None
        if settled is not None:
            self._start = settled

    def placed_again(self, margin):
        """The text was written again for placed_picture (another track or distance chosen): margin is in place now,
        worked out anew for every reading."""
        self._last, self.placed = None, margin

    def unplaced(self, now):
        """The margin feed gave last was not taken (Kodi refused it or did not answer): no margin is known to be in
        place, so something is written at the reading after WRITE_AGAIN whatever it is (_written_again)."""
        self.placed, self._last_down, self._back = UNPLACED, None, None
        self._again_at = now + WRITE_AGAIN

    def _margin(self, picture):
        key = (float(picture), picture.top, picture.bottom, picture.height)
        if self._last is None or self._last[0] != key:
            self._last = (key, self._margin_of(picture))
        return self._last[1]

    def _take_answers(self, now, height):
        while self._answers:
            shown, result = self._answers.popleft()
            self._asked.discard(shown)
            if result is None:
                self._again[shown] = now + CHECK_AGAIN
            else:
                self._verdict.learn(shown, result, height)

    def feed(self, picture, now):
        """The margin to write now, or None (unmoved says why, for a reading)."""
        self.unmoved = None
        if self._again_at is not None:
            if now + 1e-9 < self._again_at:
                self._take_answers(now, picture.height if picture is not None else 1080)
                return None
            self._again_at = None
        if picture is None:
            self._take_answers(now, 1080)
            if self.placed == UNPLACED and self._start is not None:
                # Nothing read and no margin known to be in place: the base picture's, as its placing worked it out.
                self.placed, self.placed_picture = self._margin_of(self._start), self._start
                return self.placed
            return None
        shown = (picture.top, picture.bottom)
        self._take_answers(now, picture.height)
        if (self._back is not None and close(shown, self._back[0], picture.height)
                and self._verdict.refuses(shown, picture.height)):
            (_shown, margin, picture), self._back = self._back, None  # failed while there: up
            self.placed, self.placed_picture, self._last_down = margin, picture, None
            return margin
        margin = self._margin(picture)
        if self.placed == UNPLACED:
            return self._written_again(picture, shown, margin, now)
        if abs(margin - self.placed) < 0.001:
            self.unmoved = 'same'
            return None
        if margin > self.placed:
            self._back, self._last_down = None, None
            self.placed, self.placed_picture = margin, picture
            return margin
        if not self._may_go_down(picture, shown, now):
            self.unmoved = 'refused'
            return None
        self._last_down = (now, self.placed, self.placed_picture)
        self.placed, self.placed_picture = margin, picture
        return margin

    def _written_again(self, picture, shown, margin, now):
        """The margin to write with none known to be in place: the reading judged as a move from the base picture, so
        one seen missing its picture writes that picture's margin instead (whatever Kodi holds, never the refused one),
        and one not checked yet goes down with a check, as any move down."""
        start = self._start
        if start is None:                       # nothing to go back to: a refused reading writes nothing
            if self._verdict.refuses(shown, picture.height):
                self.unmoved = 'refused'
                return None
            self.placed, self.placed_picture = margin, picture
            return margin
        self.placed, self.placed_picture = self._margin_of(start), start
        if margin < self.placed - 0.001 and not self._may_go_down(picture, shown, now):
            return self.placed
        self.placed, self.placed_picture = margin, picture
        return margin

    def hold(self, now):
        """A hold (paused, seeking) begins: the margin to go back to when the last move down came just before it
        (UNDO_WINDOW), placed for placed_picture; else None."""
        last, self._last_down = self._last_down, None
        if last is None or not self._undo or now - last[0] > UNDO_WINDOW + 1e-9:
            return None
        self.placed, self.placed_picture, self._back = last[1], last[2], None
        return last[1]

    def _may_go_down(self, picture, shown, now):
        """Whether the text may go down to this reading now; one not checked yet is, with a check asked for."""
        if self._verdict.fits(shown, picture.height):
            self._back = None
            return True
        if self._verdict.refuses(shown, picture.height):
            return False
        self._back = (shown, self.placed, self.placed_picture)
        if (self._check is not None and shown not in self._asked and now >= self._again.get(shown, now)
                and self._check(picture)):
            self._asked.add(shown)
        return True
