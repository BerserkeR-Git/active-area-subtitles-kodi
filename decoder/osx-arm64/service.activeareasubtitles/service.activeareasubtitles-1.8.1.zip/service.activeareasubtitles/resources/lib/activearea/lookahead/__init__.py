"""Reading a PC's film ahead of playback, so the scene follower moves the text at the frame of each cut, as P3i does
from the picture's own Level 5 on the box (from the screen alone moves up and down come late: text left in the bar at a
cut into scope, a dark IMAX scene with nobody talking still placed at the scope height). Only where the add-on
reads the file itself (a PC with the shipped decoder, Service.checks.file_first).

The sweep reads a keyframe every SPARSE seconds from the playing position to LEAD seconds ahead, each as the measurement
reads one (faint rows off): its picture from the frame where strongly lit (a weak reading is not believed: dark wide
misreads), with the exact edge where that is strongly lit, or from its Dolby Vision Level 5 where the frame shows
nothing believed and the film's Level 5 was seen to fit its pictures (TRUST_FITS strongly lit clear keyframes whose
Level 5 fits, the measurement's and its own, and none that does not: one that does not and Level 5 places nothing more;
a dim keyframe is no evidence either way: one dim scope keyframe read wide would end Level 5 for the playback). A
picture is always given as the version believed first (the measurement's settled shape), so the map never holds two
versions of one picture with edges a row apart. A weak reading is a lower bound on the picture's height: where trusted
Level 5 says a taller picture it goes by Level 5 (0/0: shows nothing believed). The trust is kept with the cache
(trust, kept): a cached playback decodes none of the measurement's keyframes.

What the sweep reads goes on the map at once, from its keyframes alone: two keyframes in a row of the same picture grow
the stretch; into a wider picture the cut is a coarse cut a frame after the keyframe read before (the text rises up to
a keyframe gap early, inside the old picture, never late into the bar; where the two are further apart than SPARSE and
the second SEARCH_FLOOR ahead of playback the keyframe just before it is read first, as a cut's own keyframe is read in
place of the regular one; nearer playback the two can lie SPARSE and a keyframe gap apart, and it rises up to that
early); into a narrower one the map says nothing between the two (a silent span: the screen grabs
move the text down there, never early into the bar). Every other read is a pending search (Searches): the frames between
two keyframes of different pictures (ffmpeg.Decoder.sequence), where the cut is the first frame of the new picture (into
a narrower one) or the first frame no longer showing the old one (into a wider one), which refines a coarse cut to its
frame or closes a silent span; the keyframes inside a dark run whose cut was found up to its first keyframe (a walk);
the keyframes between two read ones of the same picture where another picture is known (a shot shorter than SPARSE
starting with a keyframe of its own); a carried dark run's frames, for shots of a narrower picture. The sweep reads to
SEARCH_FLOOR ahead first; then the nearest pending search runs where the lead pays for it (a coarse cut whose keyframe
gap passes COARSE_MOST first, and once the film has shown one, the lead kept for the next: Searches), else the sweep
reads on to LEAD. On a laptop's 4K decoding one cut's frames cost about 9 s, and cuts every 3 to 6 s searched before the
next keyframe put the read-ahead behind playback and the text in the bar after half the cuts into scope.

A run of keyframes that show nothing (dark; a weakly lit one of a shape not believed that the next does not confirm is
one too) waits for the keyframe after it: the same picture on both sides carries across where a wrong call can only
leave the text a little high (nothing wider known, or a 0/0 run), its frames searched for shots of a narrower picture
known; different pictures have their cut searched across the run's frames up to DARK_SEARCH apart, the map silent
until then (no coarse cut across a dark run: it could rise far too early); otherwise the stretch ends: the map says
nothing there and the screen grabs decide (holding the old shape over a dark tall scene would be worse: text in a bar
is the worst call, a late move down the lesser one). A run of dark keyframes whose Level 5 is 0/0 is a full picture
only when the keyframe after it shows one (a fade to black says 0/0 too); its cut lies before the run's first keyframe,
so only the frames up to it are decoded and the keyframes inside the run read after (a walk). What it found is a scene
map (scenemap.SceneMap, exact) over the stretches it read, a new one each time it changes: the follower's reader takes
the latest (capture.ScreenReader).

The film is read only while Kodi plays on smoothly (steady.Steady, the playback's one wait), through the playback's one
reader at a time, a batch of reads per open (closed while it waits ahead of playback, so another reader gets its turn),
never while following is off. A read under way stops once Kodi holds, its buffer is low or its time stalls
(Steady.going, asked before every frame); a search stopped short waits to run again (JOB_TRIES), and searches wait
FRAMES_QUIET after a stall or a buffer that fell low (Steady.untroubled), the sweep going on. A seek drops every pending
search and starts a new stretch where playback went, as far ahead of it as a few keyframes cost to read (AHEAD_READS,
measured on its own reads); one back inside what was read keeps the map, and its coarse cuts still ahead are searched
again. A film that changes shape shot by shot fills the map: it then lets go of what lies scenemap.KEPT_BEHIND behind
playback (SceneMap._let_go), and a seek back past that reads there again as after any seek. A reopen of the file that
fails is tried again after a wait (RETRIES, RETRY_WAIT); a failed first open ends the reading. The log says when it
stops and why, and how far ahead of playback it is at each batch.
Every picture is in the video's own shape (non-square pixels). Keyframes far apart (one in many seconds) leave
stretches the screen grabs follow as before.
"""

from .judge import FrameJudge
from .keyindex import MATCH, NUDGE, KeyframeIndex
from .searches import COARSE_MOST, LATE, LEAD, SEARCH_FLOOR, SHOTS_FLOOR, Job, Searches
from .searching import (INSIDE_FRAMES, JOB_TRIES, RATE, READ, SEARCHED, SHOTS_MOST, STOPPED, UNREAD, WALK_MOST, Cut,
                        Searching)
from .sweep import (AHEAD_MOST, AHEAD_READS, DARK_SEARCH, IDLE, PLAYBACK_JUMP, REFILL, RETRIES, RETRY_WAIT, SPARSE,
                    STOP_FLOOR, TOLD_BELOW, TOLD_EVERY, WENT_BACK, DarkRun, Lookahead)
from .trust import TRUST_APART, TRUST_FITS, Trust
