"""Changing a Kodi setting for one playback and always putting it back.

While a value is changed, a small file holds the person's own value. The file
is the only record: it survives a crash or a forced quit, and the service puts
the value back the next time it starts. Without the file nothing is changed.
"""
import json
import os


def write_record(path, data):
    """Writes a record so that a power cut leaves the old one or the new one, never an empty
    file (which would lose the person's value). Raises OSError when it can not be written."""
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    temporary = path + '.new'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def took(write, value):
    """True when Kodi took the value. Raising counts as refused: a record must never claim a value
    that is not there, and a put back that raised is tried again next time."""
    try:
        return bool(write(value))
    except Exception:
        return False


class Record:
    """The file behind one record, shared by Keeper, Switch and override.Override.

    decode(data) turns the file's JSON into the kind's own record, raising ValueError, KeyError,
    TypeError or AttributeError for one it can not use (or returning None)."""

    def __init__(self, path, decode, unreadable=None):
        self.path = path
        self._decode = decode
        self._unreadable = unreadable      # what a file that exists but can not be used counts as

    def load(self):
        """The decoded record, or None without a file."""
        if not os.path.exists(self.path):
            return None
        try:
            with open(self.path, encoding='utf-8') as handle:
                return self._decode(json.load(handle))
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            return self._unreadable

    def change(self, data, write, value, before=None):
        """Records data, then write(value). True when Kodi took it. The record is on disk before
        Kodi is written: without it the change could not be put back after a crash, so nothing is
        changed when it can not be written. When Kodi refuses, the record goes back to before (no
        record when None)."""
        try:
            write_record(self.path, data)
        except OSError:
            return False
        if took(write, value):
            return True
        if before is None:
            self.forget()
        else:
            try:
                write_record(self.path, before)
            except OSError:
                pass        # the new record stays, as a refusal with no disk to undo it leaves it
        return False

    def mark(self, data):
        """Records that ours was put back. When it can not be written the record still says "in
        place", and the next look sees it is not."""
        try:
            write_record(self.path, data)
        except OSError:
            pass

    def forget(self):
        try:
            os.remove(self.path)
        except OSError:
            pass


def still_saved(values, on_disk, same):
    """The values of ours Kodi's settings file may still hold: all of them when on_disk (what
    the file holds) is None, unknown."""
    return [v for v in values if on_disk is None or same(on_disk, v)]


class Keeper:
    """The record stays until neither Kodi's memory nor its settings file holds the add-on's value.

    Kodi writes its settings to disk only at a clean close and from its settings window (seen in
    a real Kodi 21): a value put back during a session is not on disk yet, and Kodi saves before
    add-ons stop, so a crash, or a close during a film, brings the add-on's value back at the next
    start. saved() reads what the settings file holds (None when unknown: the record stays);
    without it, the file is taken to follow memory."""

    def __init__(self, read, write, path, saved=None):
        self._read = read      # () -> current value or None
        self._write = write    # (value) -> True when Kodi accepted it
        self._saved = saved or read
        self._record = Record(path, _decode_number)

    def _load(self):
        """(own, applied, put back already, earlier values of ours that may still be on disk) or None."""
        return self._record.load()

    def _active(self):
        """The record of a change of ours still in place, or None."""
        record = self._load()
        return record if record and not record[2] else None

    def changed(self):
        return self._active() is not None

    def own(self):
        """The person's own value, also while it is changed."""
        return _own(self._load(), self._read())

    def apply(self, value):
        """Set value for this playback. True when the value in Kodi moved: to value, or back to the person's own
        when value is theirs (until 1.4.1 that put back answered False, and the log said "unchanged")."""
        record, current = self._load(), self._read()
        if current is None:
            return False
        own = _own(record, current)
        if abs(value - own) < 0.001:
            return self.restore()
        # Values of ours from before stay on record while Kodi's settings file may hold one of
        # them (found by a long random run in a real Kodi: a close during a film saved one, the
        # next film's value replaced the record, a crash brought the saved one back unrecognised).
        earlier = []
        if record:
            earlier = still_saved([v for v in record[3] + [record[1]] if not _same(v, value)],
                                  self._saved(), _same)
        return self._record.change(_number_data(own, value, False, earlier), self._write, value,
                                   _number_data(*record) if record else None)

    def restore(self):
        """Put the person's value back. Returns True when it was written back."""
        record = self._load()
        if not record:
            return False
        own, applied, put_back, earlier = record
        current = self._read()
        if current is None:
            return False            # kept on record, tried again next time
        ours = [applied] + earlier
        written = False
        if any(_same(current, v) for v in ours):    # ours in place, or back from disk after a crash
            if not took(self._write, own):
                return False        # still ours: kept on record, tried again next time
            written = True
        elif not put_back or not _same(current, own):
            self._record.forget()   # moved by the person while ours was in place: theirs
            return False
        left = still_saved(ours, self._saved(), _same)
        if left:                    # Kodi starts with one of ours next time unless it saves again
            marked = _number_data(own, applied, True, [v for v in left if not _same(v, applied)])
            if marked != _number_data(*record):     # written only when it says something new, as Switch does
                self._record.mark(marked)
        else:
            self._record.forget()   # neither in memory nor on disk any more: done
        return written


def _decode_number(data):
    earlier = [float(v) for v in data.get('earlier', [])]
    return float(data['own']), float(data['applied']), bool(data.get('put_back', False)), earlier


def _number_data(own, applied, put_back=False, earlier=()):
    return {'own': own, 'applied': applied, 'put_back': put_back, 'earlier': list(earlier)}


def _same(a, b):
    return abs(a - b) < 0.001


def _own(record, current):
    """The person's value: the recorded one while one of ours is in place (or nothing can be
    read), else what is there now, since the person moved it meanwhile."""
    if record and (current is None or any(_same(current, v) for v in [record[1]] + record[3]) or
                   (record[2] and _same(current, record[0]))):
        return record[0]
    return current


class Switch:
    """Turning a switch setting on for one playback, and off again only when it was off before
    (or, with value False, off and on again: "on" below then means the add-on's value).

    Its record is kept, as Keeper's, until the switch is off in memory and on disk, but holds no
    values: {'switched_on': True, 'put_back': ...} plus a stamp once put back. A switch that was
    already on is not ours. Found on again after the add-on switched it off: the person's choice
    if Kodi has saved its settings since (they did it in its settings window), else ours coming
    back from disk after a crash or a close during a film. stamp() says when Kodi last wrote its
    settings file (None when unknown: taken as the person's). A record file that can not be read
    counts as ours, in place.
    """

    def __init__(self, read, write, path, saved=None, stamp=None, value=True):
        self._value, self._other = value, not value
        self._read = read      # () -> True, False, or None when it can not be read
        self._write = write    # (value) -> True when Kodi accepted it
        self._saved = saved or read
        self._stamp = stamp or (lambda: None)
        self._record = Record(path, lambda data: data if isinstance(data, dict) else {}, unreadable={})

    def on(self):
        """Switched on for this playback (or on already). False when it could not be."""
        now = self._read()
        if now is self._value:
            return True
        if now is not self._other:
            return False
        # A record from before (put back, ours possibly still on disk) is kept when Kodi refuses.
        return self._record.change({'switched_on': True, 'put_back': False}, self._write, self._value,
                                   self._record.load())

    def restore(self):
        """Switch it off again if the add-on switched it on. True when it was switched off."""
        record = self._record.load()
        if record is None:
            return False
        put_back, stamp = bool(record.get('put_back')), record.get('stamp')
        now = self._read()
        if now is None and put_back:
            return False            # kept on record, looked at again next time
        written = False
        if now is not self._other:  # on, or unreadable: switched off all the same
            if now is self._value and put_back and (stamp is None or self._stamp() != stamp):
                self._record.forget()   # on again since we switched it off, and saved: the person's
                return False
            if not took(self._write, self._other):
                return False        # still on: kept on record, tried again next time
            written = True
        elif not put_back:
            self._record.forget()   # switched off by the person while ours was on
            return False
        if self._saved() is self._other:
            self._record.forget()   # off in memory and on disk: done
        elif not put_back or written:
            self._record.mark({'switched_on': True, 'put_back': True, 'stamp': self._stamp()})
        return written
