"""The read-ahead's trust in the film's Level 5 (Trust): whether it may place a keyframe that shows nothing believed."""

from .. import detect, pictures

TRUST_FITS = 5        # strongly lit clear keyframes of different shots whose Level 5 fits their picture before Level 5
                      # places a dark one (the corpus: one film whose Level 5 says a taller picture on a third of its
                      # shots fits 3 shots before its first misfit; 408 of the 416 films whose Level 5 fits every
                      # keyframe the measurement reads are trusted from those alone at 5)
TRUST_APART = 30.0    # seconds of film between two keyframes whose fits both count (keyframes 2 s apart are one shot)


class Trust:
    """The read-ahead's trust in the film's Level 5: whether it may place a keyframe that shows nothing believed.
    Trusted once TRUST_FITS strongly lit clear keyframes of different shots (TRUST_APART apart) had Level 5 that fits
    their picture, the measurement's and the read-ahead's, and none that does not: one that does not and Level 5 places
    nothing more. A dim keyframe is no evidence either way (its edge can read wide). The trust goes to the cache as it
    grows (kept), and a cached playback starts from it: it decodes none of the measurement's keyframes."""

    def __init__(self, video_ratio, log, kept=None, cached=None):
        """log(line): the add-on's log; kept(data): the cache keeps the trust (a fit counted towards TRUST_FITS, a
        refusal); cached: the trust an earlier playback came to (data()), or None."""
        self._video_ratio, self._log = video_ratio, log
        self._kept = kept or (lambda trust: None)
        self._fits = 0                  # strongly lit keyframes whose Level 5 fits their picture; None once one did not
        self._fit_times = []            # the film times of the keyframes counted in _fits (TRUST_APART apart)
        if cached is not None:
            if cached.get('refused'):
                self._fits = None
            else:
                self._fit_times = sorted(cached.get('fits', ()))
                self._fits = len(self._fit_times)

    def learn(self, keyframes):
        """The measurement's keyframes, each judged: one write to the cache after them, where anything changed."""
        kept, self._kept = self._kept, lambda trust: None
        before = (self._fits, len(self._fit_times))
        for keyframe in keyframes:
            self.judge(keyframe)
        self._kept = kept
        if (self._fits, len(self._fit_times)) != before:
            kept(self.data())

    def judge(self, keyframe):
        """A keyframe's Level 5 held against its own clear picture (follow.trust's rule, one keyframe at a time), where
        strongly lit: a dim one's edge can read wide (a dark scope keyframe read 2.20), so it neither counts nor ends
        the trust. A fit counts only TRUST_APART from every one counted before (another shot)."""
        if (self._fits is None or keyframe.level5_pair is None or not keyframe.judgeable
                or not keyframe.sample.strong):
            return
        if keyframe.level5_pair == (0, 0) and pictures.same(detect.shape(keyframe.sample, self._video_ratio),
                                                            self._video_ratio):
            return      # a full frame fits 0/0 whatever Level 5 knows (a file without Level 5 says 0/0 throughout)
        if keyframe.side_bars or not keyframe.fits(keyframe.level5_pair)[0]:
            self._fits = None
            self._log('scenes ahead: Level 5 %d/%d does not fit a keyframe\'s picture, not used' % keyframe.level5_pair)
            self._kept(self.data())
        elif keyframe.at is None or all(abs(keyframe.at - at) >= TRUST_APART for at in self._fit_times):
            # A shot's keyframes fit together or not at all: one counts per shot (three keyframes 2 s apart
            # would earn trust, and in four corpus films Level 5 that fits nearly everywhere says a taller picture than
            # shown on a few shots).
            self._fits += 1
            if keyframe.at is not None:
                self._fit_times.append(keyframe.at)
                if len(self._fit_times) <= TRUST_FITS:
                    self._kept(self.data())
            if self._fits == TRUST_FITS:
                self._log('scenes ahead: Level 5 trusted (%d keyframes %d s apart fit their picture)' % (
                    TRUST_FITS, TRUST_APART))

    def trusted(self):
        return self._fits is not None and self._fits >= TRUST_FITS

    def data(self):
        """The trust so far, as the cache keeps it: {'fits': the film times of the fits counted, 'refused': True once a
        keyframe's picture did not fit}."""
        return {'fits': [] if self._fits is None else list(self._fit_times), 'refused': self._fits is None}

    def note(self):
        """The trust for the log."""
        if self._fits is None:
            return 'Level 5 refused (a keyframe it does not fit)'
        return 'Level 5 %s (%d of %d fits)' % ('trusted' if self.trusted() else 'not trusted yet', self._fits,
                                                TRUST_FITS)
