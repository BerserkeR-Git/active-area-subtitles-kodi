"""Every setting the add-on changes in Kodi and CoreELEC, each kept with a record so it goes back: what
goes back, in which order, and when (a stop, a crash, the add-on switched off, the next video).

Two kinds of method. Those that take the lock themselves are right whether or not a playback is running
(putting things back). Those marked "with the lock held" belong to a playback: the caller holds the lock
and has checked that its playback is still the current one, so nothing is written for a playback that
ended in between. This module knows nothing about playbacks.
"""
import functools
import threading

from . import coreelec, geometry, kodi, kodi_session, override
from .keeper import Held, Keeper

MARGIN_SETTING = 'subtitles.marginvertical'
POSITION_SETTING = 'subtitles.align'


class Restores:

    # Settings of Kodi's own on every platform that the add-on changes: a save asked after letting go is looked for in
    # the settings file by them (kodi.save_settings).
    SAVED = (MARGIN_SETTING, POSITION_SETTING)

    def __init__(self, enabled, scan_hidden=None):
        """enabled(): whether the add-on is switched on in its settings (Service.enabled). scan_hidden(kept): see
        Detection."""
        self.lock = threading.Lock()
        # Each change keeps a record until Kodi's memory and its settings file are free of it; Kodi's session tells
        # a value of ours set again by the person (the same session) from ours back from disk (Kodi started again).
        # Whether an earlier service of this Kodi made the session: a film playing at the start is its film only then.
        self.session_known = kodi_session.session_known()
        kodi_session.session()  # made here, before any thread asks for it
        kodi.saved_as_asked()   # the save the last let go asked for, looked for in Kodi's settings file
        self.override = override.Override(lambda: kodi.get_setting(override.SETTING),
                                           lambda value: kodi.set_setting(override.SETTING, value),
                                           kodi.data_path('level5.json'),
                                           lambda: kodi.saved_setting(override.SETTING), kodi_session.session)
        # Kodi's subtitle margin for text subtitles, with its position held at Manual on a PC (TextMargin).
        self.margin = TextMargin()
        # CoreELEC's "Apply configured subtitle margin": never switched on by the add-on; one an older version left on
        # (it handed CoreELEC a distance) and 1.6.x took over is switched off at the next video, at stop and at start.
        self.margin_switch = held(coreelec.MARGIN_SETTING, 'margin_option.json', (), quiet=False)
        # P3i's restriction: held off for text subtitles, on for an image subtitle (Restriction).
        self.restriction = Restriction(enabled)
        self.detection = Detection(scan_hidden)
        # Image subtitles on P3i builds: P3i's "Bitmap subtitle margin" for the distance chosen. It goes
        # back when a text subtitle shows, when playback ends, and after a crash.
        self.bitmap = Keeper(lambda: kodi.number(kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True)),
                             lambda value: kodi.set_setting(coreelec.BITMAP_MARGIN_SETTING, value),
                             kodi.data_path('bitmap_margin.json'),
                             lambda: kodi.number(kodi.saved_setting(coreelec.BITMAP_MARGIN_SETTING)),
                             kodi_session.session)
        # Every record of ours, once, in the one order they go back, with the moments each goes back at ('repair' at
        # the start after an unfinished playback, 'finish' at a playback's end, 'release' when the add-on lets go of
        # everything, 'next' at a playlist's next video and 'next on the box' with it on a box), its put back and what
        # the log says (None: the put back names what it put back itself). The put backs and the look every 30 s are
        # both read from here, so neither can miss a record. The margin option first, so nothing moves in between. A
        # playback's end leaves the restriction and CoreELEC's detection to the hold that follows it; the start lets go
        # only of an "on" of ours the unfinished playback left (the hold after the start sets the rest). The next video
        # keeps the previous one's margin on a PC (its placing writes its own) but not on a box: P3i shows no Level 5
        # at a film's end, the follower placed the full frame then, and a Next with no stop carried that margin into
        # the next film until its first placement. Kodi hides the margin option while the restriction is off, and
        # refuses to read or write it then, so at a release the option is let go once more after the restriction is
        # back: held off for text subtitles, the restriction hid it at the first try.
        every, release = ('repair', 'finish', 'release'), ('release',)
        option_off = (lambda: self.margin_switch.let_go(True), 'CoreELEC\'s subtitle margin option switched off')
        self._records = [
            (self.margin_switch, [(every + ('next',),) + option_off]),
            (self.margin, [(every + ('next on the box',), self.margin.put_back, None)]),
            (self.override, [(every + ('next',), self.override.restore, 'Level 5 correction cleared')]),
            (self.bitmap, [(every, self.bitmap.restore, 'CoreELEC\'s bitmap subtitle margin put back')]),
            (self.restriction, [(('repair',), self.restriction.repair,
                                 'CoreELEC\'s subtitle restriction switched off again'),
                                (release, self.restriction.own, 'CoreELEC\'s subtitle restriction back as it was'),
                                (release,) + option_off]),
            (self.detection, [(release, put_back, 'CoreELEC\'s %s back as it was' % name)
                              for name, put_back in self.detection.put_backs()])]

    def _put_backs(self, *which):
        """[(put back, what the log says)] of every record of ours the moments which let go, in the registry's order."""
        return [(put_back, what) for _record, rows in self._records for chosen, put_back, what in rows
                if any(moment in chosen for moment in which)]

    def _put_back(self, put_back, what):
        """The lines to log for one put back: none when nothing went back."""
        done = put_back()
        if what is None:
            return list(done)
        return [what] if done else []

    # Taking the lock: right whether or not a playback runs.

    def repair(self):
        """What an unfinished playback left (Kodi crashed or was cut off) is put back."""
        with self.lock, kodi.read_once():
            for put_back, what in self._put_backs('repair'):
                for line in self._put_back(put_back, what):
                    kodi.log('%s after an unfinished playback' % line, always=True)

    def finish(self, why, ended, always=False):
        """A playback's changes back, at its end. ended(): run first under the same lock (the playback marked
        as ended, so nothing of it is written after these); False when that playback was over already: nothing."""
        with self.lock:
            if ended() is False:
                return
            self._let_go(('finish',), why, always)

    def release_all(self, why, always=False):
        """Every setting of ours back as the person had it, in one order: the add-on switched off in its settings,
        or removed. Nothing of the person's is touched while switched off."""
        with self.lock:
            self._let_go(('release',), why, always)

    def _let_go(self, which, why, always):
        with kodi.read_once():
            for put_back, what in self._put_backs(*which):
                for line in self._put_back(put_back, what):
                    kodi.log('%s: %s' % (why, line), always)

    def settle(self, idle=lambda: False):
        """Every record already put back looked at again (Service, every SETTLE_STEP): one of our values the person set
        again since the put back is theirs from now on, which only a look inside the same Kodi session can tell (after
        a crash or a close their value and ours back from disk look the same). Nothing held now is touched. idle(),
        asked under the lock: no playback runs, so what a film's end puts back is tried again first (one Kodi refused
        then would stay ours until the next film ended); the holds between films stay."""
        with self.lock, kodi.read_once():
            if idle():
                for put_back, what in self._put_backs('finish'):
                    for line in self._put_back(put_back, what):
                        kodi.log('between films: %s' % line, always=True)
            for record, _rows in self._records:
                record.settle()

    def text_position(self):
        """The person's own subtitle position, also while Manual is held (TextMargin.own_position), read under the
        lock as every look at a record (one may be forgotten on the way, while the look every 30 s marks it)."""
        with self.lock:
            return self.margin.own_position()

    def own_restriction(self):
        """Whether the person's own P3i restriction is on (Restriction.own_on), read under the lock."""
        with self.lock:
            return self.restriction.own_on()

    def hold(self):
        """P3i's restriction held off (Restriction.off). True when the person's own "on" was switched off just now."""
        with self.lock:
            return self.restriction.off()

    def hold_detection(self, images_moved, level5_fixed):
        """P3i's detection between films (see Detection.hold)."""
        with self.lock:
            for change in self.detection.hold(images_moved, level5_fixed):
                kodi.log('CoreELEC\'s %s' % change, always=True)

    def distances_none(self):
        """Both distances set to none: CoreELEC goes back to the picture's edge at once."""
        with self.lock:
            if self.margin_switch.let_go(True):
                kodi.log('distances set to none: CoreELEC\'s subtitle margin option switched off')

    def stale_correction(self, ours):
        """A Level 5 correction that is not the playing film's (ours(), asked under the lock: this playback applied it)
        cleared: one Kodi kept while CoreELEC's Level 5 handling was off (its override hidden then)."""
        with self.lock:
            if not ours() and self.override.restore():
                kodi.log('Level 5 correction of an earlier video cleared', always=True)

    def fix_off(self):
        """Level 5 correction turned off: does nothing unless a correction is in place."""
        with self.lock:
            if self.override.restore():
                kodi.log('Level 5 correction turned off: cleared')

    # With the lock held, by a playback that is still the current one.

    def next_video(self, margin=False):
        """A playlist's next video: the previous one's Level 5 correction goes, and CoreELEC's margin option an older
        version left on (it handed CoreELEC a distance; the add-on never switches it on). margin (a box): the person's
        margin back too, as after a stop (the 'next on the box' rows of the registry)."""
        self._let_go(('next', 'next on the box') if margin else ('next',), 'next video', False)

    def for_subtitle(self, steps):
        """P3i's settings for the subtitle shown, p3i.plan's steps in their order: the restriction held off or on, or
        the person's own (the hold after the playback takes it off again); the bitmap margin the person's, or P3i's for
        a distance from the picture's edge. {setting: its step's answer}: for the restriction whether it moved; for the
        bitmap margin the one set (None on a CoreELEC without one: kept inside the picture all the same; False when
        CoreELEC did not take it, tried again at the next placing), or whether the person's went back. Not offered (an
        older build, or hidden) or switched off: nothing switched."""
        done = {}
        for setting, value, said in steps:
            if setting == 'restriction':
                changed = {'off': self.restriction.off, 'on': self.restriction.on, 'own': self.restriction.own}[value]()
            elif value == 'own':
                changed = self.bitmap.restore()
            elif kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True) is None:
                changed = None
            else:
                changed = geometry.bitmap_margin(value)
                self.bitmap.apply(changed)
                # Read back: apply's answer is False also when the value was in place already.
                held = kodi.number(kodi.get_setting(coreelec.BITMAP_MARGIN_SETTING, quiet=True))
                if held is None or abs(held - changed) >= 0.001:
                    kodi.log('bitmap subtitle margin %.1f not taken by CoreELEC' % changed, always=True)
                    changed = False
            if changed and said:
                kodi.log(said)
            done[setting] = changed
        return done


class TextMargin:
    """Kodi's subtitle margin for text subtitles, and on a PC its subtitle position held at Manual with it, each on a
    record of its own (margin.json, position.json): own() the person's margin, own_position() their position also
    while Manual is held, apply(value, keep, manual) the add-on's, restore() the person's both. The margin is always
    written first: on Kodi's other positions a new margin leaves a line on screen where it is, so the position written
    after it lays the line out once, where it belongs (on the way to Manual and back)."""

    def __init__(self):
        self._margin = Keeper(lambda: kodi.number(kodi.get_setting(MARGIN_SETTING)),
                              lambda value: kodi.set_setting(MARGIN_SETTING, value),
                              kodi.data_path('margin.json'),
                              lambda: kodi.number(kodi.saved_setting(MARGIN_SETTING)), kodi_session.session)
        self._position = Keeper(lambda: kodi.number(kodi.get_setting(POSITION_SETTING)),
                                lambda value: kodi.set_setting(POSITION_SETTING, int(round(value))),
                                kodi.data_path('position.json'),
                                lambda: kodi.number(kodi.saved_setting(POSITION_SETTING)), kodi_session.session)

    def own(self):
        return self._margin.own()

    def own_position(self):
        return self._position.own()

    def changed(self):
        """Whether a margin or a position of the add-on's is in place, on record (the histories' oracles ask)."""
        return self._margin.changed() or self._position.changed()

    def apply(self, value, keep=(), manual=False):
        """The margin value for this playback (Keeper.apply, keep its other values), the position Manual with it when
        manual, else the person's own. True when either moved. Once Manual is held nothing more is read or written for
        the position (a followed film writes a margin at every cut): a position the person sets during the film is
        taken() up by the watch, never written over here. Manual goes on only over the margin it was worked out for: a
        refused margin write leaves the person's own margin and position together."""
        moved = self._margin.apply(value, keep)
        if not manual:
            return self._position.restore() or moved
        if self._position.changed():
            return moved
        now = kodi.number(kodi.get_setting(MARGIN_SETTING))
        if now is None or abs(now - value) > 0.001:
            return moved
        if self._position.apply(geometry.ALIGN_MANUAL):
            return True
        if not self.manual_shown():     # Kodi refused Manual: the margin worked out for it goes back with it
            return self._margin.restore() or moved
        return moved

    def holds(self, value):
        """Whether Kodi's margin is value now (False when Kodi does not say): a write the scene follower can count on."""
        now = kodi.number(kodi.get_setting(MARGIN_SETTING, quiet=True))
        return now is not None and value is not None and abs(now - value) < 0.001

    def manual_shown(self):
        """Whether Kodi's position is Manual now: held by the add-on, or the person's own. With the lock held."""
        if self._position.changed():
            return True
        now = self._position.own()
        return now is not None and abs(now - geometry.ALIGN_MANUAL) < 0.001

    def taken(self):
        """True when the person set Kodi's subtitle position themselves while the add-on held Manual (in Kodi's
        on-screen settings during the film): the record goes, nothing is written, and their position is theirs from
        now on (the playback places again with it). With the lock held, by the playback."""
        if not self._position.changed():
            return False
        now = kodi.number(kodi.get_setting(POSITION_SETTING, quiet=True))
        if now is None or abs(now - geometry.ALIGN_MANUAL) < 0.001:
            return False
        self._position.restore()        # moved by the person while ours was in place: forgets the record
        return True

    def restore(self):
        """The person's margin and position back, the margin first. True when either was written back."""
        return bool(self.put_back())

    def put_back(self):
        """restore(), naming for the log what went back. A margin Kodi refuses keeps Manual with it (tried again
        together), as apply puts Manual on only over the margin it was worked out for."""
        lines = ['own subtitle margin put back'] if self._margin.restore() else []
        if self._margin.changed():
            return lines
        return lines + (['own subtitle position put back'] if self._position.restore() else [])

    def settle(self):
        self._margin.settle()
        self._position.settle()


class Restriction:
    """P3i's "Restrict subtitles to active picture", held both ways on one record (restrict.json). Held off (the
    person's own "on" switched off) while the add-on is enabled, so the add-on places every text subtitle itself;
    held on while an image subtitle shows when the person keeps it off. Each hold lets go of the other first.
    Switched off in the add-on's settings, nothing is held; own() gives the person's value back for good."""

    def __init__(self, enabled):
        self._enabled = enabled
        self._held = held(coreelec.RESTRICT_SETTING, 'restrict.json', (False, True))

    def off(self):
        """Off, for text subtitles and between films. True when the person's own "on" was switched off just now."""
        return self._enabled() and self._held.hold(False)

    def on(self):
        """On, for an image subtitle: the person's own "on" back, or ours when they keep it off. True when ours
        was switched on just now. Not offered (an older build, or hidden): nothing to switch."""
        return self._enabled() and self._held.hold(True)

    def own(self):
        """The person's own value back. True when a held-off "on" came back."""
        self._held.let_go(True)
        return self._held.let_go(False)

    def own_on(self):
        """Whether the person's own value is "on": held off by the add-on, or on now and not held on by it."""
        if self._held.holds(False):
            return True
        return kodi.get_setting(coreelec.RESTRICT_SETTING, quiet=True) is True and not self._held.holds(True)

    def repair(self):
        """At start: an "on" of ours left by an unfinished playback goes off (the hold that follows sets the rest)."""
        return self._held.let_go(True)

    def settle(self):
        self._held.settle()


class Detection:
    """P3i scans only where it must (builds from 5555). The add-on measures every film and places text subtitles
    itself; P3i's own scan is needed only for image subtitles of SDR and HDR10 films (the Level 5 override applies to
    Dolby Vision only, tested on the box). So, while the add-on is on: the subtitle scan on while an image distance
    is chosen and off otherwise; the Dolby Vision scan off while the add-on corrects Level 5 itself (its override wins
    anyway, and P3i's scan can not follow IMAX's changing Level 5); the start pause and the I/O throttle off. P3i reads
    them when a film starts, so they are set between films, never at a track switch. Each with a record, put back when
    the add-on lets go. A build without them is left alone (Held reads None and writes nothing)."""

    def __init__(self, scan_hidden=None):
        # Told after each let go of the Dolby Vision scan held off: kept, CoreELEC hides the scan now (Level 5 handling
        # off, or another DV type), Kodi refuses to write a hidden setting, and ours stays on record for the next try.
        self._scan_hidden = scan_hidden or (lambda kept: None)
        self._pause = held(coreelec.WAIT_SETTING, 'detect_pause.json', (False,))
        self._throttle = held(coreelec.THROTTLE_SETTING, 'detect_throttle.json', (False,))
        # The subtitle scan both ways on one record, so the person's own value is the one that comes back.
        self._scan = held(coreelec.SDR_SCAN_SETTING, 'detect_scan.json', (False, True))
        self._dv = held(coreelec.DV_SCAN_SETTING, 'detect_dv.json', (False,))

    def hold(self, images_moved, level5_fixed):
        """The settings for the next film. What changed, for the log."""
        changed = []

        def held_at(name, setting, value, word):
            back, switched = setting.switch(value)      # the other value let go first (the subtitle scan's)
            if back:
                changed.append('%s back as it was' % name)
            if switched:
                changed.append('%s switched %s' % (name, word))
        held_at('pause for detection', self._pause, False, 'off')
        held_at('detection I/O throttle', self._throttle, False, 'off')
        if images_moved:
            held_at('picture detection', self._scan, True, 'on (image subtitles are moved)')
        else:
            held_at('picture detection', self._scan, False, 'off (image subtitles as on the disc)')
        if level5_fixed:
            held_at('Dolby Vision picture detection', self._dv, False, 'off (the add-on corrects Level 5)')
        elif self._let_go_of_dv():
            changed.append('Dolby Vision picture detection back as it was')
        return changed

    def _let_go_of_dv(self):
        """The Dolby Vision scan's let go (the person's "on" back). True when it was written back."""
        held = self._dv.holds(False)
        back = self._dv.let_go(False)
        if held:
            self._scan_hidden(not back and self._dv.holds(False)
                              and kodi.get_setting(coreelec.DV_SCAN_SETTING, quiet=True) is None)
        return back

    def settle(self):
        for setting in (self._pause, self._throttle, self._scan, self._dv):
            setting.settle()

    def put_backs(self):
        """[(name, put back)] of every record of ours, in the order they go back (Restores._put_backs)."""
        return [(name, functools.partial(setting.let_go, value)) for name, setting, value in (
            ('pause for detection', self._pause, False), ('detection I/O throttle', self._throttle, False),
            ('picture detection', self._scan, True), ('picture detection', self._scan, False))] + [
            ('Dolby Vision picture detection', self._let_go_of_dv)]


def held(setting, record, holds, quiet=True):
    """A Held for one of CoreELEC's switch settings, its record in the add-on's folder (holds: the values the add-on
    holds it at now, all a record that can not be read may stand for)."""
    return Held(lambda: kodi.get_setting(setting, quiet=quiet), lambda value: kodi.set_setting(setting, value),
                kodi.data_path(record), lambda: switch_value(kodi.saved_setting(setting)), kodi_session.session,
                holds, lambda text: kodi.log(text, always=True))


def switch_value(text):
    """A switch setting's value as Kodi's settings file writes it: True, False or None."""
    return {'true': True, 'false': False}.get(text)
